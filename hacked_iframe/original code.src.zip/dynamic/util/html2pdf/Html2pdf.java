/*      */ package dynamic.util.html2pdf;
/*      */ 
/*      */ import com.lowagie.text.BadElementException;
/*      */ import com.lowagie.text.Cell;
/*      */ import com.lowagie.text.Document;
/*      */ import com.lowagie.text.DocumentException;
/*      */ import com.lowagie.text.Font;
/*      */ import com.lowagie.text.Gif;
/*      */ import com.lowagie.text.HeaderFooter;
/*      */ import com.lowagie.text.Image;
/*      */ import com.lowagie.text.Jpeg;
/*      */ import com.lowagie.text.PageSize;
/*      */ import com.lowagie.text.Paragraph;
/*      */ import com.lowagie.text.Phrase;
/*      */ import com.lowagie.text.Png;
/*      */ import com.lowagie.text.Rectangle;
/*      */ import com.lowagie.text.Table;
/*      */ import com.lowagie.text.Watermark;
/*      */ import com.lowagie.text.pdf.PdfWriter;
/*      */ import com.quiotix.html.parser.HtmlCollector;
/*      */ import com.quiotix.html.parser.HtmlDocument;
/*      */ import com.quiotix.html.parser.HtmlDocument.Annotation;
/*      */ import com.quiotix.html.parser.HtmlDocument.Attribute;
/*      */ import com.quiotix.html.parser.HtmlDocument.AttributeList;
/*      */ import com.quiotix.html.parser.HtmlDocument.Comment;
/*      */ import com.quiotix.html.parser.HtmlDocument.EndTag;
/*      */ import com.quiotix.html.parser.HtmlDocument.Newline;
/*      */ import com.quiotix.html.parser.HtmlDocument.Tag;
/*      */ import com.quiotix.html.parser.HtmlDocument.TagBlock;
/*      */ import com.quiotix.html.parser.HtmlDocument.Text;
/*      */ import com.quiotix.html.parser.HtmlParser;
/*      */ import com.quiotix.html.parser.HtmlScrubber;
/*      */ import com.quiotix.html.parser.HtmlVisitor;
/*      */ import dynamic.intraframe.engine.InvocationContext;
/*      */ import dynamic.intraframe.handlers.ErrorHandler;
/*      */ import java.awt.Color;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringReader;
/*      */ import java.net.MalformedURLException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.ServletResponse;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ 
/*      */ public class Html2pdf extends HtmlVisitor
/*      */ {
/*      */   private boolean table_header;
/*      */   private ByteArrayOutputStream baos;
/*      */   private int DEFAULT_FONT_FAMILY;
/*      */   private InvocationContext ic;
/*      */   private String imgDir;
/*      */   protected boolean CellWidth;
/*      */   protected boolean inCaculation;
/*      */   protected boolean inParagraph;
/*      */   protected boolean inTable;
/*      */   protected boolean inTitle;
/*      */   protected Document doc;
/*      */   protected FontStyle font;
/*      */   protected Html2PdfTable table;
/*      */   protected int inList;
/*      */   protected int ParaPosition;
/*      */   protected Phrase StrPara;
/*      */   protected PrintWriter out;
/*      */   protected Vector cellStack;
/*      */   protected Vector ListStack;
/*  119 */   public String author = "";
/*  120 */   public String subject = "";
/*      */   private static final int DEFAULT_FONT_SIZE = 10;
/*      */   protected static Hashtable tagsFontControl;
/*      */   protected static Hashtable tagsFormatControl;
/*      */   protected static Hashtable TableControl;
/*      */   protected static Hashtable tagsMiscellaneityControl;
/*      */   protected static Hashtable ColorDistribution;
/*  129 */   protected static final String[] tagsFontStrings = { "B", "I", "FONT", "U" };
/*      */ 
/*  132 */   protected static final String[] tagsFormatStrings = { "BR", "DIV", "P", "OL", "UL", "LI", "H1", "H2", "H3", "H4", "H5", "H6" };
/*      */ 
/*  136 */   protected static final String[] TableStrings = { "TABLE", "TR", "TH", "TD" };
/*      */ 
/*  139 */   protected static final String[] tagsMiscellaneityStrings = { "TITLE", "IMG", "HR", "SCRIPT", "PAGEBREAK" };
/*      */ 
/*  142 */   protected static final String[] ColorDistributionStrings = { "BLACK", "BLUE", "AQUA", "GREEN", "GRAY", "SILVER", "FUCHSIA", "WHITE", "YELLOW", "RED" };
/*      */ 
/*      */   public Html2pdf()
/*      */     throws Exception
/*      */   {
/*  148 */     init();
/*  149 */     this.table = new Html2PdfTable();
/*  150 */     this.inTitle = false;
/*  151 */     this.inTable = false;
/*  152 */     this.inCaculation = false;
/*  153 */     this.CellWidth = false;
/*  154 */     this.cellStack = new Vector();
/*  155 */     this.ListStack = new Vector();
/*  156 */     this.inList = 0;
/*  157 */     this.StrPara = new Phrase();
/*  158 */     this.inParagraph = false;
/*  159 */     this.ParaPosition = 0;
/*  160 */     this.DEFAULT_FONT_FAMILY = 2;
/*  161 */     this.imgDir = "";
/*      */   }
/*      */ 
/*      */   public Html2pdf(InvocationContext ic, Request request) throws Exception
/*      */   {
/*  166 */     init();
/*  167 */     this.ic = ic;
/*  168 */     this.table = new Html2PdfTable();
/*  169 */     this.inTitle = false;
/*  170 */     this.inTable = false;
/*  171 */     this.inCaculation = false;
/*  172 */     this.CellWidth = false;
/*  173 */     this.cellStack = new Vector();
/*  174 */     this.ListStack = new Vector();
/*  175 */     this.inList = 0;
/*  176 */     this.StrPara = new Phrase();
/*  177 */     this.inParagraph = false;
/*  178 */     this.ParaPosition = 0;
/*  179 */     this.DEFAULT_FONT_FAMILY = 2;
/*  180 */     this.imgDir = "";
/*  181 */     checkAttributes(request);
/*      */   }
/*      */ 
/*      */   private void checkAttributes(Request request) throws Exception
/*      */   {
/*  186 */     if (request.attributeExists("AUTHOR"))
/*  187 */       this.author = request.getAttribute("AUTHOR");
/*  188 */     if (request.attributeExists("SUBJECT")) {
/*  189 */       this.subject = request.getAttribute("SUBJECT");
/*      */     }
/*  191 */     if (request.attributeExists("FONT_FAMILY"))
/*  192 */       this.DEFAULT_FONT_FAMILY = getFontFamily(request.getAttribute("FONT_FAMILY"));
/*  193 */     this.font = new FontStyle();
/*      */     Rectangle rectangle;
/*  195 */     if (request.attributeExists("PAGESIZE"))
/*  196 */       rectangle = new Rectangle(getPageSize(request));
/*      */     else
/*  198 */       rectangle = new Rectangle(PageSize.LETTER);
/*  199 */     if ((request.attributeExists("LANDSCAPE")) && (request.getAttribute("LANDSCAPE").equalsIgnoreCase("true")))
/*  200 */       this.doc = new Document(rectangle.rotate(), 50, 50, 50, 50);
/*      */     else {
/*  202 */       this.doc = new Document(rectangle, 50, 50, 50, 50);
/*      */     }
/*  204 */     if (request.attributeExists("OUTPUTFILE"))
/*      */     {
/*  206 */       String s = request.getAttribute("OUTPUTFILE");
/*  207 */       PdfWriter.getInstance(this.doc, new FileOutputStream(s));
/*      */     }
/*      */     else
/*      */     {
/*  211 */       this.baos = new ByteArrayOutputStream();
/*  212 */       PdfWriter.getInstance(this.doc, this.baos);
/*      */     }
/*      */     String s1;
/*  215 */     if (request.attributeExists("IMAGESDIR"))
/*  216 */       s1 = request.getAttribute("IMAGESDIR");
/*      */     else
/*  218 */       s1 = "";
/*  219 */     if (request.attributeExists("TABLE_HEADER"))
/*  220 */       this.table_header = Boolean.valueOf(request.getAttribute("TABLE_HEADER")).booleanValue();
/*      */     else
/*  222 */       this.table_header = true;
/*      */     String s2;
/*  224 */     if (request.attributeExists("HEADER"))
/*  225 */       s2 = request.getAttribute("HEADER");
/*      */     else
/*  227 */       s2 = "no header";
/*      */     String s3;
/*  229 */     if (request.attributeExists("FOOTER"))
/*  230 */       s3 = request.getAttribute("FOOTER");
/*      */     else
/*  232 */       s3 = "no footer";
/*      */     int k;
/*  234 */     if (request.attributeExists("HD_SIZE"))
/*  235 */       k = Integer.parseInt(request.getAttribute("HD_SIZE"));
/*      */     else
/*  237 */       k = 8;
/*      */     int l;
/*  239 */     if (request.attributeExists("FT_SIZE"))
/*  240 */       l = Integer.parseInt(request.getAttribute("FT_SIZE"));
/*      */     else
/*  242 */       l = 8;
/*      */     int i1;
/*  244 */     if (request.attributeExists("HD_STYLE"))
/*  245 */       i1 = getStyle(request.getAttribute("HD_STYLE"));
/*      */     else
/*  247 */       i1 = 0;
/*      */     int j1;
/*  249 */     if (request.attributeExists("FT_STYLE"))
/*  250 */       j1 = getStyle(request.getAttribute("FT_STYLE"));
/*      */     else
/*  252 */       j1 = 0;
/*      */     Color color;
/*  254 */     if (request.attributeExists("HD_COLOR"))
/*  255 */       color = getColor(stripQuote(request.getAttribute("HD_COLOR")));
/*      */     else
/*  257 */       color = getColor("black");
/*      */     Color color1;
/*  259 */     if (request.attributeExists("FT_COLOR"))
/*  260 */       color1 = getColor(stripQuote(request.getAttribute("FT_COLOR")));
/*      */     else
/*  262 */       color1 = getColor("black");
/*      */     int k1;
/*  264 */     if (request.attributeExists("HD_ALIGNMENT"))
/*  265 */       k1 = getAlignment(stripQuote(request.getAttribute("HD_ALIGNMENT")));
/*      */     else
/*  267 */       k1 = 2;
/*      */     int l1;
/*  269 */     if (request.attributeExists("FT_ALIGNMENT"))
/*  270 */       l1 = getAlignment(stripQuote(request.getAttribute("FT_ALIGNMENT")));
/*      */     else
/*  272 */       l1 = 1;
/*  273 */     setheadfoot(s2, s3, k, l, i1, j1, color, color1, k1, l1);
/*  274 */     if (request.attributeExists("WATERMARK_NAME"))
/*      */     {
/*      */       int i;
/*  277 */       if (request.attributeExists("WM_WIDTH"))
/*  278 */         i = Integer.parseInt(request.getAttribute("WM_WIDTH"));
/*      */       else
/*  280 */         i = 200;
/*      */       int j;
/*  282 */       if (request.attributeExists("WM_HEIGHT"))
/*  283 */         j = Integer.parseInt(request.getAttribute("WM_HEIGHT"));
/*      */       else
/*  285 */         j = 200;
/*  286 */       Jpeg jpeg = new Jpeg(Image.toURL(s1 + request.getAttribute("WATERMARK_NAME")));
/*  287 */       jpeg.scaleAbsolute(i, j);
/*  288 */       Watermark watermark = new Watermark(jpeg, (rectangle.width() - i) / 2, (rectangle.height() - j) / 2);
/*  289 */       this.doc.add(watermark);
/*      */     }
/*  291 */     this.doc.open();
/*  292 */     this.doc.add(new Paragraph(new Phrase(" ")));
/*  293 */     this.imgDir = s1;
/*      */   }
/*      */ 
/*      */   private void init()
/*      */   {
/*  298 */     tagsFontControl = new Hashtable();
/*  299 */     tagsFormatControl = new Hashtable();
/*  300 */     TableControl = new Hashtable();
/*  301 */     tagsMiscellaneityControl = new Hashtable();
/*  302 */     ColorDistribution = new Hashtable();
/*  303 */     for (int i = 0; i < tagsFontStrings.length; i++) {
/*  304 */       tagsFontControl.put(tagsFontStrings[i], new Integer(i));
/*      */     }
/*  306 */     for (int j = 0; j < tagsFormatStrings.length; j++) {
/*  307 */       tagsFormatControl.put(tagsFormatStrings[j], new Integer(j));
/*      */     }
/*  309 */     for (int k = 0; k < TableStrings.length; k++) {
/*  310 */       TableControl.put(TableStrings[k], new Integer(k));
/*      */     }
/*  312 */     for (int l = 0; l < tagsMiscellaneityStrings.length; l++) {
/*  313 */       tagsMiscellaneityControl.put(tagsMiscellaneityStrings[l], new Integer(l));
/*      */     }
/*  315 */     ColorDistribution.put(ColorDistributionStrings[0], Color.black);
/*  316 */     ColorDistribution.put(ColorDistributionStrings[1], Color.blue);
/*  317 */     ColorDistribution.put(ColorDistributionStrings[2], Color.cyan);
/*  318 */     ColorDistribution.put(ColorDistributionStrings[3], Color.green);
/*  319 */     ColorDistribution.put(ColorDistributionStrings[4], Color.darkGray);
/*  320 */     ColorDistribution.put(ColorDistributionStrings[5], Color.lightGray);
/*  321 */     ColorDistribution.put(ColorDistributionStrings[6], Color.magenta);
/*  322 */     ColorDistribution.put(ColorDistributionStrings[7], Color.white);
/*  323 */     ColorDistribution.put(ColorDistributionStrings[8], Color.yellow);
/*  324 */     ColorDistribution.put(ColorDistributionStrings[9], Color.red);
/*      */   }
/*      */ 
/*      */   public void processRequest(Request request)
/*      */     throws Exception
/*      */   {
/*  333 */     if (!request.attributeExists("OUTPUTFILE"))
/*      */     {
/*  335 */       request.setAttribute("OUTPUTFILE", "default.pdf");
/*  336 */       PdfWriter.getInstance(this.doc, new FileOutputStream("default.pdf"));
/*      */     }
/*  338 */     processRequest(request, false);
/*      */   }
/*      */ 
/*      */   public void processRequest(Request request, boolean stream)
/*      */     throws Exception
/*      */   {
/*  349 */     StringReader stringreader = new StringReader(request.getAttribute("html_string"));
/*  350 */     HtmlDocument htmldocument = new HtmlParser(stringreader).HtmlDocument();
/*  351 */     htmldocument.accept(new HtmlScrubber(48));
/*  352 */     htmldocument.accept(new HtmlCollector());
/*  353 */     htmldocument.accept(this);
/*      */ 
/*  355 */     if ((stream) && (!request.attributeExists("OUTPUTFILE")))
/*      */     {
/*  357 */       HttpServletResponse response = this.ic.getHttpServletResponse();
/*  358 */       response.setContentType("application/pdf");
/*  359 */       response.setContentLength(this.baos.size());
/*  360 */       this.baos.writeTo(response.getOutputStream());
/*  361 */       this.baos.flush();
/*  362 */       this.baos.close();
/*      */     }
/*      */ 
/*  365 */     stringreader.close();
/*  366 */     finish();
/*      */   }
/*      */ 
/*      */   public void finish()
/*      */   {
/*  371 */     this.doc.close();
/*      */   }
/*      */ 
/*      */   private String convertSpace(String s)
/*      */   {
/*  376 */     boolean flag = false;
/*      */     int i;
/*      */     do {
/*  380 */       i = s.indexOf("&nbsp;");
/*  381 */       if (i >= 0)
/*      */       {
/*  383 */         s = s.substring(0, i) + "  " + s.substring(i + 6);
/*  384 */         flag = true;
/*      */       }
/*      */     }
/*  386 */     while (i != -1);
/*  387 */     if ((s.trim().length() == 0) && (flag))
/*  388 */       s = "\t";
/*  389 */     return s;
/*      */   }
/*      */ 
/*      */   private int getAlignment(String s)
/*      */   {
/*      */     byte byte0;
/*  395 */     if (s.equalsIgnoreCase("LEFT")) {
/*  396 */       byte0 = 0;
/*      */     }
/*  398 */     else if (s.equalsIgnoreCase("RIGHT"))
/*  399 */       byte0 = 2;
/*      */     else
/*  401 */       byte0 = 1;
/*  402 */     return byte0;
/*      */   }
/*      */ 
/*      */   private Color getColor(String s)
/*      */   {
/*  407 */     Color color = Color.black;
/*  408 */     if (s.charAt(0) != '#')
/*      */     {
/*  410 */       if (ColorDistribution.containsKey(s.toUpperCase()))
/*  411 */         color = (Color)ColorDistribution.get(s.toUpperCase());
/*      */       else {
/*      */         try
/*      */         {
/*  415 */           color = Color.decode("0x" + s.substring(1));
/*      */         }
/*      */         catch (NumberFormatException _ex)
/*      */         {
/*  419 */           color = null;
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*      */       try
/*      */       {
/*  426 */         color = Color.decode("0x" + s.substring(1));
/*      */       }
/*      */       catch (NumberFormatException _ex)
/*      */       {
/*  430 */         color = null;
/*      */       }
/*      */     }
/*  433 */     return color;
/*      */   }
/*      */ 
/*      */   private int getFontFamily(String s)
/*      */   {
/*      */     byte byte0;
/*  439 */     if (s.equalsIgnoreCase("COURIER")) {
/*  440 */       byte0 = 0;
/*      */     }
/*  442 */     else if (s.equalsIgnoreCase("HELVETICA")) {
/*  443 */       byte0 = 1;
/*      */     }
/*  445 */     else if (s.equalsIgnoreCase("ZAPFDINGBATS"))
/*  446 */       byte0 = 4;
/*      */     else
/*  448 */       byte0 = 2;
/*  449 */     return byte0;
/*      */   }
/*      */ 
/*      */   private Rectangle getPageSize(Request request)
/*      */   {
/*  454 */     String s = request.getAttribute("pagesize");
/*      */     Rectangle rectangle;
/*  456 */     if (s.equalsIgnoreCase("_11X17")) {
/*  457 */       rectangle = new Rectangle(PageSize._11X17);
/*      */     }
/*  459 */     else if (s.equalsIgnoreCase("A0")) {
/*  460 */       rectangle = new Rectangle(PageSize.A0);
/*      */     }
/*  462 */     else if (s.equalsIgnoreCase("A1")) {
/*  463 */       rectangle = new Rectangle(PageSize.A1);
/*      */     }
/*  465 */     else if (s.equalsIgnoreCase("A2")) {
/*  466 */       rectangle = new Rectangle(PageSize.A2);
/*      */     }
/*  468 */     else if (s.equalsIgnoreCase("A3")) {
/*  469 */       rectangle = new Rectangle(PageSize.A3);
/*      */     }
/*  471 */     else if (s.equalsIgnoreCase("A4")) {
/*  472 */       rectangle = new Rectangle(PageSize.A4);
/*      */     }
/*  474 */     else if (s.equalsIgnoreCase("A5")) {
/*  475 */       rectangle = new Rectangle(PageSize.A5);
/*      */     }
/*  477 */     else if (s.equalsIgnoreCase("A6")) {
/*  478 */       rectangle = new Rectangle(PageSize.A6);
/*      */     }
/*  480 */     else if (s.equalsIgnoreCase("A7")) {
/*  481 */       rectangle = new Rectangle(PageSize.A7);
/*      */     }
/*  483 */     else if (s.equalsIgnoreCase("A8")) {
/*  484 */       rectangle = new Rectangle(PageSize.A8);
/*      */     }
/*  486 */     else if (s.equalsIgnoreCase("A9")) {
/*  487 */       rectangle = new Rectangle(PageSize.A9);
/*      */     }
/*  489 */     else if (s.equalsIgnoreCase("A10")) {
/*  490 */       rectangle = new Rectangle(PageSize.A10);
/*      */     }
/*  492 */     else if (s.equalsIgnoreCase("ARCH_A")) {
/*  493 */       rectangle = new Rectangle(PageSize.ARCH_A);
/*      */     }
/*  495 */     else if (s.equalsIgnoreCase("ARCH_B")) {
/*  496 */       rectangle = new Rectangle(PageSize.ARCH_B);
/*      */     }
/*  498 */     else if (s.equalsIgnoreCase("ARCH_C")) {
/*  499 */       rectangle = new Rectangle(PageSize.ARCH_C);
/*      */     }
/*  501 */     else if (s.equalsIgnoreCase("ARCH_D")) {
/*  502 */       rectangle = new Rectangle(PageSize.ARCH_D);
/*      */     }
/*  504 */     else if (s.equalsIgnoreCase("ARCH_E")) {
/*  505 */       rectangle = new Rectangle(PageSize.ARCH_E);
/*      */     }
/*  507 */     else if (s.equalsIgnoreCase("B0")) {
/*  508 */       rectangle = new Rectangle(PageSize.B0);
/*      */     }
/*  510 */     else if (s.equalsIgnoreCase("B1")) {
/*  511 */       rectangle = new Rectangle(PageSize.B1);
/*      */     }
/*  513 */     else if (s.equalsIgnoreCase("B2")) {
/*  514 */       rectangle = new Rectangle(PageSize.B2);
/*      */     }
/*  516 */     else if (s.equalsIgnoreCase("B3")) {
/*  517 */       rectangle = new Rectangle(PageSize.B3);
/*      */     }
/*  519 */     else if (s.equalsIgnoreCase("B4")) {
/*  520 */       rectangle = new Rectangle(PageSize.B4);
/*      */     }
/*  522 */     else if (s.equalsIgnoreCase("B5")) {
/*  523 */       rectangle = new Rectangle(PageSize.B5);
/*      */     }
/*  525 */     else if (s.equalsIgnoreCase("FLSA")) {
/*  526 */       rectangle = new Rectangle(PageSize.FLSA);
/*      */     }
/*  528 */     else if (s.equalsIgnoreCase("FLSE")) {
/*  529 */       rectangle = new Rectangle(PageSize.FLSE);
/*      */     }
/*  531 */     else if (s.equalsIgnoreCase("HALFLETTER")) {
/*  532 */       rectangle = new Rectangle(PageSize.HALFLETTER);
/*      */     }
/*  534 */     else if (s.equalsIgnoreCase("LEDGER")) {
/*  535 */       rectangle = new Rectangle(PageSize.LEDGER);
/*      */     }
/*  537 */     else if (s.equalsIgnoreCase("NOTE")) {
/*  538 */       rectangle = new Rectangle(PageSize.NOTE);
/*      */     }
/*  540 */     else if (s.equalsIgnoreCase("LEGAL"))
/*  541 */       rectangle = new Rectangle(PageSize.LEGAL);
/*      */     else
/*  543 */       rectangle = new Rectangle(PageSize.LETTER);
/*  544 */     return rectangle;
/*      */   }
/*      */ 
/*      */   private int getStyle(String s)
/*      */   {
/*      */     byte byte0;
/*  550 */     if (s.equalsIgnoreCase("BOLD")) {
/*  551 */       byte0 = 1;
/*      */     }
/*  553 */     else if (s.equalsIgnoreCase("BOLDITALIC"))
/*  554 */       byte0 = 3;
/*      */     else
/*  556 */       byte0 = 0;
/*  557 */     return byte0;
/*      */   }
/*      */ 
/*      */   private void setheadfoot(String s, String s1, int i, int j, int k, int l, Color color, Color color1, int i1, int j1)
/*      */   {
/*  562 */     this.doc.addAuthor(this.author);
/*  563 */     this.doc.addSubject(this.subject);
/*  564 */     HeaderFooter headerfooter = new HeaderFooter(new Phrase(s, new Font(this.font.family, i, k, color)), false);
/*  565 */     HeaderFooter headerfooter1 = new HeaderFooter(new Phrase(s1 + " -- Page  ", new Font(this.font.family, j, l, color1)), true);
/*  566 */     headerfooter.setAlignment(i1);
/*  567 */     headerfooter1.setAlignment(j1);
/*  568 */     if (s != "no header")
/*  569 */       this.doc.setHeader(headerfooter);
/*  570 */     if (s1 != "no footer")
/*  571 */       this.doc.setFooter(headerfooter1);
/*      */   }
/*      */ 
/*      */   private String stripPercentageMark(String s)
/*      */   {
/*  576 */     if (s.charAt(s.length() - 1) == '%') {
/*  577 */       return s.substring(0, s.length() - 1);
/*      */     }
/*  579 */     return s;
/*      */   }
/*      */ 
/*      */   private String stripQuote(String s)
/*      */   {
/*  584 */     if (((s.charAt(0) == '\'') && (s.charAt(s.length() - 1) == '\'')) || ((s.charAt(0) == '"') && (s.charAt(s.length() - 1) == '"'))) {
/*  585 */       return s.substring(1, s.length() - 1);
/*      */     }
/*  587 */     return s;
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.Annotation annotation)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.Comment comment)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.EndTag endtag)
/*      */   {
/*  603 */     if (tagsFontControl.containsKey(endtag.tagName.toUpperCase()))
/*      */     {
/*  605 */       Integer integer = (Integer)tagsFontControl.get(endtag.tagName.toUpperCase());
/*  606 */       switch (integer.intValue())
/*      */       {
/*      */       case 0:
/*  609 */         this.font.style -= 1;
/*  610 */         break;
/*      */       case 1:
/*  613 */         this.font.style -= 2;
/*  614 */         break;
/*      */       case 2:
/*  617 */         this.font.size = 10;
/*  618 */         this.font.color = new Color(0, 0, 0);
/*  619 */         break;
/*      */       case 3:
/*  622 */         this.font.style -= 4;
/*      */       }
/*      */ 
/*      */     }
/*  626 */     else if (tagsFormatControl.containsKey(endtag.tagName.toUpperCase()))
/*      */     {
/*  628 */       Integer integer1 = (Integer)tagsFormatControl.get(endtag.tagName.toUpperCase());
/*  629 */       if ((integer1.intValue() == 1) || (integer1.intValue() == 2) || (integer1.intValue() == 5))
/*  630 */         writeAParagraph();
/*  631 */       if ((integer1.intValue() == 6) || (integer1.intValue() == 7) || (integer1.intValue() == 8) || (integer1.intValue() == 9) || (integer1.intValue() == 10) || (integer1.intValue() == 11))
/*      */       {
/*  633 */         writeAParagraph();
/*  634 */         this.font.style -= 1;
/*  635 */         this.font.size = 10;
/*      */       }
/*  637 */       if ((integer1.intValue() == 3) || (integer1.intValue() == 4))
/*      */       {
/*  639 */         this.ListStack.removeElementAt(this.inList - 1);
/*  640 */         this.inList -= 1;
/*      */       }
/*  642 */       this.ParaPosition = 0;
/*  643 */       this.inParagraph = false;
/*      */     }
/*  645 */     else if (TableControl.containsKey(endtag.tagName.toUpperCase()))
/*      */     {
/*  647 */       Integer integer2 = (Integer)TableControl.get(endtag.tagName.toUpperCase());
/*  648 */       switch (integer2.intValue())
/*      */       {
/*      */       case 0:
/*  651 */         this.inTable = false;
/*      */         try
/*      */         {
/*  654 */           Table table1 = new Table(this.table.columns);
/*  655 */           table1.setWidth(this.table.width);
/*  656 */           table1.setBorderWidth(this.table.border);
/*  657 */           int[] ai = new int[this.table.columns];
/*  658 */           if (this.table.cellWidth.size() != this.table.columns)
/*      */           {
/*  660 */             for (int i = 0; i <= this.table.columns - 1; i++) {
/*  661 */               ai[i] = 1;
/*      */             }
/*      */           }
/*      */           else {
/*  665 */             for (int j = 0; j <= this.table.cellWidth.size() - 1; j++)
/*      */             {
/*  667 */               Integer integer4 = (Integer)this.table.cellWidth.elementAt(j);
/*  668 */               ai[j] = integer4.intValue();
/*      */             }
/*      */           }
/*      */ 
/*  672 */           table1.setWidths(ai);
/*  673 */           table1.setCellpadding(this.table.cellpadding);
/*  674 */           table1.setCellspacing(this.table.cellspacing);
/*  675 */           table1.setDefaultVerticalAlignment(5);
/*  676 */           boolean flag = false;
/*  677 */           for (; !this.cellStack.isEmpty(); this.cellStack.removeElementAt(0))
/*      */           {
/*  679 */             Cell cell = (Cell)this.cellStack.firstElement();
/*  680 */             cell.setVerticalAlignment(5);
/*  681 */             if ((!cell.header()) && (!flag) && (this.table_header))
/*      */             {
/*  683 */               table1.endHeaders();
/*  684 */               flag = true;
/*      */             }
/*  686 */             table1.addCell(cell);
/*      */           }
/*      */ 
/*  689 */           this.doc.add(table1);
/*  690 */           this.doc.add(new Paragraph("", new Font(1, 0, 0, new Color(255, 255, 255))));
/*      */         }
/*      */         catch (DocumentException documentexception)
/*      */         {
/*  694 */           ErrorHandler.handleException(this.ic, documentexception, "A problem occurred while converting to PDF: " + documentexception.getMessage());
/*      */         }
/*  696 */         this.cellStack = new Vector();
/*  697 */         break;
/*      */       case 1:
/*  700 */         this.inCaculation = false;
/*  701 */         if (this.table.columns == this.table.cellWidth.size())
/*  702 */           this.CellWidth = false;
/*      */         else
/*  704 */           this.table.cellWidth = new Vector();
/*  705 */         this.table.cellbgcolor = null;
/*  706 */         break;
/*      */       case 2:
/*  709 */         this.font.style -= 1;
/*      */       }
/*      */ 
/*      */     }
/*  713 */     else if (tagsMiscellaneityControl.containsKey(endtag.tagName.toUpperCase()))
/*      */     {
/*  715 */       Integer integer3 = (Integer)tagsMiscellaneityControl.get(endtag.tagName.toUpperCase());
/*  716 */       switch (integer3.intValue())
/*      */       {
/*      */       case 0:
/*  719 */         this.inTitle = false;
/*  720 */         break;
/*      */       case 3:
/*  723 */         this.inTitle = false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.Newline newline)
/*      */   {
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.Tag tag)
/*      */   {
/*  735 */     if (tagsFontControl.containsKey(tag.tagName.toUpperCase()))
/*      */     {
/*  737 */       Integer integer = (Integer)tagsFontControl.get(tag.tagName.toUpperCase());
/*  738 */       switch (integer.intValue())
/*      */       {
/*      */       case 0:
/*  741 */         this.font.style += 1;
/*  742 */         break;
/*      */       case 1:
/*  745 */         this.font.style += 2;
/*  746 */         break;
/*      */       case 2:
/*  749 */         for (Enumeration enumeration = tag.attributeList.attributes.elements(); enumeration.hasMoreElements(); )
/*      */         {
/*  751 */           HtmlDocument.Attribute attribute = (HtmlDocument.Attribute)enumeration.nextElement();
/*  752 */           if (attribute.hasValue)
/*      */           {
/*  754 */             attribute.value = stripQuote(attribute.value);
/*  755 */             if (attribute.name.compareToIgnoreCase("size") == 0)
/*  756 */               if (attribute.value.charAt(0) == '+') {
/*  757 */                 this.font.size += Integer.parseInt(attribute.value.substring(1));
/*      */               }
/*  759 */               else if (attribute.value.charAt(0) == '-')
/*  760 */                 this.font.size -= Integer.parseInt(attribute.value.substring(1));
/*      */               else
/*  762 */                 this.font.size = (Integer.parseInt(attribute.value) + 10);
/*  763 */             if (attribute.name.compareToIgnoreCase("color") == 0) {
/*  764 */               this.font.color = getColor(attribute.value);
/*      */             }
/*      */           }
/*      */         }
/*  768 */         break;
/*      */       case 3:
/*  771 */         this.font.style += 4;
/*      */       }
/*      */ 
/*      */     }
/*  775 */     else if (tagsFormatControl.containsKey(tag.tagName.toUpperCase()))
/*      */     {
/*  777 */       Integer integer1 = (Integer)tagsFormatControl.get(tag.tagName.toUpperCase());
/*  778 */       switch (integer1.intValue())
/*      */       {
/*      */       case 0:
/*      */         try
/*      */         {
/*  783 */           if (this.inParagraph) {
/*  784 */             this.StrPara.add("\n");
/*      */           }
/*  786 */           else if (this.inTable)
/*      */           {
/*  788 */             Cell cell = (Cell)this.cellStack.lastElement();
/*  789 */             cell.addElement(new Phrase("\n"));
/*      */           }
/*      */           else {
/*  792 */             this.doc.add(new Phrase("\n"));
/*      */           }
/*      */         }
/*      */         catch (DocumentException documentexception)
/*      */         {
/*  797 */           ErrorHandler.handleException(this.ic, documentexception, "A problem occurred while converting to PDF: " + documentexception.getMessage());
/*      */         }
/*  799 */         break;
/*      */       case 1:
/*  802 */         this.inParagraph = true;
/*  803 */         for (Enumeration enumeration1 = tag.attributeList.attributes.elements(); enumeration1.hasMoreElements(); )
/*      */         {
/*  805 */           HtmlDocument.Attribute attribute1 = (HtmlDocument.Attribute)enumeration1.nextElement();
/*  806 */           if (attribute1.hasValue)
/*      */           {
/*  808 */             attribute1.value = stripQuote(attribute1.value);
/*  809 */             if (attribute1.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  811 */               if (attribute1.value.compareToIgnoreCase("left") == 0)
/*  812 */                 this.ParaPosition = 0;
/*  813 */               if (attribute1.value.compareToIgnoreCase("center") == 0)
/*  814 */                 this.ParaPosition = 1;
/*  815 */               if (attribute1.value.compareToIgnoreCase("right") == 0) {
/*  816 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  821 */         break;
/*      */       case 2:
/*  824 */         this.inParagraph = true;
/*  825 */         for (Enumeration enumeration2 = tag.attributeList.attributes.elements(); enumeration2.hasMoreElements(); )
/*      */         {
/*  827 */           HtmlDocument.Attribute attribute2 = (HtmlDocument.Attribute)enumeration2.nextElement();
/*  828 */           if (attribute2.hasValue)
/*      */           {
/*  830 */             attribute2.value = stripQuote(attribute2.value);
/*  831 */             if (attribute2.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  833 */               if (attribute2.value.compareToIgnoreCase("left") == 0)
/*  834 */                 this.ParaPosition = 0;
/*  835 */               if (attribute2.value.compareToIgnoreCase("center") == 0)
/*  836 */                 this.ParaPosition = 1;
/*  837 */               if (attribute2.value.compareToIgnoreCase("right") == 0) {
/*  838 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  843 */         break;
/*      */       case 3:
/*  846 */         if (this.inList > 0)
/*  847 */           writeAParagraph();
/*  848 */         ListStackEntry liststackentry = new ListStackEntry();
/*  849 */         liststackentry.OrderList = true;
/*  850 */         liststackentry.CurrentNum = 0;
/*  851 */         liststackentry.ListPosition = this.ParaPosition;
/*  852 */         this.ListStack.addElement(liststackentry);
/*  853 */         this.inList = this.ListStack.size();
/*  854 */         break;
/*      */       case 4:
/*  857 */         if (this.inList > 0)
/*  858 */           writeAParagraph();
/*  859 */         ListStackEntry liststackentry1 = new ListStackEntry();
/*  860 */         liststackentry1.OrderList = false;
/*  861 */         liststackentry1.CurrentNum = 0;
/*  862 */         liststackentry1.ListPosition = this.ParaPosition;
/*  863 */         this.ListStack.addElement(liststackentry1);
/*  864 */         this.inList = this.ListStack.size();
/*  865 */         break;
/*      */       case 5:
/*  868 */         this.inParagraph = true;
/*  869 */         ListStackEntry liststackentry2 = (ListStackEntry)this.ListStack.elementAt(this.inList - 1);
/*  870 */         this.ParaPosition = liststackentry2.ListPosition;
/*  871 */         if (liststackentry2.OrderList)
/*  872 */           liststackentry2.CurrentNum += 1; break;
/*      */       case 6:
/*  876 */         this.inParagraph = true;
/*  877 */         this.font.style += 1;
/*  878 */         this.font.size = 16;
/*  879 */         for (Enumeration enumeration8 = tag.attributeList.attributes.elements(); enumeration8.hasMoreElements(); )
/*      */         {
/*  881 */           HtmlDocument.Attribute attribute8 = (HtmlDocument.Attribute)enumeration8.nextElement();
/*  882 */           if (attribute8.hasValue)
/*      */           {
/*  884 */             attribute8.value = stripQuote(attribute8.value);
/*  885 */             if (attribute8.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  887 */               if (attribute8.value.compareToIgnoreCase("left") == 0)
/*  888 */                 this.ParaPosition = 0;
/*  889 */               if (attribute8.value.compareToIgnoreCase("center") == 0)
/*  890 */                 this.ParaPosition = 1;
/*  891 */               if (attribute8.value.compareToIgnoreCase("right") == 0) {
/*  892 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  897 */         break;
/*      */       case 7:
/*  900 */         this.inParagraph = true;
/*  901 */         this.font.style += 1;
/*  902 */         this.font.size = 15;
/*  903 */         for (Enumeration enumeration9 = tag.attributeList.attributes.elements(); enumeration9.hasMoreElements(); )
/*      */         {
/*  905 */           HtmlDocument.Attribute attribute9 = (HtmlDocument.Attribute)enumeration9.nextElement();
/*  906 */           if (attribute9.hasValue)
/*      */           {
/*  908 */             attribute9.value = stripQuote(attribute9.value);
/*  909 */             if (attribute9.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  911 */               if (attribute9.value.compareToIgnoreCase("left") == 0)
/*  912 */                 this.ParaPosition = 0;
/*  913 */               if (attribute9.value.compareToIgnoreCase("center") == 0)
/*  914 */                 this.ParaPosition = 1;
/*  915 */               if (attribute9.value.compareToIgnoreCase("right") == 0) {
/*  916 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  921 */         break;
/*      */       case 8:
/*  924 */         this.inParagraph = true;
/*  925 */         this.font.style += 1;
/*  926 */         this.font.size = 14;
/*  927 */         for (Enumeration enumeration10 = tag.attributeList.attributes.elements(); enumeration10.hasMoreElements(); )
/*      */         {
/*  929 */           HtmlDocument.Attribute attribute10 = (HtmlDocument.Attribute)enumeration10.nextElement();
/*  930 */           if (attribute10.hasValue)
/*      */           {
/*  932 */             attribute10.value = stripQuote(attribute10.value);
/*  933 */             if (attribute10.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  935 */               if (attribute10.value.compareToIgnoreCase("left") == 0)
/*  936 */                 this.ParaPosition = 0;
/*  937 */               if (attribute10.value.compareToIgnoreCase("center") == 0)
/*  938 */                 this.ParaPosition = 1;
/*  939 */               if (attribute10.value.compareToIgnoreCase("right") == 0) {
/*  940 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  945 */         break;
/*      */       case 9:
/*  948 */         this.inParagraph = true;
/*  949 */         this.font.style += 1;
/*  950 */         this.font.size = 13;
/*  951 */         for (Enumeration enumeration11 = tag.attributeList.attributes.elements(); enumeration11.hasMoreElements(); )
/*      */         {
/*  953 */           HtmlDocument.Attribute attribute11 = (HtmlDocument.Attribute)enumeration11.nextElement();
/*  954 */           if (attribute11.hasValue)
/*      */           {
/*  956 */             attribute11.value = stripQuote(attribute11.value);
/*  957 */             if (attribute11.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  959 */               if (attribute11.value.compareToIgnoreCase("left") == 0)
/*  960 */                 this.ParaPosition = 0;
/*  961 */               if (attribute11.value.compareToIgnoreCase("center") == 0)
/*  962 */                 this.ParaPosition = 1;
/*  963 */               if (attribute11.value.compareToIgnoreCase("right") == 0) {
/*  964 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  969 */         break;
/*      */       case 10:
/*  972 */         this.inParagraph = true;
/*  973 */         this.font.style += 1;
/*  974 */         this.font.size = 12;
/*  975 */         for (Enumeration enumeration12 = tag.attributeList.attributes.elements(); enumeration12.hasMoreElements(); )
/*      */         {
/*  977 */           HtmlDocument.Attribute attribute12 = (HtmlDocument.Attribute)enumeration12.nextElement();
/*  978 */           if (attribute12.hasValue)
/*      */           {
/*  980 */             attribute12.value = stripQuote(attribute12.value);
/*  981 */             if (attribute12.name.compareToIgnoreCase("align") == 0)
/*      */             {
/*  983 */               if (attribute12.value.compareToIgnoreCase("left") == 0)
/*  984 */                 this.ParaPosition = 0;
/*  985 */               if (attribute12.value.compareToIgnoreCase("center") == 0)
/*  986 */                 this.ParaPosition = 1;
/*  987 */               if (attribute12.value.compareToIgnoreCase("right") == 0) {
/*  988 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  993 */         break;
/*      */       case 11:
/*  996 */         this.inParagraph = true;
/*  997 */         this.font.style += 1;
/*  998 */         this.font.size = 11;
/*  999 */         for (Enumeration enumeration13 = tag.attributeList.attributes.elements(); enumeration13.hasMoreElements(); )
/*      */         {
/* 1001 */           HtmlDocument.Attribute attribute13 = (HtmlDocument.Attribute)enumeration13.nextElement();
/* 1002 */           if (attribute13.hasValue)
/*      */           {
/* 1004 */             attribute13.value = stripQuote(attribute13.value);
/* 1005 */             if (attribute13.name.compareToIgnoreCase("align") == 0)
/*      */             {
/* 1007 */               if (attribute13.value.compareToIgnoreCase("left") == 0)
/* 1008 */                 this.ParaPosition = 0;
/* 1009 */               if (attribute13.value.compareToIgnoreCase("center") == 0)
/* 1010 */                 this.ParaPosition = 1;
/* 1011 */               if (attribute13.value.compareToIgnoreCase("right") == 0) {
/* 1012 */                 this.ParaPosition = 2;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/* 1020 */     else if (TableControl.containsKey(tag.tagName.toUpperCase()))
/*      */     {
/* 1022 */       Integer integer2 = (Integer)TableControl.get(tag.tagName.toUpperCase());
/* 1023 */       switch (integer2.intValue())
/*      */       {
/*      */       case 0:
/* 1026 */         this.inTable = true;
/* 1027 */         this.inCaculation = true;
/* 1028 */         this.CellWidth = true;
/* 1029 */         this.table.initialize();
/* 1030 */         for (Enumeration enumeration3 = tag.attributeList.attributes.elements(); enumeration3.hasMoreElements(); )
/*      */         {
/* 1032 */           HtmlDocument.Attribute attribute3 = (HtmlDocument.Attribute)enumeration3.nextElement();
/* 1033 */           if (attribute3.hasValue)
/*      */           {
/* 1035 */             attribute3.value = stripQuote(attribute3.value);
/* 1036 */             if (attribute3.name.compareToIgnoreCase("align") == 0)
/*      */             {
/* 1038 */               if (attribute3.value.compareToIgnoreCase("center") == 0) {
/* 1039 */                 this.table.align = 1;
/*      */               }
/* 1041 */               else if (attribute3.value.compareToIgnoreCase("right") == 0)
/* 1042 */                 this.table.align = 2;
/*      */             }
/* 1044 */             else if (attribute3.name.compareToIgnoreCase("width") == 0)
/*      */             {
/* 1046 */               attribute3.value = stripPercentageMark(attribute3.value);
/* 1047 */               this.table.width = Integer.parseInt(attribute3.value);
/*      */             }
/* 1049 */             else if (attribute3.name.compareToIgnoreCase("border") == 0) {
/* 1050 */               this.table.border = Integer.parseInt(attribute3.value);
/*      */             }
/* 1052 */             else if (attribute3.name.compareToIgnoreCase("cellspacing") == 0) {
/* 1053 */               this.table.cellspacing = (Integer.parseInt(attribute3.value) - 3);
/*      */             }
/* 1055 */             else if (attribute3.name.compareToIgnoreCase("cellpadding") == 0) {
/* 1056 */               this.table.cellpadding = Integer.parseInt(attribute3.value);
/*      */             }
/*      */           }
/*      */         }
/* 1060 */         break;
/*      */       case 1:
/* 1063 */         for (Enumeration enumeration4 = tag.attributeList.attributes.elements(); enumeration4.hasMoreElements(); )
/*      */         {
/* 1065 */           HtmlDocument.Attribute attribute4 = (HtmlDocument.Attribute)enumeration4.nextElement();
/* 1066 */           if (attribute4.hasValue)
/*      */           {
/* 1068 */             attribute4.value = stripQuote(attribute4.value);
/* 1069 */             if (attribute4.name.compareToIgnoreCase("bgcolor") == 0) {
/* 1070 */               this.table.cellbgcolor = getColor(attribute4.value);
/*      */             }
/*      */           }
/*      */         }
/* 1074 */         break;
/*      */       case 2:
/* 1077 */         this.font.style += 1;
/*      */         try
/*      */         {
/* 1080 */           Cell cell1 = new Cell(new Phrase(""));
/* 1081 */           cell1.setHeader(true);
/* 1082 */           cell1.setBorderWidth(0.0D);
/* 1083 */           cell1.setBackgroundColor(this.table.cellbgcolor);
/* 1084 */           if (this.inCaculation)
/* 1085 */             this.table.columns += 1;
/* 1086 */           for (Enumeration enumeration5 = tag.attributeList.attributes.elements(); enumeration5.hasMoreElements(); )
/*      */           {
/* 1088 */             HtmlDocument.Attribute attribute5 = (HtmlDocument.Attribute)enumeration5.nextElement();
/* 1089 */             if (attribute5.name.compareToIgnoreCase("nowrap") == 0)
/* 1090 */               cell1.setNoWrap(true);
/* 1091 */             if (attribute5.hasValue)
/*      */             {
/* 1093 */               attribute5.value = stripQuote(attribute5.value);
/* 1094 */               if (attribute5.name.compareToIgnoreCase("colspan") == 0)
/*      */               {
/* 1096 */                 cell1.setColspan(Integer.parseInt(attribute5.value));
/* 1097 */                 if (this.inCaculation)
/* 1098 */                   this.table.columns += Integer.parseInt(attribute5.value) - 1;
/*      */               }
/* 1100 */               else if (attribute5.name.compareToIgnoreCase("rowspan") == 0) {
/* 1101 */                 cell1.setRowspan(Integer.parseInt(attribute5.value));
/*      */               }
/* 1103 */               else if (attribute5.name.compareToIgnoreCase("align") == 0)
/*      */               {
/* 1105 */                 if (attribute5.value.compareToIgnoreCase("center") == 0) {
/* 1106 */                   cell1.setHorizontalAlignment(1);
/*      */                 }
/* 1108 */                 else if (attribute5.value.compareToIgnoreCase("right") == 0) {
/* 1109 */                   cell1.setHorizontalAlignment(2);
/*      */                 }
/* 1111 */                 else if (attribute5.value.compareToIgnoreCase("left") == 0)
/* 1112 */                   cell1.setHorizontalAlignment(0);
/*      */               }
/* 1114 */               else if (attribute5.name.compareToIgnoreCase("valign") == 0)
/*      */               {
/* 1116 */                 if (attribute5.value.compareToIgnoreCase("top") == 0) {
/* 1117 */                   cell1.setVerticalAlignment(4);
/*      */                 }
/* 1119 */                 else if (attribute5.value.compareToIgnoreCase("bottom") == 0) {
/* 1120 */                   cell1.setVerticalAlignment(6);
/*      */                 }
/* 1122 */                 else if (attribute5.value.compareToIgnoreCase("baseline") == 0)
/* 1123 */                   cell1.setVerticalAlignment(7);
/*      */                 else
/* 1125 */                   cell1.setVerticalAlignment(5);
/*      */               }
/* 1127 */               else if (attribute5.name.compareToIgnoreCase("width") == 0)
/*      */               {
/* 1129 */                 if (this.CellWidth)
/*      */                 {
/* 1131 */                   attribute5.value = stripPercentageMark(attribute5.value);
/* 1132 */                   this.table.pushCellWidth(new Integer(attribute5.value));
/*      */                 }
/*      */               }
/* 1135 */               else if (attribute5.name.compareToIgnoreCase("bordercolor") == 0)
/*      */               {
/* 1137 */                 cell1.setBorderWidth(1.0D);
/* 1138 */                 cell1.setBorderColor(getColor(attribute5.value));
/*      */               }
/* 1140 */               else if (attribute5.name.compareToIgnoreCase("bgcolor") == 0) {
/* 1141 */                 cell1.setBackgroundColor(getColor(attribute5.value));
/*      */               }
/*      */             }
/*      */           }
/* 1145 */           this.cellStack.addElement(cell1);
/*      */         }
/*      */         catch (BadElementException badelementexception)
/*      */         {
/* 1149 */           ErrorHandler.handleException(this.ic, badelementexception, "A problem occurred while converting to PDF: " + badelementexception.getMessage());
/*      */         }
/* 1151 */         break;
/*      */       case 3:
/*      */         try
/*      */         {
/* 1156 */           Cell cell2 = new Cell(new Phrase(""));
/* 1157 */           cell2.setBorderWidth(0.0D);
/* 1158 */           cell2.setBackgroundColor(this.table.cellbgcolor);
/* 1159 */           if (this.inCaculation)
/* 1160 */             this.table.columns += 1;
/* 1161 */           for (Enumeration enumeration6 = tag.attributeList.attributes.elements(); enumeration6.hasMoreElements(); )
/*      */           {
/* 1163 */             HtmlDocument.Attribute attribute6 = (HtmlDocument.Attribute)enumeration6.nextElement();
/* 1164 */             if (attribute6.name.compareToIgnoreCase("nowrap") == 0)
/* 1165 */               cell2.setNoWrap(true);
/* 1166 */             if (attribute6.hasValue)
/*      */             {
/* 1168 */               attribute6.value = stripQuote(attribute6.value);
/* 1169 */               if (attribute6.name.compareToIgnoreCase("colspan") == 0)
/*      */               {
/* 1171 */                 cell2.setColspan(Integer.parseInt(attribute6.value));
/* 1172 */                 if (this.inCaculation)
/* 1173 */                   this.table.columns += Integer.parseInt(attribute6.value) - 1;
/*      */               }
/* 1175 */               else if (attribute6.name.compareToIgnoreCase("rowspan") == 0) {
/* 1176 */                 cell2.setRowspan(Integer.parseInt(attribute6.value));
/*      */               }
/* 1178 */               else if (attribute6.name.compareToIgnoreCase("align") == 0)
/*      */               {
/* 1180 */                 if (attribute6.value.compareToIgnoreCase("center") == 0) {
/* 1181 */                   cell2.setHorizontalAlignment(1);
/*      */                 }
/* 1183 */                 else if (attribute6.value.compareToIgnoreCase("right") == 0) {
/* 1184 */                   cell2.setHorizontalAlignment(2);
/*      */                 }
/* 1186 */                 else if (attribute6.value.compareToIgnoreCase("left") == 0)
/* 1187 */                   cell2.setHorizontalAlignment(0);
/*      */               }
/* 1189 */               else if (attribute6.name.compareToIgnoreCase("valign") == 0)
/*      */               {
/* 1191 */                 if (attribute6.value.compareToIgnoreCase("top") == 0) {
/* 1192 */                   cell2.setVerticalAlignment(4);
/*      */                 }
/* 1194 */                 else if (attribute6.value.compareToIgnoreCase("bottom") == 0) {
/* 1195 */                   cell2.setVerticalAlignment(6);
/*      */                 }
/* 1197 */                 else if (attribute6.value.compareToIgnoreCase("baseline") == 0)
/* 1198 */                   cell2.setVerticalAlignment(7);
/*      */                 else
/* 1200 */                   cell2.setVerticalAlignment(5);
/*      */               }
/* 1202 */               else if (attribute6.name.compareToIgnoreCase("width") == 0)
/*      */               {
/* 1204 */                 if (this.CellWidth)
/*      */                 {
/* 1206 */                   attribute6.value = stripPercentageMark(attribute6.value);
/* 1207 */                   this.table.pushCellWidth(new Integer(attribute6.value));
/*      */                 }
/*      */               }
/* 1210 */               else if (attribute6.name.compareToIgnoreCase("bordercolor") == 0)
/*      */               {
/* 1212 */                 cell2.setBorderWidth(1.0D);
/* 1213 */                 cell2.setBorderColor(getColor(attribute6.value));
/*      */               }
/* 1215 */               else if (attribute6.name.compareToIgnoreCase("bgcolor") == 0) {
/* 1216 */                 cell2.setBackgroundColor(getColor(attribute6.value));
/*      */               }
/*      */             }
/*      */           }
/* 1220 */           this.cellStack.addElement(cell2);
/*      */         }
/*      */         catch (BadElementException badelementexception)
/*      */         {
/* 1224 */           ErrorHandler.handleException(this.ic, badelementexception, "A problem occurred while converting to PDF: " + badelementexception.getMessage());
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/* 1229 */     else if (tagsMiscellaneityControl.containsKey(tag.tagName.toUpperCase()))
/*      */     {
/* 1231 */       Integer integer3 = (Integer)tagsMiscellaneityControl.get(tag.tagName.toUpperCase());
/* 1232 */       switch (integer3.intValue())
/*      */       {
/*      */       case 2:
/*      */       default:
/* 1236 */         break;
/*      */       case 0:
/* 1239 */         this.inTitle = true;
/* 1240 */         break;
/*      */       case 1:
/* 1243 */         Html2PdfImage html2pdfimage = new Html2PdfImage();
/* 1244 */         for (Enumeration enumeration7 = tag.attributeList.attributes.elements(); enumeration7.hasMoreElements(); )
/*      */         {
/* 1246 */           HtmlDocument.Attribute attribute7 = (HtmlDocument.Attribute)enumeration7.nextElement();
/* 1247 */           if (attribute7.hasValue)
/*      */           {
/* 1249 */             attribute7.value = stripQuote(attribute7.value);
/* 1250 */             if (attribute7.name.compareToIgnoreCase("src") == 0) {
/* 1251 */               html2pdfimage.StrUrl = attribute7.value.toUpperCase();
/*      */             }
/* 1253 */             else if (attribute7.name.compareToIgnoreCase("width") == 0) {
/* 1254 */               html2pdfimage.width = Integer.parseInt(attribute7.value);
/*      */             }
/* 1256 */             else if (attribute7.name.compareToIgnoreCase("height") == 0) {
/* 1257 */               html2pdfimage.height = Integer.parseInt(attribute7.value);
/*      */             }
/* 1259 */             else if (attribute7.name.compareToIgnoreCase("border") == 0) {
/* 1260 */               html2pdfimage.border = Integer.parseInt(attribute7.value);
/*      */             }
/* 1262 */             else if (attribute7.name.compareToIgnoreCase("alt") == 0) {
/* 1263 */               html2pdfimage.alt = attribute7.value;
/*      */             }
/* 1265 */             else if (attribute7.name.compareToIgnoreCase("align") == 0) {
/* 1266 */               if (attribute7.value.compareToIgnoreCase("left") == 0) {
/* 1267 */                 html2pdfimage.align = 6;
/*      */               }
/* 1269 */               else if (attribute7.value.compareToIgnoreCase("right") == 0) {
/* 1270 */                 html2pdfimage.align = 5;
/*      */               }
/* 1272 */               else if (attribute7.value.compareToIgnoreCase("middle") == 0) {
/* 1273 */                 html2pdfimage.align = 7;
/*      */               }
/* 1275 */               else if (attribute7.value.compareToIgnoreCase("baseline") == 0) {
/* 1276 */                 html2pdfimage.align = 11;
/*      */               }
/* 1278 */               else if (attribute7.value.compareToIgnoreCase("texttop") == 0) {
/* 1279 */                 html2pdfimage.align = 8;
/*      */               }
/* 1281 */               else if (attribute7.value.compareToIgnoreCase("absmiddle") == 0)
/* 1282 */                 html2pdfimage.align = 9;
/*      */               else
/* 1284 */                 html2pdfimage.align = 4;
/*      */             }
/*      */           }
/*      */         }
/*      */         try
/*      */         {
/* 1290 */           if (html2pdfimage.StrUrl.indexOf("GIF") >= 0)
/*      */           {
/*      */             Gif gif;
/* 1293 */             if (html2pdfimage.StrUrl.indexOf('/') > 0)
/*      */             {
/* 1295 */               String s = html2pdfimage.StrUrl.substring(html2pdfimage.StrUrl.lastIndexOf('/') + 1);
/*      */ 
/* 1297 */               gif = new Gif(Image.toURL(this.imgDir + s));
/*      */             }
/*      */             else {
/* 1300 */               String s1 = html2pdfimage.StrUrl;
/*      */ 
/* 1302 */               gif = new Gif(Image.toURL(s1));
/*      */             }
/* 1304 */             gif.scaleAbsolute(html2pdfimage.width, html2pdfimage.height);
/* 1305 */             gif.setBorder(html2pdfimage.border);
/* 1306 */             gif.setAlt(html2pdfimage.alt);
/* 1307 */             gif.setAlignment(html2pdfimage.align);
/* 1308 */             if (this.inTable)
/*      */             {
/* 1310 */               Cell cell3 = (Cell)this.cellStack.lastElement();
/* 1311 */               cell3.addElement(new Phrase(html2pdfimage.alt));
/*      */             }
/*      */             else {
/* 1314 */               this.doc.add(gif);
/*      */             }
/*      */           }
/* 1317 */           else if (html2pdfimage.StrUrl.indexOf("JPG") >= 0)
/*      */           {
/*      */             Jpeg jpeg;
/* 1320 */             if (html2pdfimage.StrUrl.indexOf('/') > 0)
/*      */             {
/* 1322 */               String s2 = html2pdfimage.StrUrl.substring(html2pdfimage.StrUrl.lastIndexOf('/') + 1);
/*      */ 
/* 1324 */               jpeg = new Jpeg(Image.toURL(this.imgDir + s2));
/*      */             }
/*      */             else {
/* 1327 */               String s3 = html2pdfimage.StrUrl;
/*      */ 
/* 1329 */               jpeg = new Jpeg(Image.toURL(s3));
/*      */             }
/* 1331 */             jpeg.scaleAbsolute(html2pdfimage.width, html2pdfimage.height);
/* 1332 */             jpeg.setBorder(html2pdfimage.border);
/* 1333 */             jpeg.setAlt(html2pdfimage.alt);
/* 1334 */             jpeg.setAlignment(html2pdfimage.align);
/* 1335 */             if (this.inTable)
/*      */             {
/* 1337 */               Cell cell4 = (Cell)this.cellStack.lastElement();
/* 1338 */               cell4.addElement(new Phrase(html2pdfimage.alt));
/*      */             }
/*      */             else {
/* 1341 */               this.doc.add(jpeg);
/*      */             }
/*      */           }
/* 1344 */           else if (html2pdfimage.StrUrl.indexOf("PNG") >= 0)
/*      */           {
/*      */             Png png;
/* 1347 */             if (html2pdfimage.StrUrl.indexOf('/') > 0)
/*      */             {
/* 1349 */               String s4 = html2pdfimage.StrUrl.substring(html2pdfimage.StrUrl.lastIndexOf('/') + 1);
/*      */ 
/* 1351 */               png = new Png(Image.toURL(this.imgDir + s4));
/*      */             }
/*      */             else {
/* 1354 */               String s5 = html2pdfimage.StrUrl;
/*      */ 
/* 1356 */               png = new Png(Image.toURL(s5));
/*      */             }
/* 1358 */             png.scaleAbsolute(html2pdfimage.width, html2pdfimage.height);
/* 1359 */             png.setBorder(html2pdfimage.border);
/* 1360 */             png.setAlt(html2pdfimage.alt);
/* 1361 */             png.setAlignment(html2pdfimage.align);
/* 1362 */             if (this.inTable)
/*      */             {
/* 1364 */               Cell cell5 = (Cell)this.cellStack.lastElement();
/* 1365 */               cell5.addElement(new Phrase(html2pdfimage.alt));
/*      */             }
/*      */             else {
/* 1368 */               this.doc.add(png);
/*      */             }
/*      */           }
/* 1371 */           this.doc.add(new Paragraph(""));
/*      */         }
/*      */         catch (MalformedURLException _ex)
/*      */         {
/* 1375 */           ErrorHandler.handleException(this.ic, _ex, "A problem occurred while converting an image to PDF: " + _ex.getMessage());
/*      */         }
/*      */         catch (DocumentException documentexception)
/*      */         {
/* 1379 */           ErrorHandler.handleException(this.ic, documentexception, "A problem occurred while converting an image to PDF (Use JPG format images only): " + documentexception.getMessage());
/*      */         }
/*      */         catch (IOException _ex)
/*      */         {
/* 1383 */           ErrorHandler.handleException(this.ic, _ex, "A problem occurred while converting an image to PDF: " + _ex);
/*      */         }
/* 1385 */         break;
/*      */       case 3:
/* 1388 */         this.inTitle = true;
/* 1389 */         break;
/*      */       case 4:
/*      */         try
/*      */         {
/* 1394 */           this.doc.newPage();
/*      */         }
/*      */         catch (DocumentException documentexception)
/*      */         {
/* 1398 */           ErrorHandler.handleException(this.ic, documentexception, "A problem occurred while converting to PDF: " + documentexception.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.TagBlock tagblock)
/*      */   {
/* 1407 */     visit(tagblock.startTag);
/* 1408 */     visit(tagblock.body);
/* 1409 */     visit(tagblock.endTag);
/*      */   }
/*      */ 
/*      */   public void visit(HtmlDocument.Text text)
/*      */   {
/* 1414 */     text.text = convertSpace(text.text);
/*      */     try
/*      */     {
/* 1417 */       Phrase phrase = new Phrase(text.text, this.font.valueOf());
/* 1418 */       if ((!phrase.isEmpty()) && (!this.inTitle))
/* 1419 */         if (this.inParagraph) {
/* 1420 */           this.StrPara.add(phrase);
/*      */         }
/* 1422 */         else if ((!this.inParagraph) && (this.inTable))
/*      */         {
/* 1424 */           Cell cell = (Cell)this.cellStack.lastElement();
/* 1425 */           cell.addElement(phrase);
/*      */         }
/*      */         else {
/* 1428 */           this.doc.add(phrase);
/*      */         }
/* 1430 */       phrase = null;
/*      */     }
/*      */     catch (DocumentException documentexception)
/*      */     {
/* 1434 */       ErrorHandler.handleException(this.ic, documentexception, "A problem occurred while converting to PDF: " + documentexception.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void writeAParagraph()
/*      */   {
/* 1440 */     if ((this.inList > 0) && (!this.StrPara.isEmpty()))
/*      */     {
/* 1442 */       ListStackEntry liststackentry = (ListStackEntry)this.ListStack.elementAt(this.inList - 1);
/* 1443 */       Phrase phrase = new Phrase(this.StrPara.font().size());
/* 1444 */       for (int i = 0; i < this.inList - 1; i++) {
/* 1445 */         phrase.add("            ");
/*      */       }
/* 1447 */       if (liststackentry.OrderList)
/*      */       {
/* 1449 */         phrase.add(String.valueOf(liststackentry.CurrentNum) + ".   ");
/* 1450 */         phrase.add(this.StrPara);
/*      */       }
/*      */       else {
/* 1453 */         phrase.add("*    ");
/* 1454 */         phrase.add(this.StrPara);
/*      */       }
/* 1456 */       this.ParaPosition = liststackentry.ListPosition;
/* 1457 */       this.StrPara = phrase;
/*      */     }
/* 1459 */     if (this.inTable)
/*      */     {
/* 1461 */       Cell cell = (Cell)this.cellStack.lastElement();
/* 1462 */       Paragraph paragraph1 = new Paragraph(this.StrPara);
/* 1463 */       paragraph1.setAlignment(this.ParaPosition);
/*      */       try
/*      */       {
/* 1466 */         cell.addElement(paragraph1);
/*      */       }
/*      */       catch (BadElementException badelementexception)
/*      */       {
/* 1470 */         ErrorHandler.handleException(this.ic, badelementexception, "A problem occurred while converting to PDF: " + badelementexception.getMessage());
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*      */       try {
/* 1476 */         Paragraph paragraph = new Paragraph(this.StrPara);
/* 1477 */         paragraph.setAlignment(this.ParaPosition);
/* 1478 */         this.doc.add(paragraph);
/* 1479 */         Paragraph paragraph2 = new Paragraph("");
/* 1480 */         paragraph.setAlignment(0);
/* 1481 */         this.doc.add(new Paragraph(paragraph2));
/*      */       }
/*      */       catch (DocumentException documentexception)
/*      */       {
/* 1485 */         ErrorHandler.handleException(this.ic, documentexception, "A problem occurred while converting to PDF: " + documentexception.getMessage());
/*      */       }
/*      */     }
/* 1488 */     this.StrPara = new Phrase();
/*      */   }
/*      */ 
/*      */   class FontStyle
/*      */   {
/*      */     protected int family;
/*      */     protected int size;
/*      */     protected int style;
/*      */     protected Color color;
/*      */ 
/*      */     public void printFont()
/*      */     {
/*      */     }
/*      */ 
/*      */     public Font valueOf()
/*      */     {
/*   88 */       return new Font(this.family, this.size, this.style, this.color);
/*      */     }
/*      */ 
/*      */     public FontStyle()
/*      */     {
/*   93 */       this.family = Html2pdf.this.DEFAULT_FONT_FAMILY;
/*   94 */       this.size = 10;
/*   95 */       this.style = 0;
/*   96 */       this.color = new Color(0, 0, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ListStackEntry
/*      */   {
/*      */     boolean OrderList;
/*      */     int CurrentNum;
/*      */     int ListPosition;
/*      */ 
/*      */     ListStackEntry()
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.html2pdf.Html2pdf
 * JD-Core Version:    0.6.2
 */