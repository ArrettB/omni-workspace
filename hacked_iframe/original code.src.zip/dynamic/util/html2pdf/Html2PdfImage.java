package dynamic.util.html2pdf;

public class Html2PdfImage
{
  String StrUrl;
  int width;
  int height;
  int align;
  String alt;
  int border;
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.html2pdf.Html2PdfImage
 * JD-Core Version:    0.6.2
 */