/*    */ package dynamic.util.html2pdf;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class Html2PdfTable
/*    */ {
/*    */   int width;
/*    */   int align;
/*    */   int border;
/*    */   int cellspacing;
/*    */   int cellpadding;
/*    */   int columns;
/*    */   Color cellbgcolor;
/*    */   public Vector cellWidth;
/*    */ 
/*    */   public Html2PdfTable()
/*    */   {
/* 25 */     initialize();
/*    */   }
/*    */ 
/*    */   public void initialize()
/*    */   {
/* 30 */     this.width = 100;
/* 31 */     this.align = 0;
/* 32 */     this.border = 0;
/* 33 */     this.cellspacing = 0;
/* 34 */     this.cellpadding = 0;
/* 35 */     this.columns = 0;
/* 36 */     this.cellbgcolor = null;
/* 37 */     this.cellWidth = new Vector();
/*    */   }
/*    */ 
/*    */   public void pushCellWidth(Integer integer)
/*    */   {
/* 42 */     this.cellWidth.addElement(integer);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.html2pdf.Html2PdfTable
 * JD-Core Version:    0.6.2
 */