/*     */ package dynamic.util.html2pdf;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ public class Request
/*     */ {
/*     */   Hashtable m_attributes;
/*     */   Hashtable m_settings;
/*     */ 
/*     */   public Request(Hashtable hashtable)
/*     */     throws IllegalArgumentException
/*     */   {
/*  18 */     this.m_attributes = new Hashtable();
/*  19 */     this.m_settings = new Hashtable();
/*  20 */     if (hashtable != null)
/*  21 */       initializeVariables(hashtable, this.m_attributes);
/*     */   }
/*     */ 
/*     */   public boolean attributeExists(String s)
/*     */   {
/*  26 */     if (s != null) {
/*  27 */       return this.m_attributes.containsKey(s);
/*     */     }
/*  29 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean debug()
/*     */   {
/*  34 */     return true;
/*     */   }
/*     */ 
/*     */   public String getAttribute(String s)
/*     */   {
/*  39 */     if (s != null)
/*     */     {
/*  41 */       String s1 = s.toUpperCase();
/*  42 */       String s2 = (String)this.m_attributes.get(s1);
/*  43 */       if (s2 != null) {
/*  44 */         return s2;
/*     */       }
/*  46 */       return new String("");
/*     */     }
/*     */ 
/*  49 */     return new String("");
/*     */   }
/*     */ 
/*     */   public String getAttribute(String s, String s1)
/*     */   {
/*  55 */     if (attributeExists(s)) {
/*  56 */       return getAttribute(s);
/*     */     }
/*  58 */     return s1;
/*     */   }
/*     */ 
/*     */   public String[] getAttributeList()
/*     */   {
/*  63 */     int i = this.m_attributes.size();
/*  64 */     String[] as = new String[i];
/*  65 */     int j = 0;
/*  66 */     for (Enumeration enumeration = this.m_attributes.keys(); enumeration.hasMoreElements(); )
/*     */     {
/*  68 */       as[j] = ((String)enumeration.nextElement());
/*  69 */       j++;
/*     */     }
/*     */ 
/*  72 */     return as;
/*     */   }
/*     */ 
/*     */   public int getIntAttribute(String s) throws NumberFormatException
/*     */   {
/*  77 */     if (attributeExists(s)) {
/*  78 */       return Integer.parseInt(getAttribute(s));
/*     */     }
/*  80 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getIntAttribute(String s, int i)
/*     */   {
/*  85 */     if (attributeExists(s)) {
/*     */       try
/*     */       {
/*  88 */         return Integer.parseInt(getAttribute(s));
/*     */       }
/*     */       catch (NumberFormatException _ex)
/*     */       {
/*  92 */         return i;
/*     */       }
/*     */     }
/*  95 */     return i;
/*     */   }
/*     */ 
/*     */   public String getSetting(String s)
/*     */   {
/* 100 */     if (s != null)
/*     */     {
/* 102 */       String s1 = s.toUpperCase();
/* 103 */       String s2 = (String)this.m_settings.get(s1);
/* 104 */       if (s2 != null) {
/* 105 */         return s2;
/*     */       }
/* 107 */       return new String("");
/*     */     }
/*     */ 
/* 110 */     return new String("");
/*     */   }
/*     */ 
/*     */   public void setAttribute(String key, String value)
/*     */   {
/* 116 */     this.m_attributes.put(key.toUpperCase(), value);
/*     */   }
/*     */ 
/*     */   private void initializeVariables(Hashtable hashtable, Hashtable hashtable1)
/*     */   {
/*     */     String s;
/* 122 */     for (Enumeration enumeration = hashtable.keys(); enumeration.hasMoreElements(); hashtable1.put(s.toUpperCase(), hashtable.get(s)))
/* 123 */       s = (String)enumeration.nextElement();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.html2pdf.Request
 * JD-Core Version:    0.6.2
 */