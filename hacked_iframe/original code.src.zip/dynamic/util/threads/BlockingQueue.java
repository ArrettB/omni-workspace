/*     */ package dynamic.util.threads;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ 
/*     */ public class BlockingQueue extends Queue
/*     */ {
/*  13 */   private boolean closed = false;
/*  14 */   private boolean rejectEnqueueRequests = false;
/*  15 */   private int waitingThreads = 0;
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/*  43 */     this.closed = true;
/*  44 */     notifyAll();
/*     */   }
/*     */ 
/*     */   public synchronized Object dequeue()
/*     */     throws Exception
/*     */   {
/*  63 */     if (this.closed) throw new Closed(null);
/*     */ 
/*  70 */     if (size() <= 0)
/*     */     {
/*  72 */       this.waitingThreads += 1;
/*  73 */       while (size() <= 0)
/*     */       {
/*  75 */         wait();
/*  76 */         if (this.closed)
/*     */         {
/*  78 */           this.waitingThreads -= 1;
/*  79 */           throw new Closed(null);
/*     */         }
/*     */       }
/*  82 */       this.waitingThreads -= 1;
/*     */     }
/*  84 */     Object head = super.dequeue();
/*  85 */     if ((size() == 0) && (this.rejectEnqueueRequests)) {
/*  86 */       close();
/*     */     }
/*  88 */     return head;
/*     */   }
/*     */ 
/*     */   public synchronized void enqueue(Object o)
/*     */     throws Exception
/*     */   {
/*  96 */     if ((this.closed) || (this.rejectEnqueueRequests))
/*  97 */       throw new Closed(null);
/*  98 */     super.enqueue(o);
/*  99 */     notify();
/*     */   }
/*     */ 
/*     */   public synchronized void enqueueFinalItem(Object o)
/*     */     throws Exception
/*     */   {
/* 109 */     enqueue(o);
/* 110 */     this.rejectEnqueueRequests = true;
/*     */   }
/*     */ 
/*     */   public synchronized int waitingThreads()
/*     */   {
/* 118 */     return this.waitingThreads;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 128 */       Queue q = new BlockingQueue();
/* 129 */       q.enqueue("foo");
/* 130 */       q.enqueue("bar");
/* 131 */       q.enqueue("test");
/* 132 */       Diagnostics.debug("" + q.size());
/* 133 */       Diagnostics.debug("" + q.dequeue());
/* 134 */       Diagnostics.debug("" + q.size());
/* 135 */       Diagnostics.debug("" + q.dequeue());
/* 136 */       Diagnostics.debug("" + q.size());
/* 137 */       Diagnostics.debug("" + q.dequeue());
/* 138 */       Diagnostics.debug("" + q.size());
/* 139 */       Diagnostics.debug("" + q.dequeue());
/* 140 */       Diagnostics.debug("" + q.size());
/* 141 */       System.exit(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 145 */       Diagnostics.error("Problem", e);
/* 146 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class Closed extends RuntimeException
/*     */   {
/*     */     private Closed()
/*     */     {
/*  24 */       super();
/*     */     }
/*     */ 
/*     */     Closed(BlockingQueue.1 x1)
/*     */     {
/*  20 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.threads.BlockingQueue
 * JD-Core Version:    0.6.2
 */