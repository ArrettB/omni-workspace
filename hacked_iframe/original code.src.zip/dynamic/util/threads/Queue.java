/*    */ package dynamic.util.threads;
/*    */ 
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Queue
/*    */   implements Serializable
/*    */ {
/* 14 */   private QueueItem head = null;
/* 15 */   private QueueItem tail = null;
/* 16 */   private int elementCount = 0;
/*    */ 
/*    */   public synchronized Object dequeue()
/*    */     throws Exception
/*    */   {
/* 31 */     if (this.head == null) return null;
/*    */ 
/* 33 */     Object result = this.head.item;
/*    */ 
/* 35 */     if (this.tail == this.head)
/*    */     {
/* 37 */       this.head = null;
/* 38 */       this.tail = null;
/* 39 */       this.elementCount = 0;
/*    */     }
/*    */     else
/*    */     {
/* 43 */       this.head = this.head.next;
/* 44 */       this.elementCount -= 1;
/*    */     }
/*    */ 
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   public synchronized void enqueue(Object o)
/*    */     throws Exception
/*    */   {
/* 56 */     QueueItem item = new QueueItem(o);
/* 57 */     this.elementCount += 1;
/*    */ 
/* 59 */     if (this.head == null)
/*    */     {
/* 61 */       this.head = item;
/* 62 */       this.tail = item;
/*    */     }
/*    */     else
/*    */     {
/* 66 */       this.tail.next = item;
/* 67 */       this.tail = this.tail.next;
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized int size()
/*    */   {
/* 77 */     return this.elementCount;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 87 */       Queue q = new Queue();
/* 88 */       q.enqueue("foo");
/* 89 */       q.enqueue("bar");
/* 90 */       q.enqueue("test");
/* 91 */       Diagnostics.debug("" + q.size());
/* 92 */       Diagnostics.debug("" + q.dequeue());
/* 93 */       Diagnostics.debug("" + q.size());
/* 94 */       Diagnostics.debug("" + q.dequeue());
/* 95 */       Diagnostics.debug("" + q.size());
/* 96 */       Diagnostics.debug("" + q.dequeue());
/* 97 */       Diagnostics.debug("" + q.size());
/* 98 */       Diagnostics.debug("" + q.dequeue());
/* 99 */       Diagnostics.debug("" + q.size());
/* 100 */       System.exit(0);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 104 */       Diagnostics.error("Problem", e);
/* 105 */       System.exit(1);
/*    */     }
/*    */   }
/*    */ 
/*    */   private class QueueItem
/*    */     implements Serializable
/*    */   {
/*    */     Object item;
/*    */     QueueItem next;
/*    */ 
/*    */     QueueItem(Object o)
/*    */     {
/* 22 */       this.item = o;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.threads.Queue
 * JD-Core Version:    0.6.2
 */