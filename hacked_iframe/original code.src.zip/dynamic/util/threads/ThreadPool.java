/*     */ package dynamic.util.threads;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ 
/*     */ public class ThreadPool extends ThreadGroup
/*     */ {
/*  44 */   private static int threadPoolIDSequence = 0;
/*  45 */   private int pooledThreadIDSequence = 0;
/*     */ 
/*  47 */   private int myThreadPoolID = 0;
/*  48 */   private final BlockingQueue pool = new BlockingQueue();
/*     */   private int maxThreads;
/*     */   private int runningThreads;
/*     */   private int numberThreads;
/*  52 */   private boolean hasClosed = false;
/*  53 */   private int threadPriority = 5;
/*     */ 
/*     */   public ThreadPool()
/*     */   {
/* 117 */     this(0);
/*     */   }
/*     */ 
/*     */   public ThreadPool(int threadCount)
/*     */   {
/* 126 */     this(threadCount, threadCount);
/*     */   }
/*     */ 
/*     */   public ThreadPool(int inititalThreadCount, int maxThreadCount)
/*     */   {
/* 139 */     this(inititalThreadCount, maxThreadCount, 5);
/*     */   }
/*     */ 
/*     */   public ThreadPool(int inititalThreadCount, int maxThreadCount, int priority)
/*     */   {
/* 153 */     this("ThreadPool", inititalThreadCount, maxThreadCount, priority);
/*     */   }
/*     */ 
/*     */   public ThreadPool(String name, int inititalThreadCount, int maxThreadCount, int priority)
/*     */   {
/* 173 */     super(name + getNextThreadPoolID());
/* 174 */     this.myThreadPoolID = threadPoolIDSequence;
/*     */ 
/* 176 */     if ((priority < 1) || (priority > 10))
/*     */     {
/* 178 */       throw new IllegalArgumentException("Invalid thread priority: " + priority);
/*     */     }
/* 180 */     this.threadPriority = priority;
/*     */ 
/* 183 */     this.maxThreads = (maxThreadCount > 0 ? maxThreadCount : 2147483647);
/* 184 */     this.numberThreads = Math.min(inititalThreadCount, this.maxThreads);
/* 185 */     int i = this.numberThreads;
/*     */     do {
/* 187 */       PooledThread t = new PooledThread();
/* 188 */       Diagnostics.registerThread(t, Diagnostics.getContext());
/* 189 */       t.start();
/*     */ 
/* 185 */       i--; } while (i >= 0);
/*     */   }
/*     */ 
/*     */   public static synchronized int getNextThreadPoolID()
/*     */   {
/* 198 */     return ++threadPoolIDSequence;
/*     */   }
/*     */ 
/*     */   public synchronized int getNextPooledThreadID()
/*     */   {
/* 206 */     return ++this.pooledThreadIDSequence;
/*     */   }
/*     */ 
/*     */   public synchronized int size()
/*     */   {
/* 214 */     return this.pool.size();
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/* 229 */     this.hasClosed = true;
/* 230 */     this.pool.close();
/*     */   }
/*     */ 
/*     */   public synchronized void execute(Object action)
/*     */     throws Exception
/*     */   {
/* 258 */     if (this.hasClosed) {
/* 259 */       throw new Closed();
/*     */     }
/* 261 */     if ((this.numberThreads < this.maxThreads) && (this.pool.waitingThreads() == 0))
/*     */     {
/* 263 */       synchronized (this.pool)
/*     */       {
/* 265 */         if ((this.numberThreads < this.maxThreads) && (this.pool.waitingThreads() == 0))
/*     */         {
/* 267 */           this.numberThreads += 1;
/* 268 */           PooledThread t = new PooledThread();
/* 269 */           Diagnostics.registerThread(t, Diagnostics.getContext());
/* 270 */           t.start();
/*     */         }
/* 272 */         this.pool.enqueue(action);
/*     */       }
/*     */     }
/*     */ 
/* 276 */     this.pool.enqueue(action);
/*     */   }
/*     */ 
/*     */   public synchronized void waitForCompletion()
/*     */   {
/* 285 */     while ((this.runningThreads > 0) || (this.pool.size() > 0))
/*     */       try {
/* 287 */         wait(); } catch (InterruptedException e) { break; }
/*     */ 
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 296 */     String result = super.toString();
/* 297 */     Thread[] t = new Thread[activeCount()];
/* 298 */     enumerate(t);
/* 299 */     for (int i = 0; i < t.length; i++)
/*     */     {
/* 301 */       if (t[i] == null) break;
/* 302 */       result = result + "\n" + t[i];
/*     */     }
/* 304 */     return result;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 339 */       Diagnostics.debug("Starting");
/* 340 */       ThreadPool pool = new ThreadPool(0, 10);
/* 341 */       Diagnostics.debug("Created " + pool);
/*     */ 
/* 343 */       for (int i = 1; i <= 20; i++)
/*     */       {
/* 345 */         Diagnostics.debug("Adding job " + i);
/* 346 */         pool.execute(new TestRunner(i));
/*     */       }
/*     */ 
/* 349 */       Diagnostics.debug("Waiting for threads to complete");
/* 350 */       pool.waitForCompletion();
/*     */ 
/* 352 */       Diagnostics.debug("Closing " + pool);
/* 353 */       pool.close();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 357 */       Diagnostics.error("Problem", t);
/*     */     }
/*     */     finally
/*     */     {
/* 361 */       Diagnostics.debug("Done");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TestRunner
/*     */     implements Runnable
/*     */   {
/*     */     private int i;
/*     */ 
/*     */     public TestRunner(int i)
/*     */     {
/* 314 */       this.i = i;
/*     */     }
/*     */ 
/*     */     public void run() {
/* 318 */       Diagnostics.debug("Starting " + this.i);
/*     */       try
/*     */       {
/* 321 */         Diagnostics.debug("Sleeping " + this.i);
/* 322 */         Thread.currentThread(); Thread.sleep(500L);
/*     */       }
/*     */       catch (BlockingQueue.Closed c)
/*     */       {
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 329 */         Diagnostics.error("Problem " + this.i, t);
/*     */       }
/* 331 */       Diagnostics.debug("Done " + this.i);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class Closed extends RuntimeException
/*     */   {
/*     */     Closed()
/*     */     {
/* 108 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PooledThread extends Thread
/*     */   {
/*     */     public PooledThread()
/*     */     {
/*  68 */       super("unnamed");
/*  69 */       setName("G" + ThreadPool.this.myThreadPoolID + "T" + ThreadPool.this.getNextPooledThreadID());
/*  70 */       setPriority(ThreadPool.this.threadPriority);
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/*  77 */         while (!ThreadPool.this.hasClosed)
/*     */         {
/*  79 */           Runnable r = (Runnable)ThreadPool.this.pool.dequeue();
/*  80 */           ThreadPool.access$404(ThreadPool.this);
/*  81 */           r.run();
/*  82 */           ThreadPool.access$406(ThreadPool.this);
/*  83 */           synchronized (ThreadPool.this)
/*     */           {
/*  85 */             ThreadPool.this.notify();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (BlockingQueue.Closed c)
/*     */       {
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  94 */         Diagnostics.error("Problems running PooledThread", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.threads.ThreadPool
 * JD-Core Version:    0.6.2
 */