/*     */ package dynamic.util.encryption;
/*     */ 
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class TEA
/*     */ {
/*     */   private int[] _key;
/*     */   private byte[] _keyBytes;
/*     */   private int _padding;
/*     */ 
/*     */   private static void print_usage()
/*     */   {
/* 116 */     System.err.println("Usage:");
/* 117 */     System.err.println("To encrypt data:");
/* 118 */     System.err.println("  dynamic.util.encryption.TEA -k key [-r radix] string");
/* 119 */     System.err.println("  dynamic.util.encryption.TEA -k key [-r radix] < file");
/* 120 */     System.err.println("To dencrypt data:");
/* 121 */     System.err.println("  dynamic.util.encryption.TEA -d -k key [-r radix] string");
/* 122 */     System.err.println("  dynamic.util.encryption.TEA -d -k key [-r radix] < file");
/*     */ 
/* 124 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 132 */     String key = null;
/* 133 */     String radix = "16";
/* 134 */     String target = "";
/* 135 */     boolean encode = true;
/*     */ 
/* 137 */     if ((args.length > 0) && (args[0].equals("-help"))) print_usage();
/*     */ 
/* 139 */     for (int i = 0; i < args.length; i++)
/*     */     {
/* 141 */       if (args[i].equals("-d"))
/* 142 */         encode = false;
/* 143 */       else if (args[i].equals("-k")) {
/* 144 */         if (args.length > i + 1) key = args[(++i)]; else print_usage(); 
/*     */       }
/* 145 */       else if (args[i].equals("-r")) {
/* 146 */         if ((args.length > i + 1) && (key != null)) radix = args[(++i)]; else print_usage(); 
/*     */       } else target = target + " " + args[i];
/*     */     }
/*     */ 
/* 150 */     if (key == null) print_usage();
/*     */ 
/* 152 */     target = target.trim();
/*     */ 
/* 154 */     TEA tea = new TEA(key, Integer.parseInt(radix));
/*     */ 
/* 156 */     if (target.length() == 0)
/*     */     {
/* 158 */       StringBuffer sb = new StringBuffer();
/* 159 */       int status = 0;
/* 160 */       while (status != -1)
/*     */       {
/* 162 */         status = System.in.read();
/* 163 */         if (status != -1) sb.append((char)status);
/*     */       }
/* 165 */       target = sb.toString();
/*     */     }
/*     */     String result;
/* 169 */     if (encode)
/* 170 */       result = tea.encodeString(target);
/*     */     else {
/* 172 */       result = tea.decodeString(target);
/*     */     }
/* 174 */     System.out.print(result);
/* 175 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   public TEA(long l)
/*     */   {
/* 180 */     this(new BigInteger("" + l));
/*     */   }
/*     */ 
/*     */   public TEA(String s)
/*     */   {
/* 185 */     this(s.getBytes());
/*     */   }
/*     */ 
/*     */   public TEA(String s, int radix)
/*     */   {
/* 190 */     this(new BigInteger(s, radix));
/*     */   }
/*     */ 
/*     */   public TEA(BigInteger bi)
/*     */   {
/* 195 */     this(bi.toByteArray());
/*     */   }
/*     */ 
/*     */   public TEA(byte[] key)
/*     */   {
/* 205 */     int keylen = key.length;
/*     */ 
/* 207 */     if (keylen != 16)
/*     */     {
/* 209 */       byte[] tmp = new byte[16];
/* 210 */       System.arraycopy(key, 0, tmp, 0, keylen > 16 ? 16 : keylen);
/* 211 */       key = tmp;
/* 212 */       keylen = key.length;
/*     */     }
/*     */ 
/* 215 */     this._key = new int[4];
/*     */ 
/* 217 */     int i = 0; for (int j = 0; j < 16; i++) {
/* 218 */       this._key[i] = (key[j] << 24 | (key[(j + 1)] & 0xFF) << 16 | (key[(j + 2)] & 0xFF) << 8 | key[(j + 3)] & 0xFF);
/*     */ 
/* 217 */       j += 4;
/*     */     }
/*     */ 
/* 220 */     this._keyBytes = key;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 228 */     String tea = getClass().getName();
/* 229 */     tea = tea + ": Tiny Encryption Algorithm key=" + StringUtil.toHex(new String(this._keyBytes));
/* 230 */     return tea;
/*     */   }
/*     */ 
/*     */   public int[] encipher(int[] v)
/*     */   {
/* 252 */     int y = v[0];
/* 253 */     int z = v[1];
/* 254 */     int sum = 0;
/* 255 */     int delta = -1640531527;
/* 256 */     int a = this._key[0];
/* 257 */     int b = this._key[1];
/* 258 */     int c = this._key[2];
/* 259 */     int d = this._key[3];
/* 260 */     int n = 32;
/*     */ 
/* 262 */     while (n-- > 0)
/*     */     {
/* 264 */       sum += delta;
/* 265 */       y += ((z << 4) + a ^ z + sum ^ (z >> 5) + b);
/* 266 */       z += ((y << 4) + c ^ y + sum ^ (y >> 5) + d);
/*     */     }
/*     */ 
/* 269 */     v[0] = y;
/* 270 */     v[1] = z;
/*     */ 
/* 272 */     return v;
/*     */   }
/*     */ 
/*     */   public int[] decipher(int[] v)
/*     */   {
/* 299 */     int y = v[0];
/* 300 */     int z = v[1];
/* 301 */     int sum = -957401312;
/* 302 */     int delta = -1640531527;
/* 303 */     int a = this._key[0];
/* 304 */     int b = this._key[1];
/* 305 */     int c = this._key[2];
/* 306 */     int d = this._key[3];
/* 307 */     int n = 32;
/*     */ 
/* 311 */     while (n-- > 0)
/*     */     {
/* 313 */       z -= ((y << 4) + c ^ y + sum ^ (y >> 5) + d);
/* 314 */       y -= ((z << 4) + a ^ z + sum ^ (z >> 5) + b);
/* 315 */       sum -= delta;
/*     */     }
/*     */ 
/* 318 */     v[0] = y;
/* 319 */     v[1] = z;
/*     */ 
/* 321 */     return v;
/*     */   }
/*     */ 
/*     */   public byte[] encipher(byte[] v)
/*     */   {
/* 333 */     byte y = v[0];
/* 334 */     byte z = v[1];
/* 335 */     int sum = 0;
/* 336 */     int delta = -1640531527;
/* 337 */     int a = this._key[0];
/* 338 */     int b = this._key[1];
/* 339 */     int c = this._key[2];
/* 340 */     int d = this._key[3];
/* 341 */     int n = 32;
/*     */ 
/* 343 */     while (n-- > 0)
/*     */     {
/* 345 */       sum += delta;
/* 346 */       y = (byte)(y + ((z << 4) + a ^ z + sum ^ (z >> 5) + b));
/* 347 */       z = (byte)(z + ((y << 4) + c ^ y + sum ^ (y >> 5) + d));
/*     */     }
/*     */ 
/* 350 */     v[0] = y;
/* 351 */     v[1] = z;
/*     */ 
/* 353 */     return v;
/*     */   }
/*     */ 
/*     */   public byte[] decipher(byte[] v)
/*     */   {
/* 365 */     byte y = v[0];
/* 366 */     byte z = v[1];
/* 367 */     int sum = -957401312;
/* 368 */     int delta = -1640531527;
/* 369 */     int a = this._key[0];
/* 370 */     int b = this._key[1];
/* 371 */     int c = this._key[2];
/* 372 */     int d = this._key[3];
/* 373 */     int n = 32;
/*     */ 
/* 377 */     while (n-- > 0)
/*     */     {
/* 379 */       z = (byte)(z - ((y << 4) + c ^ y + sum ^ (y >> 5) + d));
/* 380 */       y = (byte)(y - ((z << 4) + a ^ z + sum ^ (z >> 5) + b));
/* 381 */       sum -= delta;
/*     */     }
/*     */ 
/* 384 */     v[0] = y;
/* 385 */     v[1] = z;
/*     */ 
/* 387 */     return v;
/*     */   }
/*     */ 
/*     */   public int[] encode(byte[] b, int count)
/*     */   {
/* 406 */     int bLen = count;
/* 407 */     byte[] bp = b;
/*     */ 
/* 409 */     this._padding = (bLen % 8);
/* 410 */     if (this._padding != 0)
/*     */     {
/* 412 */       this._padding = (8 - bLen % 8);
/* 413 */       bp = new byte[bLen + this._padding];
/* 414 */       System.arraycopy(b, 0, bp, 0, bLen);
/* 415 */       bLen = bp.length;
/*     */     }
/*     */ 
/* 418 */     int intCount = bLen / 4;
/* 419 */     int[] r = new int[2];
/* 420 */     int[] out = new int[intCount];
/*     */ 
/* 422 */     int i = 0; for (int j = 0; j < bLen; i += 2)
/*     */     {
/* 426 */       r[0] = (bp[j] << 24 | (bp[(j + 1)] & 0xFF) << 16 | (bp[(j + 2)] & 0xFF) << 8 | bp[(j + 3)] & 0xFF);
/* 427 */       r[1] = (bp[(j + 4)] << 24 | (bp[(j + 5)] & 0xFF) << 16 | (bp[(j + 6)] & 0xFF) << 8 | bp[(j + 7)] & 0xFF);
/* 428 */       encipher(r);
/* 429 */       out[i] = r[0];
/* 430 */       out[(i + 1)] = r[1];
/*     */ 
/* 422 */       j += 8;
/*     */     }
/*     */ 
/* 433 */     return out;
/*     */   }
/*     */ 
/*     */   public int padding()
/*     */   {
/* 445 */     return this._padding;
/*     */   }
/*     */ 
/*     */   public byte[] decode(byte[] b, int count)
/*     */   {
/* 462 */     int intCount = count / 4;
/* 463 */     int[] ini = new int[intCount];
/* 464 */     int i = 0; for (int j = 0; i < intCount; j += 8)
/*     */     {
/* 466 */       ini[i] = (b[j] << 24 | (b[(j + 1)] & 0xFF) << 16 | (b[(j + 2)] & 0xFF) << 8 | b[(j + 3)] & 0xFF);
/* 467 */       ini[(i + 1)] = (b[(j + 4)] << 24 | (b[(j + 5)] & 0xFF) << 16 | (b[(j + 6)] & 0xFF) << 8 | b[(j + 7)] & 0xFF);
/*     */ 
/* 464 */       i += 2;
/*     */     }
/*     */ 
/* 469 */     return decode(ini);
/*     */   }
/*     */ 
/*     */   public byte[] decode(int[] b)
/*     */   {
/* 485 */     int intCount = b.length;
/*     */ 
/* 487 */     byte[] outb = new byte[intCount * 4];
/* 488 */     int[] tmp = new int[2];
/*     */ 
/* 492 */     int j = 0; for (int i = 0; i < intCount; j += 8)
/*     */     {
/* 494 */       tmp[0] = b[i];
/* 495 */       tmp[1] = b[(i + 1)];
/* 496 */       decipher(tmp);
/* 497 */       outb[j] = ((byte)(tmp[0] >>> 24));
/* 498 */       outb[(j + 1)] = ((byte)(tmp[0] >>> 16));
/* 499 */       outb[(j + 2)] = ((byte)(tmp[0] >>> 8));
/* 500 */       outb[(j + 3)] = ((byte)tmp[0]);
/* 501 */       outb[(j + 4)] = ((byte)(tmp[1] >>> 24));
/* 502 */       outb[(j + 5)] = ((byte)(tmp[1] >>> 16));
/* 503 */       outb[(j + 6)] = ((byte)(tmp[1] >>> 8));
/* 504 */       outb[(j + 7)] = ((byte)tmp[1]);
/*     */ 
/* 492 */       i += 2;
/*     */     }
/*     */ 
/* 507 */     return outb;
/*     */   }
/*     */ 
/*     */   public String encodeString(String s)
/*     */   {
/* 529 */     byte[] b = s.getBytes();
/* 530 */     int[] tmp = encode(b, b.length);
/* 531 */     int intCount = tmp.length;
/*     */ 
/* 533 */     byte[] result = new byte[intCount * 4];
/*     */ 
/* 535 */     int j = 0; for (int i = 0; i < intCount; j += 8)
/*     */     {
/* 537 */       result[j] = ((byte)(tmp[i] >>> 24));
/* 538 */       result[(j + 1)] = ((byte)(tmp[i] >>> 16));
/* 539 */       result[(j + 2)] = ((byte)(tmp[i] >>> 8));
/* 540 */       result[(j + 3)] = ((byte)tmp[i]);
/* 541 */       result[(j + 4)] = ((byte)(tmp[(i + 1)] >>> 24));
/* 542 */       result[(j + 5)] = ((byte)(tmp[(i + 1)] >>> 16));
/* 543 */       result[(j + 6)] = ((byte)(tmp[(i + 1)] >>> 8));
/* 544 */       result[(j + 7)] = ((byte)tmp[(i + 1)]);
/*     */ 
/* 535 */       i += 2;
/*     */     }
/*     */ 
/* 547 */     return Base64.encode(result);
/*     */   }
/*     */ 
/*     */   public String decodeString(String s)
/*     */   {
/* 556 */     byte[] result = Base64.decode(s);
/* 557 */     result = decode(result, result.length);
/* 558 */     int l = result.length;
/* 559 */     while ((l > 0) && (result[(l - 1)] == 0)) l--;
/* 560 */     return new String(result, 0, l);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.encryption.TEA
 * JD-Core Version:    0.6.2
 */