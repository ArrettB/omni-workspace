/*     */ package dynamic.util.encryption;
/*     */ 
/*     */ class PasswordData
/*     */ {
/* 104 */   static short[][][] tris = null;
/* 105 */   static long[] sigma = null;
/*     */ 
/*     */   PasswordData()
/*     */   {
/* 109 */     tris = new short[26][26][26];
/* 110 */     sigma = new long[1];
/* 111 */     PasswordDataDataInit1.fill(this);
/* 112 */     PasswordDataDataInit2.fill(this);
/* 113 */     for (int c1 = 0; c1 < 26; c1++)
/* 114 */       for (int c2 = 0; c2 < 26; c2++)
/* 115 */         for (int c3 = 0; c3 < 26; c3++)
/* 116 */           sigma[0] += tris[c1][c2][c3];
/*     */   }
/*     */ 
/*     */   void set(int x1, int x2, int x3, short v)
/*     */   {
/* 123 */     tris[x1][x2][x3] = v;
/*     */   }
/*     */ 
/*     */   long get(int x1, int x2, int x3) {
/* 127 */     return tris[x1][x2][x3];
/*     */   }
/*     */ 
/*     */   long getSigma() {
/* 131 */     return sigma[0];
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.encryption.PasswordData
 * JD-Core Version:    0.6.2
 */