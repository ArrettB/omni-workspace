/*    */ package dynamic.util.encryption;
/*    */ 
/*    */ import com.oreilly.servlet.Base64Decoder;
/*    */ import com.oreilly.servlet.Base64Encoder;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class Base64
/*    */ {
/*    */   public static String encode(byte[] bytes)
/*    */   {
/* 24 */     ByteArrayOutputStream out = new ByteArrayOutputStream((int)(bytes.length * 1.37D));
/* 25 */     Base64Encoder encodedOut = new Base64Encoder(out);
/*    */     try
/*    */     {
/* 29 */       encodedOut.write(bytes);
/* 30 */       encodedOut.close();
/*    */     } catch (IOException ignored) {
/* 32 */       return null;
/*    */     }
/* 34 */     return new String(out.toByteArray());
/*    */   }
/*    */ 
/*    */   public static byte[] decode(String s)
/*    */   {
/* 43 */     byte[] bytes = s.getBytes();
/* 44 */     Base64Decoder in = new Base64Decoder(new ByteArrayInputStream(bytes));
/* 45 */     ByteArrayOutputStream out = new ByteArrayOutputStream((int)(bytes.length * 0.67D));
/*    */     try {
/* 47 */       byte[] buf = new byte[4096];
/*    */       int bytesRead;
/* 49 */       while ((bytesRead = in.read(buf)) != -1)
/*    */       {
/*    */         int i;
/* 50 */         out.write(buf, 0, i);
/* 51 */       }out.close();
/*    */     } catch (IOException ignored) {
/* 53 */       return null;
/*    */     }
/* 55 */     return out.toByteArray();
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.encryption.Base64
 * JD-Core Version:    0.6.2
 */