/*    */ package dynamic.util.encryption;
/*    */ 
/*    */ import java.util.Random;
/*    */ 
/*    */ public class Password
/*    */ {
/* 14 */   int npw = 10;
/* 15 */   int pwl = 8;
/* 16 */   static PasswordData data = null;
/*    */   static final String alphabet = "abcdefghijklmnopqrstuvwxyz";
/*    */ 
/*    */   public Password()
/*    */   {
/* 20 */     if (data == null)
/*    */     {
/* 22 */       data = new PasswordData();
/*    */     }
/*    */   }
/*    */ 
/*    */   public String generate(int pwl)
/*    */   {
/* 30 */     int npw = 1;
/*    */ 
/* 32 */     long sum = 0L;
/*    */ 
/* 38 */     Random ran = new Random();
/*    */ 
/* 41 */     for (int pwnum = 0; pwnum < npw; )
/*    */     {
/* 43 */       StringBuffer password = new StringBuffer(pwl);
/* 44 */       double pik = ran.nextDouble();
/* 45 */       long ranno = ()(pik * data.getSigma());
/* 46 */       sum = 0L;
/*    */       int c2;
/*    */       int c3;
/* 47 */       for (int c1 = 0; c1 < 26; c1++)
/*    */       {
/* 49 */         for (c2 = 0; c2 < 26; c2++)
/*    */         {
/* 51 */           for (c3 = 0; c3 < 26; c3++)
/*    */           {
/* 53 */             sum += data.get(c1, c2, c3);
/* 54 */             if (sum > ranno)
/*    */             {
/* 56 */               password.append("abcdefghijklmnopqrstuvwxyz".charAt(c1));
/* 57 */               password.append("abcdefghijklmnopqrstuvwxyz".charAt(c2));
/* 58 */               password.append("abcdefghijklmnopqrstuvwxyz".charAt(c3));
/* 59 */               c1 = 26;
/* 60 */               c2 = 26;
/* 61 */               c3 = 26;
/*    */             }
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 68 */       int nchar = 3;
/* 69 */       while (nchar < pwl)
/*    */       {
/* 71 */         c1 = "abcdefghijklmnopqrstuvwxyz".indexOf(password.charAt(nchar - 2));
/* 72 */         c2 = "abcdefghijklmnopqrstuvwxyz".indexOf(password.charAt(nchar - 1));
/* 73 */         sum = 0L;
/* 74 */         for (c3 = 0; c3 < 26; c3++)
/* 75 */           sum += data.get(c1, c2, c3);
/* 76 */         if (sum == 0L)
/*    */         {
/*    */           break;
/*    */         }
/* 80 */         pik = ran.nextDouble();
/* 81 */         ranno = ()(pik * sum);
/* 82 */         sum = 0L;
/* 83 */         for (c3 = 0; c3 < 26; c3++)
/*    */         {
/* 85 */           sum += data.get(c1, c2, c3);
/* 86 */           if (sum > ranno)
/*    */           {
/* 88 */             password.append("abcdefghijklmnopqrstuvwxyz".charAt(c3));
/* 89 */             c3 = 26;
/*    */           }
/*    */         }
/* 92 */         nchar++;
/*    */       }
/* 94 */       return password.toString();
/*    */     }
/* 96 */     return null;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.encryption.Password
 * JD-Core Version:    0.6.2
 */