/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import dynamic.util.date.DateMath;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class CreditCardInfo
/*     */ {
/*  17 */   public static int CCI_NO_ERROR = 0;
/*  18 */   public static int CCI_ERR_NAME_ON_CARD = 1;
/*  19 */   public static int CCI_ERR_NUMBER_VERIFY = 2;
/*  20 */   public static int CCI_ERR_NUMBER_ISSUER = 3;
/*  21 */   public static int CCI_ERR_EXPIRE = 4;
/*  22 */   public static int CCI_ERR_EXPIRE_FORMAT = 5;
/*     */   private String accountNumber;
/*     */   private String cardType;
/*     */   private String expYear;
/*     */   private String expMonth;
/*     */   private String nameOnCard;
/*     */   private String errorMessage;
/*  45 */   private int errorCode = CCI_NO_ERROR;
/*     */ 
/*     */   public CreditCardInfo()
/*     */   {
/*  26 */     this("", "", "", "", "");
/*     */   }
/*     */ 
/*     */   public CreditCardInfo(String accountNumber, String cardType, String expYear, String expMonth, String nameOnCard)
/*     */   {
/*  31 */     this.accountNumber = accountNumber;
/*  32 */     this.cardType = cardType;
/*  33 */     this.expYear = expYear;
/*  34 */     this.expMonth = expMonth;
/*  35 */     this.nameOnCard = nameOnCard;
/*     */   }
/*     */ 
/*     */   public String getAccountNumber()
/*     */   {
/*  49 */     return this.accountNumber;
/*     */   }
/*     */ 
/*     */   public String getCleanAccountNumber()
/*     */   {
/*  54 */     return cleaner(this.accountNumber);
/*     */   }
/*     */ 
/*     */   public String getCardType()
/*     */   {
/*  59 */     return this.cardType;
/*     */   }
/*     */ 
/*     */   public String getExpYear()
/*     */   {
/*  64 */     return this.expYear;
/*     */   }
/*     */ 
/*     */   public String getExpMonth()
/*     */   {
/*  69 */     return this.expMonth;
/*     */   }
/*     */ 
/*     */   public String getNameOnCard()
/*     */   {
/*  74 */     return this.nameOnCard;
/*     */   }
/*     */ 
/*     */   public void setAccountNumber(String s)
/*     */   {
/*  79 */     this.accountNumber = s;
/*     */   }
/*     */ 
/*     */   public void setCardType(String s)
/*     */   {
/*  84 */     this.cardType = s;
/*     */   }
/*     */ 
/*     */   public void setExpYear(String s)
/*     */   {
/*  89 */     this.expYear = s;
/*     */   }
/*     */ 
/*     */   public void setExpMonth(String s)
/*     */   {
/*  94 */     this.expMonth = s;
/*     */   }
/*     */ 
/*     */   public void setNameOnCard(String s)
/*     */   {
/*  99 */     this.nameOnCard = s;
/*     */   }
/*     */ 
/*     */   public String getErrorMessage()
/*     */   {
/* 107 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   public int getErrorCode()
/*     */   {
/* 115 */     return this.errorCode;
/*     */   }
/*     */ 
/*     */   public boolean isValid()
/*     */   {
/* 127 */     String parsedCardNumber = cleaner(this.accountNumber);
/*     */ 
/* 129 */     boolean failed = false;
/* 130 */     String failMessage = "";
/* 131 */     int failCode = CCI_NO_ERROR;
/*     */     try
/*     */     {
/* 141 */       if ((this.nameOnCard == null) || (this.nameOnCard.equals("")))
/*     */       {
/* 143 */         failed = true;
/* 144 */         failMessage = "Please fill out the name as it appears on the card.";
/* 145 */         failCode = CCI_ERR_NAME_ON_CARD;
/*     */       }
/*     */ 
/* 149 */       if (!failed)
/*     */       {
/* 151 */         if (!CreditCardUtility.validCC(parsedCardNumber))
/*     */         {
/* 153 */           failed = true;
/* 154 */           failMessage = "Your credit card number could not be verified.  Please make sure you have typed it in correctly and try again.";
/* 155 */           failCode = CCI_ERR_NUMBER_VERIFY;
/*     */         }
/*     */       }
/*     */ 
/* 159 */       if (!failed)
/*     */       {
/* 161 */         String actualType = CreditCardUtility.getCardName(CreditCardUtility.getCardID(parsedCardNumber));
/* 162 */         if (!actualType.equalsIgnoreCase(this.cardType))
/*     */         {
/* 164 */           failed = true;
/* 165 */           failMessage = "Your credit card number could not be verified with your issuer.  Please make sure you have typed it in correctly and try again.";
/* 166 */           failCode = CCI_ERR_NUMBER_ISSUER;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 172 */       failed = true;
/* 173 */       failMessage = "Your credit card number could not be verified.  Please make sure you have typed it in correctly and try again.";
/* 174 */       failCode = CCI_ERR_NUMBER_VERIFY;
/*     */     }
/*     */ 
/* 179 */     if (!failed)
/*     */     {
/*     */       try
/*     */       {
/* 183 */         int month = Integer.parseInt(this.expMonth);
/* 184 */         int year = Integer.parseInt(this.expYear);
/* 185 */         if (year < 100) {
/* 186 */           year = DateMath.fixYear(year);
/*     */         }
/* 188 */         Date today = new Date();
/* 189 */         Date expires = new Date();
/* 190 */         expires = DateMath.setMonth(expires, month);
/* 191 */         expires = DateMath.setYear(expires, year);
/* 192 */         expires = DateMath.lastDayOfMonth(expires);
/*     */ 
/* 194 */         if (today.after(expires))
/*     */         {
/* 196 */           failed = true;
/* 197 */           failMessage = "This card has expired.  Please try another one.";
/* 198 */           failCode = CCI_ERR_EXPIRE;
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/* 204 */         failed = true;
/* 205 */         failMessage = "Please enter your expiration date and try again.";
/* 206 */         failCode = CCI_ERR_EXPIRE_FORMAT;
/*     */       }
/*     */     }
/*     */ 
/* 210 */     if (failed)
/*     */     {
/* 212 */       this.errorMessage = failMessage;
/* 213 */       this.errorCode = failCode;
/* 214 */       return false;
/*     */     }
/*     */ 
/* 218 */     this.errorMessage = null;
/* 219 */     this.errorCode = CCI_NO_ERROR;
/* 220 */     return true;
/*     */   }
/*     */ 
/*     */   public String cleaner(String acctNum)
/*     */   {
/* 229 */     char[] temp = acctNum.toCharArray();
/* 230 */     StringBuffer parsedCardNumber = new StringBuffer();
/* 231 */     for (int i = 0; i < temp.length; i++)
/*     */     {
/* 233 */       if (Character.isDigit(temp[i]))
/*     */       {
/* 235 */         parsedCardNumber.append(temp[i]);
/*     */       }
/*     */     }
/* 238 */     return parsedCardNumber.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.CreditCardInfo
 * JD-Core Version:    0.6.2
 */