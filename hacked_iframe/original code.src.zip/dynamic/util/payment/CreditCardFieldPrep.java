/*    */ package dynamic.util.payment;
/*    */ 
/*    */ public class CreditCardFieldPrep
/*    */ {
/* 12 */   static String GOODNUMBERCHARACTERS = "1234567890";
/*    */ 
/*    */   public static String creditCardNumber(String val)
/*    */   {
/* 23 */     char[] cleanedCardNum = val.trim().toCharArray();
/* 24 */     int tgtIdx = 0;
/* 25 */     for (int i = 0; i < cleanedCardNum.length; i++)
/*    */     {
/* 27 */       if (GOODNUMBERCHARACTERS.indexOf(cleanedCardNum[i]) >= 0)
/*    */       {
/* 29 */         cleanedCardNum[(tgtIdx++)] = cleanedCardNum[i];
/*    */       }
/*    */     }
/* 32 */     return new String(cleanedCardNum, 0, tgtIdx);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.CreditCardFieldPrep
 * JD-Core Version:    0.6.2
 */