/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.servlet.http.HttpUtils;
/*     */ 
/*     */ public class CambistAuth
/*     */ {
/*     */   String merchantConfFile;
/*     */   SecureHttpPostRaw goSecure;
/*  62 */   static BufferedReader pauser = new BufferedReader(new InputStreamReader(System.in));
/*     */ 
/*  64 */   static String RETURNURL = "DumMmY";
/*     */ 
/*  70 */   String avsCode = "";
/*     */ 
/*  75 */   public static int AVS_ADDRESS = 1;
/*     */ 
/*  79 */   public static int AVS_ZIP = 2;
/*     */ 
/*  83 */   public static int AVS_BOTH = AVS_ADDRESS | AVS_ZIP;
/*     */ 
/*  87 */   public static int AVS_EITHER = 4;
/*     */ 
/*  91 */   public static int AVS_OFF = 0;
/*     */ 
/*  96 */   public static String ERR_CCAUTHHOST = "CCAUTHHOST";
/*     */ 
/* 100 */   public static String ERR_CCAUTHHOSTADDR = "CCAUTHHOSTADDRESS";
/*     */ 
/* 104 */   public static String ERR_CCNOTIMP = "CCNOTIMPLEMENTED";
/*     */ 
/* 108 */   public static String ERR_REQFIELD = "CCREQFIELD";
/*     */ 
/* 112 */   public static String ERR_DENIED = "CCDENIED";
/*     */   String transactionID;
/*     */   String retVal;
/* 125 */   public static String AUTHONLY = "Book";
/*     */ 
/* 129 */   public static String MAUTHCAPTURE = "Sale";
/*     */   private String amount;
/*     */   private String cardNumber;
/*     */   private String expMonth;
/*     */   private String expYear;
/*     */   private String cardFName;
/*     */   private String cardLName;
/*     */   private String addr;
/*     */   private String city;
/*     */   private String state;
/*     */   private String zip;
/*     */   private String country;
/*     */ 
/*     */   public CambistAuth(String merchantConfFile)
/*     */   {
/* 154 */     this(merchantConfFile, "");
/*     */   }
/*     */ 
/*     */   public CambistAuth(String merchantConfFile, String transactionID)
/*     */   {
/* 166 */     this.merchantConfFile = merchantConfFile;
/*     */ 
/* 168 */     if (transactionID == null)
/* 169 */       transactionID = "";
/* 170 */     this.transactionID = transactionID; } 
/* 193 */   private String getAuth(String authType, String amount, String cardNumber, String expMonth, String expYear, String cardFName, String cardLName, String addr, String city, String state, String zip, String country) throws PaymentException { initAuth(authType);
/*     */ 
/* 195 */     this.amount = amount;
/* 196 */     addRequired("fulltotal", amount);
/* 197 */     this.cardNumber = CreditCardFieldPrep.creditCardNumber(cardNumber);
/* 198 */     addRequired("BillCreditCard", this.cardNumber);
/* 199 */     this.expMonth = expMonth;
/* 200 */     addRequired("ExpirationMonth", expMonth);
/* 201 */     this.expYear = expYear;
/* 202 */     addRequired("ExpirationYear", expYear);
/*     */ 
/* 204 */     this.cardFName = cardFName;
/* 205 */     this.cardLName = cardLName;
/* 206 */     addOptional("BillName", getBillName(cardFName, cardLName));
/* 207 */     this.addr = addr;
/* 208 */     addOptional("BillStreet", addr);
/* 209 */     this.city = city;
/* 210 */     addOptional("BillCity", city);
/* 211 */     this.state = state;
/* 212 */     addOptional("BillState", state);
/* 213 */     this.zip = zip;
/* 214 */     addOptional("BillZip", zip);
/* 215 */     this.country = country;
/* 216 */     addOptional("BillCountry", country);
/* 217 */     addOptional("BillPhone", "NONE");
/* 218 */     addOptional("BillEmail", "NONE");
/*     */     String rawRet;
/*     */     try { rawRet = this.goSecure.connect(); }
/*     */     catch (IOException e)
/*     */     {
/* 226 */       throw new PaymentException(ERR_CCAUTHHOST, "Unable to connect to the CC Authorization host: " + e);
/*     */     }
/*     */ 
/* 229 */     return rawRet;
/*     */   }
/*     */ 
/*     */   public void getAuthOnly(String amount, String cardNumber, String expMonth, String expYear, String cardFName, String cardLName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 241 */     String results = getAuth(AUTHONLY, amount, cardNumber, expMonth, expYear, cardFName, cardLName, addr, city, state, zip, country);
/* 242 */     this.transactionID = processRawResults(results);
/*     */   }
/*     */ 
/*     */   public void getAuthCapture(String amount, String cardNumber, String expMonth, String expYear, String cardFName, String cardLName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 253 */     String results = getAuth(MAUTHCAPTURE, amount, cardNumber, expMonth, expYear, cardFName, cardLName, addr, city, state, zip, country);
/* 254 */     this.transactionID = processRawResults(results);
/*     */   }
/*     */ 
/*     */   public void postAuth(String amount)
/*     */     throws PaymentException
/*     */   {
/* 277 */     throw new PaymentException(ERR_CCNOTIMP, "CambistAuth.postAuth() Post authorization not implemented.");
/*     */   }
/*     */ 
/*     */   public void postAuth(String transactionId, String amount)
/*     */     throws PaymentException
/*     */   {
/* 314 */     throw new PaymentException(ERR_CCNOTIMP, "CambistAuth.postAuth() Post authorization not implemented.");
/*     */   }
/*     */ 
/*     */   public void returnOrder(String amount, String cardNumber, String expMonth, String expYear)
/*     */     throws PaymentException
/*     */   {
/* 329 */     returnOrder(amount, cardNumber, expMonth, expYear, null, null);
/*     */   }
/*     */ 
/*     */   public void returnOrder(String amount, String cardNumber, String expMonth, String expYear, String cardFName, String cardLName)
/*     */     throws PaymentException
/*     */   {
/* 367 */     throw new PaymentException(ERR_CCNOTIMP, "CambistAuth.returnOrder() Credit not implemented.");
/*     */   }
/*     */ 
/*     */   public void voidOrder()
/*     */     throws PaymentException
/*     */   {
/* 376 */     voidOrder(this.amount, this.cardNumber, this.expMonth, this.expYear, this.cardFName, this.cardLName, this.addr, this.city, this.state, this.zip, this.country);
/*     */   }
/*     */ 
/*     */   public void voidOrder(String amount, String cardNumber, String expMonth, String expYear, String cardFName, String cardLName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 399 */     initAuth("Void");
/* 400 */     addRequired("fulltotal", amount);
/* 401 */     addRequired("BillCreditCard", cardNumber);
/* 402 */     addRequired("ExpirationMonth", expMonth);
/* 403 */     addRequired("ExpirationYear", expYear);
/* 404 */     addOptional("BillName", getBillName(cardFName, cardLName));
/* 405 */     addOptional("BillStreet", addr);
/* 406 */     addOptional("BillCity", city);
/* 407 */     addOptional("BillState", state);
/* 408 */     addOptional("BillZip", zip);
/* 409 */     addOptional("BillCountry", country);
/* 410 */     addOptional("BillPhone", "NONE");
/* 411 */     addOptional("BillEmail", "NONE");
/*     */     String results;
/*     */     try
/*     */     {
/* 416 */       results = this.goSecure.connect();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 420 */       throw new PaymentException(ERR_CCAUTHHOST, "Unable to connect to the CC Authorization host: " + e);
/*     */     }
/* 422 */     processRawResults(results);
/*     */   }
/*     */ 
/*     */   public String getOrderId()
/*     */   {
/* 435 */     return this.transactionID;
/*     */   }
/*     */ 
/*     */   public boolean isAddressVerified(int requirements)
/*     */   {
/* 449 */     boolean returnval = false;
/* 450 */     if (requirements == AVS_OFF)
/*     */     {
/* 452 */       returnval = true;
/*     */     }
/* 454 */     else if (requirements == AVS_BOTH)
/*     */     {
/* 459 */       if ((this.avsCode.equals("X")) || (this.avsCode.equals("Y")) || (this.avsCode.equals("S")))
/* 460 */         returnval = true;
/*     */     }
/* 462 */     else if (requirements == AVS_EITHER)
/*     */     {
/* 464 */       if ((!this.avsCode.equals("N")) && (!this.avsCode.equals("R")) && (!this.avsCode.equals("E")))
/* 465 */         returnval = true;
/*     */     }
/* 467 */     else if (requirements == AVS_ADDRESS)
/*     */     {
/* 473 */       if ((this.avsCode.equals("A")) || (this.avsCode.equals("X")) || (this.avsCode.equals("S")) || (this.avsCode.equals("Y")))
/* 474 */         returnval = true;
/*     */     }
/* 476 */     else if (requirements == AVS_ZIP)
/*     */     {
/* 483 */       if ((this.avsCode.equals("W")) || (this.avsCode.equals("X")) || (this.avsCode.equals("S")) || (this.avsCode.equals("Y")) || (this.avsCode.equals("Z"))) {
/* 484 */         returnval = true;
/*     */       }
/*     */     }
/* 487 */     return returnval;
/*     */   }
/*     */ 
/*     */   private void addRequired(String field, String value)
/*     */     throws PaymentException
/*     */   {
/* 498 */     if ((value == null) || (value.length() == 0))
/* 499 */       throw new PaymentException(ERR_REQFIELD, "The required CC Auth field " + field + " is empty.");
/* 500 */     this.goSecure.addField(field, value);
/*     */   }
/*     */ 
/*     */   private void addOptional(String field, String value)
/*     */   {
/* 509 */     if ((value != null) && (value.length() > 0))
/* 510 */       this.goSecure.addField(field, value);
/*     */   }
/*     */ 
/*     */   private void initAuth(String authType)
/*     */     throws PaymentException
/*     */   {
/*     */     try
/*     */     {
/* 522 */       MerchantAuthInfo merchInfo = new MerchantAuthInfo(this.merchantConfFile);
/*     */ 
/* 525 */       this.goSecure = new SecureHttpPostRaw(merchInfo.getMerchantAddress());
/* 526 */       addRequired("form_action", "AUTHORIZE PAYMENT");
/*     */ 
/* 529 */       addRequired("customerid", "133");
/* 530 */       addRequired("TransactionType", authType);
/* 531 */       addRequired("MerchantFormAction", RETURNURL);
/* 532 */       this.goSecure.addField("MerchantName", merchInfo.getMerchantLogin());
/* 533 */       this.goSecure.addField("MerchantID", merchInfo.getMerchantPassword());
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 537 */       throw new PaymentException(ERR_CCAUTHHOSTADDR, "Unable to resolve the CC Authorization host address: " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String processRawResults(String results)
/*     */     throws PaymentException
/*     */   {
/* 570 */     this.retVal = results;
/* 571 */     Diagnostics.debug("CambistAuth.processRawResults() " + results);
/*     */ 
/* 574 */     int begParams = results.indexOf(RETURNURL);
/* 575 */     int endParams = results.indexOf("\"", begParams);
/* 576 */     String params = results.substring(begParams + RETURNURL.length() + 1, endParams);
/*     */ 
/* 578 */     Hashtable response = HttpUtils.parseQueryString(params);
/* 579 */     String[] mstatus = (String[])response.get("approved");
/* 580 */     String[] transactionID = (String[])response.get("approval_code");
/* 581 */     Enumeration keys = response.keys();
/* 582 */     while (keys.hasMoreElements())
/*     */     {
/* 584 */       String key = (String)keys.nextElement();
/* 585 */       Diagnostics.debug("CambistAuth.processRawResults() " + key + "=" + ((String[])response.get(key))[0]);
/*     */     }
/*     */ 
/* 588 */     if (mstatus[0].equals("N"))
/*     */     {
/* 591 */       throw new PaymentException(ERR_DENIED, "Approval was denied.");
/*     */     }
/*     */ 
/* 596 */     String tranID = "";
/* 597 */     if (transactionID != null)
/*     */     {
/* 599 */       tranID = transactionID[0].substring(0, 6);
/* 600 */       this.avsCode = transactionID[0].substring(6, 7);
/*     */     }
/*     */ 
/* 603 */     return tranID;
/*     */   }
/*     */ 
/*     */   public String getBillName(String cardFName, String cardLName)
/*     */   {
/* 613 */     String billName = "";
/* 614 */     if (((cardFName != null ? 1 : 0) & (cardFName.length() > 0 ? 1 : 0)) != 0)
/*     */     {
/* 616 */       billName = cardFName;
/*     */     }
/* 618 */     if (((cardLName != null ? 1 : 0) & (cardLName.length() > 0 ? 1 : 0)) != 0)
/*     */     {
/* 620 */       if (billName != null)
/* 621 */         billName = billName + " ";
/* 622 */       billName = billName + cardLName;
/*     */     }
/* 624 */     return billName;
/*     */   }
/*     */ 
/*     */   public void debugPrint()
/*     */   {
/* 632 */     Diagnostics.debug("CambistAuth.debugPrint() retVal = " + this.retVal);
/*     */   }
/*     */ 
/*     */   private static void presskey()
/*     */   {
/*     */     try
/*     */     {
/* 642 */       Diagnostics.debug("CambistAuth.presskey() Please press the enter key to continue.");
/* 643 */       String in = pauser.readLine();
/* 644 */       if (in.length() > 0)
/*     */       {
/* 646 */         Diagnostics.debug("CambistAuth.presskey() Stopped by user");
/* 647 */         System.exit(1);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 652 */       Diagnostics.error("Problem with CambistAuth.presskey()", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/* 662 */     String demoAmt = "1.00";
/* 663 */     Diagnostics.debug("CambistAuth.main()");
/* 664 */     presskey();
/*     */ 
/* 666 */     CambistAuth ca = new CambistAuth("lib/plive.obj");
/*     */     try
/*     */     {
/* 673 */       ca.getAuthCapture(demoAmt, "4798 1717 3700 0733", "4", "2000", "Blake", "Von Haden", "505 North Highway 169", "Minneapolis", "Minnesota", "55441", "USA");
/*     */ 
/* 687 */       ca.debugPrint();
/* 688 */       Diagnostics.debug("CambistAuth.main() transaction ID = " + ca.getOrderId());
/* 689 */       Diagnostics.debug("CambistAuth.main() AVS address = " + ca.isAddressVerified(AVS_ADDRESS));
/* 690 */       Diagnostics.debug("CambistAuth.main() AVS zip = " + ca.isAddressVerified(AVS_ZIP));
/* 691 */       Diagnostics.debug("CambistAuth.main() AVS either = " + ca.isAddressVerified(AVS_EITHER));
/* 692 */       Diagnostics.debug("CambistAuth.main() AVS both = " + ca.isAddressVerified(AVS_BOTH));
/* 693 */       Diagnostics.debug("CambistAuth.main() AVS not required = " + ca.isAddressVerified(AVS_OFF));
/* 694 */       presskey();
/*     */ 
/* 696 */       ca.voidOrder();
/* 697 */       ca.debugPrint();
/* 698 */       presskey();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 739 */       Diagnostics.error("Problem in CambistAuth.main()", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.CambistAuth
 * JD-Core Version:    0.6.2
 */