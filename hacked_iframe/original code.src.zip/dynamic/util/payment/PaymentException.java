/*    */ package dynamic.util.payment;
/*    */ 
/*    */ public class PaymentException extends Exception
/*    */ {
/*    */   String errcode;
/*    */ 
/*    */   public PaymentException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PaymentException(String msg)
/*    */   {
/* 23 */     super(msg);
/*    */   }
/*    */ 
/*    */   public PaymentException(String errcode, String msg)
/*    */   {
/* 33 */     super(msg);
/* 34 */     this.errcode = errcode;
/*    */   }
/*    */ 
/*    */   public String getErrorCode()
/*    */   {
/* 43 */     return this.errcode;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.PaymentException
 * JD-Core Version:    0.6.2
 */