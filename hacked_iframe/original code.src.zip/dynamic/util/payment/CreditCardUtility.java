/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ 
/*     */ public class CreditCardUtility
/*     */ {
/*     */   public static final int INVALID = -1;
/*     */   public static final int VISA = 0;
/*     */   public static final int MASTERCARD = 1;
/*     */   public static final int AMERICAN_EXPRESS = 2;
/*     */   public static final int EN_ROUTE = 3;
/*     */   public static final int DINERS_CLUB = 4;
/*  21 */   private static final String[] cardNames = { "Visa", "Mastercard", "American Express", "En Route", "Diner's CLub/Carte Blanche", "Discover" };
/*     */ 
/*     */   public static boolean validCC(String number)
/*     */     throws Exception
/*     */   {
/*     */     int CardID;
/*  36 */     if ((CardID = getCardID(number)) != -1)
/*     */     {
/*  38 */       return validCCNumber(number);
/*     */     }
/*  40 */     return false;
/*     */   }
/*     */ 
/*     */   public static int getCardID(String number)
/*     */   {
/*  54 */     int valid = -1;
/*     */ 
/*  56 */     if (number.length() >= 4)
/*     */     {
/*  59 */       String digit1 = number.substring(0, 1);
/*  60 */       String digit2 = number.substring(0, 2);
/*  61 */       String digit3 = number.substring(0, 3);
/*  62 */       String digit4 = number.substring(0, 4);
/*     */ 
/*  64 */       if (isNumber(number))
/*     */       {
/*  69 */         if (digit1.equals("4")) {
/*  70 */           if ((number.length() == 13) || (number.length() == 16)) {
/*  71 */             valid = 0;
/*     */           }
/*     */ 
/*     */         }
/*  77 */         else if ((digit2.compareTo("51") >= 0) && (digit2.compareTo("55") <= 0)) {
/*  78 */           if (number.length() == 16) {
/*  79 */             valid = 1;
/*     */           }
/*     */ 
/*     */         }
/*  85 */         else if ((digit2.equals("34")) || (digit2.equals("37"))) {
/*  86 */           if (number.length() == 15) {
/*  87 */             valid = 2;
/*     */           }
/*     */ 
/*     */         }
/*  93 */         else if ((digit4.equals("2014")) || (digit4.equals("2149"))) {
/*  94 */           if (number.length() == 15) {
/*  95 */             valid = 3;
/*     */           }
/*     */ 
/*     */         }
/* 101 */         else if ((digit2.equals("36")) || (digit2.equals("38")) || ((digit3.compareTo("300") >= 0) && (digit3.compareTo("305") <= 0)))
/*     */         {
/* 103 */           if (number.length() == 14)
/* 104 */             valid = 4;
/*     */         }
/*     */       }
/*     */     }
/* 108 */     return valid;
/*     */   }
/*     */ 
/*     */   public static boolean isNumber(String n)
/*     */   {
/*     */     try
/*     */     {
/* 115 */       double d = Double.valueOf(n).doubleValue();
/* 116 */       return true;
/*     */     }
/*     */     catch (NumberFormatException e) {
/*     */     }
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   public static String getCardName(int id)
/*     */   {
/* 126 */     return (id > -1) && (id < cardNames.length) ? cardNames[id] : "";
/*     */   }
/*     */ 
/*     */   public static boolean validCCNumber(String n)
/*     */   {
/*     */     try
/*     */     {
/* 136 */       int j = n.length();
/*     */ 
/* 138 */       String[] s1 = new String[j];
/* 139 */       for (int i = 0; i < n.length(); i++) s1[i] = ("" + n.charAt(i));
/*     */ 
/* 141 */       int checksum = 0;
/*     */ 
/* 143 */       for (int i = s1.length - 1; i >= 0; i -= 2)
/*     */       {
/* 145 */         int k = 0;
/*     */ 
/* 147 */         if (i > 0)
/*     */         {
/* 149 */           k = Integer.valueOf(s1[(i - 1)]).intValue() * 2;
/* 150 */           if (k > 9)
/*     */           {
/* 152 */             String s = "" + k;
/* 153 */             k = Integer.valueOf(s.substring(0, 1)).intValue() + Integer.valueOf(s.substring(1)).intValue();
/*     */           }
/*     */ 
/* 156 */           checksum += Integer.valueOf(s1[i]).intValue() + k;
/*     */         }
/*     */         else
/*     */         {
/* 160 */           checksum += Integer.valueOf(s1[0]).intValue();
/*     */         }
/*     */       }
/* 163 */       return checksum % 10 == 0;
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 167 */     return false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 178 */     String aCard = "";
/*     */ 
/* 180 */     if (args.length > 0) {
/* 181 */       aCard = args[0];
/*     */     } else {
/* 183 */       BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
/*     */ 
/* 185 */       Diagnostics.debug("Card number : ");
/* 186 */       aCard = input.readLine();
/*     */     }
/* 188 */     if (getCardID(aCard) > -1) {
/* 189 */       Diagnostics.debug("This card is supported.");
/* 190 */       Diagnostics.debug("This a " + getCardName(getCardID(aCard)));
/* 191 */       Diagnostics.debug("The card number " + aCard + " is " + (validCC(aCard) ? " good." : " bad."));
/*     */     }
/*     */     else {
/* 194 */       Diagnostics.debug("This card is invalid or unsupported!");
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.CreditCardUtility
 * JD-Core Version:    0.6.2
 */