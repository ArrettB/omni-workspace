/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import com.sun.net.ssl.internal.ssl.Provider;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.Security;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class SecureHttpPostRaw
/*     */ {
/*     */   URL url;
/*     */   StringBuffer messageBody;
/*     */ 
/*     */   public SecureHttpPostRaw()
/*     */   {
/*  42 */     this.messageBody = new StringBuffer();
/*     */   }
/*     */ 
/*     */   public SecureHttpPostRaw(URL url)
/*     */   {
/*  47 */     this.messageBody = new StringBuffer();
/*  48 */     setUrl(url);
/*     */   }
/*     */ 
/*     */   public SecureHttpPostRaw(String strUrl) throws MalformedURLException
/*     */   {
/*  53 */     this.messageBody = new StringBuffer();
/*  54 */     setUrl(strUrl);
/*     */   }
/*     */ 
/*     */   public void setUrl(URL url)
/*     */   {
/*  59 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public void setUrl(String strUrl) throws MalformedURLException
/*     */   {
/*  64 */     this.url = new URL(strUrl);
/*     */   }
/*     */ 
/*     */   public void addField(String name, String value)
/*     */   {
/*  72 */     if (this.messageBody.length() > 0)
/*  73 */       this.messageBody.append("&");
/*  74 */     this.messageBody.append(name).append("=").append(URLEncoder.encode(value));
/*     */   }
/*     */ 
/*     */   public String connect()
/*     */     throws IOException
/*     */   {
/*  83 */     URLConnection conn = this.url.openConnection();
/*  84 */     conn.setRequestProperty("Content-type", "application/x-www-form-urlencoded");
/*     */ 
/*  86 */     conn.setDoOutput(true);
/*  87 */     OutputStream out = conn.getOutputStream();
/*  88 */     out.write(this.messageBody.toString().getBytes());
/*     */ 
/*  90 */     conn.connect();
/*  91 */     out.close();
/*     */ 
/*  93 */     InputStream in = conn.getInputStream();
/*     */ 
/*  96 */     byte[] buffer = new byte[32];
/*  97 */     StringBuffer inputString = new StringBuffer();
/*     */     int n;
/*  98 */     while ((n = in.read(buffer)) >= 0)
/*     */     {
/*     */       int i;
/*  99 */       inputString.append(new String(buffer, 0, i));
/*     */     }
/* 101 */     in.close();
/*     */ 
/* 103 */     return inputString.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*     */     try
/*     */     {
/* 114 */       SecureHttpPostRaw goSecure = new SecureHttpPostRaw("https://secure.authorize.net/gateway/transact.dll");
/* 115 */       goSecure.addField("x_Version", "3.0");
/* 116 */       goSecure.addField("x_ADC_Delim_Data", "TRUE");
/* 117 */       goSecure.addField("x_ADC_URL", "FALSE");
/* 118 */       goSecure.addField("x_Login", "questcdn");
/* 119 */       goSecure.addField("x_Type", "AUTH_ONLY");
/* 120 */       goSecure.addField("x_Password", "123456");
/* 121 */       goSecure.addField("x_Amount", "1.00");
/* 122 */       goSecure.addField("x_Card_Num", "4798171737000733");
/* 123 */       goSecure.addField("x_Exp_Date", "04/00");
/* 124 */       goSecure.addField("x_Address", "505 North Highway 169");
/* 125 */       goSecure.addField("x_Zip", "55441");
/* 126 */       String returnedVal = goSecure.connect();
/* 127 */       Diagnostics.debug(returnedVal);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 170 */       Diagnostics.error("Problem with SecureHttpPostRaw.main()", e);
/*     */     }
/* 172 */     Diagnostics.debug("Done.");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  34 */     Security.addProvider(new Provider());
/*  35 */     Properties p = System.getProperties();
/*  36 */     p.put("java.protocol.handler.pkgs", "com.sun.net.ssl.internal.www.protocol");
/*  37 */     System.setProperties(p);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.SecureHttpPostRaw
 * JD-Core Version:    0.6.2
 */