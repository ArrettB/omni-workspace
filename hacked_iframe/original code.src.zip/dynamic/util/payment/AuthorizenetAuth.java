/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class AuthorizenetAuth
/*     */ {
/*     */   String merchantConfFile;
/*     */   SecureHttpPostRaw goSecure;
/*     */   Hashtable optional;
/*  69 */   static BufferedReader pauser = new BufferedReader(new InputStreamReader(System.in));
/*     */ 
/*  75 */   String avsCode = "";
/*     */ 
/*  80 */   public static int AVS_ADDRESS = 1;
/*     */ 
/*  84 */   public static int AVS_ZIP = 2;
/*     */ 
/*  88 */   public static int AVS_BOTH = AVS_ADDRESS | AVS_ZIP;
/*     */ 
/*  92 */   public static int AVS_EITHER = 4;
/*     */ 
/*  96 */   public static int AVS_OFF = 0;
/*     */   String transactionID;
/*     */   String retVal;
/* 115 */   public static String AUTHONLY = "AUTH_ONLY";
/*     */ 
/* 119 */   public static String MAUTHCAPTURE = "AUTH_CAPTURE";
/*     */ 
/*     */   public AuthorizenetAuth(String merchantConfFile)
/*     */   {
/* 128 */     this(merchantConfFile, "");
/*     */   }
/*     */ 
/*     */   public AuthorizenetAuth(String merchantConfFile, String transactionID)
/*     */   {
/* 139 */     this.merchantConfFile = merchantConfFile;
/*     */ 
/* 141 */     if (transactionID == null)
/* 142 */       transactionID = "";
/* 143 */     this.transactionID = transactionID;
/*     */   }
/*     */ 
/*     */   private String getAuth(String authType, String amount, String cardNumber, String expDate, String cardFName, String cardLName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 164 */     initAuth(authType);
/* 165 */     addRequired("x_Amount", amount);
/* 166 */     addRequired("x_Card_Num", CreditCardFieldPrep.creditCardNumber(cardNumber));
/* 167 */     addRequired("x_Exp_Date", expDate);
/* 168 */     addOptional("x_First_Name", cardFName);
/* 169 */     addOptional("x_Last_Name", cardLName);
/* 170 */     addOptional("x_Address", addr);
/* 171 */     addOptional("x_City", city);
/* 172 */     addOptional("x_State", state);
/* 173 */     addOptional("x_Zip", zip);
/* 174 */     addOptional("x_Country", country);
/*     */     String rawRet;
/*     */     try
/*     */     {
/* 178 */       rawRet = this.goSecure.connect();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 182 */       throw new PaymentException("Unable to connect to the CC Authorization host: " + e);
/*     */     }
/*     */ 
/* 185 */     return rawRet;
/*     */   }
/*     */ 
/*     */   public void getAuthOnly(String amount, String cardNumber, String expDate, String cardFName, String cardLName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 197 */     String results = getAuth(AUTHONLY, amount, cardNumber, expDate, cardFName, cardLName, addr, city, state, zip, country);
/* 198 */     this.transactionID = processRawResults(results);
/*     */   }
/*     */ 
/*     */   public void getAuthCapture(String amount, String cardNumber, String expDate, String cardFName, String cardLName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 209 */     String results = getAuth(MAUTHCAPTURE, amount, cardNumber, expDate, cardFName, cardLName, addr, city, state, zip, country);
/* 210 */     this.transactionID = processRawResults(results);
/*     */   }
/*     */ 
/*     */   public void postAuth(String amount)
/*     */     throws PaymentException
/*     */   {
/* 223 */     if ((this.transactionID == null) || (this.transactionID.length() == 0))
/*     */     {
/* 225 */       throw new PaymentException("AuthorizenetAuth.postAuth() A transaction ID is required.");
/*     */     }
/* 227 */     postAuth(this.transactionID, amount);
/*     */   }
/*     */ 
/*     */   public void postAuth(String transactionId, String amount)
/*     */     throws PaymentException
/*     */   {
/* 241 */     if ((transactionId == null) || (transactionId.length() == 0))
/*     */     {
/* 243 */       throw new PaymentException("AuthorizenetAuth.postAuth() A transaction ID is required."); } this.transactionID = transactionId;
/*     */ 
/* 247 */     initAuth("PRIOR_AUTH_CAPTURE");
/* 248 */     addRequired("x_Trans_Id", transactionId);
/* 249 */     addRequired("x_Amount", amount);
/*     */     String results;
/*     */     try { results = this.goSecure.connect(); }
/*     */     catch (IOException e)
/*     */     {
/* 257 */       throw new PaymentException("Unable to connect to the CC Authorization host: " + e);
/*     */     }
/* 259 */     processRawResults(results);
/*     */   }
/*     */ 
/*     */   public void returnOrder(String amount, String cardNumber, String expDate)
/*     */     throws PaymentException
/*     */   {
/* 272 */     returnOrder(amount, cardNumber, expDate, null, null);
/*     */   }
/*     */ 
/*     */   public void returnOrder(String amount, String cardNumber, String expDate, String firstName, String lastName)
/*     */     throws PaymentException
/*     */   {
/* 287 */     initAuth("CREDIT");
/* 288 */     addRequired("x_Amount", amount);
/* 289 */     addRequired("x_Card_Num", cardNumber);
/* 290 */     addRequired("x_Exp_Date", expDate);
/* 291 */     addOptional("x_First_Name", firstName);
/* 292 */     addOptional("x_Last_Name", lastName);
/*     */     String results;
/*     */     try
/*     */     {
/* 297 */       results = this.goSecure.connect();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 301 */       throw new PaymentException("Unable to connect to the CC Authorization host: " + e);
/*     */     }
/* 303 */     processRawResults(results);
/*     */   }
/*     */ 
/*     */   public void voidOrder()
/*     */     throws PaymentException
/*     */   {
/* 315 */     if ((this.transactionID == null) || (this.transactionID.length() == 0))
/*     */     {
/* 317 */       throw new PaymentException("AuthorizenetAuth.voidOrder() A transaction ID is required.");
/*     */     }
/* 319 */     voidOrder(this.transactionID);
/*     */   }
/*     */ 
/*     */   public void voidOrder(String transactionId)
/*     */     throws PaymentException
/*     */   {
/* 331 */     if ((transactionId == null) || (transactionId.length() == 0))
/*     */     {
/* 333 */       throw new PaymentException("AuthorizenetAuth.voidOrder() A transaction ID is required.");
/* 335 */     }this.transactionID = transactionId;
/*     */ 
/* 337 */     initAuth("VOID");
/* 338 */     addRequired("x_Trans_Id", transactionId);
/*     */     String results;
/*     */     try {
/* 343 */       results = this.goSecure.connect();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 347 */       throw new PaymentException("Unable to connect to the CC Authorization host: " + e);
/*     */     }
/* 349 */     processRawResults(results);
/*     */   }
/*     */ 
/*     */   public String getOrderId()
/*     */   {
/* 362 */     return this.transactionID;
/*     */   }
/*     */ 
/*     */   public boolean isAddressVerified(int requirements)
/*     */   {
/* 376 */     boolean returnval = false;
/* 377 */     if (requirements == AVS_OFF)
/*     */     {
/* 379 */       returnval = true;
/*     */     }
/* 381 */     else if (requirements == AVS_BOTH)
/*     */     {
/* 386 */       if ((this.avsCode.equals("X")) || (this.avsCode.equals("Y")) || (this.avsCode.equals("S")))
/* 387 */         returnval = true;
/*     */     }
/* 389 */     else if (requirements == AVS_EITHER)
/*     */     {
/* 391 */       if ((!this.avsCode.equals("N")) && (!this.avsCode.equals("R")) && (!this.avsCode.equals("E")))
/* 392 */         returnval = true;
/*     */     }
/* 394 */     else if (requirements == AVS_ADDRESS)
/*     */     {
/* 400 */       if ((this.avsCode.equals("A")) || (this.avsCode.equals("X")) || (this.avsCode.equals("S")) || (this.avsCode.equals("Y")))
/* 401 */         returnval = true;
/*     */     }
/* 403 */     else if (requirements == AVS_ZIP)
/*     */     {
/* 410 */       if ((this.avsCode.equals("W")) || (this.avsCode.equals("X")) || (this.avsCode.equals("S")) || (this.avsCode.equals("Y")) || (this.avsCode.equals("Z"))) {
/* 411 */         returnval = true;
/*     */       }
/*     */     }
/* 414 */     return returnval;
/*     */   }
/*     */ 
/*     */   public void addDescription(String text)
/*     */   {
/* 425 */     addOptional("x_Description", text);
/*     */   }
/*     */ 
/*     */   private void addRequired(String field, String value)
/*     */     throws PaymentException
/*     */   {
/* 434 */     if ((value == null) || (value.length() == 0))
/* 435 */       throw new PaymentException("The required CC Auth field " + field + " is empty.");
/* 436 */     this.goSecure.addField(field, value);
/*     */   }
/*     */ 
/*     */   private void addOptional(String field, String value)
/*     */   {
/* 445 */     if ((value != null) && (value.length() > 0))
/*     */     {
/* 447 */       if (this.goSecure == null)
/*     */       {
/* 450 */         if (this.optional == null) this.optional = new Hashtable();
/* 451 */         this.optional.put(field, value);
/*     */       }
/*     */       else
/*     */       {
/* 455 */         this.goSecure.addField(field, value);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initAuth(String authType)
/*     */     throws PaymentException
/*     */   {
/*     */     try
/*     */     {
/* 469 */       MerchantAuthInfo merchInfo = new MerchantAuthInfo(this.merchantConfFile);
/*     */ 
/* 472 */       this.goSecure = new SecureHttpPostRaw(merchInfo.getMerchantAddress());
/* 473 */       addRequired("x_Type", authType);
/* 474 */       this.goSecure.addField("x_Version", "3.0");
/* 475 */       this.goSecure.addField("x_ADC_Delim_Data", "TRUE");
/* 476 */       this.goSecure.addField("x_ADC_URL", "FALSE");
/* 477 */       this.goSecure.addField("x_Login", merchInfo.getMerchantLogin());
/* 478 */       this.goSecure.addField("x_Password", merchInfo.getMerchantPassword());
/* 479 */       addPreOptional();
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/* 483 */       throw new PaymentException("Unable to resolve the CC Authorization host address: " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addPreOptional()
/*     */   {
/* 492 */     if (this.optional != null)
/*     */     {
/* 494 */       Enumeration keys = this.optional.keys();
/* 495 */       while (keys.hasMoreElements())
/*     */       {
/* 497 */         String key = (String)keys.nextElement();
/* 498 */         this.goSecure.addField(key, (String)this.optional.get(key));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String processRawResults(String results)
/*     */     throws PaymentException
/*     */   {
/* 527 */     this.retVal = results;
/*     */ 
/* 529 */     String transactionID = "";
/* 530 */     String mstatus = null;
/* 531 */     String merrmsg = null;
/* 532 */     String md5Hash = null;
/* 533 */     String reasonCode = null;
/*     */ 
/* 535 */     StringTokenizer tr = new StringTokenizer(results, ",");
/* 536 */     int tokenIndex = 0;
/* 537 */     while (tr.hasMoreTokens())
/*     */     {
/* 539 */       String value = tr.nextToken(",");
/* 540 */       tokenIndex++;
/* 541 */       if (tokenIndex == 7)
/*     */       {
/* 543 */         transactionID = value;
/*     */       }
/* 545 */       else if (tokenIndex == 6)
/*     */       {
/* 547 */         this.avsCode = value;
/*     */       }
/* 549 */       else if (tokenIndex == 1)
/*     */       {
/* 551 */         mstatus = value;
/*     */       }
/* 553 */       else if (tokenIndex == 4)
/*     */       {
/* 555 */         merrmsg = value;
/*     */       }
/* 557 */       else if (tokenIndex == 3)
/*     */       {
/* 559 */         reasonCode = value;
/*     */       }
/* 561 */       else if (tokenIndex == 38)
/*     */       {
/* 563 */         md5Hash = value;
/*     */       }
/*     */     }
/*     */ 
/* 567 */     if (mstatus.equals("2"))
/*     */     {
/* 570 */       throw new PaymentException(reasonCode, merrmsg);
/*     */     }
/* 572 */     if (mstatus.equals("3"))
/*     */     {
/* 575 */       throw new PaymentException(reasonCode, merrmsg);
/*     */     }
/* 577 */     return transactionID;
/*     */   }
/*     */ 
/*     */   public void debugPrint()
/*     */   {
/* 585 */     Diagnostics.debug("AuthorizenetAuth.debugPrint() retVal = " + this.retVal);
/*     */   }
/*     */ 
/*     */   private static void presskey()
/*     */   {
/*     */     try
/*     */     {
/* 595 */       Diagnostics.debug("AuthorizenetAuth.presskey() Please press the enter key to continue.");
/* 596 */       String in = pauser.readLine();
/* 597 */       if (in.length() > 0)
/*     */       {
/* 599 */         Diagnostics.debug("AuthorizenetAuth.presskey() Stopped by user");
/* 600 */         System.exit(1);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 605 */       Diagnostics.error("Problem with AuthorizenetAuth.presskey()", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/* 615 */     String demoAmt = "1.00";
/* 616 */     Diagnostics.debug("AuthorizenetAuth.main()");
/* 617 */     presskey();
/*     */ 
/* 619 */     AuthorizenetAuth ca = new AuthorizenetAuth("lib/auth.obj");
/*     */     try
/*     */     {
/* 626 */       ca.getAuthCapture(demoAmt, "4798 1717 3700 0734", "04/00", "tJohn", "tSmith", "Test, street", "Tcity", "Minnesota", "55441", "USA");
/*     */ 
/* 638 */       ca.debugPrint();
/* 639 */       Diagnostics.debug("AuthorizenetAuth.main() transaction ID = " + ca.getOrderId());
/* 640 */       Diagnostics.debug("AuthorizenetAuth.main() AVS address = " + ca.isAddressVerified(AVS_ADDRESS));
/* 641 */       Diagnostics.debug("AuthorizenetAuth.main() AVS zip = " + ca.isAddressVerified(AVS_ZIP));
/* 642 */       Diagnostics.debug("AuthorizenetAuth.main() AVS either = " + ca.isAddressVerified(AVS_EITHER));
/* 643 */       Diagnostics.debug("AuthorizenetAuth.main() AVS both = " + ca.isAddressVerified(AVS_BOTH));
/* 644 */       Diagnostics.debug("AuthorizenetAuth.main() AVS not required = " + ca.isAddressVerified(AVS_OFF));
/* 645 */       presskey();
/*     */ 
/* 647 */       ca.voidOrder();
/* 648 */       ca.debugPrint();
/* 649 */       presskey();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 689 */       Diagnostics.error("Problem with AuthorizenetAuth.main()", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.AuthorizenetAuth
 * JD-Core Version:    0.6.2
 */