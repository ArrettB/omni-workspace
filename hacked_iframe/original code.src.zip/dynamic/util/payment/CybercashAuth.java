/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ public class CybercashAuth
/*     */ {
/*  73 */   static InputStreamReader pauser = new InputStreamReader(System.in);
/*     */   String merchantConfFile;
/*  87 */   String avsCode = "";
/*     */ 
/*  92 */   public static int AVS_ADDRESS = 1;
/*     */ 
/*  96 */   public static int AVS_ZIP = 2;
/*     */ 
/* 100 */   public static int AVS_BOTH = AVS_ADDRESS | AVS_ZIP;
/*     */ 
/* 104 */   public static int AVS_EITHER = 4;
/*     */ 
/* 108 */   public static int AVS_OFF = 0;
/*     */   String orderId;
/*     */   String amount;
/*     */   String cardNumber;
/*     */   String expDate;
/*     */   String cardName;
/*     */   String addr;
/*     */   String city;
/*     */   String state;
/*     */   String zip;
/*     */   String country;
/*     */   String[] retVal;
/* 166 */   static String TXN_TYPE_POSTAUTH = "postauth";
/*     */ 
/* 170 */   static String TXN_TYPE_CAPTURE = "capture";
/*     */ 
/* 174 */   static String TXN_TYPE_RETURN = "return";
/*     */ 
/* 178 */   static String TXN_TYPE_MARKED = "marked";
/*     */ 
/* 182 */   static String TXN_TYPE_MARKRET = "markret";
/*     */ 
/* 187 */   public static String AUTHONLY = "mauthonly";
/*     */ 
/* 191 */   public static String MAUTHCAPTURE = "mauthcapture";
/*     */ 
/*     */   public CybercashAuth(String merchantConfFile)
/*     */   {
/* 199 */     this(merchantConfFile, "");
/*     */   }
/*     */ 
/*     */   public CybercashAuth(String merchantConfFile, String orderId)
/*     */   {
/* 209 */     this.merchantConfFile = merchantConfFile;
/*     */ 
/* 211 */     if (orderId == null)
/* 212 */       orderId = "";
/* 213 */     this.orderId = orderId;
/*     */   }
/*     */ 
/*     */   private native String[] jniGetAuth(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, String paramString11, String paramString12);
/*     */ 
/*     */   public void getAuthOnly(String amount, String cardNumber, String expDate, String cardName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 241 */     String[] results = jniGetAuth(this.merchantConfFile, AUTHONLY, this.orderId, amount, cardNumber, expDate, cardName, addr, city, state, zip, country);
/* 242 */     this.orderId = processResults(results);
/*     */   }
/*     */ 
/*     */   public void getAuthCapture(String amount, String cardNumber, String expDate, String cardName, String addr, String city, String state, String zip, String country)
/*     */     throws PaymentException
/*     */   {
/* 253 */     String[] results = jniGetAuth(this.merchantConfFile, MAUTHCAPTURE, this.orderId, amount, cardNumber, expDate, cardName, addr, city, state, zip, country);
/* 254 */     this.orderId = processResults(results);
/*     */   }
/*     */ 
/*     */   private native String[] jniPostAuth(String paramString1, String paramString2, String paramString3);
/*     */ 
/*     */   public void postAuth(String amount)
/*     */     throws PaymentException
/*     */   {
/* 278 */     if ((this.orderId == null) || (this.orderId.length() == 0))
/*     */     {
/* 280 */       throw new PaymentException("CybercashAuth.postAuth() An order ID is required.");
/*     */     }
/* 282 */     postAuth(this.orderId, amount);
/*     */   }
/*     */ 
/*     */   public void postAuth(String orderId, String amount)
/*     */     throws PaymentException
/*     */   {
/* 296 */     if ((orderId == null) || (orderId.length() == 0))
/*     */     {
/* 298 */       throw new PaymentException("CybercashAuth.postAuth() An order ID is required.");
/*     */     }
/* 300 */     this.orderId = orderId;
/* 301 */     String[] results = jniPostAuth(this.merchantConfFile, orderId, amount);
/* 302 */     processResults(results);
/*     */   }
/*     */ 
/*     */   private native String[] jniReturnOrder(String paramString1, String paramString2, String paramString3);
/*     */ 
/*     */   public void returnOrder(String amount)
/*     */     throws PaymentException
/*     */   {
/* 318 */     if ((this.orderId == null) || (this.orderId.length() == 0))
/*     */     {
/* 320 */       throw new PaymentException("CybercashAuth.returnOrder() An order ID is required.");
/*     */     }
/* 322 */     returnOrder(this.orderId, amount);
/*     */   }
/*     */ 
/*     */   public void returnOrder(String orderId, String amount)
/*     */     throws PaymentException
/*     */   {
/* 337 */     if ((orderId == null) || (orderId.length() == 0))
/*     */     {
/* 339 */       throw new PaymentException("CybercashAuth.returnOrder() An order ID is required.");
/*     */     }
/* 341 */     this.orderId = orderId;
/* 342 */     String[] results = jniReturnOrder(this.merchantConfFile, orderId, amount);
/* 343 */     processResults(results);
/*     */   }
/*     */ 
/*     */   private native String[] jniVoidOrder(String paramString1, String paramString2, String paramString3);
/*     */ 
/*     */   public void voidOrder(String transactionType)
/*     */     throws PaymentException
/*     */   {
/* 358 */     if ((this.orderId == null) || (this.orderId.length() == 0))
/*     */     {
/* 360 */       throw new PaymentException("CybercashAuth.voidOrder() An order ID is required.");
/*     */     }
/* 362 */     voidOrder(this.orderId, transactionType);
/*     */   }
/*     */ 
/*     */   public void voidOrder(String orderId, String transactionType)
/*     */     throws PaymentException
/*     */   {
/* 375 */     if ((orderId == null) || (orderId.length() == 0))
/*     */     {
/* 377 */       throw new PaymentException("CybercashAuth.voidOrder() An order ID is required.");
/*     */     }
/* 379 */     this.orderId = orderId;
/* 380 */     String[] results = jniVoidOrder(this.merchantConfFile, orderId, transactionType);
/* 381 */     processResults(results);
/*     */   }
/*     */ 
/*     */   public String getOrderId()
/*     */   {
/* 394 */     return this.orderId;
/*     */   }
/*     */ 
/*     */   public boolean isAddressVerified(int requirements)
/*     */   {
/* 408 */     boolean returnval = false;
/* 409 */     if (requirements == AVS_OFF)
/*     */     {
/* 411 */       returnval = true;
/*     */     }
/* 413 */     else if (requirements == AVS_BOTH)
/*     */     {
/* 418 */       if ((this.avsCode.equals("X")) || (this.avsCode.equals("Y")) || (this.avsCode.equals("S")))
/* 419 */         returnval = true;
/*     */     }
/* 421 */     else if (requirements == AVS_EITHER)
/*     */     {
/* 423 */       if ((!this.avsCode.equals("N")) && (!this.avsCode.equals("R")) && (!this.avsCode.equals("E")))
/* 424 */         returnval = true;
/*     */     }
/* 426 */     else if (requirements == AVS_ADDRESS)
/*     */     {
/* 432 */       if ((this.avsCode.equals("A")) || (this.avsCode.equals("X")) || (this.avsCode.equals("S")) || (this.avsCode.equals("Y")))
/* 433 */         returnval = true;
/*     */     }
/* 435 */     else if (requirements == AVS_ZIP)
/*     */     {
/* 442 */       if ((this.avsCode.equals("W")) || (this.avsCode.equals("X")) || (this.avsCode.equals("S")) || (this.avsCode.equals("Y")) || (this.avsCode.equals("Z"))) {
/* 443 */         returnval = true;
/*     */       }
/*     */     }
/* 446 */     return returnval;
/*     */   }
/*     */ 
/*     */   private String processResults(String[] results)
/*     */     throws PaymentException
/*     */   {
/* 461 */     this.retVal = results;
/*     */ 
/* 463 */     String orderId = "";
/* 464 */     String mstatus = null;
/* 465 */     String merrmsg = null;
/* 466 */     for (int i = 0; i < results.length / 2; i++)
/*     */     {
/* 468 */       String key = results[(2 * i)];
/* 469 */       if (key.equals("order-id"))
/* 470 */         orderId = results[(2 * i + 1)];
/* 471 */       if (key.equals("avs-code"))
/* 472 */         this.avsCode = results[(2 * i + 1)];
/* 473 */       if (key.equals("MStatus"))
/*     */       {
/* 475 */         mstatus = results[(2 * i + 1)];
/* 476 */         if (merrmsg != null)
/* 477 */           throw new PaymentException(mstatus, merrmsg);
/*     */       }
/* 479 */       if (key.equals("MErrMsg"))
/*     */       {
/* 481 */         merrmsg = results[(2 * i + 1)];
/* 482 */         if (mstatus != null)
/* 483 */           throw new PaymentException(mstatus, merrmsg);
/*     */       }
/*     */     }
/* 486 */     return orderId;
/*     */   }
/*     */ 
/*     */   public void debugPrint()
/*     */   {
/* 500 */     for (int i = 0; i < this.retVal.length / 2; i++)
/*     */     {
/* 502 */       Diagnostics.debug("CybercashAuth.debugPrint() retVal = " + this.retVal[(2 * i)] + " => " + this.retVal[(2 * i + 1)]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void debugPrint(PrintWriter output)
/*     */   {
/* 511 */     for (int i = 0; i < this.retVal.length / 2; i++)
/*     */     {
/* 513 */       Diagnostics.debug("CybercashAuth.debugPrint() retVal = " + this.retVal[(2 * i)] + " => " + this.retVal[(2 * i + 1)]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void presskey()
/*     */   {
/*     */     try
/*     */     {
/* 525 */       Diagnostics.debug("CybercashAuth.presskey() Please press the enter key to continue.");
/* 526 */       int i = pauser.read();
/* 527 */       if (i != 10)
/*     */       {
/* 529 */         Diagnostics.debug("CybercashAuth.presskey() Stopped by user");
/* 530 */         System.exit(1);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 535 */       Diagnostics.error("Problem in CybercashAuth.presskey()", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/* 545 */     String demoAmt = "usd 1.00";
/* 546 */     Diagnostics.debug("CybercashAuth.main()");
/*     */ 
/* 548 */     presskey();
/*     */ 
/* 551 */     CybercashAuth ca = new CybercashAuth("c:\\mck-3.2.0.7-nt\\cityofstpaullieplicense-88\\conf\\merchant_conf");
/*     */     try
/*     */     {
/* 555 */       ca.getAuthOnly(demoAmt, "4798171737000734", "04/00", "Test User", "Test street", "Tcity", "Minnesota", "55441", "USA");
/*     */ 
/* 567 */       ca.debugPrint();
/* 568 */       Diagnostics.debug("CybercashAuth.main() order ID = " + ca.getOrderId());
/* 569 */       Diagnostics.debug("CybercashAuth.main() AVS address = " + ca.isAddressVerified(AVS_ADDRESS));
/* 570 */       Diagnostics.debug("CybercashAuth.main() AVS zip = " + ca.isAddressVerified(AVS_ZIP));
/* 571 */       Diagnostics.debug("CybercashAuth.main() AVS either = " + ca.isAddressVerified(AVS_EITHER));
/* 572 */       Diagnostics.debug("CybercashAuth.main() AVS both = " + ca.isAddressVerified(AVS_BOTH));
/* 573 */       Diagnostics.debug("CybercashAuth.main() AVS not required = " + ca.isAddressVerified(AVS_OFF));
/* 574 */       presskey();
/*     */ 
/* 576 */       ca.postAuth(demoAmt);
/* 577 */       ca.debugPrint();
/* 578 */       presskey();
/*     */ 
/* 581 */       ca.voidOrder(TXN_TYPE_MARKED);
/* 582 */       ca.debugPrint();
/* 583 */       presskey();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 588 */       Diagnostics.error("CybercashAuth.main()", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 492 */     System.loadLibrary("DynCyberCash");
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.CybercashAuth
 * JD-Core Version:    0.6.2
 */