/*     */ package dynamic.util.payment;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ 
/*     */ public class MerchantAuthInfo
/*     */   implements Serializable
/*     */ {
/*     */   String ma;
/*     */   String ml;
/*     */   String mp;
/*     */ 
/*     */   public MerchantAuthInfo()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MerchantAuthInfo(String addr, String login, String pw)
/*     */   {
/*  34 */     this.ma = addr;
/*  35 */     this.ml = login;
/*  36 */     this.mp = pw;
/*     */   }
/*     */ 
/*     */   public MerchantAuthInfo(String authInfoFile)
/*     */     throws PaymentException
/*     */   {
/*     */     try
/*     */     {
/*  49 */       FileInputStream fis = new FileInputStream(authInfoFile);
/*  50 */       GZIPInputStream gin = new GZIPInputStream(fis);
/*  51 */       ObjectInputStream in = new ObjectInputStream(gin);
/*  52 */       MerchantAuthInfo tmp = (MerchantAuthInfo)in.readObject();
/*  53 */       this.ma = tmp.getMerchantAddress();
/*  54 */       this.ml = tmp.getMerchantLogin();
/*  55 */       this.mp = tmp.getMerchantPassword();
/*  56 */       in.close();
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/*  60 */       throw new PaymentException("Unable to find the Merchant Authorization file.");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  65 */       throw new PaymentException("Unable to open the Merchant Authorization file:" + e);
/*     */     }
/*     */     catch (ClassNotFoundException e)
/*     */     {
/*  70 */       throw new PaymentException("The Merchant Authorization file was corrupted:" + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getMerchantAddress()
/*     */   {
/*  77 */     return this.ma;
/*     */   }
/*     */ 
/*     */   public String getMerchantLogin()
/*     */   {
/*  82 */     return this.ml;
/*     */   }
/*     */ 
/*     */   public String getMerchantPassword()
/*     */   {
/*  87 */     return this.mp;
/*     */   }
/*     */ 
/*     */   public void saveToFile(String outFile)
/*     */     throws PaymentException
/*     */   {
/*     */     try
/*     */     {
/* 100 */       FileOutputStream fos = new FileOutputStream(outFile);
/* 101 */       GZIPOutputStream gout = new GZIPOutputStream(fos);
/* 102 */       ObjectOutputStream out = new ObjectOutputStream(gout);
/* 103 */       out.writeObject(this);
/* 104 */       out.flush();
/* 105 */       out.close();
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/* 110 */       throw new PaymentException("Unable to find the Merchant Authorization file.");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 115 */       throw new PaymentException("Unable to open the Merchant Authorization file:" + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*     */     try
/*     */     {
/* 127 */       BufferedReader keybd = new BufferedReader(new InputStreamReader(System.in));
/* 128 */       Diagnostics.debug("Address:  ");
/* 129 */       String addr = keybd.readLine();
/*     */ 
/* 131 */       Diagnostics.debug("Login:    ");
/* 132 */       String login = keybd.readLine();
/*     */ 
/* 134 */       Diagnostics.debug("Password: ");
/* 135 */       String pwd = keybd.readLine();
/*     */ 
/* 137 */       Diagnostics.debug("File:     ");
/* 138 */       String outFile = keybd.readLine();
/*     */ 
/* 140 */       Diagnostics.debug("Address  = " + addr);
/* 141 */       Diagnostics.debug("Login    = " + login);
/* 142 */       Diagnostics.debug("Password = " + pwd);
/* 143 */       Diagnostics.debug("Saved in = " + outFile);
/* 144 */       keybd.close();
/*     */ 
/* 146 */       MerchantAuthInfo toSave = new MerchantAuthInfo(addr, login, pwd);
/* 147 */       toSave.saveToFile(outFile);
/*     */ 
/* 149 */       Diagnostics.debug("Trying to read it back in for confirmation.");
/* 150 */       MerchantAuthInfo newVal = new MerchantAuthInfo(outFile);
/* 151 */       Diagnostics.debug("Address  = " + newVal.getMerchantAddress());
/* 152 */       Diagnostics.debug("Login    = " + newVal.getMerchantLogin());
/* 153 */       Diagnostics.debug("Password = " + newVal.getMerchantPassword());
/* 154 */       System.exit(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 158 */       Diagnostics.error("Problem in MerchantAuthInfo.main()", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.payment.MerchantAuthInfo
 * JD-Core Version:    0.6.2
 */