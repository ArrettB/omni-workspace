/*    */ package dynamic.util.classloader;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamClass;
/*    */ import java.io.StreamCorruptedException;
/*    */ 
/*    */ public class DynamicObjectInputStream extends ObjectInputStream
/*    */ {
/*    */   private ClassLoader loader;
/*    */ 
/*    */   public DynamicObjectInputStream(InputStream in, ClassLoader loader)
/*    */     throws StreamCorruptedException, IOException
/*    */   {
/* 11 */     super(in);
/*    */ 
/* 13 */     this.loader = loader;
/*    */   }
/*    */ 
/*    */   protected Class resolveClass(ObjectStreamClass v) throws IOException, ClassNotFoundException
/*    */   {
/* 18 */     return this.loader.loadClass(v.getName());
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.classloader.DynamicObjectInputStream
 * JD-Core Version:    0.6.2
 */