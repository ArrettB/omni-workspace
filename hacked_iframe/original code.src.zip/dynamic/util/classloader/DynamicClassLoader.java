/*     */ package dynamic.util.classloader;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipException;
/*     */ import java.util.zip.ZipFile;
/*     */ 
/*     */ public class DynamicClassLoader extends ClassLoader
/*     */ {
/*  72 */   private Vector dynamicClassPath = new Vector();
/*  73 */   private Vector files = new Vector();
/*  74 */   private Hashtable cache = new Hashtable();
/*  75 */   private Vector classPath = null;
/*  76 */   private long instantiatedAt = 0L;
/*     */ 
/*     */   public DynamicClassLoader()
/*     */     throws IllegalArgumentException
/*     */   {
/*  87 */     Diagnostics.trace("DynamicClassLoader.DynamicClassLoader()");
/*     */ 
/*  90 */     Vector names = StringUtil.stringToVector(System.getProperty("dynamic.class.path", "."), ';');
/*  91 */     Diagnostics.debug("dynamic.class.path = " + names);
/*     */ 
/*  93 */     Enumeration e = names.elements();
/*  94 */     while (e.hasMoreElements())
/*     */     {
/*  96 */       String path = (String)e.nextElement();
/*  97 */       File file = new File(path);
/*  98 */       if (!file.exists())
/*     */       {
/* 100 */         throw new IllegalArgumentException("dynamic.class.path entry \"" + path + "\" does not exist");
/*     */       }
/* 102 */       if (!file.canRead())
/*     */       {
/* 104 */         throw new IllegalArgumentException("dynamic.class.path entry \"" + path + "\" is not readable");
/*     */       }
/* 106 */       if ((!file.isDirectory()) && (!isZipOrJarArchive(file)))
/*     */       {
/* 108 */         throw new IllegalArgumentException("dynamic.class.path entry \"" + path + "\" is not a directory, Zip, or Jar file");
/*     */       }
/*     */ 
/* 112 */       this.dynamicClassPath.addElement(file);
/*     */     }
/*     */ 
/* 116 */     this.instantiatedAt = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   private boolean isZipOrJarArchive(File file)
/*     */   {
/* 127 */     boolean isArchive = true;
/* 128 */     ZipFile zipFile = null;
/*     */     try
/*     */     {
/* 132 */       zipFile = new ZipFile(file);
/*     */     }
/*     */     catch (ZipException zipCurrupted)
/*     */     {
/* 136 */       isArchive = false;
/*     */     }
/*     */     catch (IOException anyIOError)
/*     */     {
/* 140 */       isArchive = false;
/*     */     }
/*     */     finally
/*     */     {
/* 144 */       if (zipFile != null)
/*     */       {
/*     */         try
/*     */         {
/* 148 */           zipFile.close();
/*     */         }
/*     */         catch (IOException ignored) {
/*     */         }
/*     */       }
/*     */     }
/* 154 */     return isArchive;
/*     */   }
/*     */ 
/*     */   public synchronized void addFile(File f)
/*     */   {
/* 162 */     FileTime ft = new FileTime(f);
/* 163 */     if (!this.files.contains(ft))
/*     */     {
/* 165 */       this.files.addElement(ft);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized boolean shouldReload()
/*     */   {
/* 178 */     Enumeration e = this.files.elements();
/* 179 */     while (e.hasMoreElements())
/*     */     {
/* 181 */       FileTime ft = (FileTime)e.nextElement();
/* 182 */       if (ft.hasBeenUpdated())
/*     */       {
/* 184 */         return true;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized Class loadClass(String name, boolean resolve)
/*     */     throws ClassNotFoundException
/*     */   {
/* 223 */     Class c = (Class)this.cache.get(name);
/* 224 */     if (c != null)
/*     */     {
/* 226 */       if (resolve) resolveClass(c);
/* 227 */       return c;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 232 */       return Class.forName(name);
/*     */     }
/*     */     catch (ClassNotFoundException t)
/*     */     {
/* 237 */       Enumeration e = this.dynamicClassPath.elements();
/* 238 */       while (e.hasMoreElements())
/*     */       {
/* 240 */         byte[] classData = null;
/* 241 */         File file = (File)e.nextElement();
/*     */         try
/*     */         {
/* 244 */           if (file.isDirectory())
/*     */           {
/* 246 */             classData = loadClassFromDirectory(file, name);
/*     */           }
/*     */           else
/*     */           {
/* 250 */             classData = loadClassFromZipfile(file, name);
/*     */           }
/*     */         }
/*     */         catch (IOException ioe)
/*     */         {
/* 255 */           classData = null;
/*     */         }
/*     */ 
/* 258 */         if (classData != null)
/*     */         {
/* 260 */           c = defineClass(name, classData, 0, classData.length);
/* 261 */           this.cache.put(name, c);
/* 262 */           if (resolve) resolveClass(c);
/* 263 */           return c;
/*     */         }
/*     */       }
/*     */     }
/* 266 */     throw new ClassNotFoundException(name);
/*     */   }
/*     */ 
/*     */   private byte[] loadClassFromDirectory(File dir, String name)
/*     */     throws IOException
/*     */   {
/* 278 */     byte[] result = null;
/* 279 */     String classFileName = name.replace('.', File.separatorChar) + ".class";
/*     */ 
/* 281 */     if (!Character.isJavaIdentifierStart(classFileName.charAt(0)))
/*     */     {
/* 283 */       int start = 1;
/* 284 */       while (!Character.isJavaIdentifierStart(classFileName.charAt(start++)));
/* 285 */       classFileName = classFileName.substring(start);
/*     */     }
/* 287 */     File classFile = new File(dir, classFileName);
/*     */ 
/* 289 */     if (classFile.exists())
/*     */     {
/* 291 */       InputStream in = null;
/*     */       try
/*     */       {
/* 294 */         in = new FileInputStream(classFile);
/* 295 */         result = loadBytesFromStream(in, (int)classFile.length());
/* 296 */         addFile(classFile);
/*     */       }
/*     */       finally
/*     */       {
/* 300 */         if (in != null) in.close();
/*     */       }
/*     */     }
/*     */ 
/* 304 */     return result;
/*     */   }
/*     */ 
/*     */   private byte[] loadClassFromZipfile(File file, String name)
/*     */     throws IOException
/*     */   {
/* 315 */     byte[] result = null;
/* 316 */     String classFileName = name.replace('.', '/') + ".class";
/* 317 */     ZipFile zipFile = new ZipFile(file);
/*     */     try
/*     */     {
/* 321 */       ZipEntry entry = zipFile.getEntry(classFileName);
/* 322 */       if (entry != null)
/*     */       {
/* 324 */         result = loadBytesFromStream(zipFile.getInputStream(entry), (int)entry.getSize());
/* 325 */         addFile(file);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 330 */       zipFile.close();
/*     */     }
/*     */ 
/* 333 */     return result;
/*     */   }
/*     */ 
/*     */   private byte[] loadBytesFromStream(InputStream in, int length)
/*     */     throws IOException
/*     */   {
/* 341 */     byte[] buf = new byte[length];
/* 342 */     int count = 0;
/*     */     int nRead;
/* 344 */     while ((length > 0) && ((nRead = in.read(buf, count, length)) != -1))
/*     */     {
/*     */       int i;
/* 346 */       count += i;
/* 347 */       length -= i;
/*     */     }
/*     */ 
/* 350 */     return buf;
/*     */   }
/*     */ 
/*     */   private static class FileTime
/*     */   {
/*     */     public File file;
/*     */     public long lastKnownModified;
/*     */ 
/*     */     public FileTime(File f) {
/* 360 */       this.file = f;
/* 361 */       this.lastKnownModified = f.lastModified();
/*     */     }
/*     */ 
/*     */     public boolean hasBeenUpdated()
/*     */     {
/* 366 */       long modified = this.file.lastModified();
/* 367 */       if (modified == 0L)
/*     */       {
/* 369 */         Diagnostics.debug("FileTime.hasBeenUpdated() return true: File \"" + this.file.getName() + "\" has been removed");
/* 370 */         return true;
/*     */       }
/* 372 */       if (modified > this.lastKnownModified)
/*     */       {
/* 374 */         Diagnostics.debug("FileTime.hasBeenUpdated() return true: File \"" + this.file.getName() + "\" has been modified:" + new Date(modified) + " > " + new Date(this.lastKnownModified));
/* 375 */         return true;
/*     */       }
/*     */ 
/* 379 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 385 */       if (o == null)
/*     */       {
/* 387 */         return false;
/*     */       }
/* 389 */       if (o == this)
/*     */       {
/* 391 */         return true;
/*     */       }
/* 393 */       if ((o instanceof FileTime))
/*     */       {
/* 395 */         return ((FileTime)o).file.equals(this.file);
/*     */       }
/*     */ 
/* 399 */       return false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.classloader.DynamicClassLoader
 * JD-Core Version:    0.6.2
 */