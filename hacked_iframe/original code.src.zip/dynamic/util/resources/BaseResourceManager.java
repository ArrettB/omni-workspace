/*     */ package dynamic.util.resources;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class BaseResourceManager
/*     */   implements ResourceManager
/*     */ {
/*  20 */   private Hashtable producers = new Hashtable();
/*  21 */   private Hashtable definitions = new Hashtable();
/*  22 */   private Hashtable resources = new Hashtable();
/*  23 */   private Hashtable tnsnames = new Hashtable();
/*  24 */   private String defaultName = null;
/*  25 */   private ClassLoader loader = null;
/*     */ 
/*     */   public void initialize()
/*     */     throws Exception
/*     */   {
/*  49 */     initialize(null, null);
/*     */   }
/*     */ 
/*     */   public void initialize(Node n)
/*     */     throws Exception
/*     */   {
/*  57 */     initialize(n, null);
/*     */   }
/*     */ 
/*     */   public void initialize(Node n, ClassLoader loader)
/*     */     throws Exception
/*     */   {
/*  65 */     Diagnostics.trace("BaseResourceManager.initialize(" + n + "," + loader + ")");
/*  66 */     this.loader = loader;
/*  67 */     NodeList elements = XMLUtils.getElementsByTagName(n, "resourceProducer");
/*  68 */     for (int i = 0; i < elements.getLength(); i++)
/*     */     {
/*  70 */       Element RP = (Element)elements.item(i);
/*  71 */       parseResourceProducer(RP);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  77 */     if (this.resources != null)
/*     */     {
/*  79 */       Enumeration d = this.resources.elements();
/*  80 */       while (d.hasMoreElements())
/*     */       {
/*  82 */         Vector v = (Vector)d.nextElement();
/*  83 */         for (int i = 0; i < v.size(); i++)
/*  84 */           ((DynamicResource)v.elementAt(i)).destroy();
/*  85 */         v.removeAllElements();
/*     */       }
/*  87 */       this.resources.clear();
/*  88 */       this.resources = null;
/*     */     }
/*     */ 
/*  91 */     if (this.definitions != null) this.definitions.clear();
/*  92 */     this.definitions = null;
/*     */ 
/*  94 */     if (this.producers != null)
/*     */     {
/*  96 */       Enumeration d = this.producers.elements();
/*  97 */       while (d.hasMoreElements())
/*  98 */         ((DynamicResourceProducer)d.nextElement()).destroy();
/*  99 */       this.producers.clear();
/* 100 */       this.producers = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized DynamicResource getResource() throws Exception
/*     */   {
/* 106 */     return getResource(null);
/*     */   }
/*     */ 
/*     */   public synchronized DynamicResource getResource(String resName)
/*     */     throws Exception
/*     */   {
/* 113 */     if (resName == null) resName = this.defaultName;
/* 114 */     if (resName == null) return null;
/* 115 */     resName = resName.toLowerCase();
/*     */ 
/* 117 */     Vector v = (Vector)this.resources.get(resName);
/* 118 */     if (v != null)
/*     */     {
/* 121 */       for (int i = v.size() - 1; i >= 0; i--)
/*     */       {
/* 123 */         DynamicResource resource = (DynamicResource)v.elementAt(i);
/* 124 */         if ((resource == null) || (resource.isExpired())) v.removeElementAt(i);
/*     */       }
/*     */ 
/* 127 */       for (int i = 0; i < v.size(); i++)
/*     */       {
/* 129 */         DynamicResource resource = (DynamicResource)v.elementAt(i);
/* 130 */         if (resource.acquire()) return resource;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 135 */     DynamicResource resource = createResource(resName);
/* 136 */     resource.acquire();
/* 137 */     return resource;
/*     */   }
/*     */ 
/*     */   protected synchronized DynamicResource createResource(String resName) throws Exception
/*     */   {
/* 142 */     Diagnostics.trace("BaseResourceManager.createResource(" + resName + ")");
/* 143 */     if (resName == null) return null;
/* 144 */     resName = resName.toLowerCase();
/* 145 */     DynamicResourceDefinition rd = (DynamicResourceDefinition)this.definitions.get(resName);
/* 146 */     if (rd == null) throw new ResourceNotFoundException(resName);
/* 147 */     DynamicResourceProducer producer = (DynamicResourceProducer)this.producers.get(rd.producer);
/* 148 */     if (producer == null) throw new ResourceNotFoundException(resName);
/* 149 */     DynamicResource result = producer.newResource(resName, rd.id, rd.username, rd.password, rd.type, rd.min, rd.max, rd.ttl);
/* 150 */     Vector v = (Vector)this.resources.get(resName);
/* 151 */     if (v == null) v = new Vector();
/* 152 */     v.addElement(result);
/* 153 */     this.resources.put(resName, v);
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */   public synchronized void killResource(String resName)
/*     */   {
/* 159 */     Diagnostics.trace("BaseResourceManager.killResource(" + resName + ")");
/* 160 */     if (resName == null) return;
/* 161 */     resName = resName.toLowerCase();
/* 162 */     Vector parts = StringUtil.stringToVector(resName, ':');
/* 163 */     String name = (String)parts.elementAt(0);
/* 164 */     int index = Integer.parseInt((String)parts.elementAt(1)) - 1;
/* 165 */     Vector v = (Vector)this.resources.get(name);
/* 166 */     if (v == null) return;
/* 167 */     if (index >= v.size()) return;
/* 168 */     DynamicResource r = (DynamicResource)v.elementAt(index);
/* 169 */     if (r == null) return;
/* 170 */     r.destroy();
/*     */   }
/*     */ 
/*     */   private Class loadClass(String name) throws ClassNotFoundException
/*     */   {
/* 175 */     if (this.loader == null) {
/* 176 */       return Class.forName(name);
/*     */     }
/* 178 */     return this.loader.loadClass(name);
/*     */   }
/*     */ 
/*     */   public void registerProducer(String name, String className, String driver, String prefix, String dateFormat, String now, String tnsFile) throws Exception
/*     */   {
/* 183 */     Diagnostics.trace("BaseResourceManager.registerProducer(" + name + "," + className + "," + driver + "," + prefix + "," + dateFormat + "," + now + ")");
/* 184 */     if ((name == null) || (name.length() == 0)) throw new Exception("name was not specified for resourceProducer");
/* 185 */     if ((className == null) || (className.length() == 0)) throw new Exception("class was not specified for resourceProducer");
/* 186 */     if ((driver == null) || (driver.length() == 0)) throw new Exception("driver was not specified for resourceProducer");
/* 187 */     if (prefix == null) throw new Exception("prefix was not specified for resourceProducer");
/* 188 */     if ((dateFormat == null) || (dateFormat.length() == 0)) throw new Exception("dateFormat was not specified for resourceProducer");
/* 189 */     if ((tnsFile != null) && (tnsFile.length() > 0)) registerTNSNames(tnsFile);
/* 190 */     if (this.producers.containsKey(name)) throw new ProducerExistsException(name, className);
/* 191 */     DynamicResourceProducer producer = (DynamicResourceProducer)loadClass(className).newInstance();
/* 192 */     producer.initialize(this, name, loadClass(driver), prefix, dateFormat, now);
/* 193 */     this.producers.put(name, producer);
/*     */   }
/*     */ 
/*     */   private void parseResourceProducer(Element RP) throws Exception
/*     */   {
/* 198 */     String name = RP.getAttribute("name");
/* 199 */     String className = RP.getAttribute("class");
/* 200 */     String driver = RP.getAttribute("driver");
/* 201 */     String prefix = RP.getAttribute("prefix");
/* 202 */     String dateFormat = RP.getAttribute("dateFormat");
/* 203 */     String now = RP.getAttribute("now");
/* 204 */     String tnsFile = RP.getAttribute("tnsFile");
/* 205 */     registerProducer(name, className, driver, prefix, dateFormat, now, tnsFile);
/*     */ 
/* 207 */     NodeList elements = XMLUtils.getElementsByTagName(RP, "resource");
/* 208 */     for (int i = 0; i < elements.getLength(); i++)
/*     */     {
/* 210 */       Element R = (Element)elements.item(i);
/* 211 */       parseResourceDefinition(name, R);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerResourceDefinition(String producer, String name, String id, String username, String password) throws Exception
/*     */   {
/* 217 */     registerResourceDefinition(producer, name, id, username, password, "Pooled", "0", "500", "100", null);
/*     */   }
/*     */ 
/*     */   public void registerResourceDefinition(String producer, String name, String id, String username, String password, String type, String min, String max, String ttl, String def) throws Exception
/*     */   {
/* 222 */     Diagnostics.trace("BaseResourceManager.registerResourceDefinition(" + producer + "," + name + "," + id + "," + username + ",*******," + type + "," + min + "," + max + "," + ttl + "," + def + ")");
/* 223 */     if ((name == null) || (name.length() == 0)) throw new Exception("name was not specified for resource");
/* 224 */     name = name.toLowerCase();
/* 225 */     if ((id == null) || (id.length() == 0)) throw new Exception("id was not specified for resource");
/* 226 */     if (this.definitions.containsKey(name)) throw new ResourceDefinitionExistsException(name);
/* 227 */     DynamicResourceDefinition definition = new DynamicResourceDefinition(producer, name, id, username, password, type, min, max, ttl);
/* 228 */     this.definitions.put(name, definition);
/* 229 */     if (this.defaultName == null) this.defaultName = name;
/* 230 */     if ((def != null) && (def.equals("true"))) this.defaultName = name; 
/*     */   }
/*     */ 
/*     */   private void parseResourceDefinition(String producer, Element R)
/*     */     throws Exception
/*     */   {
/* 235 */     String name = R.getAttribute("name");
/* 236 */     if (name != null) name = name.toLowerCase();
/* 237 */     String id = R.getAttribute("id");
/* 238 */     if ((id == null) || (id.length() == 0)) id = (String)this.tnsnames.get(name);
/* 239 */     String username = R.getAttribute("username");
/* 240 */     String password = R.getAttribute("password");
/* 241 */     String type = R.getAttribute("type");
/* 242 */     String min = R.getAttribute("min");
/* 243 */     String max = R.getAttribute("max");
/* 244 */     String ttl = R.getAttribute("ttl");
/* 245 */     String def = R.getAttribute("default");
/* 246 */     registerResourceDefinition(producer, name, id, username, password, type, min, max, ttl, def);
/*     */   }
/*     */ 
/*     */   public String toHTML(String href, String resource)
/*     */   {
/* 251 */     StringBuffer result = new StringBuffer();
/* 252 */     result.append("<b>Default Resource:</b> " + this.defaultName + "<br>");
/*     */ 
/* 254 */     result.append("<table width=\"100%\">\n");
/* 255 */     result.append("<tr>\n");
/* 256 */     result.append("<td rowspan=\"2\" bgcolor=\"#8888CC\"><font size=\"2\"><b>Resource</b></font></td>\n");
/* 257 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Class</b></font></td>\n");
/* 258 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Producer</b></font></td>\n");
/* 259 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Type</b></font></td>\n");
/* 260 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Shared</b></font></td>\n");
/* 261 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Status</b></font></td>\n");
/* 262 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Use</b></font></td>\n");
/* 263 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Created</b></font></td>\n");
/* 264 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Expires</b></font></td>\n");
/* 265 */     result.append("</tr>\n");
/* 266 */     result.append("<tr>\n");
/* 267 */     result.append("<td colspan=\"9\" bgcolor=\"#8888CC\"><font size=\"2\"><b>Last Action</b></font></td>\n");
/* 268 */     result.append("</tr>\n");
/*     */ 
/* 270 */     Enumeration keys = Sort.keys(this.resources);
/*     */     Vector v;
/*     */     int i;
/* 271 */     for (; keys.hasMoreElements(); 
/* 275 */       i < v.size())
/*     */     {
/* 273 */       String key = (String)keys.nextElement();
/* 274 */       v = (Vector)this.resources.get(key);
/* 275 */       i = 0; continue;
/*     */ 
/* 277 */       DynamicResource r = (DynamicResource)v.elementAt(i);
/* 278 */       String name = r.getName() + ":" + (i + 1);
/* 279 */       result.append(r.toHTML(href, i + 1, name.equals(resource)));
/*     */ 
/* 275 */       i++;
/*     */     }
/*     */ 
/* 282 */     result.append("</table>");
/*     */ 
/* 284 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private void registerTNSNames(String tnsFileName)
/*     */     throws Exception
/*     */   {
/* 293 */     String s = null;
/* 294 */     FileInputStream fis = null;
/*     */     try
/*     */     {
/* 298 */       fis = new FileInputStream(new File(tnsFileName));
/* 299 */       byte[] buf = new byte[fis.available()];
/* 300 */       fis.read(buf);
/* 301 */       s = new String(buf);
/*     */     }
/*     */     finally
/*     */     {
/* 305 */       if (fis != null) fis.close();
/*     */     }
/*     */ 
/* 308 */     int start = 0;
/* 309 */     int end = 0;
/*     */     while (true)
/*     */     {
/*     */       try
/*     */       {
/* 319 */         char c = s.charAt(end);
/* 320 */         end++;
/* 321 */         if (c == '=')
/*     */         {
/* 323 */           String resource = s.substring(start, end - 1).trim();
/*     */ 
/* 327 */           c = s.charAt(end);
/* 328 */           end++;
/* 329 */           if (c == '(')
/*     */           {
/* 331 */             start = end;
/*     */ 
/* 333 */             int cnt = 1;
/*     */ 
/* 336 */             c = s.charAt(end);
/* 337 */             if (c == '(') cnt++;
/* 338 */             else if (c == ')') cnt--;
/* 339 */             end++;
/* 340 */             if (cnt == 0)
/*     */             {
/* 342 */               String description = s.substring(start - 1, end);
/*     */ 
/* 344 */               start = end;
/* 345 */               resource = resource.toLowerCase();
/* 346 */               String id = parseTNSDescription(description);
/* 347 */               this.tnsnames.put(resource, id);
/* 348 */               if (resource.endsWith(".world"))
/*     */               {
/* 350 */                 resource = resource.substring(0, resource.length() - 6);
/* 351 */                 this.tnsnames.put(resource, id);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (StringIndexOutOfBoundsException siobe) {
/* 358 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String parseTNSDescription(String desc)
/*     */   {
/* 367 */     desc = desc.toLowerCase();
/* 368 */     String connectString = "@" + getTNSValue(desc, "host");
/* 369 */     connectString = connectString + ":" + getTNSValue(desc, "port");
/* 370 */     connectString = connectString + ":" + getTNSValue(desc, "sid");
/*     */ 
/* 372 */     return connectString;
/*     */   }
/*     */ 
/*     */   private String getTNSValue(String str, String key)
/*     */   {
/* 379 */     int end = str.indexOf(key);
/*     */ 
/* 381 */     if (end == -1) return ""; 
/*     */ end += key.length();
/*     */     char c;
/*     */     do
/*     */     {
/* 387 */       c = str.charAt(end);
/* 388 */       end++;
/* 389 */     }while ((c == ' ') || (c == '='));
/*     */ 
/* 391 */     int begin = end - 1;
/*     */     do
/*     */     {
/* 395 */       c = str.charAt(end);
/* 396 */       end++;
/* 397 */     }while (c != ')');
/*     */ 
/* 399 */     return str.substring(begin, end - 1);
/*     */   }
/*     */ 
/*     */   public class ResourceDefinitionExistsException extends Exception
/*     */   {
/*     */     ResourceDefinitionExistsException(String resourceName)
/*     */     {
/*  40 */       super();
/*     */     }
/*     */   }
/*     */ 
/*     */   public class ProducerExistsException extends Exception
/*     */   {
/*     */     ProducerExistsException(String producerName, String className)
/*     */     {
/*  32 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.resources.BaseResourceManager
 * JD-Core Version:    0.6.2
 */