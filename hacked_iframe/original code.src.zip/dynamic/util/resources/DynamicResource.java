package dynamic.util.resources;

public abstract interface DynamicResource
{
  public abstract DynamicResource initialize(Object paramObject, DynamicResourceProducer paramDynamicResourceProducer, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract void destroy();

  public abstract boolean acquire();

  public abstract void release();

  public abstract void release(boolean paramBoolean);

  public abstract void share();

  public abstract boolean isAvailable();

  public abstract boolean isExpired();

  public abstract boolean isShareable();

  public abstract String toHTML(String paramString, int paramInt, boolean paramBoolean);

  public abstract String getName();

  /** @deprecated */
  public abstract void releaseResource();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.resources.DynamicResource
 * JD-Core Version:    0.6.2
 */