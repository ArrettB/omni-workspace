/*    */ package dynamic.util.resources;
/*    */ 
/*    */ public class ResourceNotFoundException extends Exception
/*    */ {
/*    */   public ResourceNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ResourceNotFoundException(String message)
/*    */   {
/* 15 */     super(message);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.resources.ResourceNotFoundException
 * JD-Core Version:    0.6.2
 */