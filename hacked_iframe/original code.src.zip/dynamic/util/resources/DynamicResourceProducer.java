package dynamic.util.resources;

public abstract interface DynamicResourceProducer
{
  public abstract void initialize(ResourceManager paramResourceManager, String paramString1, Class paramClass, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract void destroy();

  public abstract DynamicResource newResource(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
    throws Exception;

  public abstract String getName();

  public abstract String toString();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.resources.DynamicResourceProducer
 * JD-Core Version:    0.6.2
 */