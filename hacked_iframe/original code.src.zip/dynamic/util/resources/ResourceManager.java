package dynamic.util.resources;

import org.w3c.dom.Node;

public abstract interface ResourceManager
{
  public abstract void initialize()
    throws Exception;

  public abstract void initialize(Node paramNode)
    throws Exception;

  public abstract void initialize(Node paramNode, ClassLoader paramClassLoader)
    throws Exception;

  public abstract void destroy();

  public abstract DynamicResource getResource()
    throws Exception;

  public abstract DynamicResource getResource(String paramString)
    throws Exception;

  public abstract void killResource(String paramString);

  public abstract String toHTML(String paramString1, String paramString2);
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.resources.ResourceManager
 * JD-Core Version:    0.6.2
 */