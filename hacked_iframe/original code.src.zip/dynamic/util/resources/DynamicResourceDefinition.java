/*    */ package dynamic.util.resources;
/*    */ 
/*    */ public class DynamicResourceDefinition
/*    */ {
/*    */   protected String name;
/*    */   protected String producer;
/*    */   protected String id;
/*    */   protected String username;
/*    */   protected String password;
/*    */   protected String type;
/*    */   protected String min;
/*    */   protected String max;
/*    */   protected String ttl;
/*    */   public static final String TYPE_POOLED = "Pooled";
/*    */   public static final String TYPE_SINGLE_USE = "SingleUse";
/*    */   public static final String TYPE_SINGLE_INSTANCE = "SingleInstance";
/*    */   public static final String TYPE_SHARED_POOL = "SharedPool";
/*    */   public static final String TRANS_ = "????";
/*    */ 
/*    */   public DynamicResourceDefinition(String producer, String name, String id, String username, String password, String type, String min, String max, String ttl)
/*    */   {
/* 38 */     if ((type == null) || (type.length() == 0))
/* 39 */       type = "Pooled";
/* 40 */     else if ((!type.equals("Pooled")) && (!type.equals("SingleUse")) && (!type.equals("SingleInstance")) && (!type.equals("SharedPool"))) {
/* 41 */       throw new IllegalArgumentException("Bad resource type: \"" + type + "\"");
/*    */     }
/* 43 */     this.name = name;
/* 44 */     this.producer = producer;
/* 45 */     this.id = id;
/* 46 */     this.username = username;
/* 47 */     this.password = password;
/* 48 */     this.type = type;
/* 49 */     this.min = min;
/* 50 */     this.max = max;
/* 51 */     this.ttl = ttl;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 56 */     return " name=" + this.name + " producer=" + this.producer + " id=" + this.id + " username=" + this.username + " password=" + this.password + " type=" + this.type + " min=" + this.min + " max=" + this.max + " ttl=" + this.ttl;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.resources.DynamicResourceDefinition
 * JD-Core Version:    0.6.2
 */