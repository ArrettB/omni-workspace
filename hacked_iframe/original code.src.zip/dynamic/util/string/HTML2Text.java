/*     */ package dynamic.util.string;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ public class HTML2Text
/*     */ {
/*  18 */   boolean body_found = false;
/*  19 */   boolean in_body = false;
/*  20 */   boolean center = false;
/*  21 */   boolean pre = false;
/*  22 */   boolean spaceprinted = false;
/*  23 */   String href = "";
/*     */ 
/*     */   public String convert(String source)
/*     */     throws Exception
/*     */   {
/*  28 */     StringBuffer result = new StringBuffer();
/*  29 */     StringBuffer result2 = new StringBuffer();
/*  30 */     StringReader input = new StringReader(source);
/*     */     try
/*     */     {
/*  34 */       String text = null;
/*  35 */       int c = input.read();
/*     */ 
/*  37 */       while (c != -1)
/*     */       {
/*  39 */         text = "";
/*  40 */         if (c == 60)
/*     */         {
/*  42 */           String CurrentTag = gettag(input);
/*  43 */           text = convertTag(CurrentTag);
/*     */         }
/*  45 */         else if (c == 38)
/*     */         {
/*  47 */           String specialchar = getspecial(input);
/*  48 */           if ((specialchar.equals("lt;")) || (specialchar.equals("#60")))
/*  49 */             text = "<";
/*  50 */           else if ((specialchar.equals("gt;")) || (specialchar.equals("#62")))
/*  51 */             text = ">";
/*  52 */           else if ((specialchar.equals("amp;")) || (specialchar.equals("#38")))
/*  53 */             text = "&";
/*  54 */           else if (specialchar.equals("nbsp;"))
/*  55 */             text = " ";
/*  56 */           else if ((specialchar.equals("quot;")) || (specialchar.equals("#34")))
/*  57 */             text = "\"";
/*  58 */           else if ((specialchar.equals("copy;")) || (specialchar.equals("#169")))
/*  59 */             text = "[Copyright]";
/*  60 */           else if ((specialchar.equals("reg;")) || (specialchar.equals("#174")))
/*  61 */             text = "[Registered]";
/*  62 */           else if ((specialchar.equals("trade;")) || (specialchar.equals("#153")))
/*  63 */             text = "[Trademark]";
/*     */           else
/*  65 */             text = "&" + specialchar;
/*     */         }
/*  67 */         else if ((!this.pre) && (Character.isWhitespace((char)c)))
/*     */         {
/*  69 */           if ((c == 32) && (!this.spaceprinted)) { text = " "; this.spaceprinted = true;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  74 */           text = "" + (char)c;
/*  75 */           this.spaceprinted = false;
/*     */         }
/*     */ 
/*  78 */         if (this.in_body) result.append(text); else {
/*  79 */           result2.append(text);
/*     */         }
/*  81 */         c = input.read();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  86 */       input.close();
/*  87 */       throw e;
/*     */     }
/*     */ 
/*  90 */     if (!this.body_found) return result2.toString();
/*  91 */     return result.toString();
/*     */   }
/*     */ 
/*     */   String gettag(Reader r)
/*     */     throws IOException
/*     */   {
/*  97 */     StringBuffer result = new StringBuffer();
/*  98 */     int c = r.read();
/*     */ 
/* 100 */     result.append('<');
/* 101 */     while ((c != 62) && (c != -1))
/*     */     {
/* 103 */       result.append((char)c);
/* 104 */       c = r.read();
/*     */     }
/* 106 */     result.append('>');
/*     */ 
/* 108 */     return result.toString();
/*     */   }
/*     */ 
/*     */   String getspecial(Reader r)
/*     */     throws IOException
/*     */   {
/* 114 */     StringBuffer result = new StringBuffer();
/* 115 */     r.mark(1);
/* 116 */     int c = r.read();
/*     */ 
/* 118 */     while (Character.isLetter((char)c))
/*     */     {
/* 120 */       result.append((char)c);
/* 121 */       r.mark(1);
/* 122 */       c = r.read();
/*     */     }
/*     */ 
/* 125 */     if (c == 59) result.append(';'); else {
/* 126 */       r.reset();
/*     */     }
/* 128 */     return result.toString();
/*     */   }
/*     */ 
/*     */   boolean isTag(String s1, String s2)
/*     */   {
/* 134 */     s1 = s1.toLowerCase();
/* 135 */     String t1 = "<" + s2.toLowerCase() + ">";
/* 136 */     String t2 = "<" + s2.toLowerCase() + " ";
/*     */ 
/* 138 */     return (s1.startsWith(t1)) || (s1.startsWith(t2));
/*     */   }
/*     */ 
/*     */   String convertTag(String t)
/*     */     throws IOException
/*     */   {
/* 144 */     String result = "";
/*     */ 
/* 146 */     if (isTag(t, "body")) {
/* 147 */       this.in_body = true; this.body_found = true;
/* 148 */     } else if (isTag(t, "/body")) {
/* 149 */       this.in_body = false; result = "\n";
/* 150 */     } else if (isTag(t, "center")) {
/* 151 */       result = "\n"; this.center = true;
/* 152 */     } else if (isTag(t, "/center")) {
/* 153 */       result = "\n"; this.center = false;
/* 154 */     } else if (isTag(t, "pre")) {
/* 155 */       result = "\n"; this.pre = true;
/* 156 */     } else if (isTag(t, "/pre")) {
/* 157 */       result = "\n"; this.pre = false;
/* 158 */     } else if (isTag(t, "p")) {
/* 159 */       result = "\n\n";
/* 160 */     } else if (isTag(t, "br")) {
/* 161 */       result = "\n";
/* 162 */     } else if ((isTag(t, "h1")) || (isTag(t, "h2")) || (isTag(t, "h3")) || (isTag(t, "h4")) || (isTag(t, "h5")) || (isTag(t, "h6")) || (isTag(t, "h7"))) {
/* 163 */       result = "\n";
/* 164 */     } else if ((isTag(t, "/h1")) || (isTag(t, "/h2")) || (isTag(t, "/h3")) || (isTag(t, "/h4")) || (isTag(t, "/h5")) || (isTag(t, "/h6")) || (isTag(t, "/h7"))) {
/* 165 */       result = "\n";
/* 166 */     } else if (isTag(t, "/dl")) {
/* 167 */       result = "\n";
/* 168 */     } else if (isTag(t, "dd")) {
/* 169 */       result = "\n  * ";
/* 170 */     } else if (isTag(t, "dt")) {
/* 171 */       result = "      ";
/* 172 */     } else if (isTag(t, "li")) {
/* 173 */       result = "\n  * ";
/* 174 */     } else if (isTag(t, "/ul")) {
/* 175 */       result = "\n";
/* 176 */     } else if (isTag(t, "/ol")) {
/* 177 */       result = "\n";
/* 178 */     } else if (isTag(t, "hr")) {
/* 179 */       result = "________________________________________________________________________\n\n";
/* 180 */     } else if (isTag(t, "table")) {
/* 181 */       result = "\n";
/* 182 */     } else if (isTag(t, "/table")) {
/* 183 */       result = "\n";
/* 184 */     } else if (isTag(t, "form")) {
/* 185 */       result = "\n";
/* 186 */     } else if (isTag(t, "/form")) {
/* 187 */       result = "\n";
/* 188 */     } else if (isTag(t, "b")) {
/* 189 */       result = "*";
/* 190 */     } else if (isTag(t, "/b")) {
/* 191 */       result = "*";
/* 192 */     } else if (isTag(t, "i")) {
/* 193 */       result = "\"";
/* 194 */     } else if (isTag(t, "/i")) {
/* 195 */       result = "\"";
/* 196 */     } else if (isTag(t, "img"))
/*     */     {
/* 198 */       int idx = t.indexOf("alt=\"");
/* 199 */       if (idx != -1)
/*     */       {
/* 201 */         idx += 5;
/* 202 */         int idx2 = t.indexOf("\"", idx);
/* 203 */         result = t.substring(idx, idx2);
/*     */       }
/*     */     }
/* 206 */     else if (isTag(t, "a"))
/*     */     {
/* 208 */       int idx = t.indexOf("href=\"");
/* 209 */       if (idx != -1)
/*     */       {
/* 211 */         idx += 6;
/* 212 */         int idx2 = t.indexOf("\"", idx);
/* 213 */         this.href = t.substring(idx, idx2);
/*     */       }
/*     */       else
/*     */       {
/* 217 */         this.href = "";
/*     */       }
/*     */     }
/* 220 */     else if (isTag(t, "/a"))
/*     */     {
/* 222 */       if (this.href.length() > 0)
/*     */       {
/* 224 */         result = " [" + this.href + "]";
/* 225 */         this.href = "";
/*     */       }
/*     */     }
/*     */ 
/* 229 */     if (result.length() > 0) this.spaceprinted = false;
/* 230 */     return result;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */     throws Exception
/*     */   {
/* 236 */     FileInputStream fis = null;
/* 237 */     String s = null;
/*     */     try
/*     */     {
/* 241 */       File file = new File("test.html");
/* 242 */       fis = new FileInputStream(file);
/* 243 */       byte[] buf = new byte[fis.available()];
/* 244 */       fis.read(buf);
/* 245 */       s = new String(buf);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 249 */       if (fis != null) fis.close();
/* 250 */       throw e;
/*     */     }
/*     */ 
/* 253 */     HTML2Text h = new HTML2Text();
/* 254 */     System.out.println(h.convert(s));
/* 255 */     Thread.sleep(200L);
/* 256 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.string.HTML2Text
 * JD-Core Version:    0.6.2
 */