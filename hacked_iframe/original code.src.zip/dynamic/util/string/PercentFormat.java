/*     */ package dynamic.util.string;
/*     */ 
/*     */ import java.text.FieldPosition;
/*     */ import java.text.Format;
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class PercentFormat extends Format
/*     */ {
/*     */   public static final String DEFAULT_FORMAT = "###-####;###-###-####";
/*     */   protected final String template;
/*     */   protected Hashtable formats;
/*  24 */   protected int max = 0;
/*     */ 
/*     */   public PercentFormat()
/*     */   {
/*  28 */     this("###-####;###-###-####");
/*     */   }
/*     */ 
/*     */   private Integer count(String s)
/*     */   {
/*  33 */     int result = 0;
/*     */ 
/*  35 */     for (int i = 0; i < s.length(); i++) {
/*  36 */       if ((s.charAt(i) >= '0') && (s.charAt(i) <= '9')) result++;
/*     */     }
/*  38 */     return new Integer(result);
/*     */   }
/*     */ 
/*     */   private Integer count(String s, char c)
/*     */   {
/*  43 */     int result = 0;
/*     */ 
/*  45 */     for (int i = 0; i < s.length(); i++) {
/*  46 */       if (s.charAt(i) == c) result++;
/*     */     }
/*  48 */     return new Integer(result);
/*     */   }
/*     */ 
/*     */   public PercentFormat(String template)
/*     */   {
/*  53 */     this.template = template;
/*  54 */     this.formats = new Hashtable();
/*  55 */     Vector v = StringUtil.stringToVector(template, ';');
/*  56 */     for (int i = 0; i < v.size(); i++)
/*     */     {
/*  58 */       String t = (String)v.elementAt(i);
/*  59 */       Integer count = count(t, '#');
/*  60 */       this.formats.put(count, t);
/*  61 */       if (count.intValue() > this.max) this.max = count.intValue(); 
/*     */     }
/*     */   }
/*     */ 
/*     */   public Number parse(String s)
/*     */     throws ParseException
/*     */   {
/*  67 */     ParsePosition parsePosition = new ParsePosition(0);
/*  68 */     Long phone_number = (Long)parseObject(s, parsePosition);
/*  69 */     if (parsePosition.getIndex() == 0) throw new ParseException("Unparseable number \"" + s + "\"", 0);
/*  70 */     return phone_number;
/*     */   }
/*     */ 
/*     */   public Object parseObject(String s, ParsePosition p)
/*     */   {
/*  75 */     Long result = Long.valueOf(StringUtil.getDigits(s, false));
/*  76 */     p.setIndex(s.length() + 1);
/*  77 */     return result;
/*     */   }
/*     */ 
/*     */   public StringBuffer format(Object o, StringBuffer sb, FieldPosition fp)
/*     */   {
/*  82 */     if ((o instanceof Long))
/*     */     {
/*  84 */       return new StringBuffer(format((Long)o));
/*     */     }
/*  86 */     if ((o instanceof String))
/*     */     {
/*  88 */       return new StringBuffer(format((String)o));
/*     */     }
/*     */ 
/*  92 */     throw new IllegalArgumentException("Cannot format " + o + " as a phone number");
/*     */   }
/*     */ 
/*     */   public String format(long l)
/*     */   {
/*  98 */     return format("" + l);
/*     */   }
/*     */ 
/*     */   public String format(Long l)
/*     */   {
/* 103 */     if (l == null) return "";
/* 104 */     return format(l.toString());
/*     */   }
/*     */ 
/*     */   public String format(String s)
/*     */   {
/* 109 */     if (s == null) return "";
/* 110 */     s = s.trim();
/* 111 */     if (s.charAt(0) == '+') return s;
/* 112 */     Integer digits = count(s);
/* 113 */     String format = (String)this.formats.get(digits);
/* 114 */     if (format == null)
/*     */     {
/* 116 */       if (digits.intValue() < this.max) return s;
/* 117 */       format = (String)this.formats.get(new Integer(this.max));
/*     */     }
/*     */ 
/* 120 */     int j = 0;
/* 121 */     StringBuffer result = new StringBuffer(format);
/* 122 */     for (int i = 0; i < format.length(); i++)
/*     */     {
/* 124 */       if (format.charAt(i) == '#')
/*     */       {
/* 126 */         while (!Character.isDigit(s.charAt(j))) j++;
/* 127 */         result.setCharAt(i, s.charAt(j));
/* 128 */         j++;
/*     */       }
/*     */     }
/*     */ 
/* 132 */     if (j < s.length()) result.append(s.substring(j));
/*     */ 
/* 134 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.string.PercentFormat
 * JD-Core Version:    0.6.2
 */