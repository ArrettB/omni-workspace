/*     */ package dynamic.util.string;
/*     */ 
/*     */ import java.text.FieldPosition;
/*     */ import java.text.Format;
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class PhoneNumberFormat extends Format
/*     */ {
/*     */   public static final String DEFAULT_FORMAT = "###-####;###-###-####";
/*     */   protected final String template;
/*     */   protected Hashtable formats;
/*  25 */   protected int max = 0;
/*     */ 
/*     */   public PhoneNumberFormat()
/*     */   {
/*  29 */     this("###-####;###-###-####");
/*     */   }
/*     */ 
/*     */   private Integer count(String s)
/*     */   {
/*  34 */     int result = 0;
/*     */ 
/*  36 */     for (int i = 0; i < s.length(); i++) {
/*  37 */       if ((s.charAt(i) >= '0') && (s.charAt(i) <= '9')) result++;
/*     */     }
/*  39 */     return new Integer(result);
/*     */   }
/*     */ 
/*     */   private Integer count(String s, char c)
/*     */   {
/*  44 */     int result = 0;
/*     */ 
/*  46 */     for (int i = 0; i < s.length(); i++) {
/*  47 */       if (s.charAt(i) == c) result++;
/*     */     }
/*  49 */     return new Integer(result);
/*     */   }
/*     */ 
/*     */   public PhoneNumberFormat(String template)
/*     */   {
/*  54 */     this.template = template;
/*  55 */     this.formats = new Hashtable();
/*  56 */     Vector v = StringUtil.stringToVector(template, ';');
/*  57 */     for (int i = 0; i < v.size(); i++)
/*     */     {
/*  59 */       String t = (String)v.elementAt(i);
/*  60 */       Integer count = count(t, '#');
/*  61 */       this.formats.put(count, t);
/*  62 */       if (count.intValue() > this.max) this.max = count.intValue(); 
/*     */     }
/*     */   }
/*     */ 
/*     */   public Number parse(String s)
/*     */     throws ParseException
/*     */   {
/*  68 */     ParsePosition parsePosition = new ParsePosition(0);
/*  69 */     Long phone_number = (Long)parseObject(s, parsePosition);
/*  70 */     if (parsePosition.getIndex() == 0) throw new ParseException("Unparseable number \"" + s + "\"", 0);
/*  71 */     return phone_number;
/*     */   }
/*     */ 
/*     */   public Object parseObject(String s, ParsePosition p)
/*     */   {
/*  76 */     Long result = Long.valueOf(StringUtil.getDigits(s, false));
/*  77 */     p.setIndex(s.length() + 1);
/*  78 */     return result;
/*     */   }
/*     */ 
/*     */   public StringBuffer format(Object o, StringBuffer sb, FieldPosition fp)
/*     */   {
/*  83 */     if ((o instanceof Long))
/*     */     {
/*  85 */       return new StringBuffer(format((Long)o));
/*     */     }
/*  87 */     if ((o instanceof String))
/*     */     {
/*  89 */       return new StringBuffer(format((String)o));
/*     */     }
/*     */ 
/*  93 */     throw new IllegalArgumentException("Cannot format " + o + " as a phone number");
/*     */   }
/*     */ 
/*     */   public String format(long l)
/*     */   {
/*  99 */     return format("" + l);
/*     */   }
/*     */ 
/*     */   public String format(Long l)
/*     */   {
/* 104 */     if (l == null) return "";
/* 105 */     return format(l.toString());
/*     */   }
/*     */ 
/*     */   public String format(String s)
/*     */   {
/* 110 */     if (s == null) return "";
/* 111 */     s = s.trim();
/* 112 */     if (s.charAt(0) == '+') return s;
/* 113 */     Integer digits = count(s);
/* 114 */     String format = (String)this.formats.get(digits);
/* 115 */     if (format == null)
/*     */     {
/* 117 */       if (digits.intValue() < this.max) return s;
/* 118 */       format = (String)this.formats.get(new Integer(this.max));
/*     */     }
/*     */ 
/* 121 */     int j = 0;
/* 122 */     StringBuffer result = new StringBuffer(format);
/* 123 */     for (int i = 0; i < format.length(); i++)
/*     */     {
/* 125 */       if (format.charAt(i) == '#')
/*     */       {
/* 127 */         while (!Character.isDigit(s.charAt(j))) j++;
/* 128 */         result.setCharAt(i, s.charAt(j));
/* 129 */         j++;
/*     */       }
/*     */     }
/*     */ 
/* 133 */     if (j < s.length()) result.append(s.substring(j));
/*     */ 
/* 135 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.string.PhoneNumberFormat
 * JD-Core Version:    0.6.2
 */