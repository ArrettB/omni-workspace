/*    */ package dynamic.util.tlaunch;
/*    */ 
/*    */ import dynamic.util.date.StdDate;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class TimedEvent
/*    */ {
/*    */   private EventInterval interval;
/*    */   private ITimedEvent te;
/*    */ 
/*    */   public TimedEvent(ITimedEvent te, EventInterval interval)
/*    */   {
/* 24 */     this.interval = interval;
/* 25 */     this.te = te;
/*    */   }
/*    */ 
/*    */   public void press(StdDate curTime)
/*    */   {
/* 33 */     if (this.interval.isItTimeYet(curTime))
/*    */     {
/* 35 */       Diagnostics.debug("TimedEvent.press() actual run time: " + new StdDate());
/*    */ 
/* 37 */       Thread toPress = new EventThread(this.te, curTime);
/* 38 */       Diagnostics.registerThread(toPress, Diagnostics.getContext());
/* 39 */       toPress.start();
/*    */     }
/*    */   }
/*    */ 
/*    */   private class EventThread extends Thread
/*    */   {
/*    */     ITimedEvent eventToThread;
/*    */     StdDate curTime;
/*    */ 
/*    */     public EventThread(ITimedEvent eventToThread, StdDate curTime)
/*    */     {
/* 53 */       this.eventToThread = eventToThread;
/* 54 */       this.curTime = curTime;
/* 55 */       setName("TimedEvent" + new StdDate().getTime());
/*    */     }
/*    */ 
/*    */     public void run()
/*    */     {
/* 60 */       this.eventToThread.execute(this.curTime);
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tlaunch.TimedEvent
 * JD-Core Version:    0.6.2
 */