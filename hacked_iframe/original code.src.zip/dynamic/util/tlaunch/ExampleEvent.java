/*    */ package dynamic.util.tlaunch;
/*    */ 
/*    */ import dynamic.util.date.StdDate;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ 
/*    */ public class ExampleEvent
/*    */   implements ITimedEvent
/*    */ {
/*    */   String text;
/*    */ 
/*    */   public ExampleEvent(String text)
/*    */   {
/* 22 */     this.text = text;
/*    */   }
/*    */ 
/*    */   public void execute(StdDate curTime)
/*    */   {
/* 27 */     Diagnostics.debug("ExampleEvent.execute()****** " + this.text + " " + curTime + " ******");
/*    */     try
/*    */     {
/* 31 */       Thread.sleep(10000L);
/*    */     }
/*    */     catch (InterruptedException e)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tlaunch.ExampleEvent
 * JD-Core Version:    0.6.2
 */