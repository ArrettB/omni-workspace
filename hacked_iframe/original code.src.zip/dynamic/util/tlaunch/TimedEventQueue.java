/*    */ package dynamic.util.tlaunch;
/*    */ 
/*    */ import dynamic.util.date.StdDate;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class TimedEventQueue
/*    */ {
/*    */   EventTimer timer;
/*    */   Vector queue;
/*    */   TimedEvent[] aQueue;
/* 19 */   static long MINUTE = 60000L;
/*    */   int minutes;
/*    */ 
/*    */   public TimedEventQueue(EventTimer timer, int minutes)
/*    */   {
/* 27 */     this.queue = new Vector();
/* 28 */     this.timer = timer;
/* 29 */     this.minutes = minutes;
/*    */   }
/*    */ 
/*    */   public void runCurrent()
/*    */   {
/* 34 */     if (this.aQueue != null)
/*    */     {
/* 36 */       StdDate currentTime = new StdDate();
/* 37 */       Diagnostics.debug("TimedEventQueue.runCurrent() " + currentTime);
/* 38 */       for (int i = 0; i < this.aQueue.length; i++)
/*    */       {
/* 40 */         this.aQueue[i].press(currentTime);
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 45 */       Diagnostics.debug("TimedEventQueue.runCurrent() no events");
/*    */     }
/*    */   }
/*    */ 
/*    */   public long getTimeToNextEvent()
/*    */   {
/* 54 */     return this.minutes * MINUTE;
/*    */   }
/*    */ 
/*    */   public long getNumberOfEvents()
/*    */   {
/* 59 */     return this.aQueue.length;
/*    */   }
/*    */ 
/*    */   public void addEvent(TimedEvent timedEvent)
/*    */   {
/* 67 */     this.queue.addElement(timedEvent);
/* 68 */     this.aQueue = new TimedEvent[this.queue.size()];
/* 69 */     this.queue.copyInto(this.aQueue);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tlaunch.TimedEventQueue
 * JD-Core Version:    0.6.2
 */