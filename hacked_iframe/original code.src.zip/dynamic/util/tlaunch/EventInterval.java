/*     */ package dynamic.util.tlaunch;
/*     */ 
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ 
/*     */ public class EventInterval
/*     */ {
/*     */   private int[] minute;
/*     */   private int[] hour;
/*     */   private int[] dayOfMonth;
/*     */   private int[] monthOfYear;
/*     */   private int[] dayOfWeek;
/*     */   private int[] year;
/*     */ 
/*     */   public EventInterval(int[] minute, int[] hour, int[] dayOfMonth, int[] monthOfYear, int[] dayOfWeek, int[] year)
/*     */   {
/*  64 */     this.minute = minute;
/*  65 */     this.hour = hour;
/*  66 */     this.dayOfMonth = dayOfMonth;
/*  67 */     this.monthOfYear = monthOfYear;
/*  68 */     this.dayOfWeek = dayOfWeek;
/*  69 */     this.year = year;
/*     */   }
/*     */ 
/*     */   public boolean isItTimeYet(StdDate curTime)
/*     */   {
/*  78 */     if (this.minute != null)
/*     */     {
/*  81 */       boolean nextTrigMinute = match(this.minute, curTime.getMinute());
/*  82 */       if (!nextTrigMinute)
/*  83 */         return false;
/*     */     }
/*  85 */     if (this.hour != null)
/*     */     {
/*  88 */       boolean nextTrigHour = match(this.hour, curTime.getHour());
/*  89 */       if (!nextTrigHour) {
/*  90 */         return false;
/*     */       }
/*     */     }
/*  93 */     boolean weekday = true;
/*  94 */     if (this.dayOfWeek != null)
/*     */     {
/*  96 */       weekday = match(this.dayOfWeek, curTime.getDayOfWeek());
/*     */     }
/*  98 */     boolean monthday = true;
/*  99 */     if (this.dayOfMonth != null)
/*     */     {
/* 101 */       monthday = match(this.dayOfMonth, curTime.getDayOfMonth());
/*     */     }
/* 103 */     if ((!monthday) || (!weekday))
/*     */     {
/* 105 */       return false;
/*     */     }
/*     */ 
/* 108 */     if (this.monthOfYear != null)
/*     */     {
/* 111 */       boolean nextTrigMonth = match(this.monthOfYear, curTime.getCalMonth());
/* 112 */       if (!nextTrigMonth)
/* 113 */         return false;
/*     */     }
/* 115 */     if (this.year != null)
/*     */     {
/* 118 */       boolean nextTrigYear = match(this.year, curTime.getCalYear());
/* 119 */       if (!nextTrigYear) {
/* 120 */         return false;
/*     */       }
/*     */     }
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   private boolean match(int[] valArray, int value)
/*     */   {
/* 131 */     Diagnostics.debug("EventInterval.match() value = " + value);
/* 132 */     for (int i = 0; i < valArray.length; i++)
/*     */     {
/* 134 */       Diagnostics.debug("EventInterval.match() valArray[" + i + "] = " + valArray[i]);
/* 135 */       if (valArray[i] == value) {
/* 136 */         return true;
/*     */       }
/*     */     }
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/* 147 */     EventInterval ei = new EventInterval(null, new int[] { 14 }, null, null, null, null);
/* 148 */     StdDate testdate = new StdDate();
/* 149 */     Diagnostics.debug("EventInterval.main() current time " + testdate);
/* 150 */     Diagnostics.debug("EventInterval.main() any time between 2pm and 3pm " + ei.isItTimeYet(testdate));
/*     */ 
/* 152 */     ei = new EventInterval(null, new int[] { 14 }, new int[] { 8, 9 }, null, null, null);
/* 153 */     Diagnostics.debug("EventInterval.main() between 2pm and 3pm on the 8th or 9th " + ei.isItTimeYet(testdate));
/*     */ 
/* 155 */     ei = new EventInterval(null, new int[] { 14 }, null, new int[] { 7 }, null, null);
/* 156 */     Diagnostics.debug("EventInterval.main() between 2pm and 3pm in Aug " + ei.isItTimeYet(testdate));
/*     */ 
/* 158 */     ei = new EventInterval(null, new int[] { 14 }, null, null, new int[] { 5 }, null);
/* 159 */     Diagnostics.debug("EventInterval.main() between 2pm and 3pm on Thu " + ei.isItTimeYet(testdate));
/*     */ 
/* 161 */     ei = new EventInterval(new int[] { 21 }, new int[] { 14 }, new int[] { 9 }, new int[] { 8 }, null, new int[] { 1999 });
/* 162 */     Diagnostics.debug("EventInterval.main() Only on Thu, Sep 9 at 14:21 " + ei.isItTimeYet(testdate));
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tlaunch.EventInterval
 * JD-Core Version:    0.6.2
 */