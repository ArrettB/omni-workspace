/*     */ package dynamic.util.tlaunch;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class EventTimer extends Thread
/*     */ {
/*  19 */   long timeToNextEvent = 0L;
/*     */   TimedEventQueue timerQueue;
/*  21 */   static String TIMER_NAME = "EventTimer";
/*  22 */   boolean running = true;
/*     */ 
/*     */   public EventTimer()
/*     */   {
/*  36 */     setName(TIMER_NAME);
/*     */ 
/*  38 */     this.timerQueue = new TimedEventQueue(this, 1);
/*     */   }
/*     */ 
/*     */   public EventTimer(Vector events)
/*     */   {
/*  47 */     for (int i = 0; i < events.size(); i++)
/*     */     {
/*  49 */       if ((events.elementAt(i) instanceof TimedEvent))
/*  50 */         this.timerQueue.addEvent((TimedEvent)events.elementAt(i));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  57 */     while (this.running)
/*     */     {
/*  60 */       this.timerQueue.runCurrent();
/*     */       try
/*     */       {
/*  65 */         Thread.yield();
/*     */ 
/*  68 */         this.timeToNextEvent = this.timerQueue.getTimeToNextEvent();
/*  69 */         Thread.sleep(this.timeToNextEvent);
/*     */       }
/*     */       catch (InterruptedException e)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public TimedEventQueue getQueue()
/*     */   {
/*  86 */     return this.timerQueue;
/*     */   }
/*     */ 
/*     */   public void addEvent(TimedEvent newEvent)
/*     */   {
/*  94 */     this.timerQueue.addEvent(newEvent);
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/* 104 */     Vector eQueue = new Vector();
/*     */ 
/* 107 */     TimedEvent event = new TimedEvent(new ExampleEvent("each minute "), new EventInterval(null, null, null, null, null, null));
/*     */ 
/* 109 */     eQueue.addElement(event);
/*     */ 
/* 112 */     int[] evenMinutes = new int[30];
/* 113 */     for (int i = 0; i < evenMinutes.length; i++)
/* 114 */       evenMinutes[i] = (i * 2);
/* 115 */     event = new TimedEvent(new ExampleEvent("even minutes "), new EventInterval(evenMinutes, null, null, null, null, null));
/*     */ 
/* 117 */     eQueue.addElement(event);
/* 118 */     Diagnostics.debug("EventTimer.main() starting");
/*     */ 
/* 121 */     EventTimer et = new EventTimer(eQueue);
/* 122 */     Diagnostics.registerThread(et, Diagnostics.getContext());
/* 123 */     et.start();
/*     */     try
/*     */     {
/* 128 */       Thread.sleep(180000L);
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */     }
/*     */ 
/* 135 */     Diagnostics.debug("EventTimer.main() done");
/* 136 */     et.running = false;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tlaunch.EventTimer
 * JD-Core Version:    0.6.2
 */