package dynamic.util.tlaunch;

import dynamic.util.date.StdDate;

public abstract interface ITimedEvent
{
  public abstract void execute(StdDate paramStdDate);
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tlaunch.ITimedEvent
 * JD-Core Version:    0.6.2
 */