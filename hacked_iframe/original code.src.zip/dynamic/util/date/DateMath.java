/*     */ package dynamic.util.date;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ 
/*     */ /** @deprecated */
/*     */ public class DateMath
/*     */ {
/*  15 */   private static final int[] month_days = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*  16 */   private static final int[] leap_month_days = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
/*     */   private static final int millisPerDay = 86400000;
/*     */ 
/*     */   public static int getSeconds(Date in)
/*     */   {
/*  24 */     GregorianCalendar cal = new GregorianCalendar();
/*  25 */     cal.setTime(in);
/*  26 */     return cal.get(13);
/*     */   }
/*     */ 
/*     */   public static int getMinute(Date in)
/*     */   {
/*  34 */     GregorianCalendar cal = new GregorianCalendar();
/*  35 */     cal.setTime(in);
/*  36 */     return cal.get(12);
/*     */   }
/*     */ 
/*     */   public static int getHour(Date in)
/*     */   {
/*  44 */     GregorianCalendar cal = new GregorianCalendar();
/*  45 */     cal.setTime(in);
/*  46 */     return cal.get(11);
/*     */   }
/*     */ 
/*     */   public static int getWeek(Date in)
/*     */   {
/*  54 */     GregorianCalendar cal = new GregorianCalendar();
/*  55 */     cal.setTime(in);
/*  56 */     return cal.get(3);
/*     */   }
/*     */ 
/*     */   public static int getDayOfWeek(Date in)
/*     */   {
/*  64 */     GregorianCalendar cal = new GregorianCalendar();
/*  65 */     cal.setTime(in);
/*  66 */     return cal.get(7);
/*     */   }
/*     */ 
/*     */   public static int getMonth(Date in)
/*     */   {
/*  74 */     GregorianCalendar cal = new GregorianCalendar();
/*  75 */     cal.setTime(in);
/*  76 */     return cal.get(2);
/*     */   }
/*     */ 
/*     */   public static int getDayOfMonth(Date in)
/*     */   {
/*  84 */     GregorianCalendar cal = new GregorianCalendar();
/*  85 */     cal.setTime(in);
/*  86 */     return cal.get(5);
/*     */   }
/*     */ 
/*     */   public static int getYear(Date in)
/*     */   {
/*  94 */     GregorianCalendar cal = new GregorianCalendar();
/*  95 */     cal.setTime(in);
/*  96 */     return cal.get(1);
/*     */   }
/*     */ 
/*     */   public static Date setSeconds(Date in, int seconds)
/*     */   {
/* 104 */     GregorianCalendar cal = new GregorianCalendar();
/* 105 */     cal.setTime(in);
/* 106 */     cal.set(13, seconds);
/* 107 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date setMinutes(Date in, int minutes)
/*     */   {
/* 115 */     GregorianCalendar cal = new GregorianCalendar();
/* 116 */     cal.setTime(in);
/* 117 */     cal.set(12, minutes);
/* 118 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date setHour(Date in, int hour)
/*     */   {
/* 126 */     GregorianCalendar cal = new GregorianCalendar();
/* 127 */     cal.setTime(in);
/* 128 */     cal.set(10, hour);
/* 129 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date setDayOfMonth(Date in, int day)
/*     */   {
/* 137 */     GregorianCalendar cal = new GregorianCalendar();
/* 138 */     cal.setTime(in);
/* 139 */     cal.set(5, day);
/* 140 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date setMonth(Date in, int month)
/*     */   {
/* 148 */     GregorianCalendar cal = new GregorianCalendar();
/* 149 */     cal.setTime(in);
/* 150 */     cal.set(2, month);
/* 151 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date setYear(Date in, int year)
/*     */   {
/* 159 */     GregorianCalendar cal = new GregorianCalendar();
/* 160 */     cal.setTime(in);
/* 161 */     cal.set(1, fixYear(year));
/* 162 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addSeconds(Date in, int seconds)
/*     */   {
/* 167 */     GregorianCalendar cal = new GregorianCalendar();
/* 168 */     cal.setTime(in);
/* 169 */     cal.add(13, seconds);
/* 170 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addMinutes(Date in, int minutes)
/*     */   {
/* 175 */     GregorianCalendar cal = new GregorianCalendar();
/* 176 */     cal.setTime(in);
/* 177 */     cal.add(12, minutes);
/* 178 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addHours(Date in, int hours)
/*     */   {
/* 183 */     GregorianCalendar cal = new GregorianCalendar();
/* 184 */     cal.setTime(in);
/* 185 */     cal.add(10, hours);
/* 186 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addDays(Date in, int days)
/*     */   {
/* 191 */     GregorianCalendar cal = new GregorianCalendar();
/* 192 */     cal.setTime(in);
/* 193 */     cal.add(5, days);
/* 194 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addWeeks(Date in, int weeks)
/*     */   {
/* 199 */     GregorianCalendar cal = new GregorianCalendar();
/* 200 */     cal.setTime(in);
/* 201 */     cal.add(5, weeks * 7);
/* 202 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addMonths(Date in, int months)
/*     */   {
/* 207 */     GregorianCalendar cal = new GregorianCalendar();
/* 208 */     cal.setTime(in);
/* 209 */     cal.add(2, months);
/* 210 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date addYears(Date in, int years)
/*     */   {
/* 215 */     GregorianCalendar cal = new GregorianCalendar();
/* 216 */     cal.setTime(in);
/* 217 */     cal.add(1, years);
/* 218 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static int getDaysBetween(Date d1, Date d2)
/*     */   {
/* 226 */     if ((d1 == null) || (d2 == null))
/*     */     {
/* 228 */       return 365;
/*     */     }
/*     */ 
/* 232 */     return (int)Math.min(Math.abs(d2.getTime() - d1.getTime()) / 86400000L, 365L);
/*     */   }
/*     */ 
/*     */   public static int getWeeksBetween(Date d1, Date d2)
/*     */   {
/* 241 */     return getDaysBetween(d1, d2) / 7;
/*     */   }
/*     */ 
/*     */   public static int fixYear(int year)
/*     */   {
/* 250 */     if (year >= 100) return year;
/*     */ 
/* 252 */     GregorianCalendar cal = new GregorianCalendar();
/* 253 */     int century = cal.get(1) / 100 * 100;
/*     */ 
/* 255 */     if (year < 25) {
/* 256 */       return century + year;
/*     */     }
/* 258 */     return century + year - 100;
/*     */   }
/*     */ 
/*     */   public static Date getEarliestDate()
/*     */   {
/* 266 */     Date d = new Date();
/* 267 */     d.setTime(0L);
/* 268 */     return d;
/*     */   }
/*     */ 
/*     */   public static Date getLatestDate()
/*     */   {
/* 276 */     Date d = new Date();
/* 277 */     d.setTime(9223372036854775807L);
/* 278 */     return d;
/*     */   }
/*     */ 
/*     */   public static boolean isBusinessDay(Date in)
/*     */   {
/* 283 */     GregorianCalendar cal = new GregorianCalendar();
/* 284 */     cal.setTime(in);
/* 285 */     return isBusinessDay(cal);
/*     */   }
/*     */ 
/*     */   private static boolean isBusinessDay(Calendar cal)
/*     */   {
/* 290 */     int weekday = cal.get(7);
/* 291 */     return (weekday != 7) && (weekday != 1);
/*     */   }
/*     */ 
/*     */   public static Date addBusinessDays(Date in, int days)
/*     */   {
/* 300 */     GregorianCalendar cal = new GregorianCalendar();
/* 301 */     cal.setTime(in);
/*     */ 
/* 303 */     int daysAdded = 0;
/* 304 */     while (daysAdded < days)
/*     */     {
/* 306 */       cal.add(5, 1);
/* 307 */       if (isBusinessDay(cal))
/*     */       {
/* 309 */         daysAdded++;
/*     */       }
/*     */     }
/* 312 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date firstDayOfMonth(Date in)
/*     */   {
/* 317 */     GregorianCalendar cal = new GregorianCalendar();
/* 318 */     cal.setTime(in);
/* 319 */     cal.set(5, 1);
/* 320 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date lastDayOfMonth(Date in)
/*     */   {
/* 325 */     GregorianCalendar cal = new GregorianCalendar();
/* 326 */     cal.setTime(in);
/*     */     int day;
/* 329 */     if (cal.isLeapYear(cal.get(1)))
/* 330 */       day = leap_month_days[cal.get(2)];
/*     */     else {
/* 332 */       day = month_days[cal.get(2)];
/*     */     }
/* 334 */     cal.set(5, day);
/*     */ 
/* 336 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date firstDayOfYear(Date in)
/*     */   {
/* 341 */     GregorianCalendar cal = new GregorianCalendar();
/* 342 */     cal.setTime(in);
/* 343 */     cal.set(6, 1);
/* 344 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date lastDayOfYear(Date in)
/*     */   {
/* 349 */     GregorianCalendar cal = new GregorianCalendar();
/* 350 */     cal.setTime(in);
/*     */     int day;
/* 353 */     if (cal.isLeapYear(cal.get(1)))
/* 354 */       day = 366;
/*     */     else {
/* 356 */       day = 365;
/*     */     }
/* 358 */     cal.set(6, day);
/*     */ 
/* 360 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date LDOMMinusYear(Date in)
/*     */   {
/* 367 */     Date temp = lastDayOfMonth(in);
/* 368 */     temp = addYears(temp, -1);
/* 369 */     return addDays(temp, 1);
/*     */   }
/*     */ 
/*     */   public static Date firstSundayOfMonth(Date in)
/*     */   {
/* 374 */     GregorianCalendar cal = new GregorianCalendar();
/* 375 */     cal.setTime(in);
/* 376 */     cal.set(5, 1);
/* 377 */     if (cal.get(7) != 1) {
/* 378 */       cal.add(5, 8 - cal.get(7));
/*     */     }
/* 380 */     cal.clear(11);
/* 381 */     cal.clear(12);
/* 382 */     cal.clear(13);
/* 383 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static boolean areEqual(Date d1, Date d2)
/*     */   {
/* 391 */     if ((d1 == null) && (d2 == null)) {
/* 392 */       return true;
/*     */     }
/* 394 */     if ((d1 == null) || (d2 == null)) {
/* 395 */       return false;
/*     */     }
/* 397 */     GregorianCalendar cal = new GregorianCalendar();
/* 398 */     GregorianCalendar cal2 = new GregorianCalendar();
/* 399 */     cal.setTime(d1);
/* 400 */     cal2.setTime(d2);
/* 401 */     return (cal.get(5) == cal2.get(5)) && (cal.get(2) == cal2.get(2)) && (cal.get(1) == cal2.get(1));
/*     */   }
/*     */ 
/*     */   public static boolean equals(Date d1, Date d2)
/*     */   {
/* 411 */     if ((d1 == null) && (d2 == null)) {
/* 412 */       return true;
/*     */     }
/* 414 */     if ((d1 == null) || (d2 == null)) {
/* 415 */       return false;
/*     */     }
/* 417 */     GregorianCalendar cal = new GregorianCalendar();
/* 418 */     GregorianCalendar cal2 = new GregorianCalendar();
/* 419 */     cal.setTime(d1);
/* 420 */     cal2.setTime(d2);
/* 421 */     return (cal.get(5) == cal2.get(5)) && (cal.get(2) == cal2.get(2)) && (cal.get(1) == cal2.get(1)) && (cal.get(10) == cal2.get(10)) && (cal.get(12) == cal2.get(12)) && (cal.get(13) == cal2.get(13));
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.date.DateMath
 * JD-Core Version:    0.6.2
 */