/*     */ package dynamic.util.date;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ 
/*     */ public class Holidays
/*     */ {
/*     */   public static Date NewYearsDayObserved(int nYear)
/*     */   {
/*  19 */     GregorianCalendar cal = new GregorianCalendar(nYear, 0, 1);
/*  20 */     return beforeAfterWeekend(cal).getTime();
/*     */   }
/*     */ 
/*     */   public static Date NewYearsDay(int nYear)
/*     */   {
/*  26 */     GregorianCalendar cal = new GregorianCalendar(nYear, 0, 1);
/*  27 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date RobertELeeDay(int nYear)
/*     */   {
/*  32 */     return new GregorianCalendar(nYear, 0, 18).getTime();
/*     */   }
/*     */ 
/*     */   public static Date MartinLutherKingObserved(int nYear)
/*     */   {
/*  38 */     GregorianCalendar cal = new GregorianCalendar(nYear, 0, 1);
/*  39 */     cal.set(7, 2);
/*  40 */     cal.set(8, 3);
/*     */ 
/*  42 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date GroundhogDay(int nYear)
/*     */   {
/*  48 */     return new GregorianCalendar(nYear, 1, 8).getTime();
/*     */   }
/*     */ 
/*     */   public static Date AbrahamLincolnsBirthday(int nYear)
/*     */   {
/*  54 */     return new GregorianCalendar(nYear, 1, 12).getTime();
/*     */   }
/*     */ 
/*     */   public static Date ValentinesDay(int nYear)
/*     */   {
/*  60 */     return new GregorianCalendar(nYear, 1, 14).getTime();
/*     */   }
/*     */ 
/*     */   public static Date SusanBAnthonyDay(int nYear)
/*     */   {
/*  66 */     return new GregorianCalendar(nYear, 1, 15).getTime();
/*     */   }
/*     */ 
/*     */   public static Date PresidentsDayObserved(int nYear)
/*     */   {
/*  72 */     GregorianCalendar cal = new GregorianCalendar(nYear, 1, 1);
/*  73 */     cal.set(7, 2);
/*  74 */     cal.set(8, 3);
/*     */ 
/*  76 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date SaintPatricksDay(int nYear)
/*     */   {
/*  81 */     return new GregorianCalendar(nYear, 2, 17).getTime();
/*     */   }
/*     */ 
/*     */   public static Date GoodFridayObserved(int nYear)
/*     */   {
/*  87 */     int nEasterMonth = 0;
/*  88 */     int nEasterDay = 0;
/*  89 */     int nGoodFridayMonth = 0;
/*  90 */     int nGoodFridayDay = 0;
/*  91 */     Date dEasterSunday = EasterSunday(nYear);
/*  92 */     GregorianCalendar easterSunday = new GregorianCalendar();
/*  93 */     easterSunday.setTime(dEasterSunday);
/*  94 */     nEasterMonth = easterSunday.get(2);
/*  95 */     nEasterDay = easterSunday.get(5);
/*     */ 
/*  97 */     if ((nEasterDay <= 3) && (nEasterMonth == 3));
/*  99 */     switch (nEasterDay)
/*     */     {
/*     */     case 3:
/* 102 */       nGoodFridayMonth = nEasterMonth - 1;
/* 103 */       nGoodFridayDay = nEasterDay - 2;
/* 104 */       break;
/*     */     case 1:
/*     */     case 2:
/* 107 */       nGoodFridayMonth = nEasterMonth - 1;
/* 108 */       nGoodFridayDay = 31;
/* 109 */       break;
/*     */     default:
/* 111 */       nGoodFridayMonth = nEasterMonth;
/* 112 */       nGoodFridayDay = nEasterDay - 2; break;
/*     */ 
/* 117 */       nGoodFridayMonth = nEasterMonth;
/* 118 */       nGoodFridayDay = nEasterDay - 2;
/*     */     }
/*     */ 
/* 121 */     return new GregorianCalendar(nYear, nGoodFridayMonth, nGoodFridayDay).getTime();
/*     */   }
/*     */ 
/*     */   public static Date EasterSunday(int nYear)
/*     */   {
/* 161 */     int nA = 0;
/* 162 */     int nB = 0;
/* 163 */     int nC = 0;
/* 164 */     int nD = 0;
/* 165 */     int nE = 0;
/* 166 */     int nF = 0;
/* 167 */     int nG = 0;
/* 168 */     int nH = 0;
/* 169 */     int nI = 0;
/* 170 */     int nK = 0;
/* 171 */     int nL = 0;
/* 172 */     int nM = 0;
/* 173 */     int nP = 0;
/* 174 */     int nYY = 0;
/* 175 */     int nEasterMonth = 0;
/* 176 */     int nEasterDay = 0;
/*     */ 
/* 179 */     nYY = nYear;
/* 180 */     if (nYear < 1900)
/*     */     {
/* 184 */       nYear += 1900;
/*     */     }
/* 186 */     nA = nYear % 19;
/* 187 */     nB = nYear / 100;
/* 188 */     nC = nYear % 100;
/* 189 */     nD = nB / 4;
/* 190 */     nE = nB % 4;
/* 191 */     nF = (nB + 8) / 25;
/* 192 */     nG = (nB - nF + 1) / 3;
/* 193 */     nH = (19 * nA + nB - nD - nG + 15) % 30;
/* 194 */     nI = nC / 4;
/* 195 */     nK = nC % 4;
/* 196 */     nL = (32 + 2 * nE + 2 * nI - nH - nK) % 7;
/* 197 */     nM = (nA + 11 * nH + 22 * nL) / 451;
/*     */ 
/* 200 */     nEasterMonth = (nH + nL - 7 * nM + 114) / 31;
/* 201 */     nEasterMonth--;
/* 202 */     nP = (nH + nL - 7 * nM + 114) % 31;
/*     */ 
/* 205 */     nEasterDay = nP + 1;
/*     */ 
/* 208 */     nYear -= 1900;
/*     */ 
/* 211 */     return new GregorianCalendar(nYear, nEasterMonth, nEasterDay).getTime();
/*     */   }
/*     */ 
/*     */   public static Date EasterMonday(int nYear)
/*     */   {
/* 216 */     int nEasterMonth = 0;
/* 217 */     int nEasterDay = 0;
/* 218 */     Date dEasterSunday = EasterSunday(nYear);
/* 219 */     GregorianCalendar easterMonday = new GregorianCalendar();
/* 220 */     easterMonday.setTime(dEasterSunday);
/* 221 */     nEasterMonth = easterMonday.get(2);
/* 222 */     nEasterDay = easterMonday.get(5);
/* 223 */     if ((nEasterMonth == 2) || (nEasterDay == 31))
/*     */     {
/* 225 */       easterMonday.set(2, 3);
/* 226 */       easterMonday.set(5, 1);
/*     */     }
/*     */     else
/*     */     {
/* 230 */       easterMonday.add(5, 1);
/*     */     }
/* 232 */     return easterMonday.getTime();
/*     */   }
/*     */ 
/*     */   public static Date CincoDeMayo(int nYear)
/*     */   {
/* 238 */     return new GregorianCalendar(nYear, 4, 5).getTime();
/*     */   }
/*     */ 
/*     */   public static Date MemorialDayObserved(int nYear)
/*     */   {
/* 244 */     GregorianCalendar cal = new GregorianCalendar(nYear, 4, 1);
/* 245 */     cal.set(7, 2);
/* 246 */     cal.set(8, -1);
/*     */ 
/* 248 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date IndependenceDayObserved(int nYear)
/*     */   {
/* 253 */     GregorianCalendar cal = new GregorianCalendar(nYear, 6, 4);
/* 254 */     return beforeAfterWeekend(cal).getTime();
/*     */   }
/*     */ 
/*     */   public static Date IndependenceDay(int nYear)
/*     */   {
/* 260 */     return new GregorianCalendar(nYear, 6, 4).getTime();
/*     */   }
/*     */ 
/*     */   public static Date CanadianCivicHoliday(int nYear)
/*     */   {
/* 266 */     GregorianCalendar cal = new GregorianCalendar(nYear, 7, 1);
/* 267 */     cal.set(7, 2);
/* 268 */     cal.set(8, 1);
/*     */ 
/* 270 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date LaborDayObserved(int nYear)
/*     */   {
/* 276 */     GregorianCalendar cal = new GregorianCalendar(nYear, 8, 1);
/* 277 */     cal.set(7, 2);
/* 278 */     cal.set(8, 1);
/*     */ 
/* 280 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date ColumbusDayObserved(int nYear)
/*     */   {
/* 286 */     GregorianCalendar cal = new GregorianCalendar(nYear, 9, 1);
/* 287 */     cal.set(7, 2);
/* 288 */     cal.set(8, 2);
/*     */ 
/* 290 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date Halloween(int nYear)
/*     */   {
/* 296 */     return new GregorianCalendar(nYear, 9, 31).getTime();
/*     */   }
/*     */ 
/*     */   public static Date USElectionDay(int nYear)
/*     */   {
/* 302 */     GregorianCalendar cal = new GregorianCalendar(nYear, 10, 1);
/* 303 */     cal.set(7, 3);
/* 304 */     cal.set(8, 1);
/*     */ 
/* 306 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date VeteransDayObserved(int nYear)
/*     */   {
/* 312 */     int nMonth = 10;
/* 313 */     return new GregorianCalendar(nYear, 10, 11).getTime();
/*     */   }
/*     */ 
/*     */   public static Date RememberenceDayObserved(int nYear)
/*     */   {
/* 319 */     return VeteransDayObserved(nYear);
/*     */   }
/*     */ 
/*     */   public static Date ThanksgivingObserved(int nYear)
/*     */   {
/* 325 */     GregorianCalendar cal = new GregorianCalendar(nYear, 10, 1);
/* 326 */     cal.set(7, 5);
/* 327 */     cal.set(8, 3);
/*     */ 
/* 329 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public static Date ChristmasDayObserved(int nYear)
/*     */   {
/* 334 */     GregorianCalendar cal = new GregorianCalendar(nYear, 11, 25);
/* 335 */     return beforeAfterWeekend(cal).getTime();
/*     */   }
/*     */ 
/*     */   public static Date ChristmasDay(int nYear)
/*     */   {
/* 341 */     return new GregorianCalendar(nYear, 11, 25).getTime();
/*     */   }
/*     */ 
/*     */   private static GregorianCalendar beforeAfterWeekend(GregorianCalendar cal)
/*     */   {
/* 443 */     int nX = cal.get(7);
/* 444 */     switch (nX)
/*     */     {
/*     */     case 1:
/* 447 */       cal.add(5, 1);
/* 448 */       break;
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/* 454 */       break;
/*     */     default:
/* 457 */       cal.add(5, -1);
/*     */     }
/* 459 */     return cal;
/*     */   }
/*     */ 
/*     */   public static String getClassInfo()
/*     */   {
/* 465 */     return "Name: Holidays\r\nAuthor: Gregory N. Mirsky\r\nUpdated: John D. Mitchell\r\nVersion 1.02\r\nCopyright 1997, All rights reserved.";
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/* 477 */     System.out.println("Martin Luther King day in 1999=" + MartinLutherKingObserved(1999));
/* 478 */     System.out.println("Martin Luther King day in 2000=" + MartinLutherKingObserved(2000));
/* 479 */     System.out.println("Xmas day in 1999=" + ChristmasDay(1999));
/* 480 */     System.out.println("Xmas day observed in 1999=" + ChristmasDayObserved(1999));
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.date.Holidays
 * JD-Core Version:    0.6.2
 */