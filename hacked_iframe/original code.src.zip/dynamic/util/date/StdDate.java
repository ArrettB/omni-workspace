/*     */ package dynamic.util.date;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ 
/*     */ public class StdDate extends Date
/*     */ {
/*     */   protected static final int millisPerDay = 86400000;
/*  20 */   protected GregorianCalendar cal = new GregorianCalendar();
/*     */ 
/*  22 */   public static String DATE_FORMAT = "M/d/yyyy";
/*  23 */   public static String TIME_FORMAT = "H:mm:ss";
/*  24 */   public static String DATE_TIME_FORMAT = DATE_FORMAT + " " + TIME_FORMAT;
/*     */ 
/*     */   public StdDate()
/*     */   {
/*  29 */     this.cal.setTime(this);
/*     */   }
/*     */ 
/*     */   public StdDate(long in)
/*     */   {
/*  34 */     super(in);
/*  35 */     this.cal.setTime(this);
/*     */   }
/*     */ 
/*     */   public StdDate(Date in)
/*     */   {
/*  40 */     super(in.getTime());
/*  41 */     this.cal.setTime(this);
/*     */   }
/*     */ 
/*     */   public StdDate(String date)
/*     */     throws ParseException
/*     */   {
/*  47 */     this.cal.setTime(this);
/*  48 */     set(date);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  53 */     String format = null;
/*     */ 
/*  55 */     if ((getHour() == 0) && (getMinute() == 0) && (getSecond() == 0))
/*     */     {
/*  57 */       format = System.getProperty("dynamic.format.date");
/*  58 */       if ((format == null) || (format.length() == 0) || (format.equalsIgnoreCase("default"))) format = DATE_FORMAT;
/*     */     }
/*     */     else
/*     */     {
/*  62 */       format = System.getProperty("dynamic.format.datetime");
/*  63 */       if ((format == null) || (format.length() == 0) || (format.equalsIgnoreCase("default")) || (format.equals(DATE_TIME_FORMAT)))
/*     */       {
/*  65 */         format = DATE_TIME_FORMAT;
/*  66 */         if (getMillis() > 0) format = format + ".SSS";
/*     */       }
/*     */     }
/*     */ 
/*  70 */     return toString(format);
/*     */   }
/*     */ 
/*     */   public String toString(String format)
/*     */   {
/*  75 */     return new SimpleDateFormat(format).format(this);
/*     */   }
/*     */ 
/*     */   public int getMillis()
/*     */   {
/*  83 */     return this.cal.get(14);
/*     */   }
/*     */ 
/*     */   public int getSecond()
/*     */   {
/*  91 */     return this.cal.get(13);
/*     */   }
/*     */ 
/*     */   public int getMinute()
/*     */   {
/*  99 */     return this.cal.get(12);
/*     */   }
/*     */ 
/*     */   public int getHour()
/*     */   {
/* 107 */     return this.cal.get(11);
/*     */   }
/*     */ 
/*     */   public int getWeek()
/*     */   {
/* 115 */     return this.cal.get(3);
/*     */   }
/*     */ 
/*     */   public int getDayOfWeek()
/*     */   {
/* 123 */     return this.cal.get(7);
/*     */   }
/*     */ 
/*     */   public int getCalMonth()
/*     */   {
/* 131 */     return this.cal.get(2);
/*     */   }
/*     */ 
/*     */   public int getDayOfMonth()
/*     */   {
/* 139 */     return this.cal.get(5);
/*     */   }
/*     */ 
/*     */   public int getCalYear()
/*     */   {
/* 147 */     return this.cal.get(1);
/*     */   }
/*     */ 
/*     */   public StdDate setSecond(int second)
/*     */   {
/* 155 */     this.cal.set(13, second);
/* 156 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setMinute(int minute)
/*     */   {
/* 164 */     this.cal.set(12, minute);
/* 165 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setHour(int hour)
/*     */   {
/* 173 */     this.cal.set(11, hour);
/* 174 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate trunc()
/*     */   {
/* 182 */     this.cal.set(9, 0);
/* 183 */     this.cal.set(11, 0);
/* 184 */     this.cal.set(12, 0);
/* 185 */     this.cal.set(13, 0);
/* 186 */     this.cal.set(14, 0);
/* 187 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setWeek(int week)
/*     */   {
/* 195 */     this.cal.set(3, week);
/* 196 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setDayOfWeek(int day_of_week)
/*     */   {
/* 204 */     this.cal.set(7, day_of_week);
/* 205 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setCalMonth(int month)
/*     */   {
/* 213 */     this.cal.set(2, month);
/* 214 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setDayOfMonth(int day_of_month)
/*     */   {
/* 222 */     this.cal.set(5, day_of_month);
/* 223 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate setCalYear(int year)
/*     */   {
/* 231 */     this.cal.set(1, fixYear(year));
/* 232 */     return update();
/*     */   }
/*     */ 
/*     */   public Date firstDayOfMonth()
/*     */   {
/* 240 */     setDayOfMonth(1);
/* 241 */     return this;
/*     */   }
/*     */ 
/*     */   public Date lastDayOfMonth()
/*     */   {
/* 249 */     setDayOfMonth(1);
/* 250 */     addMonths(1);
/* 251 */     addDays(-1);
/* 252 */     return this;
/*     */   }
/*     */ 
/*     */   public Date firstDayOfYear()
/*     */   {
/* 260 */     setCalMonth(0);
/* 261 */     setDayOfMonth(1);
/* 262 */     return this;
/*     */   }
/*     */ 
/*     */   public Date lastDayOfYear()
/*     */   {
/* 270 */     setCalMonth(11);
/* 271 */     setDayOfMonth(31);
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */   public StdDate addSeconds(int seconds)
/*     */   {
/* 281 */     this.cal.add(13, seconds);
/* 282 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate addMinutes(int minutes)
/*     */   {
/* 291 */     this.cal.add(12, minutes);
/* 292 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate addHours(int hours)
/*     */   {
/* 301 */     this.cal.add(10, hours);
/* 302 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate addDays(int days)
/*     */   {
/* 311 */     this.cal.add(5, days);
/* 312 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate addBusinessDays(Date in, int days)
/*     */   {
/* 321 */     int daysAdded = 0;
/* 322 */     while (daysAdded < days)
/*     */     {
/* 324 */       addDays(1);
/* 325 */       if (isBusinessDay()) daysAdded++;
/*     */     }
/* 327 */     return this;
/*     */   }
/*     */ 
/*     */   public StdDate addWeeks(int weeks)
/*     */   {
/* 336 */     this.cal.add(5, weeks * 7);
/* 337 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate addMonths(int months)
/*     */   {
/* 346 */     this.cal.add(2, months);
/* 347 */     return update();
/*     */   }
/*     */ 
/*     */   public StdDate addYears(int years)
/*     */   {
/* 356 */     this.cal.add(1, years);
/* 357 */     return update();
/*     */   }
/*     */ 
/*     */   public int getDaysBetween(Date d)
/*     */   {
/* 365 */     return (int)(Math.abs(d.getTime() - getTime()) / 86400000L);
/*     */   }
/*     */ 
/*     */   public int getWeeksBetween(Date d)
/*     */   {
/* 373 */     return getDaysBetween(d) / 7;
/*     */   }
/*     */ 
/*     */   public boolean isBusinessDay()
/*     */   {
/* 381 */     int weekday = this.cal.get(7);
/* 382 */     return (weekday != 7) && (weekday != 1);
/*     */   }
/*     */ 
/*     */   public boolean isBefore(StdDate otherDate)
/*     */   {
/* 390 */     return before(otherDate);
/*     */   }
/*     */ 
/*     */   public boolean isAfter(StdDate otherDate)
/*     */   {
/* 398 */     return after(otherDate);
/*     */   }
/*     */ 
/*     */   public static int fixYear(int year)
/*     */   {
/* 408 */     if (year >= 100) return year;
/*     */ 
/* 410 */     GregorianCalendar cal = new GregorianCalendar();
/* 411 */     int century = cal.get(1) / 100 * 100;
/*     */ 
/* 413 */     if (year < 25) {
/* 414 */       return century + year;
/*     */     }
/* 416 */     return century + year - 100;
/*     */   }
/*     */ 
/*     */   public static Date getEarliestDate()
/*     */   {
/* 424 */     Date d = new Date();
/* 425 */     d.setTime(0L);
/* 426 */     return d;
/*     */   }
/*     */ 
/*     */   public static Date getLatestDate()
/*     */   {
/* 434 */     Date d = new Date();
/* 435 */     d.setTime(9223372036854775807L);
/* 436 */     return d;
/*     */   }
/*     */ 
/*     */   protected StdDate update()
/*     */   {
/* 444 */     setTime(this.cal.getTime().getTime());
/* 445 */     return this;
/*     */   }
/*     */ 
/*     */   public static String formatDateInterval(long interval)
/*     */   {
/* 453 */     long days = interval / 86400000L;
/* 454 */     interval %= 86400000L;
/* 455 */     long hours = interval / 3600000L;
/* 456 */     interval %= 3600000L;
/* 457 */     long minutes = interval / 60000L;
/* 458 */     interval %= 60000L;
/* 459 */     long seconds = interval / 1000L;
/* 460 */     interval %= 1000L;
/*     */ 
/* 462 */     StringBuffer result = new StringBuffer();
/* 463 */     if (days > 0L)
/*     */     {
/* 465 */       result.append(days + " day");
/* 466 */       if (days != 1L) result.append("s");
/* 467 */       result.append(" ");
/*     */     }
/* 469 */     if ((days > 0L) || (hours > 0L))
/*     */     {
/* 471 */       result.append(hours + " hour");
/* 472 */       if (hours != 1L) result.append("s");
/* 473 */       result.append(" ");
/*     */     }
/* 475 */     if ((days > 0L) || (hours > 0L) || (minutes > 0L))
/*     */     {
/* 477 */       result.append(minutes + " minute");
/* 478 */       if (minutes != 1L) result.append("s");
/* 479 */       result.append(" ");
/*     */     }
/* 481 */     result.append(seconds + " second");
/* 482 */     if (seconds != 1L) result.append("s");
/*     */ 
/* 484 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private void set(String date)
/*     */     throws ParseException
/*     */   {
/* 495 */     if ((date == null) || (date.length() == 0)) throw new ParseException("Date was not specified", 0);
/* 496 */     boolean with_time = false;
/* 497 */     boolean with_millis = false;
/* 498 */     int date_dividers = 0;
/* 499 */     int time_dividers = 0;
/* 500 */     char date_divider_char = '/';
/* 501 */     String am_pm = null;
/* 502 */     String date_part = date;
/* 503 */     String time_part = null;
/*     */ 
/* 505 */     for (int i = 0; i < date.length(); i++)
/*     */     {
/* 507 */       char c = date.charAt(i);
/* 508 */       if ((c != '-') || (i != 0))
/* 509 */         if ((c == '-') && (i > 0)) { date_dividers++; date_divider_char = '-';
/* 510 */         } else if (c == '/') { date_dividers++; date_divider_char = '/';
/* 511 */         } else if (c == ':') { time_dividers++;
/* 512 */         } else if ((c == ' ') && (!with_time)) { with_time = true; date_part = date.substring(0, i); time_part = date.substring(i + 1);
/* 513 */         } else if (((c != ' ') || (!with_time)) && 
/* 514 */           (!Character.isDigit(c))) {
/* 515 */           if ((with_time) && ((c == 'a') || (c == 'A'))) { time_part = time_part.substring(0, i - date_part.length() - 1).trim(); am_pm = "am";
/* 516 */           } else if ((with_time) && ((c == 'p') || (c == 'P'))) { time_part = time_part.substring(0, i - date_part.length() - 1).trim(); am_pm = "pm";
/* 517 */           } else if ((!with_time) || (am_pm == null) || ((c != 'm') && (c != 'M'))) {
/* 518 */             if ((with_time) && (c == '.')) with_millis = true; else
/* 519 */               throw new ParseException("Problem parsing date " + date + " at position " + i, i);
/*     */           }
/*     */         }
/*     */     }
/*     */     int x;
/*     */     int month;
/*     */     int day;
/* 522 */     switch (date_dividers)
/*     */     {
/*     */     case 0:
/* 525 */       this.cal.add(5, Integer.parseInt(date_part));
/* 526 */       break;
/*     */     case 1:
/* 528 */       x = date_part.indexOf(date_divider_char);
/* 529 */       month = Integer.parseInt(date_part.substring(0, x));
/* 530 */       day = Integer.parseInt(date_part.substring(x + 1));
/* 531 */       this.cal.set(5, 1);
/* 532 */       this.cal.set(2, month - 1);
/* 533 */       this.cal.set(5, day);
/* 534 */       break;
/*     */     case 2:
/* 536 */       x = date_part.indexOf(date_divider_char);
/* 537 */       int y = date_part.indexOf(date_divider_char, x + 1);
/* 538 */       month = Integer.parseInt(date_part.substring(0, x));
/* 539 */       day = Integer.parseInt(date_part.substring(x + 1, y));
/* 540 */       int year = Integer.parseInt(date_part.substring(y + 1));
/* 541 */       if (month > 12)
/*     */       {
/* 544 */         int temp = month;
/* 545 */         month = day;
/* 546 */         day = year;
/* 547 */         year = temp;
/*     */       }
/* 549 */       year = fixYear(year);
/* 550 */       this.cal.set(5, 1);
/* 551 */       this.cal.set(2, month - 1);
/* 552 */       this.cal.set(1, year);
/* 553 */       this.cal.set(5, day);
/* 554 */       break;
/*     */     }
/*     */ 
/* 558 */     trunc();
/*     */ 
/* 560 */     if (with_time)
/*     */     {
/*     */       int hour;
/*     */       int x;
/*     */       int minute;
/* 562 */       switch (time_dividers)
/*     */       {
/*     */       case 0:
/* 565 */         hour = Integer.parseInt(time_part);
/* 566 */         if (am_pm != null) hour %= 12;
/* 567 */         if ((am_pm != null) && (am_pm.equals("pm"))) hour += 12;
/* 568 */         this.cal.set(11, hour);
/* 569 */         break;
/*     */       case 1:
/* 571 */         x = time_part.indexOf(':');
/* 572 */         hour = Integer.parseInt(time_part.substring(0, x));
/* 573 */         if (am_pm != null) hour %= 12;
/* 574 */         if ((am_pm != null) && (am_pm.equals("pm"))) hour += 12;
/* 575 */         minute = Integer.parseInt(time_part.substring(x + 1));
/* 576 */         this.cal.set(11, hour);
/* 577 */         this.cal.set(12, minute);
/* 578 */         break;
/*     */       case 2:
/* 580 */         x = time_part.indexOf(':');
/* 581 */         int y = time_part.indexOf(':', x + 1);
/* 582 */         int z = time_part.indexOf('.', y + 1);
/* 583 */         if (z == -1) z = time_part.length();
/* 584 */         hour = Integer.parseInt(time_part.substring(0, x));
/* 585 */         if (am_pm != null) hour %= 12;
/* 586 */         if ((am_pm != null) && (am_pm.equals("pm"))) hour += 12;
/* 587 */         minute = Integer.parseInt(time_part.substring(x + 1, y));
/* 588 */         int second = Integer.parseInt(time_part.substring(y + 1, z));
/* 589 */         int millis = 0;
/* 590 */         if (with_millis)
/*     */         {
/* 592 */           millis = Integer.parseInt(time_part.substring(z + 1));
/*     */         }
/* 594 */         this.cal.set(11, hour);
/* 595 */         this.cal.set(12, minute);
/* 596 */         this.cal.set(13, second);
/* 597 */         this.cal.set(14, millis);
/* 598 */         break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 604 */     update();
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*     */     try
/*     */     {
/* 611 */       StdDate test = new StdDate();
/* 612 */       StdDate future = new StdDate(test);
/* 613 */       Diagnostics.debug("test = " + test);
/* 614 */       Diagnostics.debug("year = " + test.getCalYear());
/* 615 */       Diagnostics.debug("month = " + test.getCalMonth());
/* 616 */       Diagnostics.debug("dayOfWeek = " + test.getDayOfWeek());
/* 617 */       Diagnostics.debug("dayOfMonth = " + test.getDayOfMonth());
/* 618 */       Diagnostics.debug("hour = " + test.getHour());
/* 619 */       Diagnostics.debug("minute = " + test.getMinute());
/* 620 */       Diagnostics.debug("second = " + test.getSecond());
/*     */ 
/* 622 */       test.addMinutes(1);
/* 623 */       Diagnostics.debug("add 1 minute = " + test);
/* 624 */       future = new StdDate(test);
/* 625 */       future.addHours(1);
/* 626 */       Diagnostics.debug("difference = " + test.getDaysBetween(future));
/*     */ 
/* 628 */       test.addHours(1);
/* 629 */       Diagnostics.debug("add 1 hour = " + test);
/* 630 */       test.addDays(10);
/* 631 */       Diagnostics.debug("add 10 days = " + test);
/* 632 */       future = new StdDate(test);
/* 633 */       future.addMonths(1);
/* 634 */       Diagnostics.debug("add 1 month = " + future);
/* 635 */       Diagnostics.debug("difference = " + test.getDaysBetween(future));
/* 636 */       future.addMonths(1);
/* 637 */       Diagnostics.debug("add 1 month = " + future);
/* 638 */       Diagnostics.debug("difference = " + test.getDaysBetween(future));
/*     */ 
/* 640 */       test.firstDayOfMonth();
/* 641 */       Diagnostics.debug("firstDayOfMonth = " + test);
/* 642 */       test.lastDayOfMonth();
/* 643 */       Diagnostics.debug("lastDayOfMonth = " + test);
/* 644 */       test.firstDayOfYear();
/* 645 */       Diagnostics.debug("firstDayOfYear = " + test);
/* 646 */       test.lastDayOfYear();
/* 647 */       Diagnostics.debug("lastDayOfYear = " + test);
/*     */ 
/* 649 */       test.addYears(1);
/* 650 */       Diagnostics.debug("add 1 year = " + test);
/*     */ 
/* 652 */       test = new StdDate("2/2/2007");
/* 653 */       Diagnostics.debug("parse 2/2/2007 = " + test);
/* 654 */       test = new StdDate("2/2/01");
/* 655 */       Diagnostics.debug("parse 1/1/01 = " + test);
/* 656 */       test = new StdDate("1/1");
/* 657 */       Diagnostics.debug("parse 1/1 = " + test);
/* 658 */       test = new StdDate("0");
/* 659 */       Diagnostics.debug("parse 0 = " + test);
/* 660 */       test = new StdDate("1");
/* 661 */       Diagnostics.debug("parse 1 = " + test);
/* 662 */       test = new StdDate("-1");
/* 663 */       Diagnostics.debug("parse -1 = " + test);
/*     */ 
/* 665 */       test = new StdDate("1/1/75 12");
/* 666 */       Diagnostics.debug("parse 1/1/75 12 = " + test);
/* 667 */       test = new StdDate("02/29/96 12:34pm");
/* 668 */       Diagnostics.debug("parse 02/29/96 12:34pm = " + test);
/* 669 */       test = new StdDate("12/31/01 18:34:22");
/* 670 */       Diagnostics.debug("parse 12/31/01 18:34:22 = " + test);
/* 671 */       test = new StdDate("12/31/01 6:34:22 PM");
/* 672 */       Diagnostics.debug("parse 12/31/01 6:34:22 PM = " + test);
/* 673 */       test = new StdDate("12/31/01 4:34:22AM");
/* 674 */       Diagnostics.debug("parse 12/31/01 4:34:22AM = " + test);
/* 675 */       Thread.sleep(500L);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 679 */       Diagnostics.error("StdDate unit test failed", e);
/*     */     }
/*     */ 
/* 682 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.date.StdDate
 * JD-Core Version:    0.6.2
 */