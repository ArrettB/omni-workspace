/*    */ package dynamic.util.exec;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public final class ExecUtils
/*    */ {
/*    */   public static String exec(String command)
/*    */     throws Exception
/*    */   {
/* 28 */     Process p = Runtime.getRuntime().exec(command);
/* 29 */     return read(p);
/*    */   }
/*    */ 
/*    */   public static String exec(String[] command)
/*    */     throws Exception
/*    */   {
/* 40 */     Process p = Runtime.getRuntime().exec(command);
/* 41 */     return read(p);
/*    */   }
/*    */ 
/*    */   public static String read(Process p)
/*    */     throws Exception
/*    */   {
/* 51 */     StringBuffer result = new StringBuffer();
/* 52 */     StreamReader processIn = new StreamReader(p.getInputStream(), result);
/* 53 */     StreamReader processErr = new StreamReader(p.getErrorStream(), result);
/* 54 */     processIn.start();
/* 55 */     processErr.start();
/* 56 */     processIn.join();
/*    */ 
/* 58 */     if (processIn.problem != null) throw processIn.problem;
/* 59 */     if (processErr.problem != null) throw processErr.problem;
/*    */ 
/* 61 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 71 */       System.out.println(exec(args));
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/* 75 */       t.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class StreamReader extends Thread
/*    */   {
/*    */     BufferedReader reader;
/*    */     StringBuffer result;
/* 86 */     Exception problem = null;
/* 87 */     String EOL = System.getProperty("line.separator");
/*    */ 
/*    */     public StreamReader(InputStream is, StringBuffer sb)
/*    */     {
/* 91 */       this.reader = new BufferedReader(new InputStreamReader(is));
/* 92 */       this.result = sb;
/*    */     }
/*    */ 
/*    */     public void run()
/*    */     {
/*    */       try
/*    */       {
/* 99 */         String s = null;
/*    */         do
/*    */         {
/* 102 */           s = this.reader.readLine();
/* 103 */           if (s != null) this.result.append(s + this.EOL);
/*    */         }
/* 105 */         while (s != null);
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 109 */         this.problem = e;
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.exec.ExecUtils
 * JD-Core Version:    0.6.2
 */