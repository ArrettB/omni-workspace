/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public abstract class Sorter
/*    */ {
/*    */   public void sort(Object[] list, SortTool tool)
/*    */   {
/* 40 */     sort(list, tool, false);
/*    */   }
/*    */ 
/*    */   public abstract void sort(Object[] paramArrayOfObject, SortTool paramSortTool, boolean paramBoolean);
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.Sorter
 * JD-Core Version:    0.6.2
 */