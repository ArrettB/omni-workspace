/*     */ package dynamic.util.sorting;
/*     */ 
/*     */ public abstract class StringSearchTool
/*     */ {
/*  37 */   public static int NOT_FOUND = -1;
/*     */ 
/*  39 */   public static int SEARCH_EXACT = 0;
/*  40 */   public static int SEARCH_CASELESS = 1;
/*     */   protected String pattern;
/*     */   protected int search;
/*     */ 
/*     */   public StringSearchTool()
/*     */   {
/*  53 */     this.search = SEARCH_CASELESS;
/*  54 */     this.pattern = null;
/*     */   }
/*     */ 
/*     */   public StringSearchTool(String p)
/*     */   {
/*  62 */     this.search = SEARCH_CASELESS;
/*  63 */     setPattern(p);
/*     */   }
/*     */ 
/*     */   public StringSearchTool(String p, int type)
/*     */   {
/*  72 */     this.search = type;
/*  73 */     setPattern(p);
/*     */   }
/*     */ 
/*     */   public synchronized String getPattern()
/*     */   {
/*  82 */     return this.pattern;
/*     */   }
/*     */ 
/*     */   public synchronized void setPattern(String p)
/*     */   {
/*  90 */     if (this.search == SEARCH_CASELESS)
/*  91 */       this.pattern = p.toUpperCase();
/*     */     else
/*  93 */       this.pattern = new String(p);
/*     */   }
/*     */ 
/*     */   public synchronized int getPatternLength()
/*     */   {
/*  98 */     return this.pattern.length();
/*     */   }
/*     */ 
/*     */   public int getSearchType()
/*     */   {
/* 103 */     return this.search;
/*     */   }
/*     */ 
/*     */   public int find(String target)
/*     */   {
/* 115 */     return find(target, 0);
/*     */   }
/*     */ 
/*     */   public abstract int find(String paramString, int paramInt);
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.StringSearchTool
 * JD-Core Version:    0.6.2
 */