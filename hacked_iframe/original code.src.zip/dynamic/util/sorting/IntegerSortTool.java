/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class IntegerSortTool
/*    */   implements SortTool
/*    */ {
/*    */   public int compare(Object x1, Object x2)
/*    */   {
/* 42 */     if (((x1 instanceof Integer)) && ((x2 instanceof Integer)))
/*    */     {
/* 45 */       int n1 = ((Integer)x1).intValue();
/* 46 */       int n2 = ((Integer)x2).intValue();
/*    */ 
/* 48 */       if (n1 < n2) {
/* 49 */         return -1;
/*    */       }
/* 51 */       if (n1 > n2) {
/* 52 */         return 1;
/*    */       }
/* 54 */       return 0;
/*    */     }
/*    */ 
/* 57 */     throw SortTool.err1;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.IntegerSortTool
 * JD-Core Version:    0.6.2
 */