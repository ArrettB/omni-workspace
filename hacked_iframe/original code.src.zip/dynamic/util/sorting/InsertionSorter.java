/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class InsertionSorter extends Sorter
/*    */ {
/*    */   public void sort(Object[] list, SortTool tool, boolean descending)
/*    */   {
/*    */     int comp;
/* 45 */     if (descending)
/* 46 */       comp = -1;
/*    */     else {
/* 48 */       comp = 1;
/*    */     }
/* 50 */     for (int i = 1; i < list.length; i++)
/*    */     {
/* 52 */       Object t = list[i];
/*    */ 
/* 54 */       int j = i;
/*    */ 
/* 56 */       while ((j > 0) && (tool.compare(list[(j - 1)], t) == comp))
/*    */       {
/* 58 */         list[j] = list[(j - 1)];
/* 59 */         j--;
/*    */       }
/*    */ 
/* 62 */       list[j] = t;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.InsertionSorter
 * JD-Core Version:    0.6.2
 */