/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class SelectionSorter extends Sorter
/*    */ {
/*    */   public void sort(Object[] list, SortTool tool, boolean descending)
/*    */   {
/*    */     int comp;
/* 45 */     if (descending)
/* 46 */       comp = 1;
/*    */     else {
/* 48 */       comp = -1;
/*    */     }
/* 50 */     for (int i = 0; i < list.length - 1; i++)
/*    */     {
/* 52 */       int min = i;
/*    */ 
/* 54 */       for (int j = i + 1; j < list.length; j++)
/*    */       {
/* 56 */         if (tool.compare(list[j], list[min]) == comp) {
/* 57 */           min = j;
/*    */         }
/*    */       }
/* 60 */       Object t = list[min];
/* 61 */       list[min] = list[i];
/* 62 */       list[i] = t;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.SelectionSorter
 * JD-Core Version:    0.6.2
 */