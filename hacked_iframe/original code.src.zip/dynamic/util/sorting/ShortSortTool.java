/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class ShortSortTool
/*    */   implements SortTool
/*    */ {
/*    */   public int compare(Object x1, Object x2)
/*    */   {
/* 42 */     if (((x1 instanceof Short)) && ((x2 instanceof Short)))
/*    */     {
/* 45 */       short n1 = ((Short)x1).shortValue();
/* 46 */       short n2 = ((Short)x2).shortValue();
/*    */ 
/* 48 */       if (n1 < n2) {
/* 49 */         return -1;
/*    */       }
/* 51 */       if (n1 > n2) {
/* 52 */         return 1;
/*    */       }
/* 54 */       return 0;
/*    */     }
/*    */ 
/* 57 */     throw SortTool.err1;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.ShortSortTool
 * JD-Core Version:    0.6.2
 */