/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public abstract interface SortTool
/*    */ {
/*    */   public static final int COMP_LESS = -1;
/*    */   public static final int COMP_EQUAL = 0;
/*    */   public static final int COMP_GRTR = 1;
/* 39 */   public static final IllegalArgumentException err1 = new IllegalArgumentException("incompatible objects in sort");
/*    */ 
/*    */   public abstract int compare(Object paramObject1, Object paramObject2);
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.SortTool
 * JD-Core Version:    0.6.2
 */