/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class DoubleSortTool
/*    */   implements SortTool
/*    */ {
/*    */   public int compare(Object x1, Object x2)
/*    */   {
/* 42 */     if (((x1 instanceof Double)) && ((x2 instanceof Double)))
/*    */     {
/* 45 */       double n1 = ((Double)x1).doubleValue();
/* 46 */       double n2 = ((Double)x2).doubleValue();
/*    */ 
/* 48 */       if (n1 < n2) {
/* 49 */         return -1;
/*    */       }
/* 51 */       if (n1 > n2) {
/* 52 */         return 1;
/*    */       }
/* 54 */       return 0;
/*    */     }
/*    */ 
/* 57 */     throw SortTool.err1;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.DoubleSortTool
 * JD-Core Version:    0.6.2
 */