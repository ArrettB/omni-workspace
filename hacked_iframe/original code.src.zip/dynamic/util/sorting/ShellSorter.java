/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class ShellSorter extends Sorter
/*    */ {
/*    */   public void sort(Object[] list, SortTool tool, boolean descending)
/*    */   {
/*    */     int comp;
/* 45 */     if (descending)
/* 46 */       comp = -1;
/*    */     else {
/* 48 */       comp = 1;
/*    */     }
/* 50 */     for (int inc = 1; inc <= list.length / 9; inc = 3 * inc + 1);
/* 52 */     for (; inc > 0; inc /= 3)
/*    */     {
/* 54 */       for (int i = inc + 1; i <= list.length; i += inc)
/*    */       {
/* 56 */         Object t = list[(i - 1)];
/*    */ 
/* 58 */         int j = i;
/*    */ 
/* 60 */         while ((j > inc) && (tool.compare(list[(j - inc - 1)], t) == comp))
/*    */         {
/* 62 */           list[(j - 1)] = list[(j - inc - 1)];
/* 63 */           j -= inc;
/*    */         }
/*    */ 
/* 66 */         list[(j - 1)] = t;
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.ShellSorter
 * JD-Core Version:    0.6.2
 */