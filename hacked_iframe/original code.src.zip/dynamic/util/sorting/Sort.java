/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class Sort
/*    */ {
/*    */   public static Enumeration keys(Hashtable h)
/*    */   {
/* 11 */     Enumeration keys = h.keys();
/* 12 */     Vector v = new Vector();
/* 13 */     while (keys.hasMoreElements())
/* 14 */       v.addElement(keys.nextElement());
/* 15 */     return elements(v);
/*    */   }
/*    */ 
/*    */   public static Enumeration elements(Vector v)
/*    */   {
/* 20 */     Object[] o = new Object[v.size()];
/* 21 */     v.copyInto(o);
/* 22 */     return elements(o);
/*    */   }
/*    */ 
/*    */   public static Enumeration elements(Object[] o)
/*    */   {
/* 28 */     new QuickSorter().sort(o, new StringSortTool(), false);
/* 29 */     Vector v = new Vector();
/* 30 */     for (int i = 0; i < o.length; i++)
/* 31 */       v.addElement(o[i]);
/* 32 */     return v.elements();
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.Sort
 * JD-Core Version:    0.6.2
 */