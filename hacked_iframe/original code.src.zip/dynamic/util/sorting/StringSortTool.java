/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class StringSortTool
/*    */   implements SortTool
/*    */ {
/* 31 */   private boolean isCaseSensitive = false;
/*    */ 
/*    */   public StringSortTool() {
/*    */   }
/*    */   public StringSortTool(boolean isCaseSensitive) {
/* 36 */     this.isCaseSensitive = isCaseSensitive;
/*    */   }
/*    */ 
/*    */   public int compare(Object x1, Object x2)
/*    */   {
/* 42 */     String s1 = x1.toString();
/* 43 */     String s2 = x2.toString();
/* 44 */     int c = this.isCaseSensitive ? s1.compareTo(s2) : s1.toLowerCase().compareTo(s2.toLowerCase());
/* 45 */     if (c < 0) return -1;
/* 46 */     if (c > 0) return 1;
/* 47 */     return 0;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.StringSortTool
 * JD-Core Version:    0.6.2
 */