/*    */ package dynamic.util.sorting;
/*    */ 
/*    */ public class QuickSorter extends Sorter
/*    */ {
/* 35 */   private IllegalArgumentException err1 = new IllegalArgumentException("stack overflow in QuickSort");
/*    */ 
/*    */   public void sort(Object[] list, SortTool tool, boolean descending)
/*    */   {
/* 52 */     int stackSize = 32;
/* 53 */     StackItem[] stack = new StackItem[32];
/*    */ 
/* 55 */     for (int n = 0; n < 32; n++) {
/* 56 */       stack[n] = new StackItem(null);
/*    */     }
/* 58 */     int stackPtr = 0;
/*    */     int comp;
/* 63 */     if (descending)
/* 64 */       comp = 1;
/*    */     else {
/* 66 */       comp = -1;
/*    */     }
/*    */ 
/* 69 */     int Threshold = 7;
/*    */ 
/* 78 */     int l = 0;
/* 79 */     int r = list.length - 1;
/*    */     while (true)
/*    */     {
/*    */       int pivot;
/*    */       int scanl;
/*    */       int scanr;
/* 88 */       if (r - l > 7)
/*    */       {
/* 91 */         int mid = (l + r) / 2;
/*    */ 
/* 94 */         if (tool.compare(list[mid], list[l]) == comp)
/*    */         {
/* 96 */           temp = list[mid];
/* 97 */           list[mid] = list[l];
/* 98 */           list[l] = temp;
/*    */         }
/*    */ 
/* 101 */         if (tool.compare(list[r], list[l]) == comp)
/*    */         {
/* 103 */           temp = list[r];
/* 104 */           list[r] = list[l];
/* 105 */           list[l] = temp;
/*    */         }
/*    */ 
/* 109 */         if (tool.compare(list[r], list[mid]) == comp)
/*    */         {
/* 111 */           temp = list[mid];
/* 112 */           list[mid] = list[r];
/* 113 */           list[r] = temp;
/*    */         }
/*    */ 
/* 117 */         pivot = r - 1;
/*    */ 
/* 119 */         temp = list[mid];
/* 120 */         list[mid] = list[pivot];
/* 121 */         list[pivot] = temp;
/*    */ 
/* 123 */         scanl = l + 1;
/* 124 */         scanr = r - 2;
/*    */       }
/*    */       else
/*    */       {
/* 129 */         pivot = r;
/* 130 */         scanl = l;
/* 131 */         scanr = r - 1;
/*    */ 
/* 134 */         break label276;
/*    */ 
/* 137 */         break label276;
/* 138 */         scanl++;
/*    */       }
/*    */       while (true)
/*    */       {
/* 137 */         label276: if (tool.compare(list[scanl], list[pivot]) == comp) if (scanl < r)
/*    */           {
/*    */             break;
/*    */           }
/* 141 */         while ((tool.compare(list[pivot], list[scanr]) == comp) && (scanr > l)) {
/* 142 */           scanr--;
/*    */         }
/*    */ 
/* 145 */         if (scanl >= scanr)
/*    */         {
/*    */           break label387;
/*    */         }
/* 149 */         temp = list[scanl];
/* 150 */         list[scanl] = list[scanr];
/* 151 */         list[scanr] = temp;
/*    */ 
/* 153 */         if (scanl < r) {
/* 154 */           scanl++;
/*    */         }
/* 156 */         if (scanr > l) {
/* 157 */           scanr--;
/*    */         }
/*    */       }
/*    */ 
/* 161 */       label387: Object temp = list[scanl];
/* 162 */       list[scanl] = list[pivot];
/* 163 */       list[pivot] = temp;
/*    */ 
/* 166 */       int lsize = scanl - l;
/* 167 */       int rsize = r - scanl;
/*    */ 
/* 169 */       if (lsize > rsize)
/*    */       {
/* 171 */         if (lsize != 1)
/*    */         {
/* 173 */           stackPtr++;
/*    */ 
/* 175 */           if (stackPtr == 32) {
/* 176 */             throw this.err1;
/*    */           }
/* 178 */           stack[stackPtr].left = l;
/* 179 */           stack[stackPtr].right = (scanl - 1);
/*    */         }
/*    */ 
/* 182 */         if (rsize == 0) break label546;
/* 183 */         l = scanl + 1;
/*    */       }
/*    */       else
/*    */       {
/* 189 */         if (rsize != 1)
/*    */         {
/* 191 */           stackPtr++;
/*    */ 
/* 193 */           if (stackPtr == 32) {
/* 194 */             throw this.err1;
/*    */           }
/* 196 */           stack[stackPtr].left = (scanl + 1);
/* 197 */           stack[stackPtr].right = r;
/*    */         }
/*    */ 
/* 200 */         if (lsize == 0) break label546;
/* 201 */         r = scanl - 1;
/*    */       }
/* 86 */       while (r <= l)
/*    */       {
/* 208 */         label546: if (stackPtr == 0)
/*    */           return;
/* 210 */         l = stack[stackPtr].left;
/* 211 */         r = stack[stackPtr].right;
/*    */ 
/* 213 */         stackPtr--;
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   private class StackItem
/*    */   {
/*    */     public int left;
/*    */     public int right;
/*    */ 
/*    */     private StackItem()
/*    */     {
/*    */     }
/*    */ 
/*    */     StackItem(QuickSorter.1 x1)
/*    */     {
/* 38 */       this();
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.sorting.QuickSorter
 * JD-Core Version:    0.6.2
 */