/*     */ package dynamic.util.tree;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class HtmlTree
/*     */ {
/*  26 */   private static String FONT = "Verdana";
/*  27 */   private static String FONTSIZE = "1";
/*  28 */   private static String FONTCOLOR = "#000080";
/*  29 */   private static String CURRENTFONTCOLOR = "#990000";
/*     */ 
/*  31 */   private static String COLLAPSEGIF = "/images/dirclose.gif";
/*  32 */   private static String EXPANDGIF = "/images/diropen.gif";
/*  33 */   private static String NOITEMGIF = "/images/dirnone.gif";
/*  34 */   private static String NEWGIF = "/images/newtree.gif";
/*     */ 
/*  38 */   private static boolean PROPERTYSET = false;
/*     */ 
/*  40 */   private static String FONTDEC = "<font size=\"" + FONTSIZE + "\" color=\"" + FONTCOLOR + "\" face=\"" + FONT + "\">";
/*  41 */   private static String FONTDECCUR = "<font size=\"" + FONTSIZE + "\" color=\"" + CURRENTFONTCOLOR + "\" face=\"" + FONT + "\">";
/*     */ 
/*     */   public static synchronized void setProperties(Properties prop)
/*     */   {
/*  48 */     if (prop.get("FONT") != null) {
/*  49 */       FONT = (String)prop.get("FONT");
/*     */     }
/*     */ 
/*  52 */     PROPERTYSET = true;
/*     */   }
/*     */ 
/*     */   public static boolean isPropertySet()
/*     */   {
/*  57 */     return PROPERTYSET;
/*     */   }
/*     */ 
/*     */   public String getTree(Properties prop) throws HtmlTreeException
/*     */   {
/*  62 */     StringBuffer sbuff = new StringBuffer();
/*  63 */     getTree(prop, sbuff);
/*  64 */     return sbuff.toString();
/*     */   }
/*     */ 
/*     */   public void getTree(Properties prop, StringBuffer sbuff)
/*     */     throws HtmlTreeException
/*     */   {
/*  72 */     boolean editable = true;
/*     */ 
/*  74 */     String filler = "";
/*  75 */     boolean recursiveSelection = false;
/*     */     HtmlTreeSource hts;
/*     */     try
/*     */     {
/*  81 */       hts = (HtmlTreeSource)prop.get("HTMLTREESOURCE");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  85 */       throw new HtmlTreeException("HTMLTREESOURCE");
/*     */     }
/*     */     String additionalFormInfo;
/*     */     try
/*     */     {
/*  90 */       additionalFormInfo = (String)prop.get("ADDFORMINFO");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  94 */       throw new HtmlTreeException("ADDFORMINFO");
/*     */     }
/*     */ 
/*     */     String selectHref;
/*     */     try
/*     */     {
/* 100 */       selectHref = (String)prop.get("SELECTHREF");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 104 */       throw new HtmlTreeException("SELECTHREF");
/*     */     }
/*     */ 
/* 107 */     if (selectHref != null)
/*     */     {
/* 109 */       if (selectHref.indexOf("?") == -1)
/* 110 */         selectHref = selectHref + "?";
/*     */       else
/* 112 */         selectHref = selectHref + "&";
/*     */     }
/*     */     String refHref;
/*     */     try
/*     */     {
/* 117 */       refHref = (String)prop.get("REFERINGHREF");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 121 */       throw new HtmlTreeException("REFERINGHREF");
/*     */     }
/* 123 */     if (refHref == null)
/* 124 */       throw new HtmlTreeException("REFERINGHREF");
/*     */     HttpServletRequest req;
/*     */     try
/*     */     {
/* 128 */       req = (HttpServletRequest)prop.get("REQUEST");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 132 */       throw new HtmlTreeException("REQUEST");
/*     */     }
/*     */ 
/* 135 */     if (req == null) {
/* 136 */       throw new HtmlTreeException("REQUEST");
/*     */     }
/*     */     try
/*     */     {
/* 140 */       String ed = (String)prop.get("EDITABLE");
/* 141 */       if ((ed != null) && (ed.equalsIgnoreCase("true")))
/* 142 */         editable = true;
/*     */       else
/* 144 */         editable = false;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 148 */       throw new HtmlTreeException("EDITABLE");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 153 */       String ed = (String)prop.get("RECURSIVESELECTION");
/* 154 */       if ((ed != null) && (ed.equalsIgnoreCase("true")))
/* 155 */         recursiveSelection = true;
/*     */       else
/* 157 */         recursiveSelection = false;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 161 */       throw new HtmlTreeException("RECURSIVESELECTION");
/*     */     }
/*     */ 
/* 165 */     String topRef = "";
/*     */ 
/* 170 */     int placement = refHref.indexOf("?");
/*     */     StringTokenizer st;
/* 171 */     if ((placement != -1) && (placement != 0))
/*     */     {
/* 173 */       st = new StringTokenizer(refHref, "?");
/* 174 */       topRef = st.nextToken();
/*     */     }
/*     */ 
/* 177 */     String editedid = req.getParameter("editedid");
/* 178 */     if (editedid != null)
/*     */     {
/* 180 */       String editedvalue = req.getParameter("editedvalue");
/* 181 */       if ((editedvalue != null) && (editedvalue.length() > 0)) {
/* 182 */         hts.editBranch(editedid, editedvalue);
/*     */       }
/*     */     }
/* 185 */     String newid = req.getParameter("newid");
/* 186 */     if (newid != null)
/*     */     {
/* 188 */       if (newid.equals("$$NeWiNtErNaL$$"))
/* 189 */         newid = "";
/* 190 */       String editedvalue = req.getParameter("editedvalue");
/* 191 */       if ((editedvalue != null) && (editedvalue.length() > 0)) {
/* 192 */         hts.addBranch(newid, editedvalue);
/*     */       }
/*     */     }
/* 195 */     sbuff.append("<form action=\"" + topRef + "\" name=frm method=post>\n");
/* 196 */     if (additionalFormInfo != null)
/*     */     {
/* 198 */       sbuff.append(additionalFormInfo).append("\n");
/*     */     }
/*     */ 
/* 201 */     sbuff.append("<table width=100%>\n");
/* 202 */     sbuff.append("<tr>\n");
/* 203 */     sbuff.append("<td>\n");
/* 204 */     if (refHref.indexOf("?") != -1)
/*     */     {
/* 206 */       st = new StringTokenizer(refHref, "?");
/* 207 */       String newref = "";
/* 208 */       while (st.hasMoreElements())
/*     */       {
/* 210 */         newref = st.nextToken();
/*     */       }
/* 212 */       st = new StringTokenizer(newref, "&");
/*     */ 
/* 214 */       while (st.hasMoreTokens())
/*     */       {
/* 216 */         StringTokenizer st2 = new StringTokenizer(st.nextToken(), "=");
/* 217 */         sbuff.append("<input type=hidden name=\"" + st2.nextToken() + "\" value=\"" + st2.nextToken() + "\">");
/*     */       }
/*     */     }
/*     */ 
/* 221 */     sbuff.append("<table >\n");
/*     */ 
/* 224 */     String masterid = req.getParameter("masterid");
/* 225 */     String masteraction = req.getParameter("masteraction");
/*     */ 
/* 227 */     if (masterid == null)
/* 228 */       masterid = "";
/* 229 */     if (masteraction == null) {
/* 230 */       masteraction = "";
/*     */     }
/* 232 */     boolean dontdisplay = false;
/* 233 */     if ((editable == true) && ((masteraction.equalsIgnoreCase("new")) || (masteraction.equalsIgnoreCase("edit")))) {
/* 234 */       dontdisplay = true;
/*     */     }
/* 236 */     if (masteraction.equalsIgnoreCase("delete"))
/*     */     {
/* 238 */       hts.deleteBranch(masterid);
/*     */     }
/*     */ 
/* 241 */     if (editable)
/*     */     {
/* 243 */       sbuff.append("<tr height=1>\n");
/* 244 */       sbuff.append("<td colspan=2>\n");
/* 245 */       sbuff.append("<a href=\"javascript:submitForm('newtree', '')\"><img src=\"" + NEWGIF + "\" border=0></a>");
/*     */ 
/* 247 */       sbuff.append("<br><br></td>");
/* 248 */       sbuff.append("</tr>");
/*     */     }
/*     */ 
/* 252 */     if (masteraction.equalsIgnoreCase("newtree"))
/*     */     {
/* 254 */       sbuff.append("<tr height=1>\n");
/* 255 */       sbuff.append("<td >\n");
/* 256 */       sbuff.append("<input name=editedvalue type=text size=20 value=\"New Item\" onChange=\"checkSubmit()\">");
/* 257 */       sbuff.append("<input name=newid type=hidden value=\"$$NeWiNtErNaL$$\" >");
/* 258 */       sbuff.append("</td>");
/* 259 */       sbuff.append("</tr>");
/* 260 */       dontdisplay = true;
/*     */     }
/*     */ 
/* 263 */     Vector trees = hts.getTrees();
/* 264 */     for (int i = 0; i < trees.size(); i++)
/*     */     {
/* 266 */       sbuff.append("<tr height=1>\n");
/* 267 */       sbuff.append("<td >\n");
/* 268 */       String[] tree = (String[])trees.elementAt(i);
/* 269 */       String expansion = req.getParameter("action" + tree[0]);
/*     */ 
/* 271 */       if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */       {
/* 273 */         expansion = "expanded";
/*     */       }
/*     */ 
/* 276 */       if (tree[2].equalsIgnoreCase("0"))
/*     */       {
/* 278 */         sbuff.append("<img src=\"" + NOITEMGIF + "\" border=0>");
/* 279 */         sbuff.append("&nbsp");
/*     */ 
/* 281 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("edit")))
/*     */         {
/* 283 */           sbuff.append("<input name=editedvalue type=text size=" + tree[1].length() + " value=\"" + tree[1] + "\" onChange=\"checkSubmit()\">");
/* 284 */           sbuff.append("<input name=editedid type=hidden value=\"" + tree[0] + "\" >");
/*     */         }
/* 286 */         else if ((selectHref == null) && (!recursiveSelection)) {
/* 287 */           sbuff.append("<a href=\"javascript:submitForm('collapse', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/* 288 */         } else if (recursiveSelection) {
/* 289 */           sbuff.append("<a href=\"javascript:submitForm('select', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         } else {
/* 291 */           sbuff.append("<a href=\"" + selectHref + "id=" + tree[0] + "\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         }
/*     */ 
/* 294 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/* 295 */           sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"expanded\">");
/*     */         else {
/* 297 */           sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"none\">");
/*     */         }
/* 299 */         sbuff.append("<input type=hidden name=id" + tree[0] + " value=\"" + tree[0] + "\">");
/* 300 */         sbuff.append("<A NAME=\"anch" + tree[0] + "\"></A>");
/* 301 */         sbuff.append("</td>\n");
/*     */ 
/* 303 */         if (editable)
/*     */         {
/* 305 */           outputEdit(tree[0], sbuff, tree[1]);
/*     */         }
/*     */ 
/* 308 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */         {
/* 310 */           outputNew(tree, sbuff, "");
/*     */         }
/*     */       }
/* 313 */       else if (((expansion != null) && (expansion.equalsIgnoreCase("expanded")) && (!masterid.equalsIgnoreCase(tree[0]))) || ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("expand"))) || ((masterid.equalsIgnoreCase(tree[0])) && (expansion.equalsIgnoreCase("expanded")) && (!masteraction.equalsIgnoreCase("collapse"))))
/*     */       {
/* 317 */         sbuff.append("<a href=\"javascript:submitForm('collapse', '" + tree[0] + "')\"><img src=\"" + EXPANDGIF + "\" border=0></a>");
/* 318 */         sbuff.append("&nbsp");
/*     */ 
/* 320 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("edit")))
/*     */         {
/* 322 */           sbuff.append("<input name=editedvalue type=text size=" + tree[1].length() + " value=\"" + tree[1] + "\" onChange=\"checkSubmit()\">");
/* 323 */           sbuff.append("<input name=editedid type=hidden value=\"" + tree[0] + "\" >");
/*     */         }
/* 325 */         else if ((selectHref == null) && (!recursiveSelection)) {
/* 326 */           sbuff.append("<a href=\"javascript:submitForm('collapse', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/* 327 */         } else if (recursiveSelection) {
/* 328 */           sbuff.append("<a href=\"javascript:submitForm('select', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         } else {
/* 330 */           sbuff.append("<a href=\"" + selectHref + "id=" + tree[0] + "\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         }
/* 332 */         sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"expanded\">");
/* 333 */         sbuff.append("<input type=hidden name=id" + tree[0] + " value=\"" + tree[0] + "\">");
/* 334 */         sbuff.append("<A NAME=\"anch" + tree[0] + "\"></A>");
/*     */ 
/* 336 */         sbuff.append("</td>\n");
/* 337 */         if (editable)
/*     */         {
/* 339 */           outputEdit(tree[0], sbuff, tree[1]);
/*     */         }
/* 341 */         getExpanded(tree[0], req, sbuff, hts, "&nbsp&nbsp&nbsp", editable, selectHref, recursiveSelection);
/* 342 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */         {
/* 344 */           outputNew(tree, sbuff, "");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 349 */         sbuff.append("<a href=\"javascript:submitForm('expand', '" + tree[0] + "')\"><img src=\"" + COLLAPSEGIF + "\" border=0></a>");
/* 350 */         sbuff.append("&nbsp");
/*     */ 
/* 352 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("edit")))
/*     */         {
/* 354 */           sbuff.append("<input name=editedvalue type=text size=" + tree[1].length() + " value=\"" + tree[1] + "\" onChange=\"checkSubmit()\">");
/* 355 */           sbuff.append("<input name=editedid type=hidden value=\"" + tree[0] + "\" >");
/*     */         }
/* 357 */         else if ((selectHref == null) && (!recursiveSelection)) {
/* 358 */           sbuff.append("<a href=\"javascript:submitForm('expand', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/* 359 */         } else if (recursiveSelection) {
/* 360 */           sbuff.append("<a href=\"javascript:submitForm('select', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         } else {
/* 362 */           sbuff.append("<a href=\"" + selectHref + "id=" + tree[0] + "\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         }
/* 364 */         sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"collapsed\">");
/* 365 */         sbuff.append("<input type=hidden name=id" + tree[0] + " value=\"" + tree[0] + "\">");
/* 366 */         sbuff.append("<A NAME=\"anch" + tree[0] + "\"></A>");
/* 367 */         sbuff.append("</td>\n");
/* 368 */         if (editable)
/*     */         {
/* 370 */           outputEdit(tree[0], sbuff, tree[1]);
/*     */         }
/* 372 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */         {
/* 374 */           outputNew(tree, sbuff, "");
/*     */         }
/*     */       }
/*     */ 
/* 378 */       sbuff.append("</tr>\n");
/*     */     }
/* 380 */     sbuff.append("</table>\n");
/*     */ 
/* 382 */     sbuff.append("<input type=hidden name=masteraction value=\"\">");
/* 383 */     sbuff.append("<input type=hidden name=masterid value=\"\">");
/* 384 */     sbuff.append("</td>\n");
/* 385 */     sbuff.append("</tr>\n");
/* 386 */     sbuff.append("</table>\n");
/* 387 */     sbuff.append("</form>");
/*     */ 
/* 390 */     if (masterid.length() > 0)
/*     */     {
/* 392 */       sbuff.append("\n<script language=\"Javascript\">");
/* 393 */       sbuff.append("\n<!--");
/* 394 */       sbuff.append("\n    document.location=\"#anch" + masterid + "\";");
/* 395 */       sbuff.append("\n// -->");
/* 396 */       sbuff.append("\n</script>");
/*     */     }
/* 398 */     if ((editedid != null) && (editedid.length() > 0))
/*     */     {
/* 400 */       sbuff.append("\n<script language=\"Javascript\">");
/* 401 */       sbuff.append("\n<!--");
/* 402 */       sbuff.append("\n    document.location=\"#anch" + editedid + "\";");
/* 403 */       sbuff.append("\n// -->");
/* 404 */       sbuff.append("\n</script>");
/*     */     }
/*     */ 
/* 407 */     if ((dontdisplay) || (masteraction.equalsIgnoreCase("new")))
/*     */     {
/* 409 */       sbuff.append("\n<script language=\"Javascript\">");
/* 410 */       sbuff.append("\n<!--");
/* 411 */       sbuff.append("\n    document.frm.editedvalue.focus();");
/* 412 */       sbuff.append("\n    document.frm.editedvalue.select();");
/* 413 */       sbuff.append("\n\tfunction checkSubmit()\t{");
/* 414 */       sbuff.append("\n\t\t\tsubmitForm(\"\", \"\");");
/* 415 */       sbuff.append("\n\t}");
/* 416 */       sbuff.append("\n// -->");
/* 417 */       sbuff.append("\n</script>");
/*     */     }
/*     */ 
/* 422 */     sbuff.append("<SCRIPT LANGUAGE=\"JavaScript\">\n");
/* 423 */     sbuff.append("function submitForm(action, id) \n");
/* 424 */     sbuff.append("{ \n");
/* 425 */     sbuff.append("\tdocument.frm.masteraction.value=action;\n");
/* 426 */     sbuff.append("\tdocument.frm.masterid.value=id;\n");
/* 427 */     sbuff.append("\tdocument.frm.submit();\n");
/* 428 */     sbuff.append("} \n");
/* 429 */     sbuff.append("function submitDeleteForm(action, id, name) \n");
/* 430 */     sbuff.append("{ \n");
/* 431 */     sbuff.append("\tif(!confirm(\"Are you sure you want to delete \"+name+\".  This will delete all children of this tree!\")){\n");
/* 432 */     sbuff.append("\treturn;}\n");
/* 433 */     sbuff.append("  else{");
/* 434 */     sbuff.append("\tsubmitForm(action, id);}\n");
/* 435 */     sbuff.append("} \n");
/* 436 */     sbuff.append("</script>\n");
/*     */   }
/*     */ 
/*     */   private void outputEdit(String id, StringBuffer sbuff, String name)
/*     */   {
/* 441 */     sbuff.append("<td align=left>");
/* 442 */     sbuff.append("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href=\"javascript:submitForm('new', '" + id + "')\">" + FONTDEC + "New</FONT></a>");
/* 443 */     sbuff.append("&nbsp");
/* 444 */     sbuff.append("<a href=\"javascript:submitForm('edit', '" + id + "')\">" + FONTDEC + "Edit</font</a>");
/* 445 */     sbuff.append("&nbsp");
/* 446 */     sbuff.append("<a href=\"javascript:submitDeleteForm('delete', '" + id + "', '" + name + "')\">" + FONTDEC + "Delete</font></a>");
/* 447 */     sbuff.append("</td>");
/*     */   }
/*     */ 
/*     */   private void outputNew(String[] tree, StringBuffer sbuff, String indent) {
/* 451 */     sbuff.append("\n</tr>");
/* 452 */     sbuff.append("\n<tr>");
/* 453 */     sbuff.append("\n<td>");
/* 454 */     sbuff.append("&nbsp&nbsp&nbsp" + indent + "<input name=editedvalue type=text size=" + tree[1].length() + " value=\"\" onChange=\"checkSubmit()\">");
/* 455 */     sbuff.append("<input name=newid type=hidden value=\"" + tree[0] + "\" >");
/* 456 */     sbuff.append("\n</td>");
/*     */   }
/*     */ 
/*     */   private void getExpanded(String id, HttpServletRequest req, StringBuffer sbuff, HtmlTreeSource hts, String indent, boolean editable, String selectHref, boolean recursiveSelection)
/*     */   {
/* 461 */     Vector trees = hts.getBranches(id);
/*     */ 
/* 464 */     String masterid = req.getParameter("masterid");
/* 465 */     String masteraction = req.getParameter("masteraction");
/* 466 */     if (masterid == null)
/* 467 */       masterid = "";
/* 468 */     if (masteraction == null)
/* 469 */       masteraction = "";
/* 470 */     for (int i = 0; i < trees.size(); i++)
/*     */     {
/* 472 */       sbuff.append("<tr height=1>\n");
/* 473 */       sbuff.append("<td>\n");
/* 474 */       String[] tree = (String[])trees.elementAt(i);
/* 475 */       String expansion = req.getParameter("action" + tree[0]);
/*     */ 
/* 477 */       if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */       {
/* 479 */         expansion = "expanded";
/*     */       }
/*     */ 
/* 482 */       if (tree[2].equalsIgnoreCase("0"))
/*     */       {
/* 484 */         sbuff.append(indent + "<img src=\"" + NOITEMGIF + "\" border=0>");
/* 485 */         sbuff.append("&nbsp");
/* 486 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("edit")))
/*     */         {
/* 488 */           sbuff.append("<input name=editedvalue type=text size=" + tree[1].length() + " value=\"" + tree[1] + "\" onChange=\"checkSubmit()\">");
/* 489 */           sbuff.append("<input name=editedid type=hidden value=\"" + tree[0] + "\" >");
/*     */         }
/* 491 */         else if ((selectHref == null) && (!recursiveSelection)) {
/* 492 */           sbuff.append("<a href=\"javascript:submitForm('collapse', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/* 493 */         } else if (recursiveSelection) {
/* 494 */           sbuff.append("<a href=\"javascript:submitForm('select', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         } else {
/* 496 */           sbuff.append("<a href=\"" + selectHref + "id=" + tree[0] + "\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         }
/* 498 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/* 499 */           sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"expanded\">");
/*     */         else {
/* 501 */           sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"none\">");
/*     */         }
/* 503 */         sbuff.append("<input type=hidden name=id" + tree[0] + " value=\"" + tree[0] + "\">");
/* 504 */         sbuff.append("<A NAME=\"anch" + tree[0] + "\"></A>");
/* 505 */         sbuff.append("</td>\n");
/* 506 */         if (editable)
/*     */         {
/* 508 */           outputEdit(tree[0], sbuff, tree[1]);
/*     */         }
/* 510 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */         {
/* 512 */           outputNew(tree, sbuff, indent);
/*     */         }
/*     */       }
/* 515 */       else if (((expansion != null) && (expansion.equalsIgnoreCase("expanded")) && (!masterid.equalsIgnoreCase(tree[0]))) || ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("expand"))) || ((masterid.equalsIgnoreCase(tree[0])) && (expansion.equalsIgnoreCase("expanded")) && (!masteraction.equalsIgnoreCase("collapse"))))
/*     */       {
/* 519 */         sbuff.append(indent + "<a href=\"javascript:submitForm('collapse', '" + tree[0] + "')\"><img src=\"" + EXPANDGIF + "\" border=0></a>");
/* 520 */         sbuff.append("&nbsp");
/* 521 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("edit")))
/*     */         {
/* 523 */           sbuff.append("<input name=editedvalue type=text size=" + tree[1].length() + " value=\"" + tree[1] + "\" onChange=\"checkSubmit()\">");
/* 524 */           sbuff.append("<input name=editedid type=hidden value=\"" + tree[0] + "\" >");
/*     */         }
/* 526 */         else if ((selectHref == null) && (!recursiveSelection)) {
/* 527 */           sbuff.append("<a href=\"javascript:submitForm('collapse', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/* 528 */         } else if (recursiveSelection) {
/* 529 */           sbuff.append("<a href=\"javascript:submitForm('select', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         } else {
/* 531 */           sbuff.append("<a href=\"" + selectHref + "id=" + tree[0] + "\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         }
/* 533 */         sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"expanded\">");
/* 534 */         sbuff.append("<input type=hidden name=id" + tree[0] + " value=\"" + tree[0] + "\">");
/* 535 */         sbuff.append("<A NAME=\"anch" + tree[0] + "\"></A>");
/* 536 */         sbuff.append("</td>\n");
/* 537 */         if (editable)
/*     */         {
/* 539 */           outputEdit(tree[0], sbuff, tree[1]);
/*     */         }
/* 541 */         getExpanded(tree[0], req, sbuff, hts, indent + "&nbsp&nbsp&nbsp", editable, selectHref, recursiveSelection);
/* 542 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */         {
/* 544 */           outputNew(tree, sbuff, indent);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 549 */         sbuff.append(indent + "<a href=\"javascript:submitForm('expand', '" + tree[0] + "')\"><img src=\"" + COLLAPSEGIF + "\" border=0></a>");
/* 550 */         sbuff.append("&nbsp");
/* 551 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("edit")))
/*     */         {
/* 553 */           sbuff.append("<input name=editedvalue type=text size=" + tree[1].length() + " value=\"" + tree[1] + "\" onChange=\"checkSubmit()\">");
/* 554 */           sbuff.append("<input name=editedid type=hidden value=\"" + tree[0] + "\" >");
/*     */         }
/* 556 */         else if ((selectHref == null) && (!recursiveSelection)) {
/* 557 */           sbuff.append("<a href=\"javascript:submitForm('expand', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/* 558 */         } else if (recursiveSelection) {
/* 559 */           sbuff.append("<a href=\"javascript:submitForm('select', '" + tree[0] + "')\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         } else {
/* 561 */           sbuff.append("<a href=\"" + selectHref + "id=" + tree[0] + "\">" + FONTDEC + tree[1] + "</font></a>");
/*     */         }
/* 563 */         sbuff.append("<input type=hidden name=action" + tree[0] + " value=\"collapsed\">");
/* 564 */         sbuff.append("<input type=hidden name=id" + tree[0] + " value=\"" + tree[0] + "\">");
/* 565 */         sbuff.append("<A NAME=\"anch" + tree[0] + "\"></A>");
/* 566 */         sbuff.append("</td>\n");
/* 567 */         if (editable)
/*     */         {
/* 569 */           outputEdit(tree[0], sbuff, tree[1]);
/*     */         }
/* 571 */         if ((masterid.equalsIgnoreCase(tree[0])) && (masteraction.equalsIgnoreCase("new")))
/*     */         {
/* 573 */           outputNew(tree, sbuff, indent);
/*     */         }
/*     */       }
/*     */ 
/* 577 */       sbuff.append("</tr>\n");
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tree.HtmlTree
 * JD-Core Version:    0.6.2
 */