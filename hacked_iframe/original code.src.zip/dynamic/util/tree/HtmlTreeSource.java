package dynamic.util.tree;

import java.util.Vector;

public abstract interface HtmlTreeSource
{
  public abstract Vector getTrees();

  public abstract Vector getBranches(String paramString);

  public abstract void deleteBranch(String paramString);

  public abstract void addBranch(String paramString1, String paramString2);

  public abstract void editBranch(String paramString1, String paramString2);
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tree.HtmlTreeSource
 * JD-Core Version:    0.6.2
 */