/*    */ package dynamic.util.tree;
/*    */ 
/*    */ public class HtmlTreeException extends Exception
/*    */ {
/*    */   private String outputString;
/*    */ 
/*    */   public HtmlTreeException(String name)
/*    */   {
/* 27 */     this.outputString = name;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 32 */     return "HtmlCalendarException: " + this.outputString;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.tree.HtmlTreeException
 * JD-Core Version:    0.6.2
 */