/*     */ package dynamic.util.file;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Hashtable;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ /** @deprecated */
/*     */ public abstract class AttachmentServlet extends HttpServlet
/*     */ {
/*  40 */   private boolean initialized = false;
/*  41 */   private String initializerErrors = "";
/*     */ 
/*  43 */   private int maxSize = 1048576;
/*     */ 
/*  49 */   private static String INI_FILE_PARAM = "iniFile";
/*     */   Hashtable table;
/*     */ 
/*     */   public void init(ServletConfig config)
/*     */     throws ServletException
/*     */   {
/*  62 */     String iniFileName = config.getInitParameter(INI_FILE_PARAM);
/*  63 */     if (iniFileName == null) {
/*  64 */       throw new ServletException("The mandatory parameter " + INI_FILE_PARAM + " is not set.");
/*     */     }
/*  66 */     super.init(config);
/*     */   }
/*     */ 
/*     */   protected void doPost(HttpServletRequest req, HttpServletResponse res)
/*     */     throws ServletException, IOException
/*     */   {
/*     */     try
/*     */     {
/*  87 */       if (!req.getContentType().toLowerCase().startsWith("multipart/form-data"))
/*     */       {
/*  92 */         throw new AttachmentException("Wrong content type set for file upload");
/*     */       }
/*     */ 
/*  95 */       if (req.getContentLength() > this.maxSize)
/*     */       {
/*  97 */         throw new AttachmentException("Content too long - sent files are limited in size");
/*     */       }
/*     */ 
/* 100 */       int ind = req.getContentType().indexOf("boundary=");
/* 101 */       if (ind == -1)
/*     */       {
/* 103 */         throw new AttachmentException("boundary is not set");
/*     */       }
/*     */ 
/* 106 */       String boundary = req.getContentType().substring(ind + 9);
/*     */ 
/* 108 */       if (boundary == null)
/*     */       {
/* 110 */         throw new AttachmentException("boundary is not set");
/*     */       }
/*     */ 
/* 113 */       this.table = parseMulti(boundary, req.getInputStream());
/* 114 */       processFiles();
/* 115 */       sendSucess(res);
/*     */     }
/*     */     catch (AttachmentException a)
/*     */     {
/* 119 */       sendFailure(res, a.getMessage());
/*     */     }
/*     */     catch (OutOfMemoryError oom)
/*     */     {
/* 123 */       sendFailure(res, "Memory exhausted uploading file.");
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 127 */       t.printStackTrace(new PrintWriter(res.getOutputStream(), true));
/*     */     }
/*     */   }
/*     */ 
/*     */   Hashtable parseMulti(String boundary, ServletInputStream in)
/*     */     throws IOException
/*     */   {
/* 145 */     int buffSize = 8192;
/* 146 */     Hashtable hash = new Hashtable();
/*     */ 
/* 150 */     String boundaryStr = "--" + boundary;
/*     */ 
/* 157 */     byte[] b = new byte[buffSize];
/*     */ 
/* 159 */     int result = in.readLine(b, 0, b.length);
/*     */ 
/* 161 */     if (result == -1)
/*     */     {
/* 163 */       throw new IllegalArgumentException("InputStream truncated");
/*     */     }
/* 165 */     String line = new String(b, 0, result);
/*     */ 
/* 167 */     if (!line.startsWith(boundaryStr))
/*     */     {
/* 169 */       throw new IllegalArgumentException("MIME boundary missing: " + line);
/*     */     }
/*     */ 
/*     */     while (true)
/*     */     {
/* 174 */       String filename = null;
/* 175 */       String contentType = null;
/* 176 */       ByteArrayOutputStream content = new ByteArrayOutputStream();
/* 177 */       String name = null;
/*     */ 
/* 180 */       result = in.readLine(b, 0, b.length);
/* 181 */       if (result == -1) return hash;
/* 182 */       line = new String(b, 0, result - 2);
/* 183 */       String lowerline = line.toLowerCase();
/* 184 */       if (lowerline.startsWith("content-disposition"))
/*     */       {
/* 191 */         int ind = lowerline.indexOf("content-disposition: ");
/* 192 */         int ind2 = lowerline.indexOf(";");
/* 193 */         if ((ind == -1) || (ind2 == -1))
/*     */         {
/* 195 */           throw new IllegalArgumentException("Content Disposition line misformatted: " + line);
/*     */         }
/*     */ 
/* 198 */         String disposition = lowerline.substring(ind + 21, ind2);
/* 199 */         if (!disposition.equals("form-data"))
/*     */         {
/* 201 */           throw new IllegalArgumentException("Content Disposition of " + disposition + " is not supported");
/*     */         }
/*     */ 
/* 205 */         int ind3 = lowerline.indexOf("name=\"", ind2);
/* 206 */         int ind4 = lowerline.indexOf("\"", ind3 + 7);
/* 207 */         if ((ind3 == -1) || (ind4 == -1))
/*     */         {
/* 209 */           throw new IllegalArgumentException("Content Disposition line misformatted: " + line);
/*     */         }
/*     */ 
/* 212 */         name = line.substring(ind3 + 6, ind4);
/*     */ 
/* 214 */         int ind5 = lowerline.indexOf("filename=\"", ind4 + 2);
/* 215 */         int ind6 = lowerline.indexOf("\"", ind5 + 10);
/* 216 */         if ((ind5 != -1) && (ind6 != -1))
/*     */         {
/* 218 */           filename = line.substring(ind5 + 10, ind6);
/*     */         }
/*     */ 
/* 223 */         result = in.readLine(b, 0, b.length);
/* 224 */         if (result == -1) return hash;
/* 225 */         line = new String(b, 0, result - 2);
/* 226 */         lowerline = line.toLowerCase();
/* 227 */         if (lowerline.startsWith("content-type"))
/*     */         {
/* 229 */           int ind7 = lowerline.indexOf(" ");
/* 230 */           if (ind7 == -1)
/*     */           {
/* 232 */             throw new IllegalArgumentException("Content-Type line misformatted: " + line);
/*     */           }
/*     */ 
/* 235 */           contentType = lowerline.substring(ind7 + 1);
/*     */ 
/* 237 */           result = in.readLine(b, 0, b.length);
/* 238 */           if (result == -1) return hash;
/* 239 */           line = new String(b, 0, result - 2);
/* 240 */           if (line.length() != 0)
/*     */           {
/* 242 */             throw new IllegalArgumentException("Unexpected line in MIMEpart header: " + line);
/*     */           }
/*     */ 
/*     */         }
/* 246 */         else if (line.length() != 0)
/*     */         {
/* 248 */           throw new IllegalArgumentException("Misformatted line following disposition: " + line);
/*     */         }
/*     */ 
/* 253 */         boolean readingContent = true;
/* 254 */         boolean firstLine = true;
/* 255 */         byte[] buffbytes = new byte[buffSize];
/* 256 */         int buffnum = 0;
/*     */ 
/* 258 */         result = in.readLine(b, 0, b.length);
/* 259 */         if (result == -1) return hash;
/* 260 */         line = new String(b, 0, result);
/* 261 */         if (!line.startsWith(boundaryStr))
/*     */         {
/* 263 */           System.arraycopy(b, 0, buffbytes, 0, result);
/* 264 */           buffnum = result;
/* 265 */           result = in.readLine(b, 0, b.length);
/* 266 */           if (result == -1) return hash;
/* 267 */           line = new String(b, 0, result);
/* 268 */           firstLine = false;
/* 269 */           if (line.startsWith(boundaryStr))
/*     */           {
/* 271 */             readingContent = false;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 276 */           readingContent = false;
/*     */         }
/*     */ 
/* 279 */         while (readingContent)
/*     */         {
/* 281 */           content.write(buffbytes, 0, buffnum);
/* 282 */           System.arraycopy(b, 0, buffbytes, 0, result);
/* 283 */           buffnum = result;
/* 284 */           result = in.readLine(b, 0, b.length);
/* 285 */           if (result == -1) return hash;
/* 286 */           line = new String(b, 0, result);
/* 287 */           if (line.startsWith(boundaryStr)) readingContent = false;
/*     */         }
/* 289 */         if (!firstLine)
/*     */         {
/* 292 */           if (buffnum > 2) {
/* 293 */             content.write(buffbytes, 0, buffnum - 2);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 298 */         if (filename == null)
/*     */         {
/* 300 */           if (hash.get(name) == null)
/*     */           {
/* 302 */             String[] values = new String[1];
/* 303 */             values[0] = content.toString();
/* 304 */             hash.put(name, values);
/*     */           }
/*     */           else
/*     */           {
/* 308 */             Object prevobj = hash.get(name);
/* 309 */             if ((prevobj instanceof String[]))
/*     */             {
/* 311 */               String[] prev = (String[])prevobj;
/* 312 */               String[] newStr = new String[prev.length + 1];
/* 313 */               System.arraycopy(prev, 0, newStr, 0, prev.length);
/* 314 */               newStr[prev.length] = content.toString();
/* 315 */               hash.put(name, newStr);
/*     */             }
/*     */             else
/*     */             {
/* 320 */               throw new IllegalArgumentException("failure in parseMulti hashtable building code");
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 327 */           Hashtable filehash = new Hashtable(4);
/* 328 */           filehash.put("name", name);
/* 329 */           filehash.put("filename", filename);
/* 330 */           if (contentType == null) contentType = "application/octet-stream";
/* 331 */           filehash.put("content-type", contentType);
/* 332 */           filehash.put("content", content.toByteArray());
/* 333 */           hash.put(name, filehash);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeFile(Hashtable fileHash, File destPath)
/*     */     throws AttachmentException
/*     */   {
/*     */     try
/*     */     {
/* 350 */       Diagnostics.debug("Writing to " + destPath);
/* 351 */       BufferedOutputStream fileout = new BufferedOutputStream(new FileOutputStream(destPath));
/* 352 */       byte[] bytes = (byte[])fileHash.get("content");
/* 353 */       fileout.write(bytes, 0, bytes.length);
/* 354 */       fileout.flush();
/* 355 */       fileout.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 359 */       throw new AttachmentException("Unable to write the file: " + e.getMessage() + ".");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getServletInfo()
/*     */   {
/* 366 */     return "Member Attach Servlet (c) 1999 Dynamic Information Systems, LLC";
/*     */   }
/*     */ 
/*     */   protected String[] getParameterValues(String parmName)
/*     */   {
/* 378 */     return (String[])this.table.get(parmName);
/*     */   }
/*     */ 
/*     */   protected Hashtable getFileInfo(String inputFileParmName)
/*     */   {
/* 390 */     return (Hashtable)this.table.get(inputFileParmName);
/*     */   }
/*     */ 
/*     */   protected abstract void processFiles()
/*     */     throws AttachmentException;
/*     */ 
/*     */   protected abstract void sendFailure(HttpServletResponse paramHttpServletResponse, String paramString)
/*     */     throws IOException;
/*     */ 
/*     */   protected abstract void sendSucess(HttpServletResponse paramHttpServletResponse)
/*     */     throws IOException;
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.file.AttachmentServlet
 * JD-Core Version:    0.6.2
 */