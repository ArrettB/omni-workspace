/*    */ package dynamic.util.file;
/*    */ 
/*    */ public class ReplacementSet
/*    */ {
/*    */   String key;
/*    */   String value;
/*    */ 
/*    */   public ReplacementSet()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ReplacementSet(String key, String value)
/*    */   {
/* 19 */     this.key = key;
/* 20 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getKey()
/*    */   {
/* 25 */     return this.key;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 31 */     return this.value;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.file.ReplacementSet
 * JD-Core Version:    0.6.2
 */