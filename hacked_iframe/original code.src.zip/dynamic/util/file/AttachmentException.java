/*    */ package dynamic.util.file;
/*    */ 
/*    */ public class AttachmentException extends Exception
/*    */ {
/*    */   String errcode;
/*    */ 
/*    */   public AttachmentException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AttachmentException(String msg)
/*    */   {
/* 21 */     super(msg);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.file.AttachmentException
 * JD-Core Version:    0.6.2
 */