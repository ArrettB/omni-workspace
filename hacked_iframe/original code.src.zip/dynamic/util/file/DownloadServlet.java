/*    */ package dynamic.util.file;
/*    */ 
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import javax.servlet.GenericServlet;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public abstract class DownloadServlet extends HttpServlet
/*    */ {
/* 25 */   private static String INI_FILE_PARAM = "iniFile";
/*    */ 
/*    */   public void init(ServletConfig config)
/*    */     throws ServletException
/*    */   {
/* 36 */     String iniFileName = config.getInitParameter(INI_FILE_PARAM);
/* 37 */     if (iniFileName == null) {
/* 38 */       throw new ServletException("The mandatory parameter " + INI_FILE_PARAM + " is not set.");
/*    */     }
/* 40 */     super.init(config);
/*    */   }
/*    */ 
/*    */   public void service(HttpServletRequest req, HttpServletResponse res)
/*    */     throws ServletException, IOException
/*    */   {
/*    */     try
/*    */     {
/* 50 */       processFile(req, res);
/*    */     }
/*    */     catch (AttachmentException e)
/*    */     {
/* 54 */       sendFailure(res, e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public void returnFile(HttpServletRequest req, HttpServletResponse res, String fqnFile)
/*    */     throws AttachmentException
/*    */   {
/* 65 */     returnFile(req, res, new File(fqnFile));
/*    */   }
/*    */ 
/*    */   public void returnFile(HttpServletRequest req, HttpServletResponse res, File dFile)
/*    */     throws AttachmentException
/*    */   {
/* 74 */     returnFile(req, res, dFile, null);
/*    */   }
/*    */ 
/*    */   public void returnFile(HttpServletRequest req, HttpServletResponse res, File dFile, String mimeType)
/*    */     throws AttachmentException
/*    */   {
/* 83 */     FileInputStream fis = null;
/*    */ 
/* 85 */     if (!dFile.exists())
/* 86 */       throw new AttachmentException("The file does not exist.");
/* 87 */     if (!dFile.isFile())
/* 88 */       throw new AttachmentException("The file is not valid.");
/* 89 */     if (!dFile.canRead()) {
/* 90 */       throw new AttachmentException("The file is not readable.");
/*    */     }
/*    */     try
/*    */     {
/* 94 */       ServletOutputStream out = res.getOutputStream();
/*    */ 
/* 96 */       String contentType = getServletContext().getMimeType(dFile.getPath());
/* 97 */       Diagnostics.debug(contentType);
/*    */ 
/* 99 */       res.setHeader("X-Barry", contentType);
/*    */ 
/* 120 */       if (mimeType == null)
/*    */       {
/* 122 */         if ((contentType != null) && (contentType.trim().length() > 1))
/* 123 */           res.setContentType(contentType);
/*    */         else {
/* 125 */           res.setContentType("application/msword");
/*    */         }
/*    */       }
/*    */       else {
/* 129 */         res.setContentType(mimeType);
/*    */       }
/*    */ 
/* 134 */       fis = new FileInputStream(dFile.getPath());
/*    */ 
/* 136 */       byte[] buf = new byte[4096];
/*    */       int bytesRead;
/* 138 */       while ((bytesRead = fis.read(buf)) != -1)
/*    */       {
/*    */         int i;
/* 140 */         out.write(buf, 0, i);
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 146 */       throw new AttachmentException(e.getMessage());
/*    */     }
/*    */     finally
/*    */     {
/*    */       try
/*    */       {
/* 152 */         if (fis != null)
/* 153 */           fis.close();
/*    */       }
/*    */       catch (Exception e)
/*    */       {
/* 157 */         throw new AttachmentException(e.getMessage());
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract void processFile(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws AttachmentException;
/*    */ 
/*    */   protected abstract void sendFailure(HttpServletResponse paramHttpServletResponse, String paramString)
/*    */     throws IOException;
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.file.DownloadServlet
 * JD-Core Version:    0.6.2
 */