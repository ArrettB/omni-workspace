/*    */ package dynamic.util.file;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class Replacements
/*    */ {
/* 12 */   Vector replacementList = new Vector();
/*    */ 
/*    */   public void add(String key, String value)
/*    */   {
/* 21 */     this.replacementList.addElement(new ReplacementSet(key, value));
/*    */   }
/*    */ 
/*    */   public int getSize()
/*    */   {
/* 30 */     return this.replacementList.size();
/*    */   }
/*    */ 
/*    */   public ReplacementSet getSetAt(int index)
/*    */   {
/* 40 */     if ((index < 0) || (index > getSize()))
/*    */     {
/* 42 */       return new ReplacementSet();
/*    */     }
/*    */ 
/* 46 */     return (ReplacementSet)this.replacementList.elementAt(index);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.file.Replacements
 * JD-Core Version:    0.6.2
 */