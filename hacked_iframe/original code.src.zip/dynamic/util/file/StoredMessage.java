/*     */ package dynamic.util.file;
/*     */ 
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class StoredMessage
/*     */ {
/*  29 */   File file = null;
/*     */ 
/*     */   public StoredMessage()
/*     */   {
/*     */   }
/*     */ 
/*     */   public StoredMessage(String filePath) throws IOException
/*     */   {
/*  37 */     setupWithPath(filePath);
/*     */   }
/*     */ 
/*     */   public StoredMessage(File file) throws IOException
/*     */   {
/*  42 */     setupWithFile(file);
/*     */   }
/*     */ 
/*     */   public void setupWithPath(String filePath)
/*     */     throws IOException
/*     */   {
/*  50 */     File file = null;
/*     */     try
/*     */     {
/*  54 */       file = new File(filePath);
/*  55 */       setupWithFile(file);
/*     */     }
/*     */     catch (NullPointerException e)
/*     */     {
/*  60 */       throw new IOException("StoredMessage() No path given.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setupWithFile(File file)
/*     */     throws IOException
/*     */   {
/*  69 */     if (!file.exists())
/*     */     {
/*  71 */       throw new FileNotFoundException("StoredMessage() The file " + file + " was not found.");
/*     */     }
/*  73 */     if (!file.canRead())
/*     */     {
/*  75 */       throw new IOException("StoredMessage() The file " + file + " is not readable.  Please check the file permissions.");
/*     */     }
/*  77 */     this.file = file;
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */     throws IOException
/*     */   {
/*  87 */     return getMessage(null);
/*     */   }
/*     */ 
/*     */   public String getMessage(Replacements replacements)
/*     */     throws IOException
/*     */   {
/*  96 */     String message = getText();
/*  97 */     if (replacements != null)
/*     */     {
/*  99 */       for (int i = 0; i < replacements.getSize(); i++)
/*     */       {
/* 101 */         message = StringUtil.replaceString(message, replacements.getSetAt(i).getKey(), replacements.getSetAt(i).getValue());
/*     */       }
/*     */     }
/*     */ 
/* 105 */     return message;
/*     */   }
/*     */ 
/*     */   public String getText()
/*     */     throws IOException
/*     */   {
/* 113 */     String retVal = new String();
/* 114 */     FileInputStream fis = null;
/*     */     try
/*     */     {
/* 117 */       fis = new FileInputStream(this.file);
/* 118 */       int fileSize = fis.available();
/* 119 */       byte[] buffer = new byte[fileSize];
/* 120 */       int bytesRead = fis.read(buffer);
/*     */ 
/* 122 */       retVal = new String(buffer);
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/* 126 */       throw new FileNotFoundException("StoredMessage.getText() The file " + this.file + " was not found.");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 130 */       throw new IOException("StoredMessage.getText() " + e);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 136 */         if (fis != null)
/* 137 */           fis.close();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 141 */         throw new IOException("StoredMessage.getText() " + e);
/*     */       }
/*     */     }
/* 144 */     return retVal;
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*     */     try
/*     */     {
/* 154 */       StoredMessage sm = new StoredMessage("d:\\work\\quest\\notify_new_addenda.txt");
/* 155 */       Replacements rep = new Replacements();
/* 156 */       rep.add("%%contact_name%%", "Don");
/* 157 */       rep.add("%%available_date%%", new StdDate().addDays(1).toString());
/* 158 */       rep.add("%%project_name%%", "proj1");
/* 159 */       rep.add("%%sender%%", "testb@dynamic-info.com");
/* 160 */       Diagnostics.debug("StoredMessage.main() " + sm.getMessage(rep));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 164 */       Diagnostics.error("StoredMessage.main()", e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.file.StoredMessage
 * JD-Core Version:    0.6.2
 */