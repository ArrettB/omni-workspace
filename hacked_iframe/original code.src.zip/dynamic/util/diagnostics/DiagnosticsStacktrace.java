/*    */ package dynamic.util.diagnostics;
/*    */ 
/*    */ public class DiagnosticsStacktrace extends Exception
/*    */ {
/*    */   public DiagnosticsStacktrace()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DiagnosticsStacktrace(String s)
/*    */   {
/* 16 */     super(s);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.DiagnosticsStacktrace
 * JD-Core Version:    0.6.2
 */