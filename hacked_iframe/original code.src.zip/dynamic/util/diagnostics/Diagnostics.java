/*     */ package dynamic.util.diagnostics;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public final class Diagnostics
/*     */   implements Runnable
/*     */ {
/*     */   public static final int MIN_LEVEL = 0;
/*     */   public static final int FATAL = 0;
/*     */   public static final int ERROR = 1;
/*     */   public static final int WARNING = 4;
/*     */   public static final int STATUS = 8;
/*     */   public static final int DEBUG = 11;
/*     */   public static final int DEBUG2 = 12;
/*     */   public static final int DEBUG3 = 13;
/*     */   public static final int TRACE = 14;
/*     */   public static final int TRACE2 = 15;
/*     */   public static final int MAX_LEVEL = 15;
/*  31 */   private static Thread tid = null;
/*  32 */   private static Hashtable contexts = new Hashtable();
/*     */ 
/*     */   public static DiagnosticsContext initialize(Node n)
/*     */     throws Exception
/*     */   {
/*  51 */     DiagnosticsContext context = new DiagnosticsContext();
/*  52 */     context.initialize(n);
/*  53 */     registerThread(context);
/*  54 */     return context;
/*     */   }
/*     */ 
/*     */   public static void destroy()
/*     */   {
/*  62 */     DiagnosticsContext context = getContext();
/*  63 */     if (context == null) return;
/*     */ 
/*  66 */     Enumeration e = contexts.keys();
/*  67 */     while (e.hasMoreElements())
/*     */     {
/*  69 */       Object x = e.nextElement();
/*  70 */       Object y = contexts.get(x);
/*  71 */       if (y == context) contexts.remove(x);
/*     */     }
/*     */ 
/*  74 */     context.destroy();
/*     */   }
/*     */ 
/*     */   public static DiagnosticsContext getContext()
/*     */   {
/*  82 */     return (DiagnosticsContext)contexts.get(Thread.currentThread());
/*     */   }
/*     */ 
/*     */   public static void registerThread(Thread thread)
/*     */   {
/*  90 */     registerThread(thread, getContext());
/*     */   }
/*     */ 
/*     */   public static void registerThread(DiagnosticsContext context)
/*     */   {
/*  98 */     registerThread(Thread.currentThread(), context);
/*     */   }
/*     */ 
/*     */   public static void registerThread(Thread thread, DiagnosticsContext context)
/*     */   {
/* 106 */     if ((thread != null) && (context != null))
/* 107 */       contexts.put(thread, context);
/*     */   }
/*     */ 
/*     */   public static void releaseThread(Thread thread)
/*     */   {
/* 113 */     if (thread != null)
/* 114 */       contexts.remove(thread);
/*     */   }
/*     */ 
/*     */   private static void start()
/*     */   {
/* 119 */     tid = new Thread(new Diagnostics(), "DiagnosticsCleaner");
/* 120 */     tid.setDaemon(true);
/* 121 */     tid.setPriority(1);
/* 122 */     tid.start();
/*     */   }
/*     */ 
/*     */   private static void stop()
/*     */   {
/* 127 */     if (tid == null) return;
/* 128 */     Thread temp = tid;
/* 129 */     tid = null;
/* 130 */     if (temp != Thread.currentThread()) temp.interrupt();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 137 */       Thread thisThread = Thread.currentThread();
/* 138 */       while (thisThread == tid)
/*     */       {
/* 140 */         Enumeration hashEnum = contexts.keys();
/* 141 */         while (hashEnum.hasMoreElements())
/*     */         {
/* 143 */           Thread thread = (Thread)hashEnum.nextElement();
/* 144 */           if (!thread.isAlive())
/* 145 */             contexts.remove(thread);
/*     */         }
/*     */         try
/*     */         {
/* 149 */           Thread.sleep(60000L);
/*     */         }
/*     */         catch (InterruptedException e) {
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 156 */       e.printStackTrace(System.err);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getPort()
/*     */   {
/* 165 */     DiagnosticsContext context = getContext();
/* 166 */     if (context == null) {
/* 167 */       return 0;
/*     */     }
/* 169 */     return context.getPort();
/*     */   }
/*     */ 
/*     */   public static void write(DiagnosticsMessage msg)
/*     */   {
/* 177 */     DiagnosticsContext context = getContext();
/* 178 */     if (context == null)
/*     */     {
/* 180 */       System.err.print("* " + msg.toString());
/*     */     }
/*     */     else
/*     */     {
/* 184 */       context.write(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage write(int severity, String msg, Throwable ex, Object caller)
/*     */   {
/* 190 */     DiagnosticsMessage m = new DiagnosticsMessage(severity, msg, ex, caller);
/* 191 */     write(m);
/* 192 */     return m;
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage fatal(String msg, Throwable ex, Object caller)
/*     */   {
/* 197 */     return write(0, msg, ex, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage fatal(String msg, Throwable ex) {
/* 201 */     return write(0, msg, ex, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage fatal(String msg) {
/* 205 */     return write(0, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage error(String msg, Throwable ex, Object caller)
/*     */   {
/* 210 */     return write(1, msg, ex, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage error(String msg, Throwable ex) {
/* 214 */     return write(1, msg, ex, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage error(String msg) {
/* 218 */     return write(1, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage warning(String msg, Object caller)
/*     */   {
/* 223 */     return write(4, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage warning(String msg) {
/* 227 */     return write(4, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage status(String msg, Object caller)
/*     */   {
/* 232 */     return write(8, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage status(String msg) {
/* 236 */     return write(8, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage debug(String msg, Object caller)
/*     */   {
/* 241 */     return write(11, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage debug(String msg) {
/* 245 */     return write(11, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage debug2(String msg, Object caller)
/*     */   {
/* 250 */     return write(12, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage debug2(String msg) {
/* 254 */     return write(12, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage debug3(String msg, Object caller)
/*     */   {
/* 259 */     return write(13, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage debug3(String msg) {
/* 263 */     return write(13, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage trace(String msg, Object caller)
/*     */   {
/* 268 */     return write(14, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage trace(String msg) {
/* 272 */     return write(14, msg, null, null);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage trace2(String msg, Object caller)
/*     */   {
/* 277 */     return write(15, msg, null, caller);
/*     */   }
/*     */ 
/*     */   public static DiagnosticsMessage trace2(String msg) {
/* 281 */     return write(15, msg, null, null);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  36 */     start();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.Diagnostics
 * JD-Core Version:    0.6.2
 */