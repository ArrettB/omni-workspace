/*     */ package dynamic.util.diagnostics;
/*     */ 
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class DiagnosticsMessage
/*     */   implements Serializable
/*     */ {
/*     */   public Date date;
/*  13 */   public int severity = -1;
/*     */   public String text;
/*     */   public String exceptionName;
/*     */   public String exceptionMessage;
/*     */   public String query;
/*     */   public String stacktrace;
/*     */   public String stacktraceHTML;
/*     */   public String caller;
/*     */   public String threadName;
/*     */   private static final String dateFormat = "yyyy/MM/dd HH:mm:ss.SSS";
/*  24 */   private static String format = "%date [%severity] (%thread) %text\n%exception\n%stacktrace\n%caller";
/*     */ 
/* 186 */   public static String[] color = { "#FF00FF", "#FF0000", "#D00000", "#A00000", "#C0C000", "#A0A000", "#808000", "#404000", "#00C000", "#00A000", "#008000", "#000000", "#0000FF", "#A000A0", "#808080", "#A0A0A0", "#C0C0C0" };
/*     */ 
/*     */   public DiagnosticsMessage(int severity, String text, Throwable ex, Object caller)
/*     */   {
/*  28 */     this.date = new Date();
/*  29 */     this.severity = severity;
/*  30 */     this.text = text;
/*  31 */     this.threadName = Thread.currentThread().getName();
/*     */ 
/*  33 */     if (ex != null)
/*     */     {
/*     */       try
/*     */       {
/*  37 */         this.exceptionName = ex.getClass().getName();
/*  38 */         this.exceptionMessage = ex.getMessage();
/*  39 */         ByteArrayOutputStream fooStream = new ByteArrayOutputStream();
/*  40 */         ex.printStackTrace(new PrintWriter(fooStream, true));
/*  41 */         this.stacktrace = fooStream.toString();
/*  42 */         int dropfirstline = this.stacktrace.indexOf('\n');
/*  43 */         if (dropfirstline != -1)
/*  44 */           this.stacktrace = this.stacktrace.substring(dropfirstline + 1);
/*  45 */         if ((ex instanceof SQLException))
/*     */         {
/*  47 */           SQLException sqlEx = ((SQLException)ex).getNextException();
/*  48 */           if (sqlEx != null) {
/*  49 */             this.query = sqlEx.getMessage();
/*     */           }
/*     */         }
/*     */ 
/*  53 */         int pos = 0;
/*  54 */         StringBuffer sb = new StringBuffer();
/*     */ 
/*  56 */         Vector sourcePaths = StringUtil.stringToVector(System.getProperty("dynamic.source.path"), ';');
/*  57 */         if (sourcePaths != null)
/*     */         {
/*  59 */           while (pos >= 0)
/*     */           {
/*  61 */             int atPos = this.stacktrace.indexOf("at ", pos);
/*  62 */             int startPos = this.stacktrace.indexOf("(", pos);
/*  63 */             int endPos = this.stacktrace.indexOf(")", pos);
/*     */ 
/*  65 */             if ((atPos <= 0) || (startPos <= 0) || (endPos <= 0))
/*     */               break;
/*  67 */             String file = this.stacktrace.substring(atPos + 3, startPos);
/*  68 */             String contents = this.stacktrace.substring(startPos + 1, endPos);
/*  69 */             file = file.substring(0, file.lastIndexOf("."));
/*  70 */             file = StringUtil.replaceString(file, ".", "/");
/*  71 */             file = file + ".java";
/*  72 */             sb.append(this.stacktrace.substring(pos, startPos));
/*  73 */             boolean found = false;
/*  74 */             for (int i = 0; i < sourcePaths.size(); i++)
/*     */             {
/*  76 */               File d = new File((String)sourcePaths.elementAt(i));
/*  77 */               File f = new File(d, file);
/*  78 */               if (f.exists())
/*     */               {
/*  80 */                 sb.append("(<a href=\"file://" + f.getCanonicalPath() + "\">" + contents + "</a>" + ")");
/*  81 */                 found = true;
/*  82 */                 break;
/*     */               }
/*     */             }
/*  85 */             if (!found) sb.append("(" + contents + ")");
/*  86 */             pos = endPos + 1;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  94 */         sb.append(this.stacktrace.substring(pos));
/*  95 */         this.stacktraceHTML = sb.toString();
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*  99 */         this.stacktrace = ("stacktrace not available because: " + t);
/* 100 */         this.stacktraceHTML = ("stacktrace not available because: " + t);
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 106 */       if (caller != null)
/*     */       {
/* 108 */         this.caller = caller.getClass().getName();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 113 */       this.caller = "Could not determine caller";
/*     */     }
/*     */   }
/*     */ 
/*     */   private String exceptionToString()
/*     */   {
/* 122 */     String result = "";
/*     */     try
/*     */     {
/* 126 */       if (this.exceptionName != null)
/*     */       {
/* 128 */         result = this.exceptionName + ": " + this.exceptionMessage;
/* 129 */         if (this.query != null) result = result + " while executing: " + this.query;
/* 130 */         result = result + "\n";
/* 131 */         if (this.stacktrace != null) result = result + this.stacktrace;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 136 */       result = "Could not read exception";
/*     */     }
/*     */ 
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */   private String exceptionToHTML()
/*     */   {
/* 147 */     String result = "";
/*     */     try
/*     */     {
/* 151 */       if (this.exceptionName != null)
/*     */       {
/* 153 */         String url = "http://java.sun.com/products/jdk/1.2/docs/api/" + StringUtil.replaceString(this.exceptionName, ".", "/") + ".html";
/* 154 */         result = "<a href=\"" + url + "\" target=\"new\">" + this.exceptionName + "</a>: " + StringUtil.toHTML(this.exceptionMessage);
/* 155 */         if (this.query != null) result = result + " while executing: " + StringUtil.toHTML(this.query);
/* 156 */         result = result + "\n";
/* 157 */         if (this.stacktraceHTML != null) result = result + this.stacktraceHTML;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 162 */       result = "Could not read exception";
/*     */     }
/*     */ 
/* 165 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 173 */     String EOL = System.getProperty("line.separator");
/* 174 */     String tmp1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(this.date) + " [" + (this.severity < 10 ? " " : "") + this.severity + "] (" + this.threadName + ") " + this.text;
/* 175 */     String tmp2 = exceptionToString();
/* 176 */     String tmp3 = this.caller == null ? "" : this.caller;
/* 177 */     if (tmp1.length() > 0) tmp1 = tmp1 + EOL;
/* 178 */     if (tmp2.length() > 0) tmp2 = tmp2 + EOL;
/* 179 */     if (tmp3.length() > 0) tmp3 = tmp3 + EOL;
/* 180 */     return tmp1 + tmp2 + tmp3;
/*     */   }
/*     */ 
/*     */   public String toHTML()
/*     */   {
/* 197 */     String EOL = "\n";
/* 198 */     String tmp1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(this.date) + " [" + (this.severity < 10 ? " " : "") + this.severity + "] (" + this.threadName + ") " + StringUtil.toHTML(this.text);
/* 199 */     String tmp2 = exceptionToHTML();
/* 200 */     String tmp3 = this.caller == null ? "" : this.caller;
/* 201 */     if (tmp2.length() > 0) tmp2 = "<pre>" + tmp2 + "</pre>";
/* 202 */     if (tmp3.length() > 0) tmp3 = EOL + tmp3;
/*     */ 
/* 204 */     return "<font color=\"" + color[this.severity] + "\">" + tmp1 + tmp2 + tmp3 + "</font>" + EOL;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.DiagnosticsMessage
 * JD-Core Version:    0.6.2
 */