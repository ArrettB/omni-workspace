/*    */ package dynamic.util.diagnostics;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Container;
/*    */ import java.awt.Font;
/*    */ import java.awt.Frame;
/*    */ import java.awt.TextArea;
/*    */ import java.awt.TextComponent;
/*    */ import java.awt.Window;
/*    */ import java.awt.event.WindowEvent;
/*    */ import java.awt.event.WindowListener;
/*    */ 
/*    */ class InternalFrame extends Frame
/*    */ {
/*    */   private TextArea t;
/*    */ 
/*    */   public InternalFrame(String name)
/*    */   {
/* 29 */     super(name);
/*    */ 
/* 45 */     this.t = new TextArea("", 16, 80);
/* 46 */     this.t.setEditable(false);
/* 47 */     this.t.setFont(new Font("Courier", 0, 11));
/* 48 */     add("Center", this.t);
/* 49 */     setBounds(0, 0, 640, 360);
/*    */ 
/* 51 */     addWindowListener(new WindowListener() {
/*    */       public void windowOpened(WindowEvent evt) {  } 
/* 53 */       public void windowClosing(WindowEvent evt) { InternalFrame.this.close(); }
/*    */ 
/*    */ 
/*    */       public void windowClosed(WindowEvent evt)
/*    */       {
/*    */       }
/*    */ 
/*    */       public void windowIconified(WindowEvent evt)
/*    */       {
/*    */       }
/*    */ 
/*    */       public void windowDeiconified(WindowEvent evt)
/*    */       {
/*    */       }
/*    */ 
/*    */       public void windowActivated(WindowEvent evt)
/*    */       {
/*    */       }
/*    */ 
/*    */       public void windowDeactivated(WindowEvent evt)
/*    */       {
/*    */       }
/*    */     });
/* 60 */     show();
/*    */   }
/*    */   public void write(String s) {
/* 63 */     this.t.append(s); } 
/* 64 */   public void close() { setVisible(false); dispose();
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.InternalFrame
 * JD-Core Version:    0.6.2
 */