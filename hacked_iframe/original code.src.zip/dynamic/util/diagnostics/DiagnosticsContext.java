/*     */ package dynamic.util.diagnostics;
/*     */ 
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class DiagnosticsContext
/*     */   implements Runnable
/*     */ {
/*  26 */   Vector writers = new Vector();
/*  27 */   Vector sockets = new Vector();
/*  28 */   Vector ports = new Vector();
/*  29 */   ServerSocket serverSocket = null;
/*  30 */   Thread tid = null;
/*  31 */   boolean isShuttingDown = false;
/*     */ 
/*     */   void initialize(Node n)
/*     */     throws Exception
/*     */   {
/*  45 */     if (n == null) return;
/*     */ 
/*  47 */     Element topElement = (Element)n;
/*     */ 
/*  50 */     String path = topElement.getAttribute("sourcePath");
/*  51 */     if ((path != null) && (path.length() > 0))
/*     */     {
/*  53 */       String currentPath = System.getProperty("dynamic.source.path");
/*  54 */       currentPath = StringUtil.appendUnique(currentPath, path, ';');
/*  55 */       Properties p = System.getProperties();
/*  56 */       p.put("dynamic.source.path", currentPath);
/*  57 */       System.setProperties(p);
/*     */     }
/*     */ 
/*  61 */     int level = 15;
/*  62 */     String attr = topElement.getAttribute("level");
/*  63 */     if ((attr != null) && (attr.length() > 0)) level = Integer.parseInt(attr);
/*     */ 
/*  66 */     NodeList list = topElement.getElementsByTagName("diagnosticsStream");
/*  67 */     for (int x = 0; x < list.getLength(); x++)
/*     */     {
/*  69 */       Element element = (Element)list.item(x);
/*  70 */       attr = element.getAttribute("class");
/*  71 */       if ((attr != null) && (attr.length() > 0))
/*     */       {
/*  73 */         Class c = Class.forName(attr);
/*  74 */         attr = element.getAttribute("property");
/*  75 */         OutputStream os = (OutputStream)c.getField(attr).get(null);
/*  76 */         int l = level;
/*  77 */         String tmp = element.getAttribute("level");
/*  78 */         if ((tmp != null) && (tmp.length() > 0)) l = Integer.parseInt(tmp);
/*  79 */         registerStream(os, l);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  84 */     list = topElement.getElementsByTagName("diagnosticsFile");
/*  85 */     for (int x = 0; x < list.getLength(); x++)
/*     */     {
/*  87 */       Element element = (Element)list.item(x);
/*  88 */       attr = element.getAttribute("path");
/*  89 */       if ((attr != null) && (attr.length() > 0))
/*     */       {
/*  91 */         OutputStream os = new FileOutputStream(attr, true);
/*  92 */         int l = level;
/*  93 */         String tmp = element.getAttribute("level");
/*  94 */         if ((tmp != null) && (tmp.length() > 0)) l = Integer.parseInt(tmp);
/*  95 */         registerStream(os, l);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 100 */     list = topElement.getElementsByTagName("diagnosticsListener");
/* 101 */     for (int x = 0; x < list.getLength(); x++)
/*     */     {
/* 103 */       Element element = (Element)list.item(x);
/* 104 */       String name = element.getAttribute("name");
/* 105 */       attr = element.getAttribute("class");
/* 106 */       if ((attr != null) && (attr.length() > 0))
/*     */       {
/* 108 */         Class c = Class.forName(attr);
/* 109 */         Constructor construct = c.getConstructor(new Class[] { name.getClass() });
/* 110 */         OutputStream os = null;
/* 111 */         if (construct != null) os = (OutputStream)construct.newInstance(new Object[] { name }); else
/* 112 */           os = (OutputStream)c.newInstance();
/* 113 */         int l = level;
/* 114 */         String tmp = element.getAttribute("level");
/* 115 */         if ((tmp != null) && (tmp.length() > 0)) l = Integer.parseInt(tmp);
/* 116 */         registerStream(os, l);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 122 */     list = topElement.getElementsByTagName("diagnosticsMailer");
/* 123 */     for (int x = 0; x < list.getLength(); x++)
/*     */     {
/* 125 */       Element element = (Element)list.item(x);
/* 126 */       String host = element.getAttribute("host");
/* 127 */       if ((host == null) || (host.length() == 0)) throw new Exception("Missing required attribute \"host\" on diagnosticsMailer");
/* 128 */       String port = element.getAttribute("port");
/* 129 */       if ((port == null) || (port.length() == 0)) port = "25";
/* 130 */       String to = element.getAttribute("to");
/* 131 */       if ((to == null) || (to.length() == 0)) throw new Exception("Missing required attribute \"to\" on diagnosticsMailer");
/* 132 */       String from = element.getAttribute("from");
/* 133 */       if ((from == null) || (from.length() == 0)) throw new Exception("Missing required attribute \"from\" on diagnosticsMailer");
/* 134 */       int l = level;
/* 135 */       String tmp = element.getAttribute("level");
/* 136 */       if ((tmp != null) && (tmp.length() > 0)) l = Integer.parseInt(tmp);
/* 137 */       registerWriter(new DiagnosticsWriter(host, port, to, from, l));
/*     */     }
/*     */ 
/* 141 */     String ports = topElement.getAttribute("port");
/* 142 */     setPorts(ports);
/*     */ 
/* 144 */     start();
/*     */   }
/*     */ 
/*     */   synchronized void destroy()
/*     */   {
/* 152 */     stop();
/* 153 */     this.isShuttingDown = true;
/* 154 */     closeSockets();
/* 155 */     if (this.writers != null)
/*     */     {
/* 157 */       for (int i = 0; i < this.writers.size(); i++)
/*     */       {
/* 159 */         DiagnosticsWriter w = (DiagnosticsWriter)this.writers.elementAt(i);
/* 160 */         w.close();
/*     */       }
/*     */ 
/* 163 */       this.writers.removeAllElements();
/* 164 */       this.writers = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void registerStream(OutputStream newStream, int level)
/*     */   {
/* 173 */     this.writers.addElement(new DiagnosticsWriter(newStream, level));
/*     */   }
/*     */ 
/*     */   synchronized void registerWriter(DiagnosticsWriter writer)
/*     */   {
/* 181 */     if (this.writers.contains(writer)) return;
/* 182 */     this.writers.addElement(writer);
/*     */   }
/*     */ 
/*     */   private void setPorts(String port_string)
/*     */   {
/* 191 */     this.ports.removeAllElements();
/* 192 */     if ((port_string == null) || (port_string.length() == 0)) return;
/*     */ 
/* 194 */     Vector tmp_ports = StringUtil.stringToVector(port_string, ',');
/* 195 */     for (int i = 0; i < tmp_ports.size(); i++)
/*     */     {
/* 197 */       Vector low_high = StringUtil.stringToVector((String)tmp_ports.elementAt(i), '-');
/* 198 */       if (low_high.size() == 1)
/*     */       {
/* 200 */         this.ports.addElement(new Integer((String)low_high.elementAt(0)));
/*     */       }
/*     */       else
/*     */       {
/* 204 */         int low = Integer.parseInt((String)low_high.elementAt(0));
/* 205 */         int high = Integer.parseInt((String)low_high.elementAt(1));
/* 206 */         for (int j = low; j <= high; j++)
/*     */         {
/* 208 */           this.ports.addElement(new Integer(j));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   synchronized void write(DiagnosticsMessage msg)
/*     */   {
/* 219 */     if ((this.writers == null) || (this.writers.size() == 0))
/*     */     {
/* 221 */       System.err.print("# " + msg.toString());
/* 222 */       return;
/*     */     }
/*     */ 
/* 225 */     for (int i = this.writers.size() - 1; i >= 0; i--)
/*     */     {
/*     */       try
/*     */       {
/* 229 */         DiagnosticsWriter w = (DiagnosticsWriter)this.writers.elementAt(i);
/* 230 */         w.write(msg);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 234 */         this.writers.removeElementAt(i);
/* 235 */         System.err.println("! " + msg + "\n" + e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   int getPort()
/*     */   {
/* 242 */     if (this.serverSocket == null) return 0;
/* 243 */     return this.serverSocket.getLocalPort();
/*     */   }
/*     */ 
/*     */   private void start()
/*     */   {
/* 248 */     if (this.ports.size() == 0) return;
/* 249 */     this.tid = new Thread(this, "DiagnosticsListener");
/* 250 */     this.tid.setDaemon(true);
/* 251 */     this.tid.setPriority(1);
/* 252 */     Diagnostics.registerThread(this.tid, this);
/* 253 */     this.tid.start();
/*     */   }
/*     */ 
/*     */   private void stop()
/*     */   {
/* 258 */     if (this.tid == null) return;
/* 259 */     Thread temp = this.tid;
/* 260 */     this.tid = null;
/* 261 */     if (temp != Thread.currentThread()) temp.interrupt();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 268 */       boolean found = false;
/* 269 */       Exception lastException = null;
/*     */ 
/* 271 */       for (int i = 0; i < this.ports.size(); i++)
/*     */       {
/*     */         try
/*     */         {
/* 275 */           int port = ((Integer)this.ports.elementAt(i)).intValue();
/* 276 */           this.serverSocket = new ServerSocket(port);
/* 277 */           found = true;
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 282 */           lastException = e;
/*     */         }
/*     */       }
/*     */ 
/* 286 */       if (found)
/*     */       {
/* 288 */         Diagnostics.trace("Diagnostics listening on port " + getPort());
/* 289 */         Thread thisThread = Thread.currentThread();
/* 290 */         while (thisThread == this.tid)
/*     */         {
/* 292 */           Socket socket = this.serverSocket.accept();
/* 293 */           Diagnostics.trace("Diagnostics connection request from " + socket.getInetAddress() + ":" + socket.getPort());
/* 294 */           OutputStream out = socket.getOutputStream();
/* 295 */           registerStream(new ObjectOutputStream(out), 15);
/* 296 */           this.sockets.addElement(socket);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 301 */         Diagnostics.error("Diagnostics could find no ports to listen on", lastException);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 306 */       if (!this.isShuttingDown)
/* 307 */         Diagnostics.error("DiagnosticsContext.run() aborting due to exception", e);
/*     */     }
/*     */     finally
/*     */     {
/* 311 */       closeSockets();
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized void closeSockets()
/*     */   {
/* 317 */     if (this.serverSocket != null)
/*     */     {
/*     */       try
/*     */       {
/* 321 */         this.serverSocket.close();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 325 */         Diagnostics.error("Problems shutting down server socket: " + this.serverSocket, e);
/*     */       }
/* 327 */       this.serverSocket = null;
/*     */     }
/*     */ 
/* 330 */     if (this.sockets != null)
/*     */     {
/* 332 */       for (int i = 0; i < this.sockets.size(); i++)
/*     */       {
/* 334 */         Socket s = (Socket)this.sockets.elementAt(i);
/*     */         try
/*     */         {
/* 337 */           s.close();
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 341 */           Diagnostics.error("Problems shutting down socket: " + s, e);
/*     */         }
/*     */       }
/* 344 */       this.sockets.removeAllElements();
/* 345 */       this.sockets = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.DiagnosticsContext
 * JD-Core Version:    0.6.2
 */