/*     */ package dynamic.util.diagnostics;
/*     */ 
/*     */ import dynamic.util.mail.MailSender;
/*     */ import dynamic.util.threads.BlockingQueue;
/*     */ import dynamic.util.threads.BlockingQueue.Closed;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class DiagnosticsWriter
/*     */   implements Runnable
/*     */ {
/*     */   BlockingQueue queue;
/*     */   OutputStream stream;
/*     */   String host;
/*     */   String port;
/*     */   String to;
/*     */   String from;
/*  25 */   int level = 15;
/*     */   Thread tid;
/*     */ 
/*     */   DiagnosticsWriter(OutputStream stream, int level)
/*     */   {
/*  33 */     this.stream = stream;
/*  34 */     this.level = level;
/*     */   }
/*     */ 
/*     */   DiagnosticsWriter(String host, String port, String to, String from, int level)
/*     */   {
/*  39 */     this.host = host;
/*  40 */     this.port = port;
/*  41 */     this.to = to;
/*  42 */     this.from = from;
/*  43 */     this.level = level;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/*  51 */     if (getClass() != o.getClass()) return false;
/*  52 */     DiagnosticsWriter dw = (DiagnosticsWriter)o;
/*  53 */     if (this.stream != null) return this.stream == dw.stream;
/*  54 */     if (this.to != null) return this.to == dw.to;
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   synchronized void write(DiagnosticsMessage msg)
/*     */     throws Exception
/*     */   {
/*  63 */     if (this.tid == null) start();
/*  64 */     this.queue.enqueue(msg);
/*     */   }
/*     */ 
/*     */   void start()
/*     */   {
/*  69 */     this.queue = new BlockingQueue();
/*  70 */     this.tid = new Thread(this, "DiagnosticsWriter");
/*  71 */     this.tid.setDaemon(true);
/*  72 */     this.tid.setPriority(1);
/*  73 */     this.tid.start();
/*     */   }
/*     */ 
/*     */   void stop()
/*     */   {
/*  78 */     if (this.tid == null) return;
/*  79 */     Thread temp = this.tid;
/*  80 */     this.tid = null;
/*  81 */     if (temp != Thread.currentThread()) temp.interrupt();
/*  82 */     this.queue.close();
/*  83 */     this.queue = null;
/*     */   }
/*     */ 
/*     */   void close()
/*     */   {
/*  88 */     stop();
/*     */     try
/*     */     {
/*  92 */       if ((this.stream != null) && (this.stream != System.out) && (this.stream != System.err))
/*  93 */         this.stream.close();
/*  94 */       this.stream = null;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  98 */       Diagnostics.error("Problem shutting down stream: " + this.stream, e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 104 */     while (this.tid == Thread.currentThread())
/*     */     {
/* 106 */       DiagnosticsMessage msg = null;
/*     */       try
/*     */       {
/* 110 */         msg = (DiagnosticsMessage)this.queue.dequeue();
/* 111 */         if (msg.severity <= this.level)
/*     */         {
/* 113 */           if (this.stream == null)
/*     */           {
/* 115 */             MailSender ms = new MailSender(this.to, this.from, msg.text, new Date(), msg.toHTML());
/* 116 */             ms.setServerInfo(this.host, this.port);
/* 117 */             ms.setContentType("text/html; charset=us-ascii");
/* 118 */             ms.send();
/*     */           }
/* 120 */           else if ((this.stream instanceof ObjectOutputStream))
/*     */           {
/* 122 */             ObjectOutputStream oos = (ObjectOutputStream)this.stream;
/* 123 */             oos.writeObject(msg);
/* 124 */             oos.flush();
/* 125 */             oos.reset();
/*     */           }
/*     */           else
/*     */           {
/* 129 */             this.stream.write(msg.toString().getBytes());
/* 130 */             this.stream.flush();
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (BlockingQueue.Closed c)
/*     */       {
/* 136 */         stop();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 140 */         if (msg != null) System.err.println("! " + msg);
/* 141 */         e.printStackTrace(System.err);
/* 142 */         stop();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.DiagnosticsWriter
 * JD-Core Version:    0.6.2
 */