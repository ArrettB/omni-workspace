/*     */ package dynamic.util.diagnostics;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Assertion
/*     */ {
/*  16 */   private static Hashtable fileMap = new Hashtable();
/*  17 */   private static Vector sourceLocations = new Vector();
/*  18 */   private static String padding = "                                                      ";
/*  19 */   private static String lineString = "-------------------------------------------------------------------------------";
/*  20 */   private static String headerOne = "Fully-qualified class name                        Method Name";
/*  21 */   private static String headerTwo = "File Name           Ln#  Code";
/*  22 */   private static PrintWriter dest = new PrintWriter(System.err, true);
/*  23 */   private static boolean useDiagnosticClass = false;
/*     */ 
/*  25 */   public static boolean ENABLED = true;
/*     */ 
/*     */   public static void addSourceLocation(String s)
/*     */   {
/*  39 */     sourceLocations.addElement(s);
/*     */   }
/*     */ 
/*     */   public static void setDestintation(OutputStream os)
/*     */   {
/*  50 */     if (os == null) os = System.err;
/*  51 */     dest = new PrintWriter(os, true);
/*     */   }
/*     */ 
/*     */   public static void enable(boolean b)
/*     */   {
/*  60 */     ENABLED = b;
/*     */   }
/*     */ 
/*     */   public static void enable()
/*     */   {
/*  67 */     enable(true);
/*     */   }
/*     */ 
/*     */   public static void disable()
/*     */   {
/*  74 */     enable(false);
/*     */   }
/*     */ 
/*     */   public static void jdMethod_assert(boolean expr)
/*     */   {
/*  82 */     if ((ENABLED) && (!expr)) {
/*  83 */       dest.println("Assertion Failed");
/*  84 */       ByteArrayOutputStream fooStream = new ByteArrayOutputStream();
/*     */ 
/*  86 */       new Exception().printStackTrace(new PrintWriter(fooStream, true));
/*  87 */       String stackString = fooStream.toString();
/*  88 */       StringTokenizer stackStrTok = new StringTokenizer(stackString, "\n");
/*     */ 
/*  90 */       String t = stackStrTok.nextToken();
/*  91 */       Diagnostics.debug(t + " Exception");
/*     */ 
/*  93 */       t = stackStrTok.nextToken();
/*  94 */       Diagnostics.debug(t + " Reference");
/*     */ 
/*  96 */       t = stackStrTok.nextToken();
/*  97 */       Diagnostics.debug(t + " Reference");
/*     */ 
/* 100 */       dest.println(lineString);
/* 101 */       dest.println(headerOne);
/* 102 */       dest.println(headerTwo);
/* 103 */       dest.println(lineString);
/*     */ 
/* 105 */       while (stackStrTok.hasMoreTokens())
/*     */         try {
/* 107 */           t = stackStrTok.nextToken().trim();
/*     */ 
/* 109 */           StringTokenizer entryStrTok = new StringTokenizer(t);
/* 110 */           String foo = entryStrTok.nextToken(" ");
/* 111 */           String cm = entryStrTok.nextToken("(").trim();
/* 112 */           String className = cm.substring(0, cm.lastIndexOf("."));
/* 113 */           String methodName = cm.substring(cm.lastIndexOf(".") + 1);
/*     */ 
/* 115 */           dest.println(pad(className, 50) + pad(methodName, 25));
/* 116 */           if (t.endsWith("(Compiled Code)"))
/*     */           {
/* 118 */             dest.println("<Inside Compiled Code>");
/*     */           }
/*     */           else
/*     */           {
/* 122 */             String sourceFile = entryStrTok.nextToken(":").substring(1);
/* 123 */             String lineNumber = entryStrTok.nextToken(")").substring(1);
/* 124 */             String sourcePath = findClassSourceFile(className, sourceFile);
/* 125 */             showLine(className, sourceFile, Integer.parseInt(lineNumber));
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 131 */           Diagnostics.error("Exception raised in the stack crawl", e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String findClassSourceFile(String className, String baseName)
/*     */   {
/* 146 */     if (fileMap.containsKey(className)) return (String)fileMap.get(className);
/*     */ 
/* 148 */     String packageName = className.substring(0, className.lastIndexOf("."));
/* 149 */     Diagnostics.debug(packageName);
/* 150 */     String path = packageName.replace('.', File.separatorChar) + File.separator + baseName;
/* 151 */     Diagnostics.debug(path);
/*     */ 
/* 153 */     for (int i = 0; i < sourceLocations.size(); i++) {
/* 154 */       String testPath = (String)sourceLocations.elementAt(i) + path;
/* 155 */       Diagnostics.debug(testPath);
/*     */ 
/* 157 */       if (new File(testPath).exists()) {
/* 158 */         fileMap.put(className, testPath);
/* 159 */         Diagnostics.debug(fileMap.toString());
/* 160 */         return testPath;
/*     */       }
/*     */     }
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   private static void showLine(String className, String baseName, int line)
/*     */   {
/*     */     try
/*     */     {
/* 174 */       String path = findClassSourceFile(className, baseName);
/* 175 */       if (path == null) return;
/* 176 */       BufferedReader dis = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
/* 177 */       String foo = null;
/* 178 */       for (int i = 0; i < line; i++) {
/* 179 */         foo = dis.readLine();
/*     */       }
/* 181 */       dest.println(pad(baseName.substring(0, baseName.lastIndexOf(".")), 20) + pad(Integer.toString(line), 5) + pad(foo.trim(), 54));
/* 182 */       dis.close();
/*     */     } catch (Exception e) {
/* 184 */       Diagnostics.error("Exception raised in Assertion.showLine()", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String pad(String s, int p)
/*     */   {
/* 195 */     if (s.length() > p) return s.substring(0, p);
/* 196 */     if (s.length() < p) return s + padding.substring(0, p - s.length());
/* 197 */     return s;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.Assertion
 * JD-Core Version:    0.6.2
 */