/*    */ package dynamic.util.diagnostics;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class WindowedOutputStream extends OutputStream
/*    */ {
/* 14 */   private InternalFrame f = null;
/*    */ 
/* 15 */   public WindowedOutputStream() { this.f = new InternalFrame(""); } 
/* 16 */   public WindowedOutputStream(String name) { this.f = new InternalFrame(name); } 
/* 17 */   public void close() { this.f.close(); } 
/* 18 */   public void write(byte[] b) { this.f.write(new String(b)); } 
/* 19 */   public void write(byte[] b, int off, int len) { this.f.write(new String(b, off, len)); } 
/* 20 */   public void write(int b) { char[] c = { (char)(b & 0xFFFFFF00) }; this.f.write(new String(c));
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.diagnostics.WindowedOutputStream
 * JD-Core Version:    0.6.2
 */