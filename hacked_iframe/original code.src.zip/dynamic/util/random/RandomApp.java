/*     */ package dynamic.util.random;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class RandomApp
/*     */ {
/*  37 */   static String[] generators = { "ranmar", "ranecu", "ranlux", "randomjava", "null" };
/*  38 */   static String[] distributions = { "flat", "gaussian" };
/*     */ 
/*  40 */   static int RANMAR = 0; static int RANECU = 1; static int RANLUX = 2; static int RANJAVA = 3; static int NULL = 4;
/*  41 */   static int FLAT = 0; static int GAUSSIAN = 1;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  51 */     boolean seeded = false; boolean gselected = false; boolean dselected = false;
/*  52 */     boolean noprint = false; boolean numbered = false;
/*  53 */     boolean luxuryset = false;
/*     */ 
/*  55 */     int generator = RANMAR;
/*  56 */     int distribution = FLAT;
/*  57 */     long seed = RandomSeedable.ClockSeed();
/*  58 */     int luxury = 3;
/*  59 */     int n = 1;
/*     */ 
/*  64 */     for (int i = 0; i < args.length; i++)
/*     */     {
/*  66 */       String a = new String(args[i]);
/*  67 */       a.toLowerCase();
/*     */ 
/*  69 */       if (a.compareTo("noprint") == 0) {
/*  70 */         noprint = true;
/*     */       }
/*  74 */       else if (a.compareTo("seed") == 0) {
/*  75 */         if (seeded)
/*  76 */           die("RandomApp: only one seed can be passed");
/*  77 */         if (i == args.length - 1) {
/*  78 */           die("RandomApp: missing seed.");
/*     */         }
/*  80 */         i++;
/*  81 */         a = new String(args[i]);
/*     */         try {
/*  83 */           seed = Long.parseLong(a);
/*     */         } catch (NumberFormatException ex) {
/*  85 */           die("RandomApp: seed is not a valid number.");
/*     */         }
/*  87 */         seeded = true;
/*     */       }
/*  91 */       else if (a.compareTo("luxury") == 0) {
/*  92 */         if (luxuryset)
/*  93 */           die("RandomApp: only one luxury level can be passed");
/*  94 */         if (i == args.length - 1) {
/*  95 */           die("RandomApp: missing luxury level.");
/*     */         }
/*  97 */         i++;
/*  98 */         a = new String(args[i]);
/*     */         try {
/* 100 */           luxury = Integer.parseInt(a);
/*     */         } catch (NumberFormatException ex) {
/* 102 */           die("RandomApp: luxury level is not a valid number.");
/*     */         }
/* 104 */         luxuryset = true;
/*     */ 
/* 106 */         if ((luxury < 0) || (luxury > 4)) {
/* 107 */           die("RandomApp: luxury level must be between 0 and 4");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 112 */         for (int j = 0; j < generators.length; j++) {
/* 113 */           if (a.compareTo(generators[j]) == 0)
/*     */           {
/* 115 */             if (gselected)
/* 116 */               die("RandomApp: only one generator can be selected.");
/* 117 */             generator = j;
/* 118 */             gselected = true;
/* 119 */             break;
/*     */           }
/*     */         }
/* 122 */         for (j = 0; j < distributions.length; j++) {
/* 123 */           if (a.compareTo(distributions[j]) == 0)
/*     */           {
/* 125 */             if (dselected)
/* 126 */               die("RandomApp: only one distribution can be selected.");
/* 127 */             distribution = j;
/* 128 */             dselected = true;
/* 129 */             break;
/*     */           }
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/* 135 */           n = Integer.parseInt(a);
/* 136 */           if (numbered)
/* 137 */             die("RandomApp: only one number of random numbers can be selected.");
/* 138 */           numbered = true;
/*     */         } catch (NumberFormatException ex) {
/* 140 */           die("RandomApp: syntax error <" + a + ">");
/*     */         }
/*     */       }
/*     */     }
/* 144 */     RandomElement e = null;
/*     */ 
/* 146 */     if (generator == RANMAR)
/*     */     {
/* 148 */       e = new Ranmar(seed);
/* 149 */     } else if (generator == RANECU)
/*     */     {
/* 151 */       e = new Ranecu(seed);
/* 152 */     } else if (generator == RANLUX)
/*     */     {
/* 154 */       e = new Ranlux(luxury, seed);
/* 155 */     } else if (generator == RANJAVA)
/*     */     {
/* 157 */       e = new RandomJava();
/*     */     }
/*     */ 
/* 160 */     for (i = 1; i <= n; i++)
/*     */     {
/*     */       double x;
/* 162 */       if (distribution == FLAT)
/*     */       {
/* 164 */         if (generator != NULL) x = e.raw(); else {
/* 165 */           x = 0.0D;
/*     */         }
/*     */ 
/*     */       }
/* 169 */       else if (generator != NULL) x = e.gaussian(); else {
/* 170 */         x = 0.0D;
/*     */       }
/*     */ 
/* 174 */       if (!noprint) Diagnostics.debug(" " + x);
/*     */     }
/*     */   }
/*     */ 
/*     */   static void die(String s)
/*     */   {
/* 181 */     System.err.println(s);
/* 182 */     System.exit(-1);
/*     */   }
/*     */ 
/*     */   static double nullgen() {
/* 186 */     return 0.0D;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.RandomApp
 * JD-Core Version:    0.6.2
 */