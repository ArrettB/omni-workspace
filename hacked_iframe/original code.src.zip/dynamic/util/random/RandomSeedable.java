/*    */ package dynamic.util.random;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public abstract class RandomSeedable extends RandomElement
/*    */ {
/*    */   public static long ClockSeed(Date d)
/*    */   {
/* 61 */     return d.getTime();
/*    */   }
/*    */ 
/*    */   public static long ClockSeed()
/*    */   {
/* 75 */     return ClockSeed(new Date());
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.RandomSeedable
 * JD-Core Version:    0.6.2
 */