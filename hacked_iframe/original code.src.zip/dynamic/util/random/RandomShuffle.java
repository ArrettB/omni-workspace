/*    */ package dynamic.util.random;
/*    */ 
/*    */ public class RandomShuffle extends RandomElement
/*    */ {
/*    */   RandomElement generatorA;
/*    */   RandomElement generatorB;
/*    */   int decksize;
/*    */   double[] deck;
/*    */ 
/*    */   public RandomShuffle(RandomElement ga, RandomElement gb, int ds)
/*    */   {
/* 52 */     this.generatorA = ga;
/* 53 */     this.generatorB = gb;
/* 54 */     this.decksize = ds;
/*    */ 
/* 56 */     stackdeck();
/*    */   }
/*    */ 
/*    */   public double raw()
/*    */   {
/* 70 */     int i = this.generatorB.choose(0, this.decksize - 1);
/* 71 */     double random = this.deck[i];
/* 72 */     this.deck[i] = this.generatorA.raw();
/*    */ 
/* 74 */     return random;
/*    */   }
/*    */ 
/*    */   private void stackdeck()
/*    */   {
/* 80 */     this.deck = new double[this.decksize];
/*    */ 
/* 82 */     for (int i = 0; i < this.decksize; i++)
/* 83 */       this.deck[i] = this.generatorA.raw();
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.RandomShuffle
 * JD-Core Version:    0.6.2
 */