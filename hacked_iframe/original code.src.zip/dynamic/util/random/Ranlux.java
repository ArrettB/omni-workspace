/*     */ package dynamic.util.random;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Ranlux extends RandomSeedable
/*     */ {
/*     */   public static final int maxlev = 4;
/*     */   public static final int lxdflt = 3;
/*     */   static final int igiga = 1000000000;
/*     */   static final int jsdflt = 314159265;
/*     */   static final int twop12 = 4096;
/*     */   static final int itwo24 = 16777216;
/*     */   static final int icons = 2147483563;
/* 106 */   static final int[] ndskip = { 0, 24, 73, 199, 365 };
/*     */   int[] iseeds;
/*     */   int[] isdext;
/*     */   int[] next;
/* 109 */   int luxlev = 3;
/*     */   int nskip;
/*     */   int inseed;
/*     */   int jseed;
/* 110 */   int in24 = 0; int kount = 0; int mkount = 0; int i24 = 24; int j24 = 10;
/*     */   float[] seeds;
/* 111 */   float carry = 0.0F;
/*     */   float twom24;
/*     */   float twom12;
/* 113 */   boolean diagOn = false;
/*     */ 
/*     */   public Ranlux()
/*     */   {
/* 123 */     init_arrays();
/* 124 */     rluxdef();
/*     */   }
/*     */ 
/*     */   public Ranlux(int lux, int ins)
/*     */   {
/* 138 */     init_arrays();
/* 139 */     rluxgo(lux, Math.abs(ins));
/*     */   }
/*     */ 
/*     */   public Ranlux(int lux, long ins)
/*     */   {
/* 153 */     init_arrays();
/* 154 */     rluxgo(lux, Math.abs((int)(ins % 2147483647L)));
/*     */   }
/*     */ 
/*     */   public Ranlux(int ins)
/*     */   {
/* 166 */     init_arrays();
/* 167 */     rluxgo(3, Math.abs(ins));
/*     */   }
/*     */ 
/*     */   public Ranlux(long ins)
/*     */   {
/* 179 */     init_arrays();
/* 180 */     rluxgo(3, Math.abs((int)(ins % 2147483647L)));
/*     */   }
/*     */ 
/*     */   public Ranlux(int lux, Date d)
/*     */   {
/* 199 */     init_arrays();
/* 200 */     rluxgo(lux, (int)(RandomSeedable.ClockSeed(d) % 2147483647L));
/*     */   }
/*     */ 
/*     */   public Ranlux(Date d)
/*     */   {
/* 218 */     init_arrays();
/* 219 */     rluxgo(3, (int)(RandomSeedable.ClockSeed(d) % 2147483647L));
/*     */   }
/*     */ 
/*     */   public void setDiag(boolean b)
/*     */   {
/* 231 */     this.diagOn = b;
/*     */   }
/*     */ 
/*     */   public final double raw()
/*     */   {
/* 246 */     float uni = this.seeds[this.j24] - this.seeds[this.i24] - this.carry;
/* 247 */     if (uni < 0.0F) {
/* 248 */       uni += 1.0F;
/* 249 */       this.carry = this.twom24; } else {
/* 250 */       this.carry = 0.0F;
/*     */     }
/* 252 */     this.seeds[this.i24] = uni;
/*     */ 
/* 254 */     this.i24 = this.next[this.i24];
/* 255 */     this.j24 = this.next[this.j24];
/*     */ 
/* 257 */     float out = uni;
/*     */ 
/* 259 */     if (uni < this.twom12) {
/* 260 */       out += this.twom24 * this.seeds[this.j24];
/*     */     }
/*     */ 
/* 264 */     if (out == 0.0D) out = this.twom24 * this.twom24;
/*     */ 
/* 266 */     this.in24 += 1;
/*     */ 
/* 268 */     if (this.in24 == 24) {
/* 269 */       this.in24 = 0;
/* 270 */       this.kount += this.nskip;
/* 271 */       for (int i = 1; i <= this.nskip; i++) {
/* 272 */         uni = this.seeds[this.j24] - this.seeds[this.i24] - this.carry;
/* 273 */         if (uni < 0.0F) {
/* 274 */           uni += 1.0F;
/* 275 */           this.carry = this.twom24; } else {
/* 276 */           this.carry = 0.0F;
/*     */         }
/* 278 */         this.seeds[this.i24] = uni;
/*     */ 
/* 280 */         this.i24 = this.next[this.i24];
/* 281 */         this.j24 = this.next[this.j24];
/*     */       }
/*     */     }
/*     */ 
/* 285 */     this.kount += 1;
/* 286 */     if (this.kount >= 1000000000) {
/* 287 */       this.mkount += 1;
/* 288 */       this.kount -= 1000000000;
/*     */     }
/*     */ 
/* 291 */     return out;
/*     */   }
/*     */ 
/*     */   private void init_arrays()
/*     */   {
/* 305 */     this.iseeds = new int[25];
/* 306 */     this.isdext = new int[26];
/* 307 */     this.next = new int[25];
/* 308 */     this.seeds = new float[25];
/*     */   }
/*     */ 
/*     */   private void rluxdef()
/*     */   {
/* 316 */     this.jseed = 314159265;
/* 317 */     this.inseed = this.jseed;
/* 318 */     diag("RANLUX DEFAULT INITIALIZATION: " + this.jseed);
/* 319 */     this.luxlev = 3;
/* 320 */     this.nskip = ndskip[this.luxlev];
/* 321 */     int lp = this.nskip + 24;
/* 322 */     this.in24 = 0;
/* 323 */     this.kount = 0;
/* 324 */     this.mkount = 0;
/* 325 */     diag("RANLUX DEFAULT LUXURY LEVEL =  " + this.luxlev + "    p = " + lp);
/* 326 */     this.twom24 = 1.0F;
/*     */ 
/* 328 */     for (int i = 1; i <= 24; i++)
/*     */     {
/* 330 */       this.twom24 *= 0.5F;
/* 331 */       int k = this.jseed / 53668;
/* 332 */       this.jseed = (40014 * (this.jseed - k * 53668) - k * 12211);
/* 333 */       if (this.jseed < 0) this.jseed += 2147483563;
/* 334 */       this.iseeds[i] = (this.jseed % 16777216);
/*     */     }
/*     */ 
/* 337 */     this.twom12 = (this.twom24 * 4096.0F);
/*     */ 
/* 339 */     for (i = 1; i <= 24; i++)
/*     */     {
/* 341 */       this.seeds[i] = (this.iseeds[i] * this.twom24);
/* 342 */       this.next[i] = (i - 1);
/*     */     }
/*     */ 
/* 345 */     this.next[1] = 24;
/* 346 */     this.i24 = 24;
/* 347 */     this.j24 = 10;
/* 348 */     this.carry = 0.0F;
/* 349 */     if (this.seeds[24] == 0.0D) this.carry = this.twom24;
/*     */   }
/*     */ 
/*     */   private final void rluxgo(int lux, int ins)
/*     */   {
/* 358 */     if (lux < 0)
/*     */     {
/* 360 */       this.luxlev = 3;
/*     */     }
/* 362 */     else if (lux <= 4)
/*     */     {
/* 364 */       this.luxlev = lux;
/*     */     }
/* 366 */     else if ((lux < 24) || (lux > 2000))
/*     */     {
/* 368 */       this.luxlev = 4;
/* 369 */       diag("RANLUX ILLEGAL LUXURY RLUXGO: " + lux);
/*     */     }
/*     */     else {
/* 372 */       this.luxlev = lux;
/* 373 */       for (int ilx = 0; ilx <= 4; ilx++) {
/* 374 */         if (lux == ndskip[ilx] + 24) {
/* 375 */           this.luxlev = ilx;
/*     */         }
/*     */       }
/*     */     }
/* 379 */     if (this.luxlev <= 4) {
/* 380 */       this.nskip = ndskip[this.luxlev];
/* 381 */       diag("RANLUX LUXURY LEVEL SET BY RLUXGO : " + this.luxlev + " P= " + (this.nskip + 24));
/*     */     } else {
/* 383 */       this.nskip = (this.luxlev - 24);
/* 384 */       diag("RANLUX P-VALUE SET BY RLUXGO TO: " + this.luxlev);
/*     */     }
/*     */ 
/* 387 */     this.in24 = 0;
/*     */ 
/* 389 */     if (ins < 0) {
/* 390 */       diag("Illegal initialization by RLUXGO, negative input seed");
/*     */     }
/* 392 */     if (ins > 0) {
/* 393 */       this.jseed = ins;
/* 394 */       diag("RANLUX INITIALIZED BY RLUXGO FROM SEED " + this.jseed);
/*     */     }
/*     */     else
/*     */     {
/* 398 */       this.jseed = 314159265;
/* 399 */       diag("RANLUX INITIALIZED BY RLUXGO FROM DEFAULT SEED");
/*     */     }
/*     */ 
/* 402 */     this.inseed = this.jseed;
/* 403 */     this.twom24 = 1.0F;
/*     */ 
/* 405 */     for (int i = 1; i <= 24; i++) {
/* 406 */       this.twom24 *= 0.5F;
/* 407 */       int k = this.jseed / 53668;
/* 408 */       this.jseed = (40014 * (this.jseed - k * 53668) - k * 12211);
/* 409 */       if (this.jseed < 0) this.jseed += 2147483563;
/* 410 */       this.iseeds[i] = (this.jseed % 16777216);
/*     */     }
/*     */ 
/* 413 */     this.twom12 = (this.twom24 * 4096.0F);
/*     */ 
/* 415 */     for (i = 1; i <= 24; i++) {
/* 416 */       this.seeds[i] = (this.iseeds[i] * this.twom24);
/* 417 */       this.next[i] = (i - 1);
/*     */     }
/*     */ 
/* 420 */     this.next[1] = 24;
/* 421 */     this.i24 = 24;
/* 422 */     this.j24 = 10;
/* 423 */     this.carry = 0.0F;
/*     */ 
/* 425 */     if (this.seeds[24] == 0.0D) this.carry = this.twom24;
/*     */ 
/* 427 */     this.kount = 0;
/* 428 */     this.mkount = 0;
/*     */   }
/*     */ 
/*     */   private void diag(String s)
/*     */   {
/* 434 */     if (this.diagOn)
/* 435 */       System.err.println(s);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.Ranlux
 * JD-Core Version:    0.6.2
 */