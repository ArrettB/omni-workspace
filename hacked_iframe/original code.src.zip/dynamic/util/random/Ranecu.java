/*     */ package dynamic.util.random;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Ranecu extends RandomSeedable
/*     */ {
/*     */   int iseed1;
/*     */   int iseed2;
/*  41 */   public static int DEFSEED1 = 12345;
/*     */ 
/*  47 */   public static int DEFSEED2 = 67890;
/*     */ 
/*     */   public Ranecu()
/*     */   {
/*  57 */     this.iseed1 = DEFSEED1;
/*  58 */     this.iseed2 = DEFSEED2;
/*     */   }
/*     */ 
/*     */   public Ranecu(int s1, int s2)
/*     */   {
/*  75 */     this.iseed1 = s1;
/*  76 */     this.iseed2 = s2;
/*     */   }
/*     */ 
/*     */   public Ranecu(long l)
/*     */   {
/*  88 */     this.iseed1 = ((int)l / 2147483647);
/*  89 */     this.iseed2 = ((int)l % 2147483647);
/*     */   }
/*     */ 
/*     */   public Ranecu(Date d)
/*     */   {
/* 109 */     this.iseed1 = ((int)d.getTime() / 2147483647);
/* 110 */     this.iseed2 = ((int)d.getTime() % 2147483647);
/*     */   }
/*     */ 
/*     */   public final double raw()
/*     */   {
/* 122 */     int k = this.iseed1 / 53688;
/* 123 */     this.iseed1 = (40014 * (this.iseed1 - k * 53668) - k * 12211);
/* 124 */     if (this.iseed1 < 0) this.iseed1 += 2147483563;
/*     */ 
/* 126 */     k = this.iseed2 / 52774;
/* 127 */     this.iseed2 = (40692 * (this.iseed2 - k * 52774) - k * 3791);
/* 128 */     if (this.iseed2 < 0) this.iseed2 += 2147483399;
/*     */ 
/* 130 */     int iz = this.iseed1 - this.iseed2;
/* 131 */     if (iz < 1) iz += 2147483562;
/*     */ 
/* 133 */     return iz * 4.656613E-10D;
/*     */   }
/*     */ 
/*     */   public final void raw(double[] d, int n)
/*     */   {
/* 145 */     for (int i = 0; i < n; i++)
/*     */     {
/* 148 */       int k = this.iseed1 / 53688;
/* 149 */       this.iseed1 = (40014 * (this.iseed1 - k * 53668) - k * 12211);
/* 150 */       if (this.iseed1 < 0) this.iseed1 += 2147483563;
/*     */ 
/* 152 */       k = this.iseed2 / 52774;
/* 153 */       this.iseed2 = (40692 * (this.iseed2 - k * 52774) - k * 3791);
/* 154 */       if (this.iseed2 < 0) this.iseed2 += 2147483399;
/*     */ 
/* 156 */       int iz = this.iseed1 - this.iseed2;
/* 157 */       if (iz < 1) iz += 2147483562;
/*     */ 
/* 159 */       d[i] = (iz * 4.656613E-10D);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getSeed()
/*     */   {
/* 171 */     return this.iseed1 * 2147483647L + this.iseed2;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.Ranecu
 * JD-Core Version:    0.6.2
 */