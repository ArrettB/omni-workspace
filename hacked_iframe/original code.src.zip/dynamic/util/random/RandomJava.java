/*    */ package dynamic.util.random;
/*    */ 
/*    */ public class RandomJava extends RandomElement
/*    */ {
/*    */   public double raw()
/*    */   {
/* 42 */     return Math.random();
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.RandomJava
 * JD-Core Version:    0.6.2
 */