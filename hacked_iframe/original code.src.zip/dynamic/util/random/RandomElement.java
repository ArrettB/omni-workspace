/*     */ package dynamic.util.random;
/*     */ 
/*     */ public abstract class RandomElement
/*     */ {
/*     */   Double BMoutput;
/*     */ 
/*     */   public abstract double raw();
/*     */ 
/*     */   public void raw(double[] d, int n)
/*     */   {
/*  58 */     for (int i = 0; i < n; i++)
/*  59 */       d[i] = raw();
/*     */   }
/*     */ 
/*     */   public void raw(double[] d)
/*     */   {
/*  73 */     raw(d, d.length);
/*     */   }
/*     */ 
/*     */   public int choose(int hi)
/*     */   {
/*  82 */     return (int)(1.0D + hi * raw());
/*     */   }
/*     */ 
/*     */   public int choose(int lo, int hi)
/*     */   {
/*  93 */     return (int)(lo + (hi - lo + 1) * raw());
/*     */   }
/*     */ 
/*     */   public double uniform(double lo, double hi)
/*     */   {
/* 102 */     return lo + (hi - lo) * raw();
/*     */   }
/*     */ 
/*     */   public double gaussian()
/*     */   {
/* 118 */     if (this.BMoutput != null)
/*     */     {
/* 120 */       double out = this.BMoutput.doubleValue();
/* 121 */       this.BMoutput = null;
/* 122 */       return out; } double x;
/*     */     double y;
/*     */     double r;
/*     */     do { x = uniform(-1.0D, 1.0D);
/* 127 */       y = uniform(-1.0D, 1.0D);
/* 128 */       r = x * x + y * y; }
/* 129 */     while (r >= 1.0D);
/*     */ 
/* 131 */     double z = Math.sqrt(-2.0D * Math.log(r) / r);
/* 132 */     this.BMoutput = new Double(x * z);
/* 133 */     return y * z;
/*     */   }
/*     */ 
/*     */   public double gaussian(double sd)
/*     */   {
/* 144 */     return gaussian() * sd;
/*     */   }
/*     */ 
/*     */   public double powlaw(double alpha, double cut)
/*     */   {
/* 162 */     return cut * Math.pow(raw(), 1.0D / (alpha + 1.0D));
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.RandomElement
 * JD-Core Version:    0.6.2
 */