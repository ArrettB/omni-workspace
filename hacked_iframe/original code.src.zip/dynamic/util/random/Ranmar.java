/*     */ package dynamic.util.random;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Ranmar extends RandomSeedable
/*     */ {
/*     */   double c;
/*     */   double cd;
/*     */   double cm;
/*     */   double[] u;
/*     */   double[] uvec;
/*     */   int i97;
/*     */   int j97;
/*  45 */   public static int DEFSEED = 54217137;
/*     */ 
/*  55 */   public static int BIG_PRIME = 899999963;
/*     */ 
/*     */   public Ranmar(int ijkl)
/*     */   {
/*  68 */     ranmarin(Math.abs(ijkl % BIG_PRIME));
/*     */   }
/*     */ 
/*     */   public Ranmar(long ijkl)
/*     */   {
/*  82 */     ranmarin((int)Math.abs(ijkl % BIG_PRIME));
/*     */   }
/*     */ 
/*     */   public Ranmar()
/*     */   {
/*  96 */     ranmarin(DEFSEED);
/*     */   }
/*     */ 
/*     */   public Ranmar(Date d)
/*     */   {
/* 113 */     ranmarin((int)RandomSeedable.ClockSeed(d) % BIG_PRIME);
/*     */   }
/*     */ 
/*     */   void ranmarin(int ijkl)
/*     */   {
/* 130 */     this.u = new double[97];
/* 131 */     this.uvec = new double[97];
/*     */ 
/* 134 */     int ij = ijkl / 30082;
/* 135 */     int kl = ijkl - 30082 * ij;
/*     */ 
/* 137 */     int i = ij / 177 % 177 + 2;
/* 138 */     int j = ij % 177 + 2;
/* 139 */     int k = kl / 169 % 178 + 1;
/* 140 */     int l = kl % 169;
/* 141 */     for (int ii = 0; ii < 97; ii++)
/*     */     {
/* 143 */       double s = 0.0D;
/* 144 */       double t = 0.5D;
/* 145 */       for (int jj = 0; jj < 24; jj++)
/*     */       {
/* 147 */         int m = i * j % 179 * k % 179;
/* 148 */         i = j;
/* 149 */         j = k;
/* 150 */         k = m;
/* 151 */         l = (53 * l + 1) % 169;
/* 152 */         if (l * m % 64 >= 32) s += t;
/* 153 */         t *= 0.5D;
/*     */       }
/* 155 */       this.u[ii] = s;
/*     */     }
/* 157 */     this.c = 0.02160286903381348D;
/* 158 */     this.cd = 0.4562330842018127D;
/* 159 */     this.cm = 0.9999998211860657D;
/* 160 */     this.i97 = 96;
/* 161 */     this.j97 = 32;
/*     */   }
/*     */ 
/*     */   public final double raw()
/*     */   {
/* 174 */     double uni = this.u[this.i97] - this.u[this.j97];
/* 175 */     if (uni < 0.0D) uni += 1.0D;
/* 176 */     this.u[this.i97] = uni;
/* 177 */     if (--this.i97 < 0) this.i97 = 96;
/* 178 */     if (--this.j97 < 0) this.j97 = 96;
/* 179 */     this.c -= this.cd;
/* 180 */     if (this.c < 0.0D) this.c += this.cm;
/* 181 */     uni -= this.c;
/* 182 */     if (uni < 0.0D) uni += 1.0D;
/* 183 */     return uni;
/*     */   }
/*     */ 
/*     */   public final void raw(double[] d, int n)
/*     */   {
/* 199 */     for (int i = 0; i < n; i++)
/*     */     {
/* 201 */       double uni = this.u[this.i97] - this.u[this.j97];
/* 202 */       if (uni < 0.0D) uni += 1.0D;
/* 203 */       this.u[this.i97] = uni;
/* 204 */       if (--this.i97 < 0) this.i97 = 96;
/* 205 */       if (--this.j97 < 0) this.j97 = 96;
/* 206 */       this.c -= this.cd;
/* 207 */       if (this.c < 0.0D) this.c += this.cm;
/* 208 */       uni -= this.c;
/* 209 */       if (uni < 0.0D) uni += 1.0D;
/* 210 */       d[i] = uni;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.random.Ranmar
 * JD-Core Version:    0.6.2
 */