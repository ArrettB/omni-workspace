/*     */ package dynamic.util.xml;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.Vector;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public final class XMLUtils
/*     */ {
/*     */   public static Document parse(InputSource source)
/*     */     throws ParserConfigurationException, SAXException, IOException
/*     */   {
/*  47 */     DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
/*  48 */     DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
/*  49 */     Document d = docBuilder.parse(source);
/*  50 */     Element e = d.getDocumentElement();
/*     */     try
/*     */     {
/*  53 */       e.normalize();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  57 */       Diagnostics.error("Problem normalizing XML", t);
/*     */     }
/*  59 */     return d;
/*     */   }
/*     */ 
/*     */   public static Document parse(String uri)
/*     */     throws ParserConfigurationException, SAXException, IOException
/*     */   {
/*  71 */     return parse(new InputSource(uri));
/*     */   }
/*     */ 
/*     */   public static Document parse(File file)
/*     */     throws IllegalArgumentException, ParserConfigurationException, SAXException, IOException
/*     */   {
/*  83 */     if (file == null) {
/*  84 */       throw new IllegalArgumentException("File cannot be null");
/*     */     }
/*     */ 
/*  87 */     String uri = "file:" + file.getAbsolutePath();
/*  88 */     if (File.separatorChar == '\\') {
/*  89 */       uri = uri.replace('\\', '/');
/*     */     }
/*     */ 
/*  92 */     return parse(uri);
/*     */   }
/*     */ 
/*     */   public static String getEnclosedText(Node n)
/*     */   {
/* 103 */     StringBuffer result = new StringBuffer();
/* 104 */     String value = n.getNodeValue();
/* 105 */     if (value != null)
/*     */     {
/* 107 */       result.append(value);
/*     */     }
/* 109 */     NodeList children = n.getChildNodes();
/* 110 */     for (int i = 0; i < children.getLength(); i++)
/*     */     {
/* 112 */       Node child = children.item(i);
/* 113 */       result.append(getEnclosedText(child));
/*     */     }
/* 115 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static Element getSingleElement(Node n, String name)
/*     */     throws Exception
/*     */   {
/* 127 */     NodeList nl = getElementsByTagName(n, name);
/* 128 */     if (nl == null) return null;
/* 129 */     if (nl.getLength() > 1) throw new Exception("Got " + nl.getLength() + " elements named " + name);
/* 130 */     return (Element)nl.item(0);
/*     */   }
/*     */ 
/*     */   public static NodeList getElementsByTagName(Node n, String name)
/*     */   {
/* 141 */     NodeList nl = null;
/*     */ 
/* 143 */     if ((n instanceof Document))
/*     */     {
/* 145 */       nl = ((Document)n).getElementsByTagName(name);
/*     */     }
/* 147 */     else if ((n instanceof Element))
/*     */     {
/* 149 */       nl = ((Element)n).getElementsByTagName(name);
/*     */     }
/*     */     else
/*     */     {
/* 153 */       nl = new NodeList() {
/*     */         public int getLength() {
/* 155 */           return 0; } 
/* 156 */         public Node item(int i) { return null; }
/*     */ 
/*     */       };
/*     */     }
/* 160 */     return nl;
/*     */   }
/*     */ 
/*     */   public static String getValue(Node n, String name)
/*     */     throws Exception
/*     */   {
/* 184 */     String path = null;
/* 185 */     String attr = null;
/* 186 */     String value = "";
/*     */ 
/* 189 */     int index = name.indexOf(":");
/* 190 */     if (index != -1)
/*     */     {
/* 192 */       path = name.substring(0, index);
/* 193 */       attr = name.substring(index + 1);
/*     */     }
/*     */     else
/*     */     {
/* 197 */       path = name;
/*     */     }
/*     */ 
/* 200 */     Vector pathNames = StringUtil.stringToVector(path, '/');
/* 201 */     for (int i = 0; i < pathNames.size(); i++)
/*     */     {
/* 203 */       String node = (String)pathNames.elementAt(i);
/* 204 */       if ((node != null) && (node.length() > 0)) {
/* 205 */         n = getSingleElement(n, node);
/*     */       }
/*     */     }
/* 208 */     if (n == null) return value;
/*     */ 
/* 210 */     if ((attr != null) && (attr.length() > 0))
/* 211 */       value = ((Element)n).getAttribute(attr);
/*     */     else {
/* 213 */       value = getEnclosedText(n);
/*     */     }
/* 215 */     return value;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 225 */       String config = "<test><foo attrib=\"bar\">enclosed text</foo></test>";
/* 226 */       Document d = parse(new InputSource(new StringReader(config)));
/* 227 */       Diagnostics.debug("=" + getValue(d, ""));
/* 228 */       Diagnostics.debug(":attrib=" + getValue(d, ":attrib"));
/* 229 */       Diagnostics.debug("test=" + getValue(d, "test"));
/* 230 */       Diagnostics.debug("test:attrib=" + getValue(d, "test:attrib"));
/* 231 */       Diagnostics.debug("test/foo=" + getValue(d, "test/foo"));
/* 232 */       Diagnostics.debug("test/foo:attrib=" + getValue(d, "test/foo:attrib"));
/* 233 */       Diagnostics.debug("foo=" + getValue(d, "foo"));
/* 234 */       Diagnostics.debug("foo:attrib=" + getValue(d, "foo:attrib"));
/* 235 */       System.exit(0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 239 */       Diagnostics.error("Problem", e);
/* 240 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.xml.XMLUtils
 * JD-Core Version:    0.6.2
 */