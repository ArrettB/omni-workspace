/*     */ package dynamic.util.cache;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ public class Cache extends Hashtable
/*     */ {
/*     */   private int cacheSize;
/*  17 */   CacheRecord head = null;
/*  18 */   CacheRecord tail = null;
/*  19 */   Hashtable list = new Hashtable();
/*     */ 
/*     */   public Cache()
/*     */   {
/*  23 */     this(-1);
/*     */   }
/*     */ 
/*     */   public Cache(int cacheSize)
/*     */   {
/*  28 */     super(cacheSize);
/*  29 */     this.cacheSize = cacheSize;
/*     */   }
/*     */ 
/*     */   public synchronized void clear()
/*     */   {
/*  49 */     this.list.clear();
/*  50 */     super.clear();
/*     */   }
/*     */ 
/*     */   public synchronized Object get(Object key)
/*     */   {
/*  64 */     if (this.cacheSize == 0) return null;
/*  65 */     if (this.cacheSize == -1) return super.get(key);
/*     */ 
/*  67 */     CacheRecord cr = deleteFromList(key);
/*  68 */     if (cr == null) return null;
/*     */ 
/*  70 */     addToHead(cr);
/*     */ 
/*  72 */     return super.get(key);
/*     */   }
/*     */ 
/*     */   public synchronized Object put(Object key, Object value)
/*     */   {
/*  91 */     if (this.cacheSize == 0) return null;
/*  92 */     if (this.cacheSize == -1) return super.put(key, value);
/*     */ 
/*  94 */     CacheRecord cr = deleteFromList(key);
/*  95 */     if (cr == null)
/*     */     {
/*  97 */       cr = new CacheRecord(key);
/*  98 */       this.list.put(key, cr);
/*  99 */       if (this.list.size() > this.cacheSize) remove(this.tail.key);
/*     */     }
/* 101 */     addToHead(cr);
/*     */ 
/* 103 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */   public synchronized Object remove(Object key)
/*     */   {
/* 116 */     if (this.cacheSize == 0) return null;
/* 117 */     if (this.cacheSize == -1) return super.remove(key);
/*     */ 
/* 119 */     deleteFromList(key);
/*     */ 
/* 121 */     this.list.remove(key);
/* 122 */     return super.remove(key);
/*     */   }
/*     */ 
/*     */   private synchronized CacheRecord deleteFromList(Object key)
/*     */   {
/* 130 */     CacheRecord cr = (CacheRecord)this.list.get(key);
/* 131 */     if (cr == null) return null;
/*     */ 
/* 133 */     if ((cr != this.head) && (cr != this.tail))
/*     */     {
/* 135 */       cr.prev.next = cr.next;
/* 136 */       cr.next.prev = cr.prev;
/*     */     }
/* 138 */     else if ((cr == this.tail) && (cr != this.head))
/*     */     {
/* 140 */       cr.prev.next = null;
/* 141 */       this.tail = cr.prev;
/*     */     }
/* 143 */     else if ((cr != this.tail) && (cr == this.head))
/*     */     {
/* 145 */       cr.next.prev = null;
/* 146 */       this.head = cr.next;
/*     */     }
/*     */     else
/*     */     {
/* 150 */       this.head = null;
/* 151 */       this.tail = null;
/*     */     }
/* 153 */     return cr;
/*     */   }
/*     */ 
/*     */   private synchronized void addToHead(CacheRecord cr)
/*     */   {
/* 161 */     if (this.head != null) this.head.prev = cr;
/* 162 */     cr.next = this.head;
/* 163 */     cr.prev = null;
/* 164 */     this.head = cr;
/* 165 */     if (this.tail == null) this.tail = cr;
/*     */   }
/*     */ 
/*     */   public class CacheRecord
/*     */   {
/*  34 */     public CacheRecord prev = null;
/*  35 */     public CacheRecord next = null;
/*     */     public Object key;
/*     */ 
/*     */     public CacheRecord(Object key)
/*     */     {
/*  40 */       this.key = key;
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.cache.Cache
 * JD-Core Version:    0.6.2
 */