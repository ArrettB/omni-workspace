/*    */ package dynamic.util.performance;
/*    */ 
/*    */ import dynamic.util.date.StdDate;
/*    */ 
/*    */ public class Stopwatch
/*    */   implements Cloneable
/*    */ {
/*  7 */   protected String name = "";
/*  8 */   protected long when = 0L;
/*  9 */   protected long elapsed = 0L;
/* 10 */   protected long count = 0L;
/* 11 */   protected long total = 0L;
/* 12 */   protected long avg = 0L;
/*    */ 
/*    */   public Stopwatch()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Stopwatch(String name)
/*    */   {
/* 20 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public Object clone() throws CloneNotSupportedException
/*    */   {
/* 25 */     return super.clone();
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 30 */     return this.name;
/*    */   }
/*    */ 
/*    */   public long getCount()
/*    */   {
/* 35 */     return this.count;
/*    */   }
/*    */ 
/*    */   public String getInterval()
/*    */   {
/* 40 */     return StdDate.formatDateInterval(this.avg);
/*    */   }
/*    */ 
/*    */   public StdDate getDate()
/*    */   {
/* 45 */     return new StdDate(this.when);
/*    */   }
/*    */ 
/*    */   public void start()
/*    */   {
/* 50 */     this.when = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   public long split()
/*    */   {
/* 55 */     return System.currentTimeMillis() - this.when;
/*    */   }
/*    */ 
/*    */   public synchronized long stop()
/*    */   {
/* 60 */     this.elapsed = (System.currentTimeMillis() - this.when);
/* 61 */     add(this.elapsed);
/* 62 */     return this.elapsed;
/*    */   }
/*    */ 
/*    */   public synchronized void add(long elapsed)
/*    */   {
/* 67 */     this.count += 1L;
/* 68 */     this.total += elapsed;
/* 69 */     this.avg = (this.total / this.count);
/*    */   }
/*    */ 
/*    */   public synchronized void add(Stopwatch s)
/*    */   {
/* 74 */     this.count += s.count;
/* 75 */     this.total += s.total;
/* 76 */     this.avg = (this.total / this.count);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o)
/*    */   {
/* 81 */     if (o == null)
/*    */     {
/* 83 */       return false;
/*    */     }
/* 85 */     if (o == this)
/*    */     {
/* 87 */       return true;
/*    */     }
/* 89 */     if ((o instanceof Stopwatch))
/*    */     {
/* 91 */       return ((Stopwatch)o).name.equals(this.name);
/*    */     }
/*    */ 
/* 95 */     return false;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.performance.Stopwatch
 * JD-Core Version:    0.6.2
 */