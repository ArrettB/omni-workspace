/*    */ package dynamic.util.performance;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class StopwatchList extends Vector
/*    */ {
/*  7 */   public static int TYPE_MAX = 1;
/*  8 */   public static int TYPE_MIN = 2;
/*  9 */   public static int TYPE_LAST = 3;
/*    */ 
/* 11 */   protected int type = TYPE_MAX;
/*    */ 
/*    */   public StopwatchList()
/*    */   {
/* 15 */     this(TYPE_MAX, 10);
/*    */   }
/*    */ 
/*    */   public StopwatchList(int type, int capacity)
/*    */   {
/* 20 */     super(capacity + 1);
/* 21 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public synchronized void addStopwatch(Stopwatch s)
/*    */   {
/* 26 */     int i = indexOf(s, 0);
/* 27 */     if (i >= 0)
/*    */     {
/* 29 */       Stopwatch o = (Stopwatch)this.elementData[i];
/* 30 */       removeElementAt(i);
/*    */       try { s = (Stopwatch)s.clone(); } catch (Exception e) {
/* 32 */       }s.add(o);
/*    */     }
/*    */ 
/* 35 */     if (this.type == TYPE_MAX)
/*    */     {
/* 37 */       if (this.elementCount == this.elementData.length - 1)
/*    */       {
/* 39 */         Stopwatch x = (Stopwatch)this.elementData[(this.elementCount - 1)];
/* 40 */         if (s.avg < x.avg) return;
/*    */       }
/* 42 */       for (i = 0; i < this.elementCount + 1; i++)
/*    */       {
/* 44 */         Stopwatch x = (Stopwatch)this.elementData[i];
/* 45 */         if ((x == null) || (s.avg >= x.avg))
/*    */         {
/* 47 */           insertElementAt(s, i);
/* 48 */           break;
/*    */         }
/*    */       }
/*    */     }
/* 52 */     else if (this.type == TYPE_MIN)
/*    */     {
/* 54 */       if (this.elementCount == this.elementData.length - 1)
/*    */       {
/* 56 */         Stopwatch x = (Stopwatch)this.elementData[(this.elementCount - 1)];
/* 57 */         if (s.avg > x.avg) return;
/*    */       }
/* 59 */       for (i = 0; i < this.elementCount + 1; i++)
/*    */       {
/* 61 */         Stopwatch x = (Stopwatch)this.elementData[i];
/* 62 */         if ((x == null) || (s.avg <= x.avg))
/*    */         {
/* 64 */           insertElementAt(s, i);
/* 65 */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 71 */       insertElementAt(s, 0);
/*    */     }
/*    */ 
/* 75 */     if (this.elementCount == this.elementData.length)
/*    */     {
/* 77 */       this.elementData[(--this.elementCount)] = null;
/*    */     }
/*    */   }
/*    */ 
/*    */   public Stopwatch getStopwatch(int index)
/*    */   {
/* 83 */     return (Stopwatch)elementAt(index);
/*    */   }
/*    */ 
/*    */   public Stopwatch getStopwatch(String name)
/*    */   {
/* 88 */     for (int i = 0; i < this.elementCount; i++)
/*    */     {
/* 90 */       Stopwatch s = (Stopwatch)this.elementData[i];
/* 91 */       if (s.getName().equals(name)) {
/* 92 */         return s;
/*    */       }
/*    */     }
/* 95 */     return null;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.performance.StopwatchList
 * JD-Core Version:    0.6.2
 */