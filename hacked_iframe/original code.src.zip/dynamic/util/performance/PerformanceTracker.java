/*     */ package dynamic.util.performance;
/*     */ 
/*     */ import dynamic.util.date.StdDate;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class PerformanceTracker
/*     */   implements Cloneable
/*     */ {
/*   9 */   protected long createdTime = 0L;
/*  10 */   protected long loadedTime = 0L;
/*  11 */   protected long requestCount = 0L;
/*  12 */   protected long totalTime = 0L;
/*  13 */   protected int last_size = 1;
/*  14 */   protected int min_size = 1;
/*  15 */   protected int max_size = 1;
/*  16 */   protected StopwatchList last = null;
/*  17 */   protected StopwatchList min = null;
/*  18 */   protected StopwatchList max = null;
/*  19 */   protected Hashtable stopwatches = new Hashtable();
/*     */ 
/*     */   public PerformanceTracker()
/*     */   {
/*  23 */     this(1);
/*     */   }
/*     */ 
/*     */   public PerformanceTracker(int size)
/*     */   {
/*  28 */     this(size, size, size);
/*     */   }
/*     */ 
/*     */   public PerformanceTracker(int last_size, int min_size, int max_size)
/*     */   {
/*  33 */     this.last_size = last_size;
/*  34 */     this.min_size = min_size;
/*  35 */     this.max_size = max_size;
/*  36 */     reload();
/*  37 */     this.createdTime = this.loadedTime;
/*     */   }
/*     */ 
/*     */   public synchronized Object clone() throws CloneNotSupportedException
/*     */   {
/*  42 */     PerformanceTracker s = (PerformanceTracker)super.clone();
/*  43 */     s.reload();
/*  44 */     return s;
/*     */   }
/*     */ 
/*     */   public synchronized void reload()
/*     */   {
/*  49 */     this.loadedTime = System.currentTimeMillis();
/*  50 */     clear();
/*     */   }
/*     */ 
/*     */   public synchronized void clear()
/*     */   {
/*  55 */     this.stopwatches = new Hashtable();
/*  56 */     this.requestCount = 0L;
/*  57 */     this.totalTime = 0L;
/*  58 */     this.last = new StopwatchList(StopwatchList.TYPE_LAST, this.last_size);
/*  59 */     this.min = new StopwatchList(StopwatchList.TYPE_MIN, this.min_size);
/*  60 */     this.max = new StopwatchList(StopwatchList.TYPE_MAX, this.max_size);
/*     */   }
/*     */ 
/*     */   public Stopwatch start(String event)
/*     */   {
/*  65 */     Stopwatch s = new Stopwatch(event);
/*  66 */     s.start();
/*  67 */     this.stopwatches.put(Thread.currentThread(), s);
/*  68 */     return s;
/*     */   }
/*     */ 
/*     */   public long split(String event)
/*     */   {
/*  73 */     Stopwatch s = (Stopwatch)this.stopwatches.get(Thread.currentThread());
/*  74 */     if (s == null) return 0L;
/*  75 */     return s.split();
/*     */   }
/*     */ 
/*     */   public synchronized long stop(String event)
/*     */   {
/*  80 */     Stopwatch s = (Stopwatch)this.stopwatches.get(Thread.currentThread());
/*  81 */     if (s == null) return 0L;
/*  82 */     s.stop();
/*  83 */     this.stopwatches.remove(Thread.currentThread());
/*     */ 
/*  85 */     this.last.addStopwatch(s);
/*  86 */     this.min.addStopwatch(s);
/*  87 */     this.max.addStopwatch(s);
/*  88 */     this.requestCount += 1L;
/*  89 */     this.totalTime += s.elapsed;
/*     */ 
/*  91 */     return s.elapsed;
/*     */   }
/*     */ 
/*     */   public StdDate getCreatedTime()
/*     */   {
/*  96 */     return new StdDate(this.createdTime);
/*     */   }
/*     */ 
/*     */   public StdDate getLoadedTime()
/*     */   {
/* 101 */     return new StdDate(this.loadedTime);
/*     */   }
/*     */ 
/*     */   public long getRequestCount()
/*     */   {
/* 106 */     return this.requestCount;
/*     */   }
/*     */ 
/*     */   public long getConcurrentRequestCount()
/*     */   {
/* 111 */     return this.stopwatches.size();
/*     */   }
/*     */ 
/*     */   public String getTotalTime()
/*     */   {
/* 116 */     return StdDate.formatDateInterval(this.totalTime);
/*     */   }
/*     */ 
/*     */   public String getAverageInterval()
/*     */   {
/* 121 */     if (this.requestCount == 0L) return "";
/* 122 */     return StdDate.formatDateInterval(this.totalTime / this.requestCount);
/*     */   }
/*     */ 
/*     */   public StopwatchList getLast()
/*     */   {
/* 127 */     return this.last;
/*     */   }
/*     */ 
/*     */   public StopwatchList getMin()
/*     */   {
/* 132 */     return this.min;
/*     */   }
/*     */ 
/*     */   public StopwatchList getMax()
/*     */   {
/* 137 */     return this.max;
/*     */   }
/*     */ 
/*     */   public String getLastInterval()
/*     */   {
/* 142 */     return this.last.size() == 0 ? "" : this.last.getStopwatch(0).getInterval();
/*     */   }
/*     */ 
/*     */   public String getLastEvent()
/*     */   {
/* 147 */     return this.last.size() == 0 ? "" : this.last.getStopwatch(0).getName();
/*     */   }
/*     */ 
/*     */   public StdDate getLastDate()
/*     */   {
/* 152 */     return this.last.size() == 0 ? new StdDate(0L) : this.last.getStopwatch(0).getDate();
/*     */   }
/*     */ 
/*     */   public String getMinInterval()
/*     */   {
/* 157 */     return this.min.size() == 0 ? "" : this.min.getStopwatch(0).getInterval();
/*     */   }
/*     */ 
/*     */   public String getMinEvent()
/*     */   {
/* 162 */     return this.min.size() == 0 ? "" : this.min.getStopwatch(0).getName();
/*     */   }
/*     */ 
/*     */   public StdDate getMinDate()
/*     */   {
/* 167 */     return this.min.size() == 0 ? new StdDate(0L) : this.min.getStopwatch(0).getDate();
/*     */   }
/*     */ 
/*     */   public String getMaxInterval()
/*     */   {
/* 172 */     return this.max.size() == 0 ? "" : this.max.getStopwatch(0).getInterval();
/*     */   }
/*     */ 
/*     */   public String getMaxEvent()
/*     */   {
/* 177 */     return this.max.size() == 0 ? "" : this.max.getStopwatch(0).getName();
/*     */   }
/*     */ 
/*     */   public StdDate getMaxDate()
/*     */   {
/* 182 */     return this.max.size() == 0 ? new StdDate(0L) : this.max.getStopwatch(0).getDate();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.performance.PerformanceTracker
 * JD-Core Version:    0.6.2
 */