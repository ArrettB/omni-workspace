/*     */ package dynamic.util.mail;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.activation.DataSource;
/*     */ 
/*     */ public class ByteArrayDataSource
/*     */   implements DataSource
/*     */ {
/*     */   private byte[] data;
/*     */   private String type;
/*     */ 
/*     */   public ByteArrayDataSource(InputStream is, String type)
/*     */   {
/*  53 */     this.type = type;
/*     */     try {
/*  55 */       ByteArrayOutputStream os = new ByteArrayOutputStream();
/*     */       int ch;
/*  58 */       while ((ch = is.read()) != -1)
/*     */       {
/*     */         int i;
/*  61 */         os.write(i);
/*  62 */       }this.data = os.toByteArray();
/*     */     }
/*     */     catch (IOException ioex) {
/*     */     }
/*     */   }
/*     */ 
/*     */   public ByteArrayDataSource(byte[] data, String type) {
/*  69 */     this.data = data;
/*  70 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public ByteArrayDataSource(String data, String type)
/*     */   {
/*     */     try
/*     */     {
/*  79 */       this.data = data.getBytes("iso-8859-1"); } catch (UnsupportedEncodingException uex) {
/*     */     }
/*  81 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*  89 */     if (this.data == null)
/*  90 */       throw new IOException("no data");
/*  91 */     return new ByteArrayInputStream(this.data);
/*     */   }
/*     */ 
/*     */   public OutputStream getOutputStream() throws IOException {
/*  95 */     throw new IOException("cannot do this");
/*     */   }
/*     */ 
/*     */   public String getContentType() {
/*  99 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 103 */     return "dummy";
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.mail.ByteArrayDataSource
 * JD-Core Version:    0.6.2
 */