/*     */ package dynamic.util.mail;
/*     */ 
/*     */ import dynamic.util.string.HTML2Text;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.activation.FileDataSource;
/*     */ import javax.activation.URLDataSource;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ 
/*     */ public class MailSender
/*     */   implements Runnable
/*     */ {
/*     */   private String to;
/*     */   private String from;
/*     */   private String subject;
/*     */   private Date date;
/*     */   private String message;
/*     */   private String contentType;
/*     */   private Vector attachments;
/*  55 */   private int port = 25;
/*  56 */   private String host = "mail.dynamic-info.com";
/*  57 */   private Thread tid = null;
/*     */   public static final String DEFAULT_CONTENT_TYPE = "text/plain; charset=us-ascii";
/*     */   public static final String HTML_CONTENT_TYPE = "text/html; charset=us-ascii";
/*     */   public static final String SMTP_DATE_FORMAT = "EEE, dd MMM yyyy HH:mm:ss zzz";
/*     */ 
/*     */   public MailSender(String to, String from, String subj, Date date, String message)
/*     */   {
/*  75 */     this.to = to;
/*  76 */     this.from = from;
/*  77 */     this.subject = subj;
/*  78 */     this.date = date;
/*  79 */     this.message = message;
/*  80 */     this.contentType = "text/plain; charset=us-ascii";
/*  81 */     this.attachments = new Vector();
/*     */   }
/*     */ 
/*     */   public void setContentType(String contentType)
/*     */   {
/*  89 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   public void setServerInfo(String host)
/*     */   {
/*  99 */     if (host != null) this.host = host;
/*     */   }
/*     */ 
/*     */   public void setServerInfo(String host, int port)
/*     */   {
/* 110 */     if (host != null) this.host = host;
/* 111 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public void setServerInfo(String host, String port)
/*     */   {
/* 122 */     if (host != null) this.host = host;
/* 123 */     if (port != null) this.port = Integer.parseInt(port);
/*     */   }
/*     */ 
/*     */   public void addAttachment(File file)
/*     */     throws Exception
/*     */   {
/* 131 */     addAttachment(new FileDataSource(file));
/*     */   }
/*     */ 
/*     */   public void addAttachment(URL url)
/*     */     throws Exception
/*     */   {
/* 139 */     addAttachment(new URLDataSource(url));
/*     */   }
/*     */ 
/*     */   public void addAttachment(DataSource ds)
/*     */     throws Exception
/*     */   {
/* 147 */     this.attachments.addElement(ds);
/*     */   }
/*     */ 
/*     */   public void addAttachment(Object o)
/*     */     throws Exception
/*     */   {
/* 155 */     if (o == null) return;
/* 156 */     if ((o instanceof File)) addAttachment((File)o);
/* 157 */     else if ((o instanceof URL)) addAttachment((URL)o);
/* 158 */     else if ((o instanceof DataSource)) addAttachment((DataSource)o); else
/* 159 */       throw new Exception("Unknown attachment class " + o.getClass().getName());
/*     */   }
/*     */ 
/*     */   public void send()
/*     */     throws Exception
/*     */   {
/* 169 */     Properties props = System.getProperties();
/* 170 */     props.put("mail.smtp.port", "" + this.port);
/* 171 */     props.put("mail.smtp.host", this.host);
/* 172 */     Session session = Session.getDefaultInstance(props, null);
/* 173 */     Message msg = new MimeMessage(session);
/* 174 */     InternetAddress fromAddress = new InternetAddress(this.from);
/* 175 */     msg.setFrom(fromAddress);
/*     */ 
/* 178 */     Vector toVect = StringUtil.stringToVector(this.to);
/* 179 */     for (int i = 0; i < toVect.size(); i++)
/*     */     {
/* 181 */       String temp = ((String)toVect.elementAt(i)).trim();
/* 182 */       if (temp.length() != 0) {
/* 183 */         InternetAddress toAddress = new InternetAddress(temp);
/* 184 */         msg.addRecipient(Message.RecipientType.TO, toAddress);
/*     */       }
/*     */     }
/* 187 */     msg.setSubject(this.subject);
/* 188 */     msg.setSentDate(this.date);
/*     */ 
/* 190 */     Multipart mp = new MimeMultipart();
/*     */ 
/* 192 */     if (this.contentType.equals("text/html; charset=us-ascii"))
/*     */     {
/* 194 */       Multipart mp1 = new MimeMultipart("alternative");
/* 195 */       HTML2Text converter = new HTML2Text();
/* 196 */       MimeBodyPart mbp1 = new MimeBodyPart();
/* 197 */       mbp1.setText(converter.convert(this.message));
/* 198 */       mp1.addBodyPart(mbp1);
/* 199 */       MimeBodyPart mbp2 = new MimeBodyPart();
/* 200 */       mbp2.setDataHandler(new DataHandler(new ByteArrayDataSource(this.message, "text/html")));
/* 201 */       mp1.addBodyPart(mbp2);
/*     */ 
/* 203 */       MimeBodyPart mbp = new MimeBodyPart();
/* 204 */       mbp.setContent(mp1);
/* 205 */       mp.addBodyPart(mbp);
/*     */     }
/*     */     else
/*     */     {
/* 209 */       MimeBodyPart mbp = new MimeBodyPart();
/* 210 */       mbp.setText(this.message);
/* 211 */       mp.addBodyPart(mbp);
/*     */     }
/*     */ 
/* 214 */     if ((this.attachments != null) && (this.attachments.size() > 0))
/*     */     {
/* 216 */       for (int i = 0; i < this.attachments.size(); i++)
/*     */       {
/* 218 */         DataSource ds = (DataSource)this.attachments.elementAt(i);
/* 219 */         String pFileName = ds.getName();
/* 220 */         MimeBodyPart mbp = new MimeBodyPart();
/* 221 */         mbp.setDataHandler(new DataHandler(ds));
/* 222 */         mbp.setFileName(pFileName);
/* 223 */         mp.addBodyPart(mbp);
/*     */       }
/*     */     }
/*     */ 
/* 227 */     msg.setContent(mp);
/* 228 */     Transport.send(msg);
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/* 236 */     this.tid = new Thread(this, "MailSender");
/* 237 */     this.tid.start();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 247 */       send();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 251 */       System.err.println("MailSender: Problem send mail to server " + this.host + ":" + this.port);
/* 252 */       t.printStackTrace(System.err);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*     */     try
/*     */     {
/* 263 */       String message = "<html><body><h1>Test</h1>This is a test of the <b>MailSender</b></body></html>";
/* 264 */       MailSender ms = new MailSender(argv[0], "test@dynamic-info.com", "Test Message", new Date(), message);
/* 265 */       ms.setContentType("text/html; charset=us-ascii");
/* 266 */       if (argv[1] != null) ms.addAttachment(new File(argv[1]));
/* 267 */       ms.send();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 271 */       t.printStackTrace(System.err);
/*     */     }
/*     */     try {
/* 274 */       Thread.sleep(500L);
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.mail.MailSender
 * JD-Core Version:    0.6.2
 */