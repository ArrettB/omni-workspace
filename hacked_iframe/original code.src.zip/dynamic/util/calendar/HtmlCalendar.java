/*      */ package dynamic.util.calendar;
/*      */ 
/*      */ import dynamic.util.diagnostics.Diagnostics;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.Statement;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import javax.servlet.ServletRequest;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ 
/*      */ public class HtmlCalendar
/*      */ {
/*   28 */   private static String HEADERFONT = "Verdana";
/*   29 */   private static String HEADERFONTSIZE = "+1";
/*   30 */   private static String HEADERFONTCOLOR = "WHITE";
/*   31 */   private static String HEADERCOLOR = "#336699";
/*   32 */   private static String LINKCOLOR = "#999999";
/*   33 */   private static String CURRENTLINKCOLOR = "#990000";
/*   34 */   private static String INFOLINKCOLOR = "#336699";
/*   35 */   private static String CALENDARHEADERFONT = "Verdana";
/*   36 */   private static String CALENDARHEADERFONTSIZE = "-1";
/*   37 */   private static String CALENDARHEADERFONTCOLOR = "WHITE";
/*   38 */   private static String CALENDARHEADERCOLOR = "#336699";
/*   39 */   private static String CALENDARLINKCOLOR = "#336699";
/*   40 */   private static String CALENDARCURRENTLINKCOLOR = "#336699";
/*   41 */   private static String HIGHLIGHTCOLOR = "#FFFFCC";
/*   42 */   private static int TIMEFROM = 6;
/*   43 */   private static int TIMETO = 20;
/*   44 */   private static String GOGIF = "/images/go.gif";
/*   45 */   private static String MONTHTABGIF = "/images/monthtab.gif";
/*   46 */   private static String DAYTABGIF = "/images/daytab.gif";
/*   47 */   private static String WEEKTABGIF = "/images/weektab.gif";
/*   48 */   private static String BROWSERIGHTGIF = "/images/browseright.gif";
/*   49 */   private static String BROWSELEFTGIF = "/images/browseleft.gif";
/*      */ 
/*   52 */   private static boolean PROPERTYSET = false;
/*      */ 
/*      */   public static synchronized void setProperties(Properties prop)
/*      */   {
/*   61 */     if (prop.get("HEADERFONT") != null)
/*   62 */       HEADERFONT = (String)prop.get("HEADERFONT");
/*   63 */     if (prop.get("HEADERFONTSIZE") != null)
/*   64 */       HEADERFONTSIZE = (String)prop.get("HEADERFONTSIZE");
/*   65 */     if (prop.get("HEADERFONTCOLOR") != null)
/*   66 */       HEADERFONTCOLOR = (String)prop.get("HEADERFONTCOLOR");
/*   67 */     if (prop.get("HEADERCOLOR") != null)
/*   68 */       HEADERCOLOR = (String)prop.get("HEADERCOLOR");
/*   69 */     if (prop.get("LINKCOLOR") != null)
/*   70 */       LINKCOLOR = (String)prop.get("LINKCOLOR");
/*   71 */     if (prop.get("CURRENTLINKCOLOR") != null)
/*   72 */       CURRENTLINKCOLOR = (String)prop.get("CURRENTLINKCOLOR");
/*   73 */     if (prop.get("INFOLINKCOLOR") != null)
/*   74 */       INFOLINKCOLOR = (String)prop.get("INFOLINKCOLOR");
/*   75 */     if (prop.get("CALENDARHEADERFONT") != null)
/*   76 */       CALENDARHEADERFONT = (String)prop.get("CALENDARHEADERFONT");
/*   77 */     if (prop.get("CALENDARHEADERFONTSIZE") != null)
/*   78 */       CALENDARHEADERFONTSIZE = (String)prop.get("CALENDARHEADERFONTSIZE");
/*   79 */     if (prop.get("CALENDARHEADERFONTCOLOR") != null)
/*   80 */       CALENDARHEADERFONTCOLOR = (String)prop.get("CALENDARHEADERFONTCOLOR");
/*   81 */     if (prop.get("CALENDARHEADERCOLOR") != null)
/*   82 */       CALENDARHEADERCOLOR = (String)prop.get("CALENDARHEADERCOLOR");
/*   83 */     if (prop.get("CALENDARLINKCOLOR") != null)
/*   84 */       CALENDARLINKCOLOR = (String)prop.get("CALENDARLINKCOLOR");
/*   85 */     if (prop.get("CALENDARCURRENTLINKCOLOR") != null)
/*   86 */       CALENDARCURRENTLINKCOLOR = (String)prop.get("CALENDARCURRENTLINKCOLOR");
/*   87 */     if (prop.get("HIGHLIGHTCOLOR") != null)
/*   88 */       HIGHLIGHTCOLOR = (String)prop.get("HIGHLIGHTCOLOR");
/*   89 */     if (prop.get("TIMEFROM") != null)
/*   90 */       TIMEFROM = Integer.parseInt((String)prop.get("TIMEFROM"));
/*   91 */     if (prop.get("TIMETO") != null) {
/*   92 */       TIMETO = Integer.parseInt((String)prop.get("TIMETO"));
/*      */     }
/*   94 */     if (prop.get("GOGIF") != null)
/*   95 */       GOGIF = (String)prop.get("GOGIF");
/*   96 */     if (prop.get("MONTHTABGIF") != null)
/*   97 */       MONTHTABGIF = (String)prop.get("MONTHTABGIF");
/*   98 */     if (prop.get("WEEKTABGIF") != null)
/*   99 */       WEEKTABGIF = (String)prop.get("WEEKTABGIF");
/*  100 */     if (prop.get("DAYTABGIF") != null)
/*  101 */       DAYTABGIF = (String)prop.get("DAYTABGIF");
/*  102 */     if (prop.get("BROWSERIGHTGIF") != null)
/*  103 */       BROWSERIGHTGIF = (String)prop.get("BROWSERIGHTGIF");
/*  104 */     if (prop.get("BROWSELEFTGIF") != null) {
/*  105 */       BROWSELEFTGIF = (String)prop.get("BROWSELEFTGIF");
/*      */     }
/*  107 */     PROPERTYSET = true;
/*      */   }
/*      */ 
/*      */   public static boolean isPropertySet()
/*      */   {
/*  112 */     return PROPERTYSET;
/*      */   }
/*      */ 
/*      */   public String getCalendar(Properties prop) throws HtmlCalendarException
/*      */   {
/*  117 */     StringBuffer sbuff = new StringBuffer();
/*  118 */     getCalendar(prop, sbuff);
/*  119 */     return sbuff.toString();
/*      */   }
/*      */ 
/*      */   public void getCalendar(Properties prop, StringBuffer sbuff)
/*      */     throws HtmlCalendarException
/*      */   {
/*      */     Connection con;
/*      */     try
/*      */     {
/*  137 */       con = (Connection)prop.get("CONNECTION");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  141 */       throw new HtmlCalendarException("CONNECTION");
/*      */     }
/*      */ 
/*  144 */     if (con == null)
/*  145 */       throw new HtmlCalendarException("CONNECTION");
/*      */     String queryHref;
/*      */     try
/*      */     {
/*  149 */       queryHref = (String)prop.get("QUERYHREF");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  153 */       throw new HtmlCalendarException("QUERYHREF");
/*      */     }
/*      */ 
/*  156 */     if (queryHref == null)
/*  157 */       throw new HtmlCalendarException("QUERYHREF");
/*      */     String refHref;
/*      */     try
/*      */     {
/*  161 */       refHref = (String)prop.get("REFERINGHREF");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  165 */       throw new HtmlCalendarException("REFERINGHREF");
/*      */     }
/*  167 */     if (refHref == null)
/*  168 */       throw new HtmlCalendarException("REFERINGHREF");
/*      */     String primarykey;
/*      */     try
/*      */     {
/*  172 */       primarykey = (String)prop.get("PRIMARYKEY");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  176 */       throw new HtmlCalendarException("PRIMARYKEY");
/*      */     }
/*      */ 
/*  179 */     if (primarykey == null)
/*  180 */       throw new HtmlCalendarException("PRIMARYKEY");
/*      */     String description;
/*      */     try
/*      */     {
/*  184 */       description = (String)prop.get("DESCRIPTION");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  188 */       throw new HtmlCalendarException("DESCRIPTION");
/*      */     }
/*      */ 
/*  191 */     if (description == null)
/*  192 */       throw new HtmlCalendarException("DESCRIPTION");
/*      */     String whereclause;
/*      */     try
/*      */     {
/*  196 */       whereclause = (String)prop.get("WHERECLAUSE");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  200 */       throw new HtmlCalendarException("WHERECLAUSE");
/*      */     }
/*      */ 
/*  203 */     if (whereclause == null)
/*  204 */       throw new HtmlCalendarException("WHERECLAUSE");
/*      */     String fromclause;
/*      */     try
/*      */     {
/*  208 */       fromclause = (String)prop.get("FROMCLAUSE");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  212 */       throw new HtmlCalendarException("FROMCLAUSE");
/*      */     }
/*      */ 
/*  215 */     if (fromclause == null)
/*  216 */       throw new HtmlCalendarException("FROMCLAUSE");
/*      */     String dateRange1;
/*      */     try
/*      */     {
/*  220 */       dateRange1 = (String)prop.get("DATERANGE1");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  224 */       throw new HtmlCalendarException("DATERANGE1");
/*      */     }
/*      */ 
/*  227 */     if (dateRange1 == null)
/*  228 */       throw new HtmlCalendarException("DATERANGE1");
/*      */     String dateRange2;
/*      */     try
/*      */     {
/*  232 */       dateRange2 = (String)prop.get("DATERANGE2");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  236 */       throw new HtmlCalendarException("DATERANGE2");
/*      */     }
/*      */ 
/*  239 */     if (dateRange2 == null)
/*  240 */       throw new HtmlCalendarException("DATERANGE2");
/*      */     HttpServletRequest req;
/*      */     try
/*      */     {
/*  244 */       req = (HttpServletRequest)prop.get("REQUEST");
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  248 */       throw new HtmlCalendarException("REQUEST");
/*      */     }
/*      */ 
/*  251 */     if (req == null) {
/*  252 */       throw new HtmlCalendarException("REQUEST");
/*      */     }
/*      */ 
/*  255 */     String state = req.getParameter("state");
/*  256 */     if (state == null) {
/*  257 */       state = (String)prop.get("STATE");
/*      */     }
/*  259 */     if (state == null) {
/*  260 */       state = "0";
/*      */     }
/*  262 */     String gotodate = req.getParameter("gotodate");
/*      */ 
/*  265 */     Calendar cal = Calendar.getInstance();
/*  266 */     String year = req.getParameter("year");
/*      */ 
/*  268 */     if (year != null)
/*      */     {
/*      */       try
/*      */       {
/*  272 */         int iyear = Integer.parseInt(year);
/*  273 */         int imonth = Integer.parseInt(req.getParameter("month"));
/*  274 */         if (req.getParameter("gotodate") != null) {
/*  275 */           imonth--;
/*      */         }
/*  277 */         int day = Integer.parseInt(req.getParameter("day"));
/*  278 */         String flag = req.getParameter("flag");
/*  279 */         cal.set(iyear, imonth, day);
/*  280 */         if ((flag != null) && (flag.equalsIgnoreCase("-1")))
/*      */         {
/*  282 */           cal.add(2, -1);
/*      */         }
/*  284 */         else if ((flag != null) && (flag.equalsIgnoreCase("1")))
/*      */         {
/*  286 */           cal.add(2, 1);
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  291 */         Diagnostics.error("Problem in HtmlCalendar.getCalendar", e);
/*      */       }
/*      */     }
/*      */ 
/*  295 */     int hyyear = cal.get(1);
/*  296 */     int hymonth = cal.get(2);
/*  297 */     int hyday = cal.get(5);
/*      */ 
/*  299 */     sbuff.append("<table width=100%>");
/*  300 */     sbuff.append("<tr valign=top>");
/*  301 */     sbuff.append("<td>");
/*  302 */     sbuff.append("&nbsp");
/*  303 */     sbuff.append("</td>");
/*  304 */     sbuff.append("<td>");
/*  305 */     sbuff.append("\t\t<table cellpadding=0 cellspacing=0 border=0>\t");
/*  306 */     sbuff.append("\t\t<tr>");
/*  307 */     sbuff.append("\t\t<td valign=top>");
/*  308 */     String temp = "&";
/*  309 */     if (refHref.indexOf("?") == -1)
/*      */     {
/*  311 */       temp = "?";
/*      */     }
/*      */ 
/*  314 */     sbuff.append("\t\t\t\t\t<a href=\"" + refHref + "" + temp + "state=0&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=" + DAYTABGIF + " border=0></a>");
/*  315 */     sbuff.append("\t\t</td>");
/*  316 */     sbuff.append("\t\t<td valign=top>");
/*  317 */     sbuff.append("\t\t\t\t    <a href=\"" + refHref + "" + temp + "state=1&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=" + WEEKTABGIF + " border=0></a>");
/*  318 */     sbuff.append("\t\t</td>");
/*  319 */     sbuff.append("\t\t<td valign=top>");
/*  320 */     sbuff.append("\t\t\t\t    <a href=\"" + refHref + "" + temp + "state=2&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=" + MONTHTABGIF + " border=0></a>");
/*      */ 
/*  322 */     sbuff.append("\t\t</td>");
/*  323 */     sbuff.append("\t\t</tr>");
/*  324 */     sbuff.append("\t\t");
/*  325 */     sbuff.append("\t\t</table>");
/*  326 */     sbuff.append("</td>");
/*  327 */     sbuff.append("</tr>");
/*  328 */     sbuff.append("<tr valign=top>");
/*  329 */     sbuff.append("<td>");
/*  330 */     if (refHref.indexOf("?") == -1)
/*  331 */       refHref = refHref + "?";
/*      */     else {
/*  333 */       refHref = refHref + "&";
/*      */     }
/*  335 */     getCal(cal, refHref, state, sbuff, req, prop);
/*      */ 
/*  337 */     Hashtable queryComponents = new Hashtable();
/*      */ 
/*  339 */     queryComponents.put("con", con);
/*  340 */     queryComponents.put("queryHref", queryHref);
/*      */ 
/*  342 */     sbuff.append("</td>");
/*  343 */     sbuff.append("<td width=85%>");
/*  344 */     if (state.equals("2"))
/*  345 */       getMonth(cal, refHref, state, sbuff, req, prop);
/*  346 */     else if (state.equals("1"))
/*  347 */       getWeek(cal, refHref, state, sbuff, req, prop);
/*      */     else {
/*  349 */       getDay(cal, refHref, state, sbuff, req, prop);
/*      */     }
/*  351 */     sbuff.append("</td>");
/*  352 */     sbuff.append("</tr>");
/*  353 */     sbuff.append("</table>");
/*      */   }
/*      */ 
/*      */   public void getCal(Calendar cal, String href, String state, StringBuffer buff, HttpServletRequest req, Properties prop)
/*      */     throws HtmlCalendarException
/*      */   {
/*  362 */     int hyyear = cal.get(1);
/*  363 */     int hymonth = cal.get(2);
/*  364 */     int hyday = cal.get(5);
/*      */ 
/*  366 */     buff.append("\n<script language=\"Javascript\">");
/*  367 */     buff.append("\n<!--");
/*  368 */     buff.append("\n\tfunction checkDate()\t{");
/*  369 */     buff.append("\n\t\tbadDate = false;");
/*  370 */     buff.append("\n\t\ttheString = document.calform.gotodate.value;");
/*  371 */     buff.append("\n\t\ttheArray = theString.split(\"/\");");
/*  372 */     buff.append("\n\t\tif (theArray.length==3)\t{");
/*  373 */     buff.append("\n\t\t\tbadDate = ((theArray[0]!=parseInt(theArray[0],10)) || (theArray[1]!=parseInt(theArray[1],10)) || (theArray[2]!=parseInt(theArray[2],10)));");
/*  374 */     buff.append("\n\t\t\tif (!badDate) badDate = !((theArray[0] >= 1) && (theArray[0] <= 12));");
/*  375 */     buff.append("\n\t\t\tif (!badDate) badDate = !((theArray[1] >= 1) && (theArray[1] <= 31));");
/*  376 */     buff.append("\n\t\t\tif (!badDate) badDate = !(((theArray[2] >= 0) && (theArray[2] <= 99)) || ((theArray[2] >= 1900) && (theArray[2] <= 2200)));");
/*  377 */     buff.append("\n\t\t} else {");
/*  378 */     buff.append("\n\t\t\tbadDate = true;");
/*  379 */     buff.append("\n\t\t}");
/*  380 */     buff.append("\n\t\tif (badDate) {");
/*  381 */     buff.append("\n\t\t\talert(\"You have entered an invalid date.\");");
/*  382 */     buff.append("\n\t\t\tdocument.calform.gotodate.value=\"" + (hymonth + 1) + "/" + hyday + "/" + hyyear + "\";");
/*  383 */     buff.append("\n\t\t\tdocument.calform.gotodate.focus(); document.calform.gotodate.select();");
/*  384 */     buff.append("\n\t\t} else {");
/*  385 */     buff.append("\n\t\t\tif (theArray[2]<50) {");
/*  386 */     buff.append("\n\t\t\t    theArray[2]= parseInt(theArray[2],10)+2000;\t\t// 1950 - 2049 is allowed");
/*  387 */     buff.append("\n\t\t\t} else if (theArray[2]<1900) {");
/*  388 */     buff.append("\n\t\t\t    theArray[2]= parseInt(theArray[2],10)+1900;");
/*  389 */     buff.append("\n\t\t\t}");
/*  390 */     buff.append("\n\t\t\t// alert(\"Month = \" + theArray[0] + \", Year = \" + theArray[2] + \", Day = \" + theArray[1]);");
/*  391 */     buff.append("\n\t\t\tdocument.calform.day.value= theArray[1];");
/*  392 */     buff.append("\n\t\t\tdocument.calform.month.value= theArray[0];");
/*  393 */     buff.append("\n\t\t\tdocument.calform.year.value= theArray[2];");
/*  394 */     buff.append("\n\t\t}");
/*  395 */     buff.append("\n\t}");
/*  396 */     buff.append("\n// -->");
/*  397 */     buff.append("\n</script>");
/*      */ 
/*  400 */     href = href + "state=" + state;
/*  401 */     int mn = cal.get(2);
/*  402 */     int monthEnd = 31;
/*  403 */     GregorianCalendar comp = new GregorianCalendar();
/*      */ 
/*  405 */     comp.set(cal.get(1), cal.get(2), 1);
/*      */ 
/*  407 */     String month = "";
/*  408 */     switch (mn)
/*      */     {
/*      */     case 0:
/*  411 */       month = "January";
/*  412 */       monthEnd = 31;
/*  413 */       break;
/*      */     case 1:
/*  415 */       month = "February";
/*  416 */       monthEnd = 28;
/*  417 */       if (comp.isLeapYear(cal.get(1)))
/*  418 */         monthEnd++; break;
/*      */     case 2:
/*  421 */       month = "March";
/*  422 */       monthEnd = 31;
/*  423 */       break;
/*      */     case 3:
/*  425 */       month = "April";
/*  426 */       monthEnd = 30;
/*  427 */       break;
/*      */     case 4:
/*  429 */       month = "May";
/*  430 */       monthEnd = 31;
/*  431 */       break;
/*      */     case 5:
/*  433 */       month = "June";
/*  434 */       monthEnd = 30;
/*  435 */       break;
/*      */     case 6:
/*  437 */       month = "July";
/*  438 */       monthEnd = 31;
/*  439 */       break;
/*      */     case 7:
/*  441 */       month = "August";
/*  442 */       monthEnd = 31;
/*  443 */       break;
/*      */     case 8:
/*  445 */       month = "September";
/*  446 */       monthEnd = 30;
/*  447 */       break;
/*      */     case 9:
/*  449 */       month = "October";
/*  450 */       monthEnd = 31;
/*  451 */       break;
/*      */     case 10:
/*  453 */       month = "November";
/*  454 */       monthEnd = 30;
/*  455 */       break;
/*      */     case 11:
/*  457 */       month = "December";
/*  458 */       monthEnd = 31;
/*      */     }
/*      */ 
/*  462 */     Hashtable colors = new Hashtable();
/*      */ 
/*  464 */     String calsel = (String)prop.get("CALENDARSELECT");
/*      */ 
/*  467 */     if (calsel != null)
/*      */     {
/*  469 */       String calwhere = (String)prop.get("CALENDARWHERECLAUSE");
/*  470 */       if (calwhere == null) {
/*  471 */         calwhere = "";
/*      */       }
/*  473 */       StringBuffer queryBuff = new StringBuffer();
/*  474 */       queryBuff.append("select to_char(" + (String)prop.get("DATERANGE1") + ", 'MM/DD'), " + calsel + " " + " FROM " + (String)prop.get("FROMCLAUSE") + " WHERE ");
/*      */ 
/*  479 */       if (calwhere.length() > 0)
/*      */       {
/*  481 */         queryBuff.append(calwhere + " AND ");
/*      */       }
/*      */ 
/*  484 */       queryBuff.append("(trunc(" + (String)prop.get("DATERANGE1") + ")>=trunc(to_date('" + (cal.get(2) + 1) + "/1/" + cal.get(1) + "', 'MM/DD/YYYY')) ");
/*  485 */       queryBuff.append(" and trunc(" + (String)prop.get("DATERANGE1") + ")<=trunc(to_date('" + (cal.get(2) + 1) + "/" + monthEnd + "/" + cal.get(1) + "', 'MM/DD/YYYY')))");
/*      */       try
/*      */       {
/*  490 */         Connection con = (Connection)prop.get("CONNECTION");
/*  491 */         Statement st = con.createStatement();
/*  492 */         ResultSet rs = st.executeQuery(queryBuff.toString());
/*      */ 
/*  494 */         while (rs.next())
/*      */         {
/*  496 */           String date = rs.getString(1);
/*  497 */           String color = rs.getString(2);
/*  498 */           colors.put(date, color);
/*      */         }
/*  500 */         rs.close();
/*  501 */         st.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  505 */         Diagnostics.debug("In exception 1" + e);
/*  506 */         throw new HtmlCalendarException("An error occurred: " + e);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  511 */     int relative = comp.get(7);
/*  512 */     int extend = relative;
/*      */ 
/*  515 */     buff.append("\n<form name=calform action=\"" + href + "&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=1\"\">");
/*  516 */     buff.append("<table border=0 cellpadding=0 cellspacing=0 width=141>");
/*  517 */     buff.append("\n\t\t<tr>");
/*  518 */     buff.append("\n\t\t\t<td bgcolor=" + CALENDARHEADERCOLOR + " width=6><a href=\"" + href + "&flag=-1&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=\"" + BROWSELEFTGIF + "\" width=6 height=12 hspace=2 border=0></a></td>");
/*  519 */     buff.append("\n\t\t\t<td bgcolor=" + CALENDARHEADERCOLOR + " align=center><font face=\"" + CALENDARHEADERFONT + "\" size=" + CALENDARHEADERFONTSIZE + " color=" + CALENDARHEADERFONTCOLOR + "><b>" + month + " " + cal.get(1) + "</b></font></td>");
/*  520 */     buff.append("\n\t\t\t<td bgcolor=" + CALENDARHEADERCOLOR + " width=6><a href=\"" + href + "&flag=1&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=\"" + BROWSERIGHTGIF + "\" width=6 height=12 hspace=2 border=0></a></td>");
/*  521 */     buff.append("\n\t\t</tr>");
/*  522 */     buff.append("\n</table>");
/*  523 */     buff.append("\n<table border=0 cellpadding=0 cellspacing=0 width=141>");
/*  524 */     buff.append("\n\t\t<tr align=right>");
/*  525 */     buff.append("\n\t\t        <td></td>");
/*  526 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>S</b></font></td>");
/*  527 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>M</b></font></td>");
/*  528 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>T</b></font></td>");
/*  529 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>W</b></font></td>");
/*  530 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>R</b></font></td>");
/*  531 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>F</b></font></td>");
/*  532 */     buff.append("\n\t\t        <td><font face=\"" + CALENDARHEADERFONT + "\" color=" + CALENDARLINKCOLOR + " size=-2><b>S</b></font></td>");
/*  533 */     buff.append("\n\t\t        <td></td>");
/*  534 */     buff.append("\n\t\t</tr>");
/*      */ 
/*  536 */     buff.append("\n \t\t<tr align=right>");
/*  537 */     buff.append("\n\t\t\t<td>&nbsp</td>");
/*      */ 
/*  539 */     int count = 1;
/*  540 */     for (int i = 1; i <= relative - 1; i++)
/*      */     {
/*  542 */       buff.append("\n\t\t\t<td><!-- -->&nbsp</td>");
/*  543 */       count++;
/*      */     }
/*  545 */     boolean grey = true;
/*      */ 
/*  547 */     int curr = cal.get(5);
/*      */ 
/*  549 */     int noRows = 2;
/*      */ 
/*  551 */     String date = "";
/*  552 */     String color = "";
/*  553 */     Calendar cal2 = Calendar.getInstance();
/*  554 */     for (int i = 1; i <= monthEnd; i++)
/*      */     {
/*  556 */       if (calsel != null)
/*      */       {
/*  558 */         date = comp.get(2) + 1 + "/";
/*  559 */         if (comp.get(2) + 1 < 10)
/*  560 */           date = "0" + date;
/*  561 */         if (i < 10)
/*  562 */           date = date + "0" + i;
/*      */         else {
/*  564 */           date = date + i;
/*      */         }
/*  566 */         color = (String)colors.get(date);
/*  567 */         if (color != null)
/*  568 */           buff.append("\n          <td bgcolor=\"" + color + "\">");
/*      */         else
/*  570 */           buff.append("\n          <td>");
/*      */       }
/*      */       else {
/*  573 */         buff.append("\n          <td>");
/*      */       }
/*  575 */       if ((cal2.get(2) == hymonth) && (cal2.get(5) == i) && (cal2.get(1) == hyyear))
/*  576 */         buff.append("<a href=\"" + href + "&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + i + "\"><font face=\"" + CALENDARHEADERFONT + "\" color=\"" + CALENDARLINKCOLOR + "\"size=-2 ><font color=" + CURRENTLINKCOLOR + ">" + i + "</font></a></td>");
/*      */       else
/*  578 */         buff.append("<a href=\"" + href + "&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + i + "\"><font face=\"" + CALENDARHEADERFONT + "\" color=\"" + CALENDARLINKCOLOR + "\"size=-2 ><font color=" + CALENDARLINKCOLOR + ">" + i + "</font></a></td>");
/*  579 */       count++;
/*  580 */       if ((relative == 7) || (relative == 14) || (relative == 21) || (relative == 28) || (relative == 35))
/*      */       {
/*  582 */         buff.append("\n       \t\t\t<td>&nbsp</td>");
/*  583 */         buff.append("\n\t\t</tr>");
/*      */ 
/*  586 */         grey = false;
/*  587 */         buff.append("\n\t\t<tr align=right>");
/*      */ 
/*  594 */         noRows++;
/*  595 */         buff.append("\n\t\t\t<td>&nbsp</td>");
/*  596 */         count++;
/*  597 */         count++;
/*      */       }
/*  599 */       relative++;
/*      */     }
/*      */ 
/*  603 */     if (count % 9 != 0)
/*      */     {
/*  605 */       while (count % 9 != 0)
/*      */       {
/*  607 */         buff.append("\n\t\t\t<td>&nbsp</td>");
/*  608 */         count++;
/*      */       }
/*      */     }
/*      */ 
/*  612 */     buff.append("\n\t\t</tr>");
/*  613 */     while (noRows < 7)
/*      */     {
/*  615 */       buff.append("<TR>");
/*  616 */       buff.append("<td colspan=9>");
/*  617 */       buff.append("&nbsp");
/*  618 */       buff.append("</td>");
/*  619 */       buff.append("</TR>");
/*  620 */       noRows++;
/*      */     }
/*  622 */     buff.append("<tr valign=top>");
/*  623 */     buff.append("<td valign=top colspan=9>");
/*  624 */     buff.append("<center>");
/*  625 */     buff.append("<table>");
/*  626 */     buff.append("<tr>");
/*  627 */     buff.append("<td valign=top>");
/*  628 */     buff.append("<input type=image name=submit value=submit src=" + GOGIF + " border=0>");
/*  629 */     buff.append("</td>");
/*  630 */     buff.append("<td valign=top>");
/*  631 */     buff.append("<input type=text size=8 maxsize=10 name=\"gotodate\" value=\"" + (cal.get(2) + 1) + "/" + cal.get(5) + "/" + cal.get(1) + "\" onChange=\"checkDate()\">");
/*  632 */     buff.append("<input type=hidden name=\"year\" value=\"" + cal.get(1) + "\" >");
/*  633 */     buff.append("<input type=hidden name=\"month\" value=\"" + (cal.get(2) + 1) + "\" >");
/*  634 */     buff.append("<input type=hidden name=\"day\" value=\"" + cal.get(5) + "\" >");
/*  635 */     if (href.indexOf("?") != -1)
/*      */     {
/*  637 */       StringTokenizer st = new StringTokenizer(href, "?");
/*  638 */       String newref = "";
/*  639 */       while (st.hasMoreElements())
/*      */       {
/*  641 */         newref = st.nextToken();
/*      */       }
/*  643 */       st = new StringTokenizer(newref, "&");
/*      */ 
/*  645 */       while (st.hasMoreTokens())
/*      */       {
/*  647 */         StringTokenizer st2 = new StringTokenizer(st.nextToken(), "=");
/*  648 */         buff.append("<input type=hidden name=\"" + st2.nextToken() + "\" value=\"" + st2.nextToken() + "\">");
/*      */       }
/*      */     }
/*  651 */     buff.append("</td>");
/*  652 */     buff.append("</tr>");
/*  653 */     buff.append("\n</table>");
/*  654 */     buff.append("<input type=hidden name=$state value=" + state + ">");
/*  655 */     buff.append("</td>");
/*  656 */     buff.append("</tr>");
/*  657 */     String filler = (String)prop.get("FILLER");
/*  658 */     if ((filler != null) && (filler.length() > 0))
/*      */     {
/*  660 */       buff.append("<tr>");
/*  661 */       buff.append("<td colspan=9 align=left valign=center>");
/*  662 */       buff.append(filler);
/*  663 */       buff.append("</td>");
/*  664 */       buff.append("</tr>");
/*      */     }
/*  666 */     buff.append("\n</table>");
/*  667 */     buff.append("</form>");
/*      */   }
/*      */ 
/*      */   private void getWeek(Calendar cal, String href, String state, StringBuffer buff, HttpServletRequest req, Properties prop)
/*      */     throws HtmlCalendarException
/*      */   {
/*  677 */     String queryHref = (String)prop.get("QUERYHREF");
/*  678 */     boolean javascript = false;
/*  679 */     if (queryHref.indexOf("javascript") != -1) {
/*  680 */       javascript = true;
/*      */     }
/*  682 */     if (!javascript)
/*      */     {
/*  684 */       if (queryHref.indexOf("?") == -1)
/*  685 */         queryHref = queryHref + "?";
/*      */       else {
/*  687 */         queryHref = queryHref + "&";
/*      */       }
/*      */     }
/*  690 */     Calendar curr = Calendar.getInstance();
/*  691 */     int hyday = curr.get(5);
/*  692 */     int hymonth = curr.get(2);
/*  693 */     int hyyear = curr.get(1);
/*      */ 
/*  695 */     Calendar cal2 = Calendar.getInstance();
/*      */ 
/*  697 */     cal2.set(cal.get(1), cal.get(2), cal.get(5));
/*      */ 
/*  699 */     int offset = cal2.get(7);
/*  700 */     int posoffset = 7 - cal2.get(7);
/*  701 */     offset = -offset + 1;
/*  702 */     cal2.add(5, offset);
/*      */ 
/*  704 */     String title = "Week of ";
/*      */ 
/*  706 */     switch (cal2.get(2))
/*      */     {
/*      */     case 0:
/*  709 */       title = title + "January";
/*  710 */       break;
/*      */     case 1:
/*  712 */       title = title + "February";
/*  713 */       break;
/*      */     case 2:
/*  715 */       title = title + "March";
/*  716 */       break;
/*      */     case 3:
/*  718 */       title = title + "April";
/*  719 */       break;
/*      */     case 4:
/*  721 */       title = title + "May";
/*  722 */       break;
/*      */     case 5:
/*  724 */       title = title + "June";
/*  725 */       break;
/*      */     case 6:
/*  727 */       title = title + "July";
/*  728 */       break;
/*      */     case 7:
/*  730 */       title = title + "August";
/*  731 */       break;
/*      */     case 8:
/*  733 */       title = title + "September";
/*  734 */       break;
/*      */     case 9:
/*  736 */       title = title + "October";
/*  737 */       break;
/*      */     case 10:
/*  739 */       title = title + "November";
/*  740 */       break;
/*      */     case 11:
/*  742 */       title = title + "December";
/*      */     }
/*      */ 
/*  746 */     title = title + " " + cal2.get(5);
/*      */ 
/*  748 */     curr.set(cal.get(1), cal.get(2), cal.get(5));
/*      */ 
/*  750 */     curr.add(5, -curr.get(7));
/*      */ 
/*  752 */     buff.append("<table width=100% border=0 cellpadding=0 cellspacing=0\n");
/*  753 */     buff.append("\t<tr  bgcolor=" + HEADERCOLOR + ">\n");
/*  754 */     buff.append("\t<td colspan=2>\n");
/*  755 */     buff.append("\t<font face=\"" + HEADERFONT + "\" size=\"" + HEADERFONTSIZE + "\" color=" + HEADERFONTCOLOR + ">\n");
/*  756 */     buff.append("\n\t\t\t<a href=\"" + href + "&state=1&flag=0&year=" + curr.get(1) + "&month=" + curr.get(2) + "&day=" + curr.get(5) + "\"><img src=\"" + BROWSELEFTGIF + "\" width=6 height=12 hspace=2 border=0></a>");
/*  757 */     buff.append("\t<b>Week Schedule \n");
/*  758 */     curr.add(5, 8);
/*  759 */     buff.append("\n\t\t\t<a href=\"" + href + "&state=1&flag=0&year=" + curr.get(1) + "&month=" + curr.get(2) + "&day=" + curr.get(5) + "\"><img src=\"" + BROWSERIGHTGIF + "\" width=6 height=12 hspace=2 border=0></a>");
/*  760 */     buff.append("   " + title + "</b>");
/*  761 */     buff.append("\t</font>\n");
/*  762 */     buff.append("\t  </td>\n");
/*  763 */     buff.append("\t</tr>\n");
/*      */ 
/*  765 */     href = href + "state=0";
/*  766 */     String day = "Sun";
/*      */ 
/*  772 */     Hashtable datesDes = new Hashtable();
/*  773 */     Calendar prevCal = Calendar.getInstance();
/*  774 */     prevCal.set(cal.get(1), cal.get(2), cal.get(5));
/*  775 */     Calendar postCal = Calendar.getInstance();
/*  776 */     postCal.set(cal.get(1), cal.get(2), cal.get(5));
/*      */ 
/*  778 */     prevCal.add(5, offset);
/*      */ 
/*  780 */     postCal.add(5, posoffset + 1);
/*      */ 
/*  782 */     StringBuffer queryBuff = new StringBuffer();
/*  783 */     queryBuff.append("select " + (String)prop.get("PRIMARYKEY") + ", " + "to_char(" + (String)prop.get("DATERANGE1") + ", 'MM/DD'), " + (String)prop.get("DESCRIPTION") + " FROM " + (String)prop.get("FROMCLAUSE") + " WHERE " + (String)prop.get("WHERECLAUSE"));
/*      */ 
/*  791 */     if (((String)prop.get("WHERECLAUSE")).length() > 0) {
/*  792 */       queryBuff.append(" AND ");
/*      */     }
/*  794 */     queryBuff.append("(" + (String)prop.get("DATERANGE1") + ">=to_date('" + (prevCal.get(2) + 1) + "/" + prevCal.get(5) + "/" + prevCal.get(1) + "', 'MM/DD/YYYY') ");
/*  795 */     queryBuff.append(" and " + (String)prop.get("DATERANGE1") + "<=to_date('" + (postCal.get(2) + 1) + "/" + postCal.get(5) + "/" + postCal.get(1) + "', 'MM/DD/YYYY'))");
/*      */ 
/*  797 */     queryBuff.append(" ORDER BY " + (String)prop.get("DATERANGE1"));
/*      */     try
/*      */     {
/*  801 */       Connection con = (Connection)prop.get("CONNECTION");
/*  802 */       Statement st = con.createStatement();
/*  803 */       ResultSet rs = st.executeQuery(queryBuff.toString());
/*      */ 
/*  805 */       while (rs.next())
/*      */       {
/*  807 */         String date = rs.getString(2);
/*  808 */         String[] vars = new String[2];
/*  809 */         vars[0] = rs.getString(1);
/*  810 */         vars[1] = rs.getString(3);
/*  811 */         Vector times = (Vector)datesDes.get(date);
/*  812 */         if (times == null)
/*  813 */           times = new Vector();
/*  814 */         times.addElement(vars);
/*  815 */         datesDes.put(date, times);
/*      */       }
/*  817 */       rs.close();
/*  818 */       st.close();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  822 */       Diagnostics.debug("In exception 2" + e);
/*  823 */       throw new HtmlCalendarException("An error occurred: " + e);
/*      */     }
/*      */ 
/*  827 */     for (int i = 0; i < 7; i++)
/*      */     {
/*  829 */       cal2.add(5, i);
/*  830 */       buff.append("\t<tr>\n");
/*      */ 
/*  832 */       switch (i)
/*      */       {
/*      */       case 0:
/*  835 */         day = "Sun";
/*  836 */         break;
/*      */       case 1:
/*  838 */         day = "Mon";
/*  839 */         break;
/*      */       case 2:
/*  841 */         day = "Tue";
/*  842 */         break;
/*      */       case 3:
/*  844 */         day = "Wed";
/*  845 */         break;
/*      */       case 4:
/*  847 */         day = "Thu";
/*  848 */         break;
/*      */       case 5:
/*  850 */         day = "Fri";
/*  851 */         break;
/*      */       case 6:
/*  853 */         day = "Sat";
/*      */       }
/*      */ 
/*  857 */       if ((cal2.get(2) == hymonth) && (cal2.get(5) == hyday) && (cal2.get(1) == hyyear))
/*  858 */         buff.append("\t\t<td width=8% height=75 bgcolor=" + HIGHLIGHTCOLOR + " align=center valign=top><a href=\"" + href + "&flag=0&year=" + cal2.get(1) + "&month=" + cal2.get(2) + "&day=" + cal2.get(5) + "\"><font face=\"" + HEADERFONT + "\" size=-2 color=\"" + CURRENTLINKCOLOR + "\">" + day + "</font></a><BR><font face=\"" + HEADERFONT + "\" size=+3 color=\"" + CURRENTLINKCOLOR + "\">" + cal2.get(5) + "</font><BR>\n");
/*      */       else
/*  860 */         buff.append("\t\t<td width=8% height=75 bgcolor=" + HIGHLIGHTCOLOR + " align=center valign=top><a href=\"" + href + "&flag=0&year=" + cal2.get(1) + "&month=" + cal2.get(2) + "&day=" + cal2.get(5) + "\"><font face=\"" + HEADERFONT + "\" size=-2 color=\"" + HEADERCOLOR + "\">" + day + "</font></a><BR><font face=\"" + HEADERFONT + "\" size=+3 color=\"BLACK\">" + cal2.get(5) + "</font><BR>\n");
/*  861 */       buff.append("       </td>\n");
/*  862 */       buff.append("\t\t<td width=100% bgcolor=white>\n");
/*  863 */       buff.append("\t\t        <div align=right><font face=\"Arial,Helvetica\" size=-1><b></b></font></div>\n");
/*  864 */       buff.append("\t\t\t<table border=0 cellpadding=0 cellspacing=0>\n");
/*  865 */       buff.append("           <tr>\n");
/*  866 */       buff.append("           <td>\n");
/*  867 */       String date = cal2.get(2) + 1 + "/";
/*  868 */       if (cal2.get(2) + 1 < 10)
/*  869 */         date = "0" + date;
/*  870 */       if (cal2.get(5) < 10)
/*  871 */         date = date + "0" + cal2.get(5);
/*      */       else
/*  873 */         date = date + cal2.get(5);
/*  874 */       Vector times = (Vector)datesDes.get(date);
/*  875 */       if (times != null)
/*      */       {
/*  878 */         for (int j = 0; j < times.size(); j++)
/*      */         {
/*  880 */           String[] vars = (String[])times.elementAt(j);
/*  881 */           if (javascript)
/*  882 */             buff.append("<a href=\"" + queryHref + vars[0] + ")\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */           else
/*  884 */             buff.append("<a href=\"" + queryHref + "id=" + vars[0] + "\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */         }
/*      */       }
/*  887 */       buff.append("           </td>\n");
/*  888 */       buff.append("           </tr>\n");
/*  889 */       buff.append("\t\t\t</table>\n");
/*  890 */       buff.append("\t\t</td>\n");
/*  891 */       buff.append("\t</tr>\n");
/*      */ 
/*  893 */       buff.append("\t<tr>\n");
/*  894 */       buff.append("\t\t<td colspan=2 height=1 bgcolor=999999><img src=\"gray153.gif\" width=1 height=1 border=0></td>\n");
/*  895 */       buff.append("\t</tr>\t<tr>\n");
/*      */ 
/*  897 */       cal2.set(cal.get(1), cal.get(2), cal.get(5));
/*  898 */       cal2.add(5, offset);
/*      */     }
/*      */ 
/*  901 */     buff.append("</table>\n");
/*      */   }
/*      */ 
/*      */   private void getMonth(Calendar cal, String href, String state, StringBuffer buff, HttpServletRequest req, Properties prop)
/*      */     throws HtmlCalendarException
/*      */   {
/*  909 */     String queryHref = (String)prop.get("QUERYHREF");
/*  910 */     boolean javascript = false;
/*  911 */     if (queryHref.indexOf("javascript") != -1) {
/*  912 */       javascript = true;
/*      */     }
/*  914 */     if (!javascript)
/*      */     {
/*  916 */       if (queryHref.indexOf("?") == -1)
/*  917 */         queryHref = queryHref + "?";
/*      */       else {
/*  919 */         queryHref = queryHref + "&";
/*      */       }
/*      */     }
/*  922 */     int mn = cal.get(2);
/*  923 */     int yr = cal.get(1);
/*  924 */     int monthEnd = 31;
/*  925 */     int monthPrior = 31;
/*  926 */     GregorianCalendar comp = new GregorianCalendar();
/*      */ 
/*  928 */     comp.set(cal.get(1), cal.get(2), 1);
/*      */ 
/*  930 */     String month = "";
/*  931 */     switch (mn)
/*      */     {
/*      */     case 0:
/*  934 */       month = "January";
/*  935 */       monthEnd = 31;
/*  936 */       monthPrior = 31;
/*  937 */       break;
/*      */     case 1:
/*  939 */       month = "February";
/*  940 */       monthEnd = 28;
/*  941 */       if (comp.isLeapYear(cal.get(1)))
/*  942 */         monthEnd++;
/*  943 */       monthPrior = 31;
/*  944 */       break;
/*      */     case 2:
/*  946 */       month = "March";
/*  947 */       monthEnd = 31;
/*  948 */       monthPrior = 28;
/*  949 */       if (comp.isLeapYear(cal.get(1)))
/*  950 */         monthPrior++; break;
/*      */     case 3:
/*  953 */       month = "April";
/*  954 */       monthEnd = 30;
/*  955 */       monthPrior = 31;
/*  956 */       break;
/*      */     case 4:
/*  958 */       month = "May";
/*  959 */       monthEnd = 31;
/*  960 */       monthPrior = 30;
/*  961 */       break;
/*      */     case 5:
/*  963 */       month = "June";
/*  964 */       monthEnd = 30;
/*  965 */       monthPrior = 31;
/*  966 */       break;
/*      */     case 6:
/*  968 */       month = "July";
/*  969 */       monthEnd = 31;
/*  970 */       monthPrior = 30;
/*  971 */       break;
/*      */     case 7:
/*  973 */       month = "August";
/*  974 */       monthEnd = 31;
/*  975 */       monthPrior = 31;
/*  976 */       break;
/*      */     case 8:
/*  978 */       month = "September";
/*  979 */       monthEnd = 30;
/*  980 */       monthPrior = 31;
/*  981 */       break;
/*      */     case 9:
/*  983 */       month = "October";
/*  984 */       monthEnd = 31;
/*  985 */       monthPrior = 30;
/*  986 */       break;
/*      */     case 10:
/*  988 */       month = "November";
/*  989 */       monthPrior = 31;
/*  990 */       monthEnd = 30;
/*  991 */       break;
/*      */     case 11:
/*  993 */       month = "December";
/*  994 */       monthEnd = 31;
/*  995 */       monthPrior = 30;
/*      */     }
/*      */ 
/* 1000 */     int relative = comp.get(7);
/* 1001 */     int extend = relative;
/*      */ 
/* 1003 */     int hyyear = cal.get(1);
/* 1004 */     int hymonth = cal.get(2);
/* 1005 */     int hyday = cal.get(5);
/*      */ 
/* 1007 */     comp.set(cal.get(1), cal.get(2), 1);
/*      */ 
/* 1009 */     comp.add(2, -1);
/* 1010 */     hyyear = comp.get(1);
/* 1011 */     hymonth = comp.get(2);
/* 1012 */     hyday = comp.get(5);
/*      */ 
/* 1014 */     buff.append("<table width=100% border=0 cellpadding=0 cellspacing=0>\n");
/* 1015 */     buff.append("\t<tr  bgcolor=" + HEADERCOLOR + ">\n");
/* 1016 */     buff.append("\t<td>\n");
/* 1017 */     buff.append("\t<font face=\"" + HEADERFONT + "\" size=\"+1\" color=white>\n");
/* 1018 */     buff.append("\n\t\t\t<a href=\"" + href + "&state=2&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=\"" + BROWSELEFTGIF + "\" width=6 height=12 hspace=2 border=0></a>");
/* 1019 */     buff.append("\n\t\t\t<font face=\"" + HEADERFONT + "\" size=" + HEADERFONTSIZE + " color=" + HEADERFONTCOLOR + "><b>Month Schedule</b></font>");
/* 1020 */     comp.add(2, 2);
/* 1021 */     hyyear = comp.get(1);
/* 1022 */     hymonth = comp.get(2);
/* 1023 */     hyday = comp.get(5);
/*      */ 
/* 1025 */     buff.append("\n\t\t\t<a href=\"" + href + "&state=2&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=\"" + BROWSERIGHTGIF + "\" width=6 height=12 hspace=2 border=0></a>");
/* 1026 */     hyyear = cal.get(1);
/* 1027 */     hymonth = cal.get(2);
/* 1028 */     hyday = cal.get(5);
/* 1029 */     hymonth++;
/* 1030 */     buff.append("\n\t\t\t<font face=\"" + HEADERFONT + "\" size=" + HEADERFONTSIZE + " color=" + HEADERFONTCOLOR + "><b> - " + month + "</b></font>");
/* 1031 */     buff.append("\t</font>\n");
/* 1032 */     buff.append("\t  </td>\n");
/* 1033 */     buff.append("\t</tr>\n");
/*      */ 
/* 1035 */     buff.append("\t\n");
/* 1036 */     buff.append("<table width=100% border=0 cellpadding=0 cellspacing=1 bgcolor=gray>\n");
/* 1037 */     buff.append("<tr>\n");
/* 1038 */     buff.append("<TD bgcolor=gray>");
/* 1039 */     buff.append("<table width=100% border=0 cellpadding=1 cellspacing=1 bgcolor=gray>\n");
/* 1040 */     buff.append("<tr>\n");
/* 1041 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Sun</b></font></td>\n");
/* 1042 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Mon</b></font></td>\n");
/* 1043 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Tue</b></font></td>\n");
/* 1044 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Wed</b></font></td>\n");
/* 1045 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Thu</b></font></td>\n");
/* 1046 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Fri</b></font></td>\n");
/* 1047 */     buff.append("\t<td align=center bgcolor=cccccc width=14%><font face=\"Arial,Geneva\" size=-1 color=666666><b>Sat</b></font></td>\n");
/* 1048 */     buff.append("</tr>\n");
/*      */ 
/* 1050 */     buff.append("<tr bgcolor=ffffff>\n");
/*      */ 
/* 1052 */     int count = 0;
/* 1053 */     int offset = monthPrior - relative + 2;
/*      */ 
/* 1055 */     int monthPriorDay = offset;
/*      */ 
/* 1057 */     comp.set(cal.get(1), cal.get(2), 1);
/* 1058 */     comp.add(2, -1);
/* 1059 */     hyyear = comp.get(1);
/* 1060 */     hymonth = comp.get(2);
/* 1061 */     hyday = comp.get(5);
/*      */ 
/* 1067 */     Hashtable datesDes = new Hashtable();
/* 1068 */     Calendar prevCal = Calendar.getInstance();
/* 1069 */     prevCal.set(cal.get(1), cal.get(2), monthPrior);
/* 1070 */     Calendar postCal = Calendar.getInstance();
/* 1071 */     postCal.set(cal.get(1), cal.get(2), 1);
/*      */ 
/* 1073 */     prevCal.add(2, -1);
/* 1074 */     prevCal.add(5, -6);
/*      */ 
/* 1076 */     postCal.add(2, 1);
/* 1077 */     postCal.add(5, 6);
/*      */ 
/* 1079 */     StringBuffer queryBuff = new StringBuffer();
/* 1080 */     queryBuff.append("select " + (String)prop.get("PRIMARYKEY") + ", " + "to_char(" + (String)prop.get("DATERANGE1") + ", 'MM/DD'), " + (String)prop.get("DESCRIPTION") + " FROM " + (String)prop.get("FROMCLAUSE") + " WHERE " + (String)prop.get("WHERECLAUSE"));
/*      */ 
/* 1088 */     if (((String)prop.get("WHERECLAUSE")).length() > 0) {
/* 1089 */       queryBuff.append(" AND ");
/*      */     }
/* 1091 */     queryBuff.append("(" + (String)prop.get("DATERANGE1") + ">=to_date('" + (prevCal.get(2) + 1) + "/" + prevCal.get(5) + "/" + prevCal.get(1) + "', 'MM/DD/YYYY') ");
/* 1092 */     queryBuff.append(" and " + (String)prop.get("DATERANGE1") + "<=to_date('" + (postCal.get(2) + 1) + "/" + postCal.get(5) + "/" + postCal.get(1) + "', 'MM/DD/YYYY'))");
/*      */ 
/* 1094 */     queryBuff.append(" ORDER BY " + (String)prop.get("DATERANGE1"));
/*      */     try
/*      */     {
/* 1098 */       Connection con = (Connection)prop.get("CONNECTION");
/* 1099 */       Statement st = con.createStatement();
/* 1100 */       ResultSet rs = st.executeQuery(queryBuff.toString());
/*      */ 
/* 1102 */       while (rs.next())
/*      */       {
/* 1104 */         String date = rs.getString(2);
/* 1105 */         String[] vars = new String[2];
/* 1106 */         vars[0] = rs.getString(1);
/* 1107 */         vars[1] = rs.getString(3);
/* 1108 */         Vector times = (Vector)datesDes.get(date);
/* 1109 */         if (times == null)
/* 1110 */           times = new Vector();
/* 1111 */         times.addElement(vars);
/* 1112 */         datesDes.put(date, times);
/*      */       }
/* 1114 */       rs.close();
/* 1115 */       st.close();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1119 */       Diagnostics.debug("In exception 3" + e);
/* 1120 */       throw new HtmlCalendarException("An error occurred: " + e);
/*      */     }
/*      */ 
/* 1123 */     for (int i = 1; i <= relative - 1; i++)
/*      */     {
/* 1125 */       count++;
/* 1126 */       buff.append("\t<td width=14% valign=top height=80 bgcolor=\"lightgrey\" ><font face=Arial size=-2><a href=\"" + href + "state=0&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + i + "\"><font color=999999>" + offset + "</font></a>&nbsp;&nbsp;\n");
/* 1127 */       buff.append("<br>\n");
/* 1128 */       String date = prevCal.get(2) + 1 + "/" + offset;
/* 1129 */       Vector times = (Vector)datesDes.get(date);
/* 1130 */       if (times != null)
/*      */       {
/* 1133 */         for (int j = 0; j < times.size(); j++)
/*      */         {
/* 1135 */           String[] vars = (String[])times.elementAt(j);
/* 1136 */           if (javascript)
/* 1137 */             buff.append("<a href=\"" + queryHref + vars[0] + ")\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */           else
/* 1139 */             buff.append("<a href=\"" + queryHref + "id=" + vars[0] + "\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */         }
/*      */       }
/* 1142 */       buff.append("</font></td>\n");
/* 1143 */       offset++;
/*      */     }
/*      */ 
/* 1146 */     comp.add(2, 1);
/* 1147 */     hyyear = comp.get(1);
/* 1148 */     hymonth = comp.get(2);
/* 1149 */     hyday = comp.get(5);
/*      */ 
/* 1151 */     Calendar cal2 = Calendar.getInstance();
/*      */ 
/* 1153 */     for (int i = 1; i <= monthEnd; i++)
/*      */     {
/* 1155 */       if ((cal2.get(2) == hymonth) && (cal2.get(5) == i) && (cal2.get(1) == hyyear))
/* 1156 */         buff.append("<td width=14% valign=top height=80 bgcolor=" + HIGHLIGHTCOLOR + "><font face=Arial size=-2><a href=\"" + href + "state=0&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + i + "\"><font color=" + CURRENTLINKCOLOR + ">" + i + "</font></a>&nbsp;&nbsp;\n");
/*      */       else
/* 1158 */         buff.append("<td width=14% valign=top height=80  ><font face=Arial size=-2><a href=\"" + href + "state=0&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + i + "\"><font color=999999>" + i + "</font></a>&nbsp;&nbsp;\n");
/* 1159 */       buff.append("<br>\n");
/*      */ 
/* 1161 */       String date = cal.get(2) + 1 + "/";
/* 1162 */       if (cal.get(2) + 1 < 10)
/* 1163 */         date = "0" + date;
/* 1164 */       if (i < 10)
/* 1165 */         date = date + "0" + i;
/*      */       else
/* 1167 */         date = date + i;
/* 1168 */       Vector times = (Vector)datesDes.get(date);
/* 1169 */       if (times != null)
/*      */       {
/* 1172 */         for (int j = 0; j < times.size(); j++)
/*      */         {
/* 1174 */           String[] vars = (String[])times.elementAt(j);
/* 1175 */           if (javascript)
/* 1176 */             buff.append("<a href=\"" + queryHref + vars[0] + ")\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */           else
/* 1178 */             buff.append("<a href=\"" + queryHref + "id=" + vars[0] + "\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */         }
/*      */       }
/* 1181 */       buff.append("</font></td>\n");
/* 1182 */       count++;
/* 1183 */       if ((relative == 7) || (relative == 14) || (relative == 21) || (relative == 28) || (relative == 35))
/*      */       {
/* 1185 */         buff.append("\n\t\t</tr>");
/* 1186 */         buff.append("\n\t\t<tr  bgcolor=ffffff>");
/*      */       }
/* 1188 */       relative++;
/*      */     }
/*      */ 
/* 1191 */     offset = 1;
/* 1192 */     comp.add(2, 1);
/* 1193 */     hyyear = comp.get(1);
/* 1194 */     hymonth = comp.get(2);
/* 1195 */     hyday = comp.get(5);
/*      */ 
/* 1197 */     if (count % 7 != 0)
/*      */     {
/* 1199 */       while (count % 7 != 0)
/*      */       {
/* 1201 */         buff.append("<td width=14% valign=top height=80  bgcolor=\"lightgrey\" ><font face=Arial size=-2><a href=\"" + href + "state=0&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + offset + "\"><font color=999999>" + offset + "</font></a>&nbsp;&nbsp;\n");
/* 1202 */         buff.append("<br>\n");
/* 1203 */         String date = postCal.get(2) + 1 + "/0" + offset;
/* 1204 */         if (postCal.get(2) + 1 < 10) {
/* 1205 */           date = "0" + date;
/*      */         }
/* 1207 */         Vector times = (Vector)datesDes.get(date);
/* 1208 */         if (times != null)
/*      */         {
/* 1211 */           for (int j = 0; j < times.size(); j++)
/*      */           {
/* 1213 */             String[] vars = (String[])times.elementAt(j);
/* 1214 */             if (javascript)
/* 1215 */               buff.append("<a href=\"" + queryHref + vars[0] + ")\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */             else
/* 1217 */               buff.append("<a href=\"" + queryHref + "id=" + vars[0] + "\"><font color=" + INFOLINKCOLOR + ">" + vars[1] + "</font></a><BR>\n");
/*      */           }
/*      */         }
/* 1220 */         buff.append("</font></td>\n");
/* 1221 */         count++;
/* 1222 */         offset++;
/*      */       }
/*      */     }
/*      */ 
/* 1226 */     buff.append("</tr>\n");
/* 1227 */     buff.append("</table>\n");
/* 1228 */     buff.append("</td>\n");
/* 1229 */     buff.append("</tr>\n");
/* 1230 */     buff.append("</table>\n");
/*      */   }
/*      */ 
/*      */   private void getDay(Calendar cal, String href, String state, StringBuffer buff, HttpServletRequest req, Properties prop)
/*      */     throws HtmlCalendarException
/*      */   {
/* 1241 */     String queryHref = (String)prop.get("QUERYHREF");
/* 1242 */     boolean javascript = false;
/* 1243 */     if (queryHref.indexOf("javascript") != -1) {
/* 1244 */       javascript = true;
/*      */     }
/* 1246 */     if (!javascript)
/*      */     {
/* 1248 */       if (queryHref.indexOf("?") == -1)
/* 1249 */         queryHref = queryHref + "?";
/*      */       else {
/* 1251 */         queryHref = queryHref + "&";
/*      */       }
/*      */     }
/* 1254 */     href = href + "state=" + state;
/* 1255 */     GregorianCalendar comp = new GregorianCalendar();
/*      */ 
/* 1257 */     comp.set(cal.get(1), cal.get(2), cal.get(5));
/*      */ 
/* 1259 */     comp.add(5, -1);
/* 1260 */     int hyyear = comp.get(1);
/* 1261 */     int hymonth = comp.get(2);
/* 1262 */     int hyday = comp.get(5);
/*      */ 
/* 1264 */     buff.append("<table width=\"100%\" border=0 cellpadding=0 cellspacing=0>\n");
/* 1265 */     buff.append("\t<tr  bgcolor=" + HEADERCOLOR + ">\n");
/* 1266 */     buff.append("\t<td colspan=100>\n");
/* 1267 */     buff.append("\t<font face=\"" + HEADERFONT + "\" size=\"+1\" color=white>\n");
/* 1268 */     buff.append("\n\t\t\t<a href=\"" + href + "&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=\"" + BROWSELEFTGIF + "\" width=6 height=12 hspace=2 border=0></a>");
/* 1269 */     buff.append("\n\t\t\t<font face=\"" + HEADERFONT + "\" size=" + HEADERFONTSIZE + " color=" + HEADERFONTCOLOR + "><b>Day Schedule</b></font>");
/* 1270 */     comp.add(5, 2);
/* 1271 */     hyyear = comp.get(1);
/* 1272 */     hymonth = comp.get(2);
/* 1273 */     hyday = comp.get(5);
/*      */ 
/* 1275 */     buff.append("\n\t\t\t<a href=\"" + href + "&flag=0&year=" + hyyear + "&month=" + hymonth + "&day=" + hyday + "\"><img src=\"" + BROWSERIGHTGIF + "\" width=6 height=12 hspace=2 border=0></a>");
/* 1276 */     hymonth++;
/*      */ 
/* 1278 */     hyyear = cal.get(1);
/* 1279 */     hymonth = cal.get(2);
/* 1280 */     hyday = cal.get(5);
/* 1281 */     hymonth++;
/* 1282 */     buff.append("\n\t\t\t<font face=\"" + HEADERFONT + "\" size=" + HEADERFONTSIZE + " color=" + HEADERFONTCOLOR + "><b> - " + hymonth + "/" + hyday + "/" + hyyear + "</b></font>");
/* 1283 */     buff.append("\t</font>\n");
/* 1284 */     buff.append("\t  </td>\n");
/* 1285 */     buff.append("\t</tr>\n");
/*      */ 
/* 1292 */     Hashtable datesDes = new Hashtable();
/*      */ 
/* 1294 */     StringBuffer queryBuff = new StringBuffer();
/* 1295 */     queryBuff.append("select " + (String)prop.get("PRIMARYKEY") + ", " + "to_char(" + (String)prop.get("DATERANGE1") + ", 'HH24'), " + "to_char(" + (String)prop.get("DATERANGE1") + ", 'MI'), " + "to_char(" + (String)prop.get("DATERANGE2") + ", 'HH24'), " + "to_char(" + (String)prop.get("DATERANGE2") + ", 'MI'), " + (String)prop.get("DESCRIPTION") + " FROM " + (String)prop.get("FROMCLAUSE") + " WHERE " + (String)prop.get("WHERECLAUSE"));
/*      */ 
/* 1306 */     if (((String)prop.get("WHERECLAUSE")).length() > 0) {
/* 1307 */       queryBuff.append(" AND ");
/*      */     }
/*      */ 
/* 1310 */     if (cal.get(2) + 1 < 10)
/* 1311 */       sdate = "0" + (cal.get(2) + 1);
/*      */     else {
/* 1313 */       sdate = "" + (cal.get(2) + 1);
/*      */     }
/* 1315 */     if (cal.get(5) < 10)
/* 1316 */       sdate = sdate + "/0" + cal.get(5);
/*      */     else {
/* 1318 */       sdate = sdate + "/" + cal.get(5);
/*      */     }
/* 1320 */     String sdate = sdate + "/" + cal.get(1);
/*      */ 
/* 1322 */     queryBuff.append("trunc(" + (String)prop.get("DATERANGE1") + ")=to_date('" + sdate + "', 'MM/DD/YYYY')");
/*      */ 
/* 1324 */     queryBuff.append(" ORDER BY " + (String)prop.get("DATERANGE1"));
/*      */     try
/*      */     {
/* 1328 */       Connection con = (Connection)prop.get("CONNECTION");
/* 1329 */       Statement st = con.createStatement();
/* 1330 */       ResultSet rs = st.executeQuery(queryBuff.toString());
/*      */ 
/* 1332 */       while (rs.next())
/*      */       {
/* 1334 */         String date = rs.getString(2);
/* 1335 */         String[] vars = new String[5];
/* 1336 */         vars[0] = rs.getString(1);
/* 1337 */         vars[1] = rs.getString(3);
/* 1338 */         vars[2] = rs.getString(4);
/* 1339 */         vars[3] = rs.getString(5);
/* 1340 */         vars[4] = rs.getString(6);
/* 1341 */         Vector times = (Vector)datesDes.get(date);
/* 1342 */         if (times == null)
/* 1343 */           times = new Vector();
/* 1344 */         times.addElement(vars);
/* 1345 */         datesDes.put(date, times);
/*      */       }
/* 1347 */       rs.close();
/* 1348 */       st.close();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1352 */       Diagnostics.debug("In exception 4" + e);
/* 1353 */       throw new HtmlCalendarException("An error occurred: " + queryBuff.toString());
/*      */     }
/*      */ 
/* 1356 */     boolean toggle = true;
/*      */ 
/* 1358 */     int rowspan = 0;
/* 1359 */     int spancount = 0;
/*      */     String stime;
/*      */     Vector times;
/*      */     String[] vars;
/*      */     int hour1;
/*      */     int minute1;
/*      */     int hour2;
/*      */     int minute2;
/* 1365 */     for (int i = 0; i < TIMEFROM; i++)
/*      */     {
/* 1367 */       if (i < 10)
/* 1368 */         stime = "0" + i;
/*      */       else
/* 1370 */         stime = "" + i;
/* 1371 */       times = (Vector)datesDes.get(stime);
/*      */ 
/* 1373 */       if (times != null)
/*      */       {
/* 1375 */         Vector newTimes = new Vector();
/* 1376 */         for (int x = 0; x < times.size(); x++)
/*      */         {
/* 1378 */           vars = (String[])times.elementAt(x);
/* 1379 */           hour1 = i;
/* 1380 */           minute1 = Integer.parseInt(vars[1]);
/* 1381 */           hour2 = Integer.parseInt(vars[2]);
/* 1382 */           minute2 = Integer.parseInt(vars[3]);
/* 1383 */           if (hour2 >= TIMEFROM)
/*      */           {
/* 1385 */             hour2 -= hour1;
/* 1386 */             hour1 = TIMEFROM;
/* 1387 */             if (hour1 < 10)
/* 1388 */               stime = "0" + hour1;
/*      */             else
/* 1390 */               stime = "" + hour1;
/* 1391 */             vars[2] = ("" + hour2);
/* 1392 */             newTimes.addElement(vars);
/* 1393 */             datesDes.put(stime, newTimes);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1399 */     for (int i = TIMEFROM; i <= TIMETO; i++)
/*      */     {
/* 1401 */       for (int j = 0; j < 2; j++)
/*      */       {
/* 1403 */         if (toggle)
/*      */         {
/* 1405 */           if (j != 0)
/* 1406 */             toggle = false;
/* 1407 */           buff.append("   \t<tr bgcolor=\"" + HIGHLIGHTCOLOR + "\">\n");
/*      */         }
/*      */         else {
/* 1410 */           if (j != 0)
/* 1411 */             toggle = true;
/* 1412 */           buff.append("   \t<tr bgcolor=\"WHITE\">\n");
/*      */         }
/*      */ 
/* 1415 */         buff.append("\t\t<td width=1% valign=top hieght=1>\n");
/* 1416 */         buff.append("\t\t<font face=\"" + HEADERFONT + "\" size=\"-1\" color=\"#000000\">\n");
/* 1417 */         if ((i == TIMEFROM) && (j == 0))
/* 1418 */           buff.append("\t\t<B>AM</B>\n");
/* 1419 */         else if ((i == 12) && (j == 0))
/* 1420 */           buff.append("\t\t<B>PM</B>\n");
/*      */         else {
/* 1422 */           buff.append("       &nbsp\n");
/*      */         }
/* 1424 */         buff.append("\t\t</font>\n");
/* 1425 */         buff.append("\t\t</td>\n");
/*      */ 
/* 1427 */         buff.append("\t\t<td width=1%>\n");
/* 1428 */         buff.append("\t\t<font face=\"" + HEADERFONT + "\" size=\"-1\" color=\"#000000\">\n");
/* 1429 */         if (i > 12)
/*      */         {
/* 1431 */           if (j == 0)
/* 1432 */             buff.append("\t\t" + (i - 12) + ":00\n");
/*      */           else {
/* 1434 */             buff.append("\t\t" + (i - 12) + ":30\n");
/*      */           }
/*      */ 
/*      */         }
/* 1438 */         else if (j == 0)
/* 1439 */           buff.append("\t\t" + i + ":00\n");
/*      */         else {
/* 1441 */           buff.append("\t\t" + i + ":30\n");
/*      */         }
/* 1443 */         buff.append("\t\t</font>\n");
/* 1444 */         buff.append("\t\t</td>\n");
/*      */ 
/* 1446 */         if (i < 10)
/* 1447 */           stime = "0" + i;
/*      */         else {
/* 1449 */           stime = "" + i;
/*      */         }
/* 1451 */         times = (Vector)datesDes.get(stime);
/*      */ 
/* 1453 */         spancount = 98;
/* 1454 */         if (times != null)
/*      */         {
/* 1456 */           for (int x = 0; x < times.size(); x++)
/*      */           {
/* 1458 */             vars = (String[])times.elementAt(x);
/* 1459 */             hour1 = i;
/* 1460 */             minute1 = Integer.parseInt(vars[1]);
/* 1461 */             hour2 = Integer.parseInt(vars[2]);
/* 1462 */             minute2 = Integer.parseInt(vars[3]);
/* 1463 */             if ((j == 0) && (minute1 < 30))
/*      */             {
/* 1465 */               if (hour2 > hour1)
/*      */               {
/* 1467 */                 rowspan = (hour2 - hour1) * 2 + 1;
/* 1468 */                 if (minute2 > 29)
/* 1469 */                   rowspan++;
/*      */               }
/* 1471 */               else if ((hour2 == hour1) && (minute2 > 29)) {
/* 1472 */                 rowspan = 2;
/*      */               } else {
/* 1474 */                 rowspan = 0;
/*      */               }
/* 1476 */               buff.append("                <td valign=top width=20% bgcolor=lightgrey rowspan=" + rowspan + ">\n");
/* 1477 */               buff.append("                <table border=1 width=100% height=100%>\n");
/* 1478 */               buff.append("                <tr>\n");
/* 1479 */               buff.append("                <td valign=top>\n");
/* 1480 */               if (javascript)
/* 1481 */                 buff.append("                &nbsp<a href=\"" + queryHref + vars[0] + ")\"><font color=" + INFOLINKCOLOR + ">" + vars[4] + "</font></a>\n");
/*      */               else
/* 1483 */                 buff.append("                &nbsp<a href=\"" + queryHref + "id=" + vars[0] + "\"><font color=" + INFOLINKCOLOR + ">" + vars[4] + "</font></a>\n");
/* 1484 */               buff.append("                </td>\n");
/* 1485 */               buff.append("                </tr>\n");
/* 1486 */               buff.append("                </table>\n");
/* 1487 */               buff.append("                </td>\n");
/*      */             }
/* 1489 */             else if ((j == 1) && (minute1 >= 30))
/*      */             {
/* 1491 */               buff.append("                <td valign=top width=20% bgcolor=lightgrey>\n");
/* 1492 */               buff.append("                <table border=1 width=100% height=100%>\n");
/* 1493 */               buff.append("                <tr>\n");
/* 1494 */               buff.append("                <td valign=top>\n");
/* 1495 */               if (javascript)
/* 1496 */                 buff.append("                &nbsp<a href=\"" + queryHref + vars[0] + ")\"><font color=" + INFOLINKCOLOR + ">" + vars[4] + "</font></a>\n");
/*      */               else
/* 1498 */                 buff.append("                &nbsp<a href=\"" + queryHref + "id=" + vars[0] + "\"><font color=" + INFOLINKCOLOR + ">" + vars[4] + "</font></a>\n");
/* 1499 */               buff.append("                </td>\n");
/* 1500 */               buff.append("                </tr>\n");
/* 1501 */               buff.append("                </table>\n");
/* 1502 */               buff.append("                </td>\n");
/*      */             }
/* 1504 */             spancount--;
/*      */           }
/*      */         }
/* 1507 */         buff.append("                <td colspan=" + spancount + ">\n");
/* 1508 */         buff.append("                &nbsp\n");
/* 1509 */         buff.append("                </td>\n");
/* 1510 */         buff.append("\t\t</tr>\n");
/*      */       }
/*      */     }
/* 1513 */     buff.append("</table>\n");
/*      */   }
/*      */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.calendar.HtmlCalendar
 * JD-Core Version:    0.6.2
 */