/*    */ package dynamic.util.calendar;
/*    */ 
/*    */ public class HtmlCalendarException extends Exception
/*    */ {
/*    */   private String outputString;
/*    */ 
/*    */   HtmlCalendarException(String name)
/*    */   {
/* 29 */     if (name.equals("CONNECTION"))
/* 30 */       this.outputString = "The java.sql.Connection CONNECTION must be enterend into the Properties object submitted to HtmlCalendar. This connection contains the database connection to the calendar info.";
/* 31 */     else if (name.equals("QUERYHREF"))
/* 32 */       this.outputString = "The String QUERYHREF must be enterend into the Properties object submitted to HtmlCalendar. This String contains the hyperlink which will direct the user to a page which is specific to a individual result from the query.";
/* 33 */     else if (name.equals("REFERINGHREF"))
/* 34 */       this.outputString = "The String REFERINGHREF must be enterend into the Properties object submitted to HtmlCalendar. This is the linkback page for navigation.  Essentially the link to whatever is calling this.";
/* 35 */     else if (name.equals("DATERANGE1"))
/* 36 */       this.outputString = "The String DATERANGE1 must be enterend into the Properties object submitted to HtmlCalendar.  The date time field for time 1.";
/* 37 */     else if (name.equals("DATERANGE2"))
/* 38 */       this.outputString = "The String DATERANGE2 must be enterend into the Properties object submitted to HtmlCalendar.  The date time field for time 2.";
/* 39 */     else if (name.equals("REQUEST"))
/* 40 */       this.outputString = "The String REQUEST must be enterend into the Properties object submitted to HtmlCalendar.  This is the user request required for navigation";
/* 41 */     else if (name.equals("PRIMARYKEY"))
/* 42 */       this.outputString = "The String PRIMARYKEY must be enterend into the Properties object submitted to HtmlCalendar.  This is the primary key field used for creation of the query href";
/* 43 */     else if (name.equals("DESCRIPTION"))
/* 44 */       this.outputString = "The String DESCRIPTION must be enterend into the Properties object submitted to HtmlCalendar.  This is the description field used for creation of the query href";
/* 45 */     else if (name.equals("FROMCLAUSE"))
/* 46 */       this.outputString = "The String FROMCLAUSE must be enterend into the Properties object submitted to HtmlCalendar.  This is the from clause used in querying the database for the query href";
/* 47 */     else if (name.equals("WHERECLAUSE"))
/* 48 */       this.outputString = "The String WHERECLAUSE must be enterend into the Properties object submitted to HtmlCalendar.  This is the from clause used in querying the database for the query href";
/*    */     else
/* 50 */       this.outputString = ("The parameter " + name + " was not inlcluded");
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 55 */     return "HtmlCalendarException: " + this.outputString;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.util.calendar.HtmlCalendarException
 * JD-Core Version:    0.6.2
 */