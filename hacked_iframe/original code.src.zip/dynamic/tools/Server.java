/*    */ package dynamic.tools;
/*    */ 
/*    */ public class Server
/*    */ {
/*    */   // ERROR //
/*    */   public static void main(java.lang.String[] args)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aconst_null
/*    */     //   1: astore_1
/*    */     //   2: new 2	java/net/ServerSocket
/*    */     //   5: dup
/*    */     //   6: bipush 88
/*    */     //   8: invokespecial 3	java/net/ServerSocket:<init>	(I)V
/*    */     //   11: astore_1
/*    */     //   12: goto +3 -> 15
/*    */     //   15: aconst_null
/*    */     //   16: astore_2
/*    */     //   17: aload_1
/*    */     //   18: invokevirtual 4	java/net/ServerSocket:accept	()Ljava/net/Socket;
/*    */     //   21: astore_2
/*    */     //   22: aload_2
/*    */     //   23: invokevirtual 5	java/net/Socket:getInputStream	()Ljava/io/InputStream;
/*    */     //   26: astore_3
/*    */     //   27: goto +33 -> 60
/*    */     //   30: aload_3
/*    */     //   31: invokevirtual 6	java/io/InputStream:read	()I
/*    */     //   34: istore 4
/*    */     //   36: iload 4
/*    */     //   38: iconst_m1
/*    */     //   39: if_icmpne +6 -> 45
/*    */     //   42: goto +25 -> 67
/*    */     //   45: getstatic 7	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   48: iload 4
/*    */     //   50: i2b
/*    */     //   51: invokevirtual 8	java/io/PrintStream:write	(I)V
/*    */     //   54: getstatic 7	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   57: invokevirtual 9	java/io/PrintStream:flush	()V
/*    */     //   60: aload_3
/*    */     //   61: invokevirtual 10	java/io/InputStream:available	()I
/*    */     //   64: ifgt -34 -> 30
/*    */     //   67: aload_2
/*    */     //   68: invokevirtual 11	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
/*    */     //   71: astore 4
/*    */     //   73: ldc 12
/*    */     //   75: astore 5
/*    */     //   77: getstatic 7	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   80: new 13	java/lang/StringBuffer
/*    */     //   83: dup
/*    */     //   84: invokespecial 14	java/lang/StringBuffer:<init>	()V
/*    */     //   87: ldc 15
/*    */     //   89: invokevirtual 16	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   92: aload 5
/*    */     //   94: invokevirtual 16	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   97: invokevirtual 17	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*    */     //   100: invokevirtual 18	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   103: aload 4
/*    */     //   105: aload 5
/*    */     //   107: invokevirtual 19	java/lang/String:getBytes	()[B
/*    */     //   110: invokevirtual 20	java/io/OutputStream:write	([B)V
/*    */     //   113: jsr +28 -> 141
/*    */     //   116: goto +50 -> 166
/*    */     //   119: astore_3
/*    */     //   120: aload_3
/*    */     //   121: getstatic 22	java/lang/System:err	Ljava/io/PrintStream;
/*    */     //   124: invokevirtual 23	java/lang/Throwable:printStackTrace	(Ljava/io/PrintStream;)V
/*    */     //   127: jsr +14 -> 141
/*    */     //   130: goto +36 -> 166
/*    */     //   133: astore 6
/*    */     //   135: jsr +6 -> 141
/*    */     //   138: aload 6
/*    */     //   140: athrow
/*    */     //   141: astore 7
/*    */     //   143: aload_2
/*    */     //   144: ifnull +7 -> 151
/*    */     //   147: aload_2
/*    */     //   148: invokevirtual 24	java/net/Socket:close	()V
/*    */     //   151: goto +13 -> 164
/*    */     //   154: astore 8
/*    */     //   156: aload 8
/*    */     //   158: getstatic 22	java/lang/System:err	Ljava/io/PrintStream;
/*    */     //   161: invokevirtual 23	java/lang/Throwable:printStackTrace	(Ljava/io/PrintStream;)V
/*    */     //   164: ret 7
/*    */     //   166: goto -151 -> 15
/*    */     //   169: astore_2
/*    */     //   170: aload_2
/*    */     //   171: getstatic 22	java/lang/System:err	Ljava/io/PrintStream;
/*    */     //   174: invokevirtual 23	java/lang/Throwable:printStackTrace	(Ljava/io/PrintStream;)V
/*    */     //   177: jsr +14 -> 191
/*    */     //   180: goto +36 -> 216
/*    */     //   183: astore 9
/*    */     //   185: jsr +6 -> 191
/*    */     //   188: aload 9
/*    */     //   190: athrow
/*    */     //   191: astore 10
/*    */     //   193: aload_1
/*    */     //   194: ifnull +7 -> 201
/*    */     //   197: aload_1
/*    */     //   198: invokevirtual 25	java/net/ServerSocket:close	()V
/*    */     //   201: goto +13 -> 214
/*    */     //   204: astore 11
/*    */     //   206: aload 11
/*    */     //   208: getstatic 22	java/lang/System:err	Ljava/io/PrintStream;
/*    */     //   211: invokevirtual 23	java/lang/Throwable:printStackTrace	(Ljava/io/PrintStream;)V
/*    */     //   214: ret 10
/*    */     //   216: return
/*    */     //
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   17	113	119	java/lang/Exception
/*    */     //   17	133	133	finally
/*    */     //   143	151	154	java/lang/Exception
/*    */     //   2	169	169	java/lang/Exception
/*    */     //   2	183	183	finally
/*    */     //   193	201	204	java/lang/Exception
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.tools.Server
 * JD-Core Version:    0.6.2
 */