/*     */ package dynamic.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ public class MakeJPR
/*     */ {
/*  12 */   private static int id = 0;
/*  13 */   private static int pathLength = 0;
/*     */ 
/*     */   private static void doit(File d, int parent_id, StringBuffer files, StringBuffer properties)
/*     */   {
/*  17 */     String[] l = d.list();
/*  18 */     for (int i = 0; i < l.length; i++)
/*     */     {
/*  20 */       File f = new File(d, l[i]);
/*  21 */       int myid = ++id;
/*  22 */       String t = f.toString();
/*  23 */       if (f.isDirectory())
/*     */       {
/*  25 */         t = t.substring(d.toString().length() + 1);
/*  26 */         files.append("#" + id + "=" + t + "\r\n");
/*  27 */         properties.append("sys[" + myid + "].Parent=" + parent_id + "\r\n");
/*  28 */         properties.append("sys[" + myid + "].Type=Folder\r\n");
/*  29 */         doit(f, myid, files, properties);
/*     */       }
/*     */       else
/*     */       {
/*  34 */         files.append("#" + id + "=" + t + "\r\n");
/*  35 */         properties.append("sys[" + myid + "].Parent=" + parent_id + "\r\n");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void usage()
/*     */   {
/*  42 */     usage(null);
/*     */   }
/*     */ 
/*     */   private static void usage(String problem)
/*     */   {
/*  47 */     if (problem != null) System.err.println(problem);
/*  48 */     System.err.println("Usage: makejpr jprname.jpr directory");
/*  49 */     System.exit(1);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception
/*     */   {
/*  54 */     if (args.length < 2) usage();
/*  55 */     String projectName = args[0];
/*  56 */     FileOutputStream fos = new FileOutputStream(projectName);
/*  57 */     PrintWriter o = new PrintWriter(fos);
/*  58 */     String directory = args[1];
/*  59 */     File f = new File(directory);
/*  60 */     pathLength = f.toString().length() + 1;
/*  61 */     if (!f.exists()) System.err.println("Directory " + f + " does not exist.");
/*  62 */     if (!f.isDirectory()) System.err.println("Directory " + f + " is not a directory.");
/*  63 */     StringBuffer files = new StringBuffer();
/*  64 */     StringBuffer properties = new StringBuffer();
/*  65 */     doit(f, 0, files, properties);
/*  66 */     o.println(";JBuilder -- PROJECT FILE VERSION {2.00} - do not alter this line!");
/*  67 */     o.println("#0=" + projectName);
/*  68 */     o.print(files);
/*  69 */     o.println("idl[0].ProcessIDL=false");
/*  70 */     o.println("jbuilder.debug[0].NoTracingClasses.1=,java.*,1");
/*  71 */     o.println("jbuilder.debug[0].NoTracingClasses.10=,com.borland.jbuilder.runtime,1");
/*  72 */     o.println("jbuilder.debug[0].NoTracingClasses.11=,com.inprise.vbroker,1");
/*  73 */     o.println("jbuilder.debug[0].NoTracingClasses.12=,com.visigenic,1");
/*  74 */     o.println("jbuilder.debug[0].NoTracingClasses.13=,org.omg,1");
/*  75 */     o.println("jbuilder.debug[0].NoTracingClasses.2=,javax.*,1");
/*  76 */     o.println("jbuilder.debug[0].NoTracingClasses.3=,sun.*,1");
/*  77 */     o.println("jbuilder.debug[0].NoTracingClasses.4=,com.sun.*,1");
/*  78 */     o.println("jbuilder.debug[0].NoTracingClasses.5=,com.borland.jbcl,1");
/*  79 */     o.println("jbuilder.debug[0].NoTracingClasses.6=,com.borland.sql,1");
/*  80 */     o.println("jbuilder.debug[0].NoTracingClasses.7=,com.borland.dbswing,1");
/*  81 */     o.println("jbuilder.debug[0].NoTracingClasses.8=,com.borland.datastore,1");
/*  82 */     o.println("jbuilder.debug[0].NoTracingClasses.9=,com.borland.dx,1");
/*  83 */     o.println("jbuilder.debug[0].ShowBreakpointInNoTracingClass=0");
/*  84 */     o.println("jbuilder.debug[0].SmartStepSkipStaticInitializers=0");
/*  85 */     o.println("jbuilder.debug[0].SmartStepSkipSynthetics=0");
/*  86 */     o.println("runtime.0[0].RunnableType=com.borland.jbuilder.runtime.ApplicationRunner");
/*  87 */     o.println("sys[0].Author=");
/*  88 */     o.println("sys[0].BeansInstantiate=false");
/*  89 */     o.println("sys[0].BraceStyle=1");
/*  90 */     o.println("sys[0].ClassPath=");
/*  91 */     o.println("sys[0].Company=");
/*  92 */     o.println("sys[0].Copyright=Copyright (c) ");
/*  93 */     o.println("sys[0].Description=");
/*  94 */     o.println("sys[0].DocPath=docs");
/*  95 */     o.println("sys[0].EventMatch=false");
/*  96 */     o.println("sys[0].EventStyle=1");
/*  97 */     o.println("sys[0].InstanceVisibility=0");
/*  98 */     o.println("sys[0].JDK=java version \"1.2.2\"");
/*  99 */     o.println("sys[0].LastTag=6");
/* 100 */     o.println("sys[0].Libraries=imports");
/* 101 */     o.println("sys[0].OutPath=classes");
/* 102 */     o.println("sys[0].SourcePath=" + f);
/* 103 */     o.println("sys[0].Title=");
/* 104 */     o.println("sys[0].Version=1.0");
/* 105 */     o.println(properties);
/* 106 */     o.close();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.tools.MakeJPR
 * JD-Core Version:    0.6.2
 */