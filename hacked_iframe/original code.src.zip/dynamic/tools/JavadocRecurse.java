/*    */ package dynamic.tools;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ 
/*    */ public class JavadocRecurse
/*    */ {
/*    */   static PrintWriter writer;
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 19 */     if (args.length < 2) {
/* 20 */       System.out.println("First command line argument is the destination file");
/* 21 */       System.out.println("where the package names will be stored");
/* 22 */       System.out.println("Rest of the arguments are directory paths to the packages");
/* 23 */       System.out.println("Example:");
/* 24 */       System.out.println("java JavadocRecurse packages.txt rootdir1 rootdir2 rootdirN");
/*    */ 
/* 26 */       return;
/*    */     }
/*    */     try
/*    */     {
/* 30 */       writer = new PrintWriter(new BufferedWriter(new FileWriter(args[0])));
/* 31 */       for (int i = 1; i < args.length; i++) {
/* 32 */         File root = new File(args[i]);
/* 33 */         if (root.isDirectory()) {
/* 34 */           writeDirs(root, root);
/*    */         }
/*    */       }
/* 37 */       writer.close();
/*    */     } catch (IOException ex) {
/* 39 */       ex.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private static void writeDirs(File root, File dir) {
/* 44 */     String[] files = dir.list();
/* 45 */     boolean fileFound = true;
/* 46 */     for (int i = 0; i < files.length; i++) {
/* 47 */       File file = new File(dir, files[i]);
/* 48 */       if (file.isDirectory()) {
/* 49 */         writeDirs(root, file);
/* 50 */       } else if ((fileFound) && ((files[i].endsWith(".class")) || (files[i].endsWith(".java"))))
/*    */       {
/* 53 */         fileFound = false;
/* 54 */         if (!root.equals(dir))
/*    */         {
/* 58 */           writer.println(dir.getPath().substring(root.getPath().length() + 1).replace(File.separatorChar, '.'));
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.tools.JavadocRecurse
 * JD-Core Version:    0.6.2
 */