/*    */ package dynamic;
/*    */ 
/*    */ import dynamic.util.date.StdDate;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   private static final String author = "$Author: Ara Bulbulian$";
/*    */   private static final String date = "$Date: 8/15/01 5:55:52 PM$";
/*    */   private static final String project = "$Project: iFrame2$";
/*    */   private static final String revision = "$Revision: 10$";
/*    */   private static final String version = "2.06";
/*    */ 
/*    */   public static String getAuthor()
/*    */   {
/* 21 */     return "$Author: Ara Bulbulian$".substring(9, "$Author: Ara Bulbulian$".length() - 1);
/*    */   }
/*    */ 
/*    */   public static String getDateString()
/*    */   {
/* 26 */     return "$Date: 8/15/01 5:55:52 PM$".substring(7, "$Date: 8/15/01 5:55:52 PM$".length() - 1);
/*    */   }
/*    */ 
/*    */   public static String getDate()
/*    */   {
/* 31 */     String result = "";
/*    */     try { result = new StdDate(getDateString()).trunc().toString(); } catch (Exception e) {
/* 33 */     }return result;
/*    */   }
/*    */ 
/*    */   public static String getDateTime()
/*    */   {
/* 38 */     String result = "";
/*    */     try { result = new StdDate(getDateString()).toString(); } catch (Exception e) {
/* 40 */     }return result;
/*    */   }
/*    */ 
/*    */   public static String getTime()
/*    */   {
/* 45 */     String result = "";
/*    */     try { result = new StdDate(getDateString()).toString("h:mm a"); } catch (Exception e) {
/* 47 */     }return result;
/*    */   }
/*    */ 
/*    */   public static String getProject()
/*    */   {
/* 52 */     return "$Project: iFrame2$".substring(10, "$Project: iFrame2$".length() - 1);
/*    */   }
/*    */ 
/*    */   public static String getRevision()
/*    */   {
/* 57 */     String result = "$Revision: 10$".substring(11, "$Revision: 10$".length() - 1);
/* 58 */     if (result.length() == 1) result = "00" + result;
/* 59 */     if (result.length() == 2) result = "0" + result;
/* 60 */     return result;
/*    */   }
/*    */ 
/*    */   public static String getVersion()
/*    */   {
/* 65 */     return "2.06." + getRevision();
/*    */   }
/*    */ 
/*    */   public static String getFullVersion()
/*    */   {
/* 70 */     return getProject() + " " + getVersion() + " (" + getDate() + ")";
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 75 */     return getFullVersion();
/*    */   }
/*    */ 
/*    */   public static void main(String[] argv)
/*    */   {
/* 80 */     System.out.println(new Version().toString());
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.Version
 * JD-Core Version:    0.6.2
 */