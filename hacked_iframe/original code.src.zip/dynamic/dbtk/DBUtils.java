/*    */ package dynamic.dbtk;
/*    */ 
/*    */ import dynamic.dbtk.connection.ConnectionWrapper;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.handlers.ErrorHandler;
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.ResultSet;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ public class DBUtils
/*    */ {
/*    */   public static boolean isView(InvocationContext ic, ConnectionWrapper conn, String aTableName, String aSchema)
/*    */   {
/* 25 */     boolean result = false;
/* 26 */     if (conn != null)
/*    */     {
/* 28 */       Hashtable list_of_views = (Hashtable)ic.getSessionDatum(conn.getName().toLowerCase() + ":list_of_views");
/* 29 */       if (list_of_views == null)
/*    */       {
/* 31 */         list_of_views = new Hashtable();
/*    */         try
/*    */         {
/* 34 */           DatabaseMetaData db_metadata = conn.getMetaData();
/*    */ 
/* 36 */           String[] types = new String[2];
/* 37 */           types[0] = ""; types[1] = "VIEW";
/* 38 */           ResultSet table_names = db_metadata.getTables(null, aSchema, "%", types);
/*    */ 
/* 40 */           while (table_names.next())
/*    */           {
/* 43 */             if (table_names.getString("TABLE_TYPE").equalsIgnoreCase("view")) {
/* 44 */               list_of_views.put(table_names.getString("TABLE_NAME").toLowerCase(), "");
/*    */             }
/*    */           }
/* 47 */           ic.setSessionDatum(conn.getName().toLowerCase() + ":list_of_views", list_of_views);
/*    */         }
/*    */         catch (Exception e)
/*    */         {
/* 51 */           ErrorHandler.handleException(ic, e, "MetaData.isView() failed to get DatabaseMetaData from conneection.");
/*    */         }
/*    */         finally
/*    */         {
/* 55 */           conn.release();
/*    */         }
/*    */       }
/* 58 */       result = list_of_views.containsKey(aTableName.toLowerCase());
/*    */     }
/* 60 */     return result;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.DBUtils
 * JD-Core Version:    0.6.2
 */