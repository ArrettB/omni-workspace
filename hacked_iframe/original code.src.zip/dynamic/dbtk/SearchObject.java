/*     */ package dynamic.dbtk;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SearchObject
/*     */ {
/*     */   private static final String GROUPBY = "\"";
/*  41 */   private static final Vector AND = new Vector();
/*  42 */   private static final Vector OR = new Vector();
/*     */   private static final String EXCLUSION = "-";
/*     */ 
/*     */   public static String getClause(String comparison, Vector columns)
/*     */   {
/*  61 */     StringBuffer buff = new StringBuffer();
/*  62 */     getClause(comparison, columns, buff);
/*  63 */     return buff.toString();
/*     */   }
/*     */ 
/*     */   public static void getClause(String comparison, Vector columns, StringBuffer buff)
/*     */   {
/*  74 */     Vector tokens = new Vector();
/*     */ 
/*  76 */     int beginIndex = 0;
/*  77 */     int endIndex = 0;
/*  78 */     int priorIndex = 0;
/*  79 */     boolean andPrecedence = false;
/*     */     StringTokenizer st;
/*     */     while (true)
/*     */     {
/*  85 */       beginIndex = comparison.indexOf("\"", priorIndex);
/*  86 */       if (beginIndex == -1) {
/*     */         break;
/*     */       }
/*  89 */       endIndex = comparison.indexOf("\"", beginIndex + 1);
/*  90 */       if (endIndex == -1) {
/*     */         break;
/*     */       }
/*  93 */       if (priorIndex < beginIndex)
/*     */       {
/*  95 */         String result = comparison.substring(priorIndex, beginIndex).trim();
/*  96 */         st = new StringTokenizer(result);
/*  97 */         while (st.hasMoreTokens())
/*     */         {
/*  99 */           result = st.nextToken();
/* 100 */           result = strip(result);
/* 101 */           if (result != null)
/*     */           {
/* 103 */             if (AND.contains(result.toLowerCase()))
/* 104 */               andPrecedence = true;
/* 105 */             else if (!result.equalsIgnoreCase("-")) {
/* 106 */               tokens.addElement(result);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 112 */       String result = strip(comparison.substring(beginIndex + 1, endIndex).trim());
/*     */ 
/* 114 */       if ((beginIndex > 0) && (comparison.substring(beginIndex - 1, beginIndex).equalsIgnoreCase("-"))) {
/* 115 */         result = "-" + result;
/*     */       }
/* 117 */       if (result != null)
/*     */       {
/* 119 */         tokens.addElement(result);
/*     */       }
/*     */ 
/* 122 */       endIndex++; priorIndex = endIndex;
/*     */     }
/*     */ 
/* 127 */     if (priorIndex < comparison.length())
/*     */     {
/* 130 */       String result = strip(comparison.substring(priorIndex, comparison.length()));
/*     */ 
/* 132 */       st = new StringTokenizer(result);
/* 133 */       while (st.hasMoreTokens())
/*     */       {
/* 135 */         result = st.nextToken();
/* 136 */         result = strip(result);
/* 137 */         if (result != null)
/*     */         {
/* 139 */           if (AND.contains(result.toLowerCase()))
/* 140 */             andPrecedence = true;
/* 141 */           else if (!result.equalsIgnoreCase("-")) {
/* 142 */             tokens.addElement(result);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 149 */     boolean firstLoop = true;
/* 150 */     boolean not = false;
/* 151 */     StringBuffer notBuff = new StringBuffer();
/* 152 */     boolean logOr = false;
/*     */ 
/* 154 */     if (tokens.size() <= 1) {
/* 155 */       andPrecedence = true;
/*     */     }
/* 157 */     for (int i = 0; i < tokens.size(); i++)
/*     */     {
/* 159 */       firstLoop = true;
/* 160 */       String value = (String)tokens.elementAt(i);
/* 161 */       if (value.startsWith("-"))
/*     */       {
/* 163 */         value = value.substring(1, value.length());
/* 164 */         not = true;
/*     */       }
/*     */       else
/*     */       {
/* 168 */         not = false;
/*     */       }
/*     */ 
/* 171 */       for (int j = 0; j < columns.size(); j++)
/*     */       {
/* 173 */         String colName = (String)columns.elementAt(j);
/* 174 */         if (andPrecedence)
/*     */         {
/* 176 */           if (not)
/*     */           {
/* 178 */             if (firstLoop)
/* 179 */               buff.append("(lower(" + colName + ") not like lower(" + mutate(value) + ") \n");
/* 180 */             else if ((j == columns.size() - 1) && (i != tokens.size() - 1))
/* 181 */               buff.append("and lower(" + colName + ") not like lower(" + mutate(value) + ")) and \n");
/* 182 */             else if ((j == columns.size() - 1) && (i == tokens.size() - 1))
/* 183 */               buff.append("and lower(" + colName + ") not like lower(" + mutate(value) + "))");
/*     */             else {
/* 185 */               buff.append("and lower(" + colName + ") not like lower(" + mutate(value) + ") \n");
/*     */             }
/*     */ 
/*     */           }
/* 189 */           else if (firstLoop)
/* 190 */             buff.append("(lower(" + colName + ") like lower(" + mutate(value) + ") \n");
/* 191 */           else if ((j == columns.size() - 1) && (i != tokens.size() - 1))
/* 192 */             buff.append("or lower(" + colName + ") like lower(" + mutate(value) + ")) and \n");
/* 193 */           else if ((j == columns.size() - 1) && (i == tokens.size() - 1))
/* 194 */             buff.append("or lower(" + colName + ") like lower(" + mutate(value) + "))");
/*     */           else {
/* 196 */             buff.append("or lower(" + colName + ") like lower(" + mutate(value) + ") \n");
/*     */           }
/*     */ 
/* 199 */           firstLoop = false;
/*     */         }
/*     */         else
/*     */         {
/* 203 */           if (not)
/*     */           {
/* 205 */             if (firstLoop)
/* 206 */               notBuff.append("(lower(" + colName + ") not like lower(" + mutate(value) + ") \n");
/* 207 */             else if ((j == columns.size() - 1) && (i == tokens.size() - 1))
/* 208 */               notBuff.append("and lower(" + colName + ") not like lower(" + mutate(value) + "))");
/* 209 */             else if ((j == columns.size() - 1) && (i != tokens.size() - 1))
/* 210 */               notBuff.append("and lower(" + colName + ") not like lower(" + mutate(value) + ")) and \n");
/*     */             else
/* 212 */               notBuff.append("and lower(" + colName + ") not like lower(" + mutate(value) + ") \n");
/*     */           }
/*     */           else
/*     */           {
/* 216 */             logOr = true;
/* 217 */             if (firstLoop)
/* 218 */               buff.append("(lower(" + colName + ") like lower(" + mutate(value) + ") \n");
/* 219 */             else if ((j == columns.size() - 1) && (i == tokens.size() - 1))
/* 220 */               buff.append("or lower(" + colName + ") like lower(" + mutate(value) + "))");
/* 221 */             else if ((j == columns.size() - 1) && (i != tokens.size() - 1))
/* 222 */               buff.append("or lower(" + colName + ") like lower(" + mutate(value) + ")) or \n");
/*     */             else {
/* 224 */               buff.append("or lower(" + colName + ") like lower(" + mutate(value) + ") \n");
/*     */             }
/*     */           }
/* 227 */           firstLoop = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 232 */     if (notBuff.length() > 0)
/*     */     {
/* 234 */       String s = buff.toString();
/* 235 */       if (s.endsWith("or \n"))
/* 236 */         s = s.substring(0, s.length() - 5);
/* 237 */       buff.setLength(0);
/* 238 */       buff.append(s);
/*     */ 
/* 240 */       if (logOr)
/* 241 */         buff.append("\n and ");
/* 242 */       s = notBuff.toString();
/* 243 */       if (s.endsWith("and \n"))
/* 244 */         s = s.substring(0, s.length() - 6);
/* 245 */       buff.append(s);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String strip(String result)
/*     */   {
/* 257 */     if (result.indexOf("\"") != -1) {
/* 258 */       result = result.replace('"', ' ');
/*     */     }
/* 260 */     result = result.trim();
/* 261 */     if ((!result.equals("")) && (result.length() > 0) && (!OR.contains(result.toLowerCase()))) {
/* 262 */       return result;
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   private static String mutate(String result)
/*     */   {
/* 275 */     char tick = '\'';
/* 276 */     StringBuffer sb = new StringBuffer(result);
/* 277 */     int idx = result.indexOf(tick);
/* 278 */     if (idx > -1)
/*     */     {
/* 280 */       while (idx > -1)
/*     */       {
/* 282 */         sb.insert(idx, tick);
/* 283 */         idx = sb.toString().indexOf(tick, idx + 2);
/*     */       }
/*     */     }
/* 286 */     sb.append("%'");
/* 287 */     sb.insert(0, "'%");
/* 288 */     result = sb.toString();
/* 289 */     return result;
/*     */   }
/*     */ 
/*     */   public static String replace(String replaceInto, String replaceWhat, String replaceWith)
/*     */   {
/* 301 */     StringBuffer sbuff = new StringBuffer();
/* 302 */     int position1 = 0;
/* 303 */     int prior = 0;
/* 304 */     boolean inServer = false;
/*     */ 
/* 306 */     String lowerFile = replaceInto.toLowerCase();
/*     */ 
/* 308 */     position1 = lowerFile.indexOf(replaceWhat, 0);
/* 309 */     if (position1 != -1)
/*     */     {
/* 311 */       for (int i = position1 - 1; i < lowerFile.length(); i++)
/*     */       {
/* 313 */         position1 = lowerFile.indexOf(replaceWhat, i);
/* 314 */         if (position1 == -1)
/*     */         {
/* 316 */           sbuff.append(replaceInto.substring(prior));
/* 317 */           break;
/*     */         }
/*     */ 
/* 320 */         sbuff.append(replaceInto.substring(prior, position1));
/*     */ 
/* 322 */         sbuff.append(replaceWith);
/* 323 */         prior = position1 + replaceWhat.length();
/*     */ 
/* 325 */         i = position1 + 1;
/*     */       }
/*     */     }
/*     */     else {
/* 329 */       return replaceInto;
/*     */     }
/* 331 */     return sbuff.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  47 */     AND.addElement("and");
/*  48 */     AND.addElement("&");
/*  49 */     AND.addElement("+");
/*  50 */     OR.addElement("or");
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.SearchObject
 * JD-Core Version:    0.6.2
 */