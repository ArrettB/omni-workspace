/*     */ package dynamic.dbtk.connection;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.sql.Date;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class QueryResults
/*     */ {
/*     */   private ConnectionWrapper conn;
/*     */   private ResultSet rs;
/*     */   private Statement stmt;
/*     */ 
/*     */   public QueryResults()
/*     */     throws SQLException
/*     */   {
/*     */   }
/*     */ 
/*     */   public QueryResults(ConnectionWrapper conn, Statement stmt, ResultSet rs)
/*     */     throws SQLException
/*     */   {
/*  42 */     this.conn = conn;
/*  43 */     this.rs = rs;
/*  44 */     this.stmt = stmt;
/*     */   }
/*     */ 
/*     */   public ConnectionWrapper getConnection()
/*     */   {
/*  53 */     return this.conn;
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */   {
/*  62 */     return this.rs;
/*     */   }
/*     */ 
/*     */   public Statement getStatement()
/*     */   {
/*  72 */     return this.stmt;
/*     */   }
/*     */ 
/*     */   public boolean next()
/*     */     throws SQLException
/*     */   {
/*  92 */     return this.rs.next();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 111 */     this.rs.close();
/* 112 */     this.stmt.close();
/* 113 */     this.conn.removeStatement(this.stmt);
/*     */   }
/*     */ 
/*     */   public boolean wasNull()
/*     */     throws SQLException
/*     */   {
/* 128 */     return this.rs.wasNull();
/*     */   }
/*     */ 
/*     */   public Object getObject(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 144 */     return this.rs.getObject(columnIndex);
/*     */   }
/*     */ 
/*     */   public String getString(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 156 */     return this.rs.getString(columnIndex);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 168 */     return this.rs.getBoolean(columnIndex);
/*     */   }
/*     */ 
/*     */   public byte getByte(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 180 */     return this.rs.getByte(columnIndex);
/*     */   }
/*     */ 
/*     */   public short getShort(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 192 */     return this.rs.getShort(columnIndex);
/*     */   }
/*     */ 
/*     */   public int getInt(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 204 */     return this.rs.getInt(columnIndex);
/*     */   }
/*     */ 
/*     */   public long getLong(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 216 */     return this.rs.getLong(columnIndex);
/*     */   }
/*     */ 
/*     */   public float getFloat(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 228 */     return this.rs.getFloat(columnIndex);
/*     */   }
/*     */ 
/*     */   public double getDouble(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 240 */     return this.rs.getDouble(columnIndex);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public byte[] getBytes(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 270 */     return this.rs.getBytes(columnIndex);
/*     */   }
/*     */ 
/*     */   public Date getDate(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 282 */     return this.rs.getDate(columnIndex);
/*     */   }
/*     */ 
/*     */   public Time getTime(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 294 */     return this.rs.getTime(columnIndex);
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 306 */     return this.rs.getTimestamp(columnIndex);
/*     */   }
/*     */ 
/*     */   public InputStream getAsciiStream(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 331 */     return this.rs.getAsciiStream(columnIndex);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public InputStream getBinaryStream(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 387 */     return this.rs.getBinaryStream(columnIndex);
/*     */   }
/*     */ 
/*     */   public Object getObject(String columnName)
/*     */     throws SQLException
/*     */   {
/* 404 */     return this.rs.getObject(columnName);
/*     */   }
/*     */ 
/*     */   public String getString(String columnName)
/*     */     throws SQLException
/*     */   {
/* 416 */     return this.rs.getString(columnName);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String columnName)
/*     */     throws SQLException
/*     */   {
/* 428 */     return this.rs.getBoolean(columnName);
/*     */   }
/*     */ 
/*     */   public byte getByte(String columnName)
/*     */     throws SQLException
/*     */   {
/* 440 */     return this.rs.getByte(columnName);
/*     */   }
/*     */ 
/*     */   public short getShort(String columnName)
/*     */     throws SQLException
/*     */   {
/* 452 */     return this.rs.getShort(columnName);
/*     */   }
/*     */ 
/*     */   public int getInt(String columnName)
/*     */     throws SQLException
/*     */   {
/* 464 */     return this.rs.getInt(columnName);
/*     */   }
/*     */ 
/*     */   public long getLong(String columnName)
/*     */     throws SQLException
/*     */   {
/* 476 */     return this.rs.getLong(columnName);
/*     */   }
/*     */ 
/*     */   public float getFloat(String columnName)
/*     */     throws SQLException
/*     */   {
/* 488 */     return this.rs.getFloat(columnName);
/*     */   }
/*     */ 
/*     */   public double getDouble(String columnName)
/*     */     throws SQLException
/*     */   {
/* 500 */     return this.rs.getDouble(columnName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public byte[] getBytes(String columnName)
/*     */     throws SQLException
/*     */   {
/* 531 */     return this.rs.getBytes(columnName);
/*     */   }
/*     */ 
/*     */   public Date getDate(String columnName)
/*     */     throws SQLException
/*     */   {
/* 543 */     return this.rs.getDate(columnName);
/*     */   }
/*     */ 
/*     */   public Time getTime(String columnName)
/*     */     throws SQLException
/*     */   {
/* 555 */     return this.rs.getTime(columnName);
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(String columnName)
/*     */     throws SQLException
/*     */   {
/* 567 */     return this.rs.getTimestamp(columnName);
/*     */   }
/*     */ 
/*     */   public InputStream getAsciiStream(String columnName)
/*     */     throws SQLException
/*     */   {
/* 592 */     return this.rs.getAsciiStream(columnName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public InputStream getBinaryStream(String columnName)
/*     */     throws SQLException
/*     */   {
/* 650 */     return this.rs.getBinaryStream(columnName);
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 676 */     return this.rs.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 687 */     this.rs.clearWarnings();
/*     */   }
/*     */ 
/*     */   public String getCursorName()
/*     */     throws SQLException
/*     */   {
/* 713 */     return this.rs.getCursorName();
/*     */   }
/*     */ 
/*     */   public ResultSetMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 724 */     return this.rs.getMetaData();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.connection.QueryResults
 * JD-Core Version:    0.6.2
 */