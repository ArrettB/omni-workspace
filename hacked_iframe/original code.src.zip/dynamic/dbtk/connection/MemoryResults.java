/*     */ package dynamic.dbtk.connection;
/*     */ 
/*     */ import dynamic.util.date.StdDate;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class MemoryResults extends QueryResults
/*     */ {
/*  28 */   Vector v = null;
/*  29 */   int counter = -1;
/*     */   private MemoryMetaData rsmd;
/*  31 */   int numRows = 0;
/*  32 */   int startWith = 0;
/*  33 */   int offset = 0;
/*     */ 
/*     */   public MemoryResults() throws SQLException
/*     */   {
/*     */   }
/*     */ 
/*     */   public MemoryResults(Object o) throws SQLException
/*     */   {
/*  41 */     this(o, 0, 0);
/*     */   }
/*     */ 
/*     */   public MemoryResults(Object o, int startWith, int numRows) throws SQLException
/*     */   {
/*  46 */     this.rsmd = new MemoryMetaData();
/*  47 */     this.startWith = startWith;
/*  48 */     this.numRows = numRows;
/*  49 */     if ((o instanceof Vector))
/*     */     {
/*  51 */       this.v = ((Vector)o);
/*  52 */       if (numRows == 0) numRows = this.v.size(); 
/*     */     }
/*     */     else
/*     */     {
/*  55 */       throw new SQLException("Unsupported source type \"" + o.getClass().getName() + "\" for MemoryResults");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  94 */     if (this.v == null) return "";
/*  95 */     return this.v.toString();
/*     */   }
/*     */ 
/*     */   Field getFieldByString(String name) throws SQLException
/*     */   {
/* 100 */     if (this.counter == -1) throw new SQLException("MemoryResults.next was not called");
/*     */ 
/*     */     try
/*     */     {
/* 104 */       return this.v.elementAt(this.counter).getClass().getField(name);
/*     */     }
/*     */     catch (NoSuchFieldException e) {
/*     */     }
/* 108 */     throw new SQLException("Invalid column name");
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 114 */     return this.numRows;
/*     */   }
/*     */ 
/*     */   Object currentElement()
/*     */   {
/* 119 */     if (this.v == null) return null;
/* 120 */     return this.v.elementAt(this.counter);
/*     */   }
/*     */ 
/*     */   public boolean next()
/*     */     throws SQLException
/*     */   {
/* 144 */     if (this.offset < this.startWith)
/*     */     {
/* 146 */       this.offset += 1;
/* 147 */       return true;
/*     */     }
/*     */ 
/* 151 */     this.counter += 1;
/* 152 */     if (this.counter < this.v.size())
/* 153 */       return true;
/* 154 */     if (this.counter == this.v.size()) {
/* 155 */       return false;
/*     */     }
/* 157 */     throw new SQLException();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 168 */     this.v = null;
/*     */   }
/*     */ 
/*     */   public boolean wasNull()
/*     */     throws SQLException
/*     */   {
/* 183 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public Object getObject(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 206 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public String getString(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 218 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 230 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public byte getByte(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 242 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public short getShort(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 254 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public int getInt(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 266 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public long getLong(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 278 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public float getFloat(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 290 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public double getDouble(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 302 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public byte[] getBytes(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 332 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public java.sql.Date getDate(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 344 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public Time getTime(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 356 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 368 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public InputStream getAsciiStream(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 393 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public InputStream getBinaryStream(int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 448 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public Object getObject(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 468 */       return getFieldByString(fieldName).get(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 472 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getString(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 487 */       Object o = getFieldByString(fieldName).get(currentElement());
/* 488 */       if (o == null) return null;
/* 489 */       return o.toString();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 493 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 508 */       return getFieldByString(fieldName).getBoolean(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 512 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte getByte(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 527 */       return getFieldByString(fieldName).getByte(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 531 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public short getShort(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 546 */       return getFieldByString(fieldName).getShort(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 550 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getInt(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 566 */       return getFieldByString(fieldName).getInt(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 570 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLong(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 585 */       return getFieldByString(fieldName).getLong(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 589 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public float getFloat(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 604 */       return getFieldByString(fieldName).getFloat(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 608 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public double getDouble(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 623 */       return getFieldByString(fieldName).getDouble(currentElement());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 627 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public byte[] getBytes(String columnName)
/*     */     throws SQLException
/*     */   {
/* 659 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public java.sql.Date getDate(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 674 */       Object o = getFieldByString(fieldName).get(currentElement());
/* 675 */       if (o == null) return null;
/* 676 */       if ((o instanceof java.sql.Date)) return (java.sql.Date)o;
/* 677 */       if (o.toString().length() > 0) return new java.sql.Date(new StdDate(o.toString()).getTime());
/* 678 */       return null;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 682 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Time getTime(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 697 */       Object o = getFieldByString(fieldName).get(currentElement());
/* 698 */       if (o == null) return null;
/* 699 */       if ((o instanceof Time)) return (Time)o;
/* 700 */       if (o.toString().length() > 0) return new Time(new StdDate(o.toString()).getTime());
/* 701 */       return null;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 705 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(String fieldName)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 720 */       Object o = getFieldByString(fieldName).get(currentElement());
/* 721 */       if (o == null) return null;
/* 722 */       if ((o instanceof Timestamp)) return (Timestamp)o;
/* 723 */       if (o.toString().length() > 0) return new Timestamp(new StdDate(o.toString()).getTime());
/* 724 */       return null;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 728 */       throw new SQLException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public InputStream getAsciiStream(String fieldName)
/*     */     throws SQLException
/*     */   {
/* 754 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public InputStream getBinaryStream(String columnName)
/*     */     throws SQLException
/*     */   {
/* 812 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 838 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 850 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public String getCursorName()
/*     */     throws SQLException
/*     */   {
/* 877 */     throw new SQLException("Not supported");
/*     */   }
/*     */ 
/*     */   public ResultSetMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 890 */     return this.rsmd.getMetaData();
/*     */   }
/*     */ 
/*     */   class MemoryMetaData
/*     */     implements ResultSetMetaData
/*     */   {
/*     */     public static final int columnNoNulls = 0;
/*     */     public static final int columnNullable = 0;
/*     */     public static final int columnNullableUnknown = 0;
/*     */ 
/*     */     public MemoryMetaData()
/*     */     {
/*     */     }
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/*  68 */       return 0; } 
/*  69 */     public boolean isAutoIncrement(int column) { return false; } 
/*  70 */     public boolean isCaseSensitive(int column) { return false; } 
/*  71 */     public boolean isSearchable(int column) { return false; } 
/*  72 */     public boolean isCurrency(int column) { return false; } 
/*  73 */     public int isNullable(int column) { return 0; } 
/*  74 */     public boolean isSigned(int column) { return false; } 
/*  75 */     public int getColumnDisplaySize(int column) { return 0; } 
/*  76 */     public String getColumnLabel(int column) { return ""; } 
/*  77 */     public String getColumnName(int column) { return ""; } 
/*  78 */     public String getSchemaName(int column) { return ""; } 
/*  79 */     public int getPrecision(int column) { return 2; } 
/*  80 */     public int getScale(int column) { return 10; } 
/*  81 */     public String getTableName(int column) { return ""; } 
/*  82 */     public String getCatalogName(int column) { return ""; } 
/*  83 */     public int getColumnType(int column) { return 0; } 
/*  84 */     public String getColumnTypeName(int column) { return ""; } 
/*  85 */     public boolean isReadOnly(int column) { return false; } 
/*  86 */     public boolean isWritable(int column) { return false; } 
/*  87 */     public boolean isDefinitelyWritable(int column) { return false; } 
/*  88 */     public String getColumnClassName(int column) { return ""; } 
/*  89 */     public MemoryMetaData getMetaData() { return MemoryResults.this.rsmd; }
/*     */ 
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.connection.MemoryResults
 * JD-Core Version:    0.6.2
 */