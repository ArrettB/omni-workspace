/*     */ package dynamic.dbtk.connection;
/*     */ 
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.resources.DynamicResource;
/*     */ import dynamic.util.resources.DynamicResourceProducer;
/*     */ import dynamic.util.resources.ResourceManager;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class JDBCResourceProducer
/*     */   implements DynamicResourceProducer
/*     */ {
/*     */   private ResourceManager manager;
/*     */   private String name;
/*     */   private Class driver;
/*     */   private String prefix;
/*     */   private String dateFormat;
/*     */   private String now;
/*     */ 
/*     */   public void initialize(ResourceManager manager, String name, Class driver, String prefix, String dateFormat, String now)
/*     */     throws Exception
/*     */   {
/*  60 */     Diagnostics.trace("JDBCResourceProducer.initialize(" + name + "," + driver + "," + prefix + "," + dateFormat + "," + now + ")");
/*  61 */     this.manager = manager;
/*  62 */     this.name = name;
/*  63 */     this.driver = driver;
/*  64 */     this.prefix = prefix;
/*  65 */     this.dateFormat = dateFormat;
/*  66 */     this.now = now;
/*  67 */     DriverManager.registerDriver((Driver)driver.newInstance());
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*     */   }
/*     */ 
/*     */   public DynamicResource newResource(String name, String id, String username, String password, String type, String min, String max, String ttl) throws Exception {
/*  74 */     Diagnostics.trace("JDBCResourceProducer.newResource(" + name + "," + id + "," + username + ",*******)");
/*  75 */     id = this.prefix + id;
/*     */ 
/*  77 */     Properties p = new Properties();
/*  78 */     p.put("sql7", "true");
/*     */ 
/*  80 */     if ((username != null) && (username.length() > 0) && (password != null))
/*     */     {
/*  82 */       p.put("user", username);
/*  83 */       p.put("password", password);
/*     */     }
/*  85 */     Connection dbCnxn = DriverManager.getConnection(id, p);
/*     */ 
/*  87 */     if (dbCnxn == null)
/*     */     {
/*  89 */       throw new Exception("Problems establishing connection " + name + ": " + id);
/*     */     }
/*     */ 
/*  92 */     DynamicResource theWrapper = new ConnectionWrapper().initialize(dbCnxn, this, name, type, min, max, ttl);
/*     */ 
/*  94 */     return theWrapper;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  99 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String toSQLString(String s)
/*     */   {
/* 104 */     return StringUtil.toSQLString(s);
/*     */   }
/*     */ 
/*     */   public String toSQLString(Date d)
/*     */   {
/* 109 */     if (d == null) return toSQLString((String)null);
/* 110 */     return new SimpleDateFormat(this.dateFormat).format(d);
/*     */   }
/*     */ 
/*     */   public String now()
/*     */   {
/* 115 */     if ((this.now != null) && (this.now.length() > 0)) return this.now;
/* 116 */     return toSQLString(new Date());
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.connection.JDBCResourceProducer
 * JD-Core Version:    0.6.2
 */