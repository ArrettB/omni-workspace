/*     */ package dynamic.dbtk.meta;
/*     */ 
/*     */ public class MetaColumn extends DBObject
/*     */ {
/*     */   private int allowNulls;
/*     */   private int dataSize;
/*     */   private int dataTypeID;
/*     */   private int sequence;
/*     */   private int displayLength;
/*     */   private int decimals;
/*     */   private boolean defaultUse;
/*     */   private String description;
/*     */   private String lovRegionID;
/*     */   private String styleID;
/*     */ 
/*     */   public MetaColumn()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MetaColumn(int allowNulls, int dataSize, int dataTypeID, int sequence, boolean defaultUse, int length, int displayLength)
/*     */   {
/*  28 */     this.allowNulls = allowNulls;
/*  29 */     this.dataSize = dataSize;
/*  30 */     this.dataTypeID = dataTypeID;
/*  31 */     this.sequence = sequence;
/*  32 */     this.defaultUse = defaultUse;
/*  33 */     this.displayLength = length;
/*     */   }
/*     */ 
/*     */   public int getAllowNulls()
/*     */   {
/*  39 */     return this.allowNulls;
/*     */   }
/*     */ 
/*     */   public int getDataSize()
/*     */   {
/*  44 */     return this.dataSize;
/*     */   }
/*     */ 
/*     */   public int getDataTypeID()
/*     */   {
/*  49 */     return this.dataTypeID;
/*     */   }
/*     */ 
/*     */   public boolean useAsDefault()
/*     */   {
/*  54 */     return this.defaultUse;
/*     */   }
/*     */ 
/*     */   public int getDisplayLength()
/*     */   {
/*  59 */     return this.displayLength;
/*     */   }
/*     */ 
/*     */   public int getSequence()
/*     */   {
/*  64 */     return this.sequence;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/*  69 */     return this.description;
/*     */   }
/*     */ 
/*     */   public String getLovRegionID()
/*     */   {
/*  74 */     return this.lovRegionID;
/*     */   }
/*     */ 
/*     */   public String getStyleID()
/*     */   {
/*  79 */     return this.styleID;
/*     */   }
/*     */ 
/*     */   public int getDecimals()
/*     */   {
/*  84 */     return this.decimals;
/*     */   }
/*     */ 
/*     */   public void setAllowNulls(int val)
/*     */   {
/*  90 */     this.allowNulls = val;
/*     */   }
/*     */ 
/*     */   public void setDataSize(int size)
/*     */   {
/*  95 */     this.dataSize = size;
/*     */   }
/*     */ 
/*     */   public void setDataTypeID(int id)
/*     */   {
/* 100 */     this.dataTypeID = id;
/*     */   }
/*     */ 
/*     */   public void setUseAsDefault(boolean use)
/*     */   {
/* 105 */     this.defaultUse = use;
/*     */   }
/*     */ 
/*     */   public void setDisplayLength(int length)
/*     */   {
/* 110 */     this.displayLength = length;
/*     */   }
/*     */ 
/*     */   public void setSequence(int seq)
/*     */   {
/* 115 */     this.sequence = seq;
/*     */   }
/*     */ 
/*     */   public void setDescription(String des)
/*     */   {
/* 120 */     this.description = des;
/*     */   }
/*     */ 
/*     */   public void setLovRegionID(String id)
/*     */   {
/* 125 */     this.lovRegionID = id;
/*     */   }
/*     */ 
/*     */   public void setStyleID(String id)
/*     */   {
/* 130 */     this.styleID = id;
/*     */   }
/*     */ 
/*     */   public void setDecimals(int dec)
/*     */   {
/* 135 */     this.decimals = dec;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 141 */     if (this == o)
/*     */     {
/* 143 */       return true;
/*     */     }
/* 145 */     if ((o instanceof MetaColumn))
/*     */     {
/* 147 */       String internalID = ((MetaColumn)o).getInternalID();
/* 148 */       if (internalID != null)
/*     */       {
/* 150 */         return internalID.equals(getInternalID());
/*     */       }
/*     */ 
/* 153 */       return ((MetaColumn)o).getDBName().equals(getDBName());
/*     */     }
/*     */ 
/* 156 */     return false;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.MetaColumn
 * JD-Core Version:    0.6.2
 */