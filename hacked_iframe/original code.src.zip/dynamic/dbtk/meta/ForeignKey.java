/*    */ package dynamic.dbtk.meta;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class ForeignKey extends DBObject
/*    */ {
/*    */   private Vector fkPairs;
/*    */ 
/*    */   public ForeignKey()
/*    */   {
/* 13 */     this.fkPairs = new Vector();
/*    */   }
/*    */ 
/*    */   public void addFKPair(ForeignKeyPair pair)
/*    */   {
/* 18 */     if (pair != null)
/*    */     {
/* 20 */       this.fkPairs.addElement(pair);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void addFKPair(MetaColumn parentCol, MetaColumn childCol)
/*    */   {
/* 26 */     ForeignKeyPair pair = new ForeignKeyPair(parentCol, childCol);
/* 27 */     addFKPair(pair);
/*    */   }
/*    */ 
/*    */   public Vector getFKPairs()
/*    */   {
/* 32 */     return this.fkPairs;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.ForeignKey
 * JD-Core Version:    0.6.2
 */