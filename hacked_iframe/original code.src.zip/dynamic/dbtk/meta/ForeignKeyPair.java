/*    */ package dynamic.dbtk.meta;
/*    */ 
/*    */ public class ForeignKeyPair extends DBObject
/*    */ {
/*    */   public MetaColumn parentCol;
/*    */   public MetaColumn childCol;
/*    */ 
/*    */   public ForeignKeyPair()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ForeignKeyPair(MetaColumn parentCol, MetaColumn childCol)
/*    */   {
/* 19 */     this.parentCol = parentCol;
/* 20 */     this.childCol = childCol;
/*    */   }
/*    */ 
/*    */   public MetaColumn parentCol()
/*    */   {
/* 25 */     return this.parentCol;
/*    */   }
/*    */ 
/*    */   public MetaColumn childCol()
/*    */   {
/* 30 */     return this.childCol;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.ForeignKeyPair
 * JD-Core Version:    0.6.2
 */