/*    */ package dynamic.dbtk.meta;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class PrimaryKey extends DBObject
/*    */ {
/*    */   private Vector columns;
/*    */ 
/*    */   public PrimaryKey()
/*    */   {
/* 13 */     this.columns = new Vector();
/*    */   }
/*    */ 
/*    */   public void addColumn(MetaColumn col)
/*    */   {
/* 18 */     if (col != null)
/*    */     {
/* 20 */       this.columns.addElement(col);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Vector getColumns()
/*    */   {
/* 26 */     return this.columns;
/*    */   }
/*    */ 
/*    */   public MetaColumn getColumn(String name)
/*    */   {
/* 31 */     for (Enumeration e = this.columns.elements(); e.hasMoreElements(); ) {
/* 32 */       MetaColumn metaColumn = (MetaColumn)e.nextElement();
/* 33 */       if (name.compareTo(metaColumn.getDBName()) == 0) {
/* 34 */         return metaColumn;
/*    */       }
/*    */     }
/*    */ 
/* 38 */     return null;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.PrimaryKey
 * JD-Core Version:    0.6.2
 */