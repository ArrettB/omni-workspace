/*     */ package dynamic.dbtk.meta;
/*     */ 
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ public class MetaLoader
/*     */ {
/*     */   private static Hashtable tableHash;
/*     */   private static String dbSourceID;
/*     */   private static String schOwner;
/*     */   private ConnectionWrapper srcConn;
/*     */ 
/*     */   public MetaLoader(ConnectionWrapper conn, String dbSourceID, String schOwner)
/*     */   {
/*  21 */     tableHash = new Hashtable();
/*     */ 
/*  23 */     dbSourceID = dbSourceID;
/*  24 */     this.srcConn = conn;
/*  25 */     schOwner = schOwner.toUpperCase();
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Hashtable loadMetaData()
/*     */   {
/*     */     try
/*     */     {
/*  39 */       Diagnostics.debug("Loading tables and columns.");
/*  40 */       loadTables();
/*     */ 
/*  43 */       for (Enumeration e = tableHash.elements(); e.hasMoreElements(); )
/*     */       {
/*  45 */         MetaTable mTable = (MetaTable)e.nextElement();
/*     */ 
/*  47 */         Diagnostics.debug("Loading primary keys for table: " + mTable.getDBName());
/*  48 */         loadPrimaryKey(mTable);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  57 */       e.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */ 
/*  64 */     return tableHash;
/*     */   }
/*     */ 
/*     */   public MetaColumn getColumn(String tableName, String colName)
/*     */   {
/*  69 */     MetaTable t = (MetaTable)tableHash.get(tableName);
/*     */ 
/*  71 */     return t.getColumn(colName);
/*     */   }
/*     */ 
/*     */   private void loadTables()
/*     */   {
/*     */     try
/*     */     {
/*  78 */       DatabaseMetaData meta = this.srcConn.getMetaData();
/*  79 */       ResultSet rs = meta.getTables(null, schOwner, "%", null);
/*     */ 
/*  81 */       while (rs.next())
/*     */       {
/*  83 */         Diagnostics.debug("Loading table: " + rs.getString("TABLE_NAME"));
/*     */ 
/*  86 */         if (rs.getString("TABLE_TYPE").equals("TABLE"))
/*     */         {
/*  88 */           MetaTable metaTable = new MetaTable();
/*     */ 
/*  90 */           metaTable.setDBSourceID(dbSourceID);
/*  91 */           metaTable.setDBName(rs.getString("TABLE_NAME"));
/*  92 */           metaTable.setOwner(schOwner);
/*     */ 
/*  94 */           loadColumns(metaTable);
/*     */ 
/*  96 */           tableHash.put(metaTable.getDBName(), metaTable);
/*     */         }
/*     */         else
/*     */         {
/* 100 */           Diagnostics.debug("Skipping object " + rs.getString("TABLE_NAME") + " with type = " + rs.getString("TABLE_TYPE"));
/*     */         }
/*     */       }
/*     */ 
/* 104 */       rs.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 108 */       System.out.println("**** Error in loadTables(MetaTable table) ****");
/* 109 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadColumns(MetaTable table)
/*     */   {
/*     */     try
/*     */     {
/* 117 */       DatabaseMetaData meta = this.srcConn.getMetaData();
/* 118 */       ResultSet rs = meta.getColumns(null, table.getOwner(), table.getDBName(), null);
/*     */ 
/* 120 */       while (rs.next())
/*     */       {
/* 123 */         Diagnostics.debug("\tLoading column: " + rs.getString("COLUMN_NAME"));
/*     */ 
/* 125 */         MetaColumn metaColumn = new MetaColumn();
/*     */ 
/* 128 */         metaColumn.setDataTypeID(rs.getInt("DATA_TYPE"));
/* 129 */         metaColumn.setDataSize(rs.getInt("COLUMN_SIZE"));
/* 130 */         metaColumn.setAllowNulls(rs.getInt("NULLABLE"));
/* 131 */         metaColumn.setDBName(rs.getString("COLUMN_NAME"));
/* 132 */         metaColumn.setSequence(rs.getInt("ORDINAL_POSITION"));
/* 133 */         metaColumn.setDecimals(rs.getInt("DECIMAL_DIGITS"));
/* 134 */         table.addColumn(metaColumn);
/*     */       }
/*     */ 
/* 137 */       rs.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 141 */       System.out.println("**** Error in loadColumns(MetaTable table) ****");
/* 142 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadPrimaryKey(MetaTable table)
/*     */   {
/*     */     try
/*     */     {
/* 150 */       DatabaseMetaData meta = this.srcConn.getMetaData();
/* 151 */       PrimaryKey pk = null;
/*     */ 
/* 154 */       ResultSet rs = meta.getPrimaryKeys(null, null, table.getDBName());
/*     */ 
/* 156 */       while (rs.next())
/*     */       {
/* 158 */         Diagnostics.debug("Loading primary key: " + rs.getString("PK_NAME"));
/*     */ 
/* 160 */         MetaColumn col = getColumn(rs.getString("TABLE_NAME"), rs.getString("COLUMN_NAME"));
/* 161 */         if (pk == null)
/*     */         {
/* 163 */           pk = new PrimaryKey();
/* 164 */           pk.setDBName(rs.getString("PK_NAME"));
/*     */         }
/*     */ 
/* 167 */         pk.addColumn(col);
/*     */       }
/*     */ 
/* 170 */       rs.close();
/* 171 */       table.setPrimaryKey(pk);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 176 */       System.out.println("**** Error in loadPrimaryKey(MetaTable table) ****");
/* 177 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadForeignKeys(MetaTable table)
/*     */   {
/*     */     try
/*     */     {
/* 185 */       DatabaseMetaData meta = this.srcConn.getMetaData();
/* 186 */       ResultSet rs = meta.getExportedKeys(null, table.getOwner(), table.getDBName());
/* 187 */       while (rs.next())
/*     */       {
/* 189 */         MetaColumn parent = getColumn(rs.getString("PKTABLE_NAME"), rs.getString("PKCOLUMN_NAME"));
/* 190 */         MetaColumn child = getColumn(rs.getString("FKTABLE_NAME"), rs.getString("FKCOLUMN_NAME"));
/* 191 */         ForeignKey fk = new ForeignKey();
/*     */ 
/* 201 */         fk.addFKPair(parent, child);
/* 202 */         fk.setDBName(rs.getString("FK_NAME"));
/*     */ 
/* 204 */         table.addForeignKey(fk);
/*     */       }
/*     */ 
/* 207 */       rs.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 211 */       System.out.println("**** Error in loadForeignKeys(MetaTable table) ****");
/* 212 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.MetaLoader
 * JD-Core Version:    0.6.2
 */