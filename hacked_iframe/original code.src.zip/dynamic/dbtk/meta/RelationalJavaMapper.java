/*      */ package dynamic.dbtk.meta;
/*      */ 
/*      */ import dynamic.dbtk.connection.ConnectionWrapper;
/*      */ import dynamic.util.resources.ResourceManager;
/*      */ import dynamic.util.string.StringUtil;
/*      */ import dynamic.util.xml.XMLUtils;
/*      */ import java.io.File;
/*      */ import java.io.FileWriter;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintStream;
/*      */ import java.io.Writer;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ 
/*      */ public class RelationalJavaMapper
/*      */ {
/*      */   private String packageName;
/*      */   private String directory;
/*      */   private MetaTable[] tables;
/*      */ 
/*      */   public RelationalJavaMapper(String packageName, String directory, MetaTable table)
/*      */   {
/*   25 */     this(packageName, directory, new MetaTable[] { table });
/*      */   }
/*      */ 
/*      */   public RelationalJavaMapper(String packageName, String directory, MetaTable[] tables)
/*      */   {
/*   30 */     this.packageName = packageName;
/*   31 */     this.directory = directory;
/*   32 */     this.tables = tables;
/*      */   }
/*      */ 
/*      */   public void doit()
/*      */   {
/*   37 */     File dirFile = new File(this.directory);
/*   38 */     for (int i = 0; i < this.tables.length; i++)
/*      */     {
/*   40 */       MetaTable mt = this.tables[i];
/*   41 */       String fileName = getClassName(mt) + ".java";
/*      */       try
/*      */       {
/*   44 */         System.out.println("Creating " + fileName);
/*   45 */         FileWriter writer = new FileWriter(new File(dirFile, fileName));
/*   46 */         writer.write(getJava(mt));
/*   47 */         writer.close();
/*      */       }
/*      */       catch (IOException e)
/*      */       {
/*   51 */         System.out.println("Error! - Could not write to " + this.directory + "\\" + fileName);
/*   52 */         System.out.println("Reason: " + e.getMessage());
/*   53 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void printUsage()
/*      */   {
/*   61 */     System.out.println("Usage:");
/*   62 */     System.out.println("java dynamic.dbtk.meta.RelationJavaMapper filename.xml schema package destDir resourceName");
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */   {
/*   69 */     ConnectionWrapper conn = null;
/*      */     try
/*      */     {
/*   72 */       if (args.length != 5)
/*      */       {
/*   74 */         printUsage();
/*   75 */         System.exit(-1);
/*      */       }
/*      */ 
/*   79 */       String xmlFileName = args[0];
/*   80 */       String schema = args[1];
/*   81 */       String packageName = args[2];
/*   82 */       String destDirName = args[3];
/*   83 */       String resourceName = args[4];
/*      */ 
/*   86 */       File xmlFile = new File(xmlFileName);
/*   87 */       if (!xmlFile.exists())
/*      */       {
/*   89 */         System.out.println(xmlFileName + " does not exist.  Exiting.");
/*   90 */         System.exit(-1);
/*      */       }
/*   92 */       if (!xmlFile.isFile())
/*      */       {
/*   94 */         System.out.println(xmlFileName + " exists, but is not a file.  Exiting.");
/*   95 */         System.exit(-1);
/*      */       }
/*   97 */       if (!xmlFile.canRead())
/*      */       {
/*   99 */         System.out.println(xmlFileName + " exists, but can not be read. Exiting.");
/*  100 */         System.exit(-1);
/*      */       }
/*      */ 
/*  104 */       File destDir = new File(destDirName);
/*  105 */       if (!destDir.exists())
/*      */       {
/*  107 */         System.out.println(destDirName + " does not exist.  Exiting.");
/*  108 */         System.exit(-1);
/*      */       }
/*  110 */       if (!destDir.isDirectory())
/*      */       {
/*  112 */         System.out.println(destDirName + " is not a directory.  Exiting.");
/*  113 */         System.exit(-1);
/*      */       }
/*      */ 
/*  118 */       Document doc = XMLUtils.parse(xmlFile);
/*      */ 
/*  120 */       Element resourceManagerElement = XMLUtils.getSingleElement(doc, "resourceManager");
/*  121 */       String resourceManagerClass = resourceManagerElement.getAttribute("class");
/*  122 */       ResourceManager RM = (ResourceManager)Class.forName(resourceManagerClass).newInstance();
/*  123 */       RM.initialize(resourceManagerElement, null);
/*      */ 
/*  125 */       conn = (ConnectionWrapper)RM.getResource(resourceName);
/*      */ 
/*  137 */       MetaLoader mLoader = new MetaLoader(conn, schema, schema);
/*      */ 
/*  139 */       Hashtable meta = mLoader.loadMetaData();
/*      */ 
/*  141 */       MetaTable[] tables = new MetaTable[meta.size()];
/*  142 */       Enumeration keys = meta.keys();
/*  143 */       int i = 0;
/*  144 */       while (keys.hasMoreElements())
/*      */       {
/*  146 */         tables[(i++)] = ((MetaTable)meta.get(keys.nextElement()));
/*      */       }
/*      */ 
/*  149 */       RelationalJavaMapper mapper = new RelationalJavaMapper(packageName, destDirName, tables);
/*  150 */       mapper.doit();
/*      */ 
/*  152 */       System.exit(0);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  157 */       e.printStackTrace();
/*      */     }
/*      */     finally
/*      */     {
/*  161 */       if (conn != null)
/*      */       {
/*  163 */         conn.release();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String getImports()
/*      */   {
/*  172 */     StringBuffer result = new StringBuffer();
/*  173 */     result.append("import java.util.Date;\n");
/*  174 */     result.append("import java.io.Serializable;\n");
/*  175 */     result.append("import java.sql.SQLException;\n");
/*  176 */     result.append("import dynamic.dbtk.connection.ConnectionWrapper;\n");
/*  177 */     result.append("import dynamic.dbtk.connection.QueryResults;\n");
/*  178 */     result.append("import dynamic.dbtk.meta.AbstractDatabaseObject;\n");
/*  179 */     result.append("import dynamic.intraframe.engine.InvocationContext;\n");
/*  180 */     result.append("import dynamic.intraframe.handlers.ErrorHandler;\n");
/*  181 */     result.append("import dynamic.util.string.StringUtil;\n");
/*  182 */     result.append("import dynamic.util.diagnostics.Diagnostics;\n");
/*      */ 
/*  184 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public String getJava(MetaTable mt)
/*      */   {
/*  190 */     MetaColumn[] columns = getColumnsAsArray(mt);
/*      */ 
/*  192 */     StringBuffer result = new StringBuffer();
/*  193 */     result.append("package " + this.packageName + ";");
/*  194 */     result.append("\n\n");
/*      */ 
/*  196 */     result.append(getImports());
/*  197 */     result.append("\n");
/*      */ 
/*  199 */     result.append("public class " + getClassName(mt) + " extends AbstractDatabaseObject implements Serializable");
/*  200 */     result.append("\n{\n");
/*      */ 
/*  202 */     result.append("\n");
/*  203 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  205 */       result.append(getMember(columns[i]));
/*      */     }
/*      */ 
/*  208 */     result.append("\n");
/*  209 */     result.append(getConstructor(mt));
/*  210 */     result.append("\n");
/*      */ 
/*  213 */     result.append("\n");
/*  214 */     result.append(getFetchMethod(mt));
/*  215 */     result.append("\n");
/*      */ 
/*  217 */     result.append("\n");
/*  218 */     result.append(getInsertSQLMethod(mt));
/*  219 */     result.append("\n");
/*      */ 
/*  221 */     result.append("\n");
/*  222 */     result.append(getDeleteSQLMethod(mt));
/*  223 */     result.append("\n");
/*      */ 
/*  225 */     result.append("\n");
/*  226 */     result.append(getUpdateSQLMethod(mt));
/*  227 */     result.append("\n");
/*      */ 
/*  229 */     result.append("\n");
/*  230 */     result.append(getInternalUpdateMethod(mt));
/*  231 */     result.append("\n");
/*      */ 
/*  233 */     result.append("\n");
/*  234 */     result.append(getInternalInsertMethod(mt));
/*  235 */     result.append("\n");
/*      */ 
/*  237 */     result.append("\n");
/*  238 */     result.append(getInternalDeleteMethod(mt));
/*  239 */     result.append("\n");
/*      */ 
/*  241 */     result.append("\n");
/*  242 */     result.append(getSkipPrimaryMethod(mt));
/*  243 */     result.append("\n");
/*      */ 
/*  245 */     result.append("\n");
/*  246 */     result.append(getToStringMethod(mt));
/*  247 */     result.append("\n");
/*      */ 
/*  249 */     result.append("\n");
/*  250 */     result.append(getToHTMLStringMethod(mt));
/*  251 */     result.append("\n");
/*      */ 
/*  255 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  257 */       result.append("\n");
/*  258 */       result.append(getAccessor(columns[i]));
/*      */     }
/*      */ 
/*  261 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  263 */       result.append("\n");
/*  264 */       result.append(getMutator(columns[i]));
/*      */     }
/*      */ 
/*  268 */     result.append("}\n");
/*      */ 
/*  270 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getConstructor(MetaTable mt)
/*      */   {
/*  277 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  279 */     result.append("\tpublic ").append(getClassName(mt)).append("()\n");
/*  280 */     result.append("\t{\n");
/*  281 */     result.append("\t\tsuper();\n");
/*  282 */     result.append("\t}\n");
/*      */ 
/*  284 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getFetchMethod(MetaTable mt)
/*      */   {
/*  289 */     StringBuffer result = new StringBuffer();
/*  290 */     MetaColumn[] columns = getColumnsAsArray(mt);
/*  291 */     String className = getClassName(mt);
/*      */ 
/*  295 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  296 */     if (pKey == null)
/*      */     {
/*  299 */       return "";
/*      */     }
/*      */ 
/*  303 */     String argsNatural = getPrimaryKeyArgs(mt, false);
/*  304 */     String argsAsString = getPrimaryKeyArgs(mt, true);
/*  305 */     if (!argsNatural.equals(argsAsString))
/*      */     {
/*  307 */       result.append("\tpublic static ").append(className).append(" fetch(").append(argsAsString).append(", InvocationContext ic)\n");
/*  308 */       result.append("\t{\n");
/*  309 */       result.append("\t\t return fetch(").append(getPrimaryKeyPassAlongArgsConverted(mt)).append(", ic, null);\n");
/*  310 */       result.append("\t}\n\n");
/*      */ 
/*  312 */       result.append("\tpublic static ").append(className).append(" fetch(").append(argsAsString).append(", InvocationContext ic, String resourceName)\n");
/*  313 */       result.append("\t{\n");
/*  314 */       result.append("\t\t return fetch(").append(getPrimaryKeyPassAlongArgsConverted(mt)).append(", ic, resourceName);\n");
/*  315 */       result.append("\t}\n\n");
/*      */     }
/*      */ 
/*  318 */     result.append("\tpublic static ").append(className).append(" fetch(").append(argsNatural).append(", InvocationContext ic)\n");
/*  319 */     result.append("\t{\n");
/*  320 */     result.append("\t\t return fetch(").append(getPrimaryKeyPassAlongArgs(mt)).append(", ic, null);\n");
/*  321 */     result.append("\t}\n\n");
/*      */ 
/*  323 */     result.append("\tpublic static ").append(className).append(" fetch(").append(argsNatural).append(", InvocationContext ic, String resourceName)\n");
/*  324 */     result.append("\t{\n");
/*      */ 
/*  326 */     result.append("\t\tDiagnostics.trace(\"").append(className).append(".fetch()\");\n\n");
/*      */ 
/*  328 */     result.append("\t\t").append(className).append(" result = null;\n");
/*  329 */     result.append("\t\tConnectionWrapper conn = null;\n");
/*  330 */     result.append("\t\ttry\n");
/*  331 */     result.append("\t\t{\n");
/*  332 */     result.append("\t\t\tconn = (ConnectionWrapper)ic.getResource(resourceName);\n");
/*  333 */     result.append("\t\t\tresult = fetch(").append(getPrimaryKeyPassAlongArgs(mt)).append(", conn);\n");
/*  334 */     result.append("\t\t}\n");
/*  335 */     result.append("\t\tcatch (Exception e)\n");
/*  336 */     result.append("\t\t{\n");
/*  337 */     result.append("\t\t\tErrorHandler.handleException(ic, e, \"Exception in ").append(className).append(".fetch()\");\n");
/*  338 */     result.append("\t\t}\n");
/*  339 */     result.append("\t\tfinally\n");
/*  340 */     result.append("\t\t{\n");
/*  341 */     result.append("\t\t\tif (conn != null)\n");
/*  342 */     result.append("\t\t\t{\n");
/*  343 */     result.append("\t\t\t\tconn.release();\n");
/*  344 */     result.append("\t\t\t}\n");
/*  345 */     result.append("\t\t}\n");
/*  346 */     result.append("\n");
/*  347 */     result.append("\t\t if (result != null) result.handleAction(FETCH_ACTION);\n");
/*  348 */     result.append("\t\treturn result;\n");
/*  349 */     result.append("\t}\n\n");
/*      */ 
/*  354 */     result.append("\tpublic static ").append(className).append(" fetch(").append(argsNatural).append(", ConnectionWrapper conn)\n");
/*  355 */     result.append("\t{\n");
/*      */ 
/*  357 */     result.append("\t\tDiagnostics.trace(\"").append(className).append(".fetch()\");\n\n");
/*      */ 
/*  359 */     result.append("\t\t").append(className).append(" result = null;\n");
/*  360 */     result.append("\t\ttry\n");
/*  361 */     result.append("\t\t{\n");
/*      */ 
/*  363 */     result.append("\t\t\tStringBuffer query = new StringBuffer();\n");
/*      */ 
/*  366 */     result.append("\t\t\tquery.append(\"SELECT ").append(columns[0].getDBName().toLowerCase()).append(" \");\n");
/*  367 */     for (int i = 1; i < columns.length; i++)
/*      */     {
/*  369 */       result.append("\t\t\tquery.append(\", ").append(columns[i].getDBName().toLowerCase()).append(" \");\n");
/*      */     }
/*  371 */     result.append("\t\t\tquery.append(\"FROM ").append(mt.getDBName().toLowerCase()).append(" \");\n");
/*  372 */     result.append("\t\t\tquery.append(\"").append(getPrimaryKeyWhereClauseFetch(mt)).append(" \");\n");
/*      */ 
/*  374 */     result.append("\n");
/*  375 */     result.append("\t\t\tQueryResults rs = conn.resultsQueryEx(query);\n");
/*  376 */     result.append("\t\t\tif (rs.next())\n");
/*  377 */     result.append("\t\t\t{\n");
/*      */ 
/*  379 */     result.append("\t\t\t\tresult = new ").append(className).append("();\n");
/*      */ 
/*  382 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  384 */       MetaColumn mc = columns[i];
/*  385 */       String setter = "set" + toTitleCase(mc.getDBName());
/*  386 */       String javaType = mapDataType(mc.getDataTypeID(), mc.getDecimals(), mc.getDBName());
/*  387 */       String rsGetter = "get" + StringUtil.toInitialCaps(javaType);
/*      */ 
/*  389 */       result.append("\t\t\t\tresult.").append(setter).append("(rs.").append(rsGetter).append("(").append(i + 1).append("));\n");
/*      */     }
/*      */ 
/*  393 */     result.append("\t\t\t}\n");
/*  394 */     result.append("\t\t\telse\n");
/*  395 */     result.append("\t\t\t{\n");
/*  396 */     result.append("\t\t\t\tDiagnostics.error(\"Error in ").append(className).append(".fetch(), Could not find ").append(className).append("; Select was:\" + query);\n");
/*  397 */     result.append("\t\t\t}\n");
/*  398 */     result.append("\t\t\trs.close();\n");
/*  399 */     result.append("\t\t}\n");
/*  400 */     result.append("\t\tcatch (Exception e)\n");
/*  401 */     result.append("\t\t{\n");
/*  402 */     result.append("\t\t\tDiagnostics.error(\"Exception in ").append(className).append(".fetch()\", e);\n");
/*  403 */     result.append("\t\t}\n");
/*  404 */     result.append("\n");
/*  405 */     result.append("\t\t if (result != null) result.handleAction(FETCH_ACTION);\n");
/*  406 */     result.append("\t\treturn result;\n");
/*  407 */     result.append("\t}");
/*      */ 
/*  409 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getPrimaryKeyArgs(MetaTable mt, boolean forceString)
/*      */   {
/*  415 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  417 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  418 */     if (pKey == null)
/*      */     {
/*  420 */       return null;
/*      */     }
/*      */ 
/*  423 */     Vector pColumns = pKey.getColumns();
/*  424 */     for (int i = 0; i < pColumns.size(); i++)
/*      */     {
/*  426 */       MetaColumn primaryKeyColumn = (MetaColumn)pColumns.elementAt(i);
/*  427 */       String javaType = mapDataType(primaryKeyColumn.getDataTypeID(), primaryKeyColumn.getDecimals(), primaryKeyColumn.getDBName());
/*  428 */       if (i != 0)
/*      */       {
/*  430 */         result.append(", ");
/*      */       }
/*  432 */       if (forceString)
/*      */       {
/*  434 */         result.append("String ");
/*      */       }
/*      */       else
/*      */       {
/*  438 */         result.append(javaType).append(" ");
/*      */       }
/*  440 */       result.append(toCamelCase(primaryKeyColumn.getDBName()));
/*      */     }
/*  442 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getPrimaryKeyPassAlongArgs(MetaTable mt)
/*      */   {
/*  448 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  450 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  451 */     if (pKey == null)
/*      */     {
/*  453 */       return null;
/*      */     }
/*      */ 
/*  456 */     Vector pColumns = pKey.getColumns();
/*  457 */     for (int i = 0; i < pColumns.size(); i++)
/*      */     {
/*  459 */       MetaColumn primaryKeyColumn = (MetaColumn)pColumns.elementAt(i);
/*  460 */       if (i != 0)
/*      */       {
/*  462 */         result.append(", ");
/*      */       }
/*  464 */       result.append(toCamelCase(primaryKeyColumn.getDBName()));
/*      */     }
/*  466 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getPrimaryKeyPassAlongArgsConverted(MetaTable mt)
/*      */   {
/*  473 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  475 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  476 */     if (pKey == null)
/*      */     {
/*  478 */       return null;
/*      */     }
/*      */ 
/*  481 */     Vector pColumns = pKey.getColumns();
/*  482 */     for (int i = 0; i < pColumns.size(); i++)
/*      */     {
/*  484 */       MetaColumn primaryKeyColumn = (MetaColumn)pColumns.elementAt(i);
/*  485 */       String javaType = mapDataType(primaryKeyColumn.getDataTypeID(), primaryKeyColumn.getDecimals(), primaryKeyColumn.getDBName());
/*  486 */       if (i != 0)
/*      */       {
/*  488 */         result.append(", ");
/*      */       }
/*  490 */       if (javaType.equals("String"))
/*      */       {
/*  492 */         result.append(toCamelCase(primaryKeyColumn.getDBName()));
/*      */       }
/*  494 */       if (javaType.equals("int"))
/*      */       {
/*  496 */         result.append("Integer.parseInt(").append(toCamelCase(primaryKeyColumn.getDBName())).append(")");
/*      */       }
/*  498 */       if (javaType.equals("long"))
/*      */       {
/*  500 */         result.append("Long.parseLong(").append(toCamelCase(primaryKeyColumn.getDBName())).append(")");
/*      */       }
/*  502 */       if (javaType.equals("float"))
/*      */       {
/*  504 */         result.append("Float.parseFloat(").append(toCamelCase(primaryKeyColumn.getDBName())).append(")");
/*      */       }
/*  506 */       if (javaType.equals("double"))
/*      */       {
/*  508 */         result.append("Double.parseDouble(").append(toCamelCase(primaryKeyColumn.getDBName())).append(")");
/*      */       }
/*      */     }
/*  511 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getPrimaryKeyWhereClauseFetch(MetaTable mt)
/*      */   {
/*  519 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  521 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  522 */     if (pKey == null)
/*      */     {
/*  524 */       return null;
/*      */     }
/*      */ 
/*  527 */     Vector pColumns = pKey.getColumns();
/*  528 */     for (int i = 0; i < pColumns.size(); i++)
/*      */     {
/*  530 */       MetaColumn primaryKeyColumn = (MetaColumn)pColumns.elementAt(i);
/*  531 */       if (i == 0)
/*      */       {
/*  533 */         result.append("WHERE (");
/*      */       }
/*      */       else
/*      */       {
/*  537 */         result.append(" AND ");
/*      */       }
/*  539 */       result.append(primaryKeyColumn.getDBName().toLowerCase());
/*  540 */       result.append(" = \").append(");
/*  541 */       result.append(toCamelCase(primaryKeyColumn.getDBName()));
/*  542 */       result.append(").append(\"");
/*      */     }
/*  544 */     result.append(")");
/*  545 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getPrimaryKeyWhereClauseUpdateDelete(MetaTable mt)
/*      */   {
/*  551 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  553 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  554 */     if (pKey == null)
/*      */     {
/*  556 */       return null;
/*      */     }
/*      */ 
/*  560 */     Vector pColumns = pKey.getColumns();
/*  561 */     for (int i = 0; i < pColumns.size(); i++)
/*      */     {
/*  563 */       MetaColumn primaryKeyColumn = (MetaColumn)pColumns.elementAt(i);
/*  564 */       if (i == 0)
/*      */       {
/*  566 */         result.append(" WHERE (");
/*      */       }
/*      */       else
/*      */       {
/*  570 */         result.append(" AND ");
/*      */       }
/*      */ 
/*  573 */       String pkGetter = "get" + toTitleCase(primaryKeyColumn.getDBName());
/*      */ 
/*  575 */       result.append(primaryKeyColumn.getDBName().toLowerCase());
/*  576 */       result.append(" = \").append(");
/*  577 */       result.append("this.").append(pkGetter).append("()).append(\"");
/*      */     }
/*  579 */     result.append(")");
/*  580 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getSkipPrimaryMethod(MetaTable mt)
/*      */   {
/*  586 */     StringBuffer result = new StringBuffer();
/*  587 */     result.append("\tprivate boolean skipPrimaryKey()\n");
/*  588 */     result.append("\t{\n");
/*  589 */     result.append("\t\tboolean skipPrimaryKey = false;\n");
/*      */ 
/*  591 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  592 */     if (pKey != null)
/*      */     {
/*  595 */       Vector pColumns = pKey.getColumns();
/*  596 */       String op = "if";
/*  597 */       for (int i = 0; i < pColumns.size(); i++)
/*      */       {
/*  599 */         MetaColumn primaryKeyColumn = (MetaColumn)pColumns.elementAt(i);
/*  600 */         String javaType = mapDataType(primaryKeyColumn.getDataTypeID(), primaryKeyColumn.getDecimals(), primaryKeyColumn.getDBName());
/*  601 */         if (javaType.equals("String"))
/*      */         {
/*  603 */           result.append("\t\t").append(op).append(" (this.get").append(toTitleCase(primaryKeyColumn.getDBName())).append("() == null || this.get").append(toTitleCase(primaryKeyColumn.getDBName())).append("().equals(AbstractDatabaseObject.USE_IDENTITY))\n");
/*  604 */           if (op.equals("if"))
/*      */           {
/*  606 */             op = "else if";
/*      */           }
/*  608 */           result.append("\t\t{\n");
/*  609 */           result.append("\t\t\tskipPrimaryKey = true;\n");
/*  610 */           result.append("\t\t}\n");
/*      */         }
/*  612 */         else if (!javaType.equals("Date"))
/*      */         {
/*  617 */           result.append("\t\t").append(op).append(" (this.get").append(toTitleCase(primaryKeyColumn.getDBName())).append("() <= 0)\n");
/*  618 */           if (op.equals("if"))
/*      */           {
/*  620 */             op = "else if";
/*      */           }
/*  622 */           result.append("\t\t{\n");
/*  623 */           result.append("\t\t\tskipPrimaryKey = true;\n");
/*  624 */           result.append("\t\t}\n");
/*      */         }
/*      */       }
/*      */     }
/*  628 */     result.append("\t\treturn skipPrimaryKey;\n");
/*  629 */     result.append("\t}\n");
/*  630 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getUpdateSQLMethod(MetaTable mt)
/*      */   {
/*  636 */     StringBuffer result = new StringBuffer();
/*  637 */     MetaColumn[] columns = getColumnsAsArray(mt);
/*      */ 
/*  641 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  642 */     if (pKey == null)
/*      */     {
/*  645 */       return "";
/*      */     }
/*      */ 
/*  648 */     Vector pColumns = pKey.getColumns();
/*      */ 
/*  651 */     result.append("\tpublic String getUpdateSQL(ConnectionWrapper conn)\n");
/*  652 */     result.append("\t{\n");
/*      */ 
/*  654 */     result.append("\t\tDiagnostics.trace(\"").append(getClassName(mt)).append(".getUpdateSQL()\");\n\n");
/*      */ 
/*  658 */     result.append("\t\tStringBuffer update = new StringBuffer();\n");
/*  659 */     result.append("\t\tupdate.append(\"UPDATE ").append(mt.getDBName().toLowerCase()).append(" \");\n");
/*      */ 
/*  661 */     boolean didFirst = false;
/*  662 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  664 */       MetaColumn mc = columns[i];
/*  665 */       if (!pColumns.contains(mc))
/*      */       {
/*  667 */         String getter = "get" + toTitleCase(mc.getDBName());
/*  668 */         String javaType = mapDataType(mc.getDataTypeID(), mc.getDecimals(), mc.getDBName());
/*  669 */         if (!didFirst)
/*      */         {
/*  671 */           didFirst = true;
/*  672 */           result.append("\t\tupdate.append(\"SET ");
/*      */         }
/*      */         else
/*      */         {
/*  676 */           result.append("\t\tupdate.append(\", ");
/*      */         }
/*  678 */         result.append(mc.getDBName().toLowerCase()).append(" = \")");
/*      */         String temp;
/*  681 */         if (javaType.equals("String"))
/*      */         {
/*  683 */           temp = "conn.toSQLString(StringUtil.truncate(this." + getter + "(), " + mc.getDataSize() + "))";
/*      */         }
/*  685 */         else if (javaType.equals("Date"))
/*      */         {
/*  687 */           temp = "conn.toSQLString(this." + getter + "())";
/*      */         }
/*      */         else
/*      */         {
/*  691 */           temp = "this." + getter + "()";
/*      */         }
/*  693 */         result.append(".append(").append(temp).append(");\n");
/*      */       }
/*      */     }
/*      */ 
/*  697 */     result.append("\t\tupdate.append(\"").append(getPrimaryKeyWhereClauseUpdateDelete(mt)).append("\");\n");
/*  698 */     result.append("\t\treturn update.toString();\n");
/*  699 */     result.append("\t}\n");
/*  700 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getInternalUpdateMethod(MetaTable mt)
/*      */   {
/*  707 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  709 */     result.append("\tprotected void internalUpdate(ConnectionWrapper conn) throws SQLException\n");
/*  710 */     result.append("\t{\n");
/*  711 */     result.append("\t\tDiagnostics.trace(\"").append(getClassName(mt)).append(".internalUpdate()\");\n\n");
/*  712 */     result.append("\t\tconn.updateExactlyEx(getUpdateSQL(conn), 1);\n");
/*  713 */     result.append("\t}\n");
/*      */ 
/*  715 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getInsertCode(MetaTable mt, MetaColumn[] columns)
/*      */   {
/*  722 */     StringBuffer result = new StringBuffer();
/*  723 */     result.append("\t\t\t\tinsert.append(\"INSERT INTO ").append(mt.getDBName().toLowerCase()).append(" (\");\n");
/*      */ 
/*  725 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  727 */       MetaColumn mc = columns[i];
/*  728 */       if (i == 0)
/*      */       {
/*  730 */         result.append("\t\t\t\tinsert.append(\"").append(mc.getDBName().toLowerCase()).append("\");\n");
/*      */       }
/*      */       else
/*      */       {
/*  734 */         result.append("\t\t\t\tinsert.append(\", ").append(mc.getDBName().toLowerCase()).append("\");\n");
/*      */       }
/*      */     }
/*  737 */     result.append("\t\t\t\tinsert.append(\") VALUES (\");\n");
/*      */ 
/*  739 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/*  741 */       MetaColumn mc = columns[i];
/*  742 */       String getter = "get" + toTitleCase(mc.getDBName());
/*  743 */       String javaType = mapDataType(mc.getDataTypeID(), mc.getDecimals(), mc.getDBName());
/*      */       String temp;
/*  746 */       if (javaType.equals("String"))
/*      */       {
/*  748 */         temp = "conn.toSQLString(StringUtil.truncate(this." + getter + "(), " + mc.getDataSize() + "))";
/*      */       }
/*  750 */       else if (javaType.equals("Date"))
/*      */       {
/*  752 */         temp = "conn.toSQLString(this." + getter + "())";
/*      */       }
/*      */       else
/*      */       {
/*  756 */         temp = "this." + getter + "()";
/*      */       }
/*      */ 
/*  759 */       if (i == 0)
/*      */       {
/*  761 */         result.append("\t\t\t\tinsert.append(").append(temp).append(");\n");
/*      */       }
/*      */       else
/*      */       {
/*  765 */         result.append("\t\t\t\tinsert.append(\", \").append(").append(temp).append(");\n");
/*      */       }
/*      */     }
/*      */ 
/*  769 */     result.append("\t\t\t\tinsert.append(\")\");\n");
/*      */ 
/*  771 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getInsertSQLMethod(MetaTable mt)
/*      */   {
/*  776 */     StringBuffer result = new StringBuffer();
/*  777 */     MetaColumn[] columns = getColumnsAsArray(mt);
/*  778 */     MetaColumn[] otherColumns = null;
/*  779 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  780 */     boolean hasKey = pKey != null;
/*      */ 
/*  782 */     if (hasKey)
/*      */     {
/*  784 */       Vector pColumns = pKey.getColumns();
/*      */ 
/*  787 */       Vector temp = new Vector();
/*  788 */       for (int i = 0; i < columns.length; i++)
/*      */       {
/*  790 */         MetaColumn mc = columns[i];
/*  791 */         if (mc == null)
/*      */         {
/*  793 */           System.out.println("mc is null at " + i);
/*      */         }
/*      */         else
/*      */         {
/*  797 */           System.out.println(mc.getDBName());
/*  798 */           if (!pColumns.contains(mc))
/*      */           {
/*  800 */             temp.addElement(mc);
/*      */           }
/*      */         }
/*      */       }
/*  804 */       otherColumns = new MetaColumn[temp.size()];
/*  805 */       for (int i = 0; i < otherColumns.length; i++)
/*      */       {
/*  807 */         otherColumns[i] = ((MetaColumn)temp.elementAt(i));
/*      */       }
/*      */     }
/*      */ 
/*  811 */     result.append("\tpublic String getInsertSQL(ConnectionWrapper conn)\n");
/*  812 */     result.append("\t{\n");
/*  813 */     result.append("\t\t\tStringBuffer insert = new StringBuffer();\n");
/*      */ 
/*  815 */     if (hasKey)
/*      */     {
/*  817 */       result.append("\t\t\tboolean skipPrimary = skipPrimaryKey();\n");
/*  818 */       result.append("\t\t\tif (skipPrimary)\n");
/*  819 */       result.append("\t\t\t{\n");
/*  820 */       result.append(getInsertCode(mt, otherColumns));
/*  821 */       result.append("\t\t\t}\n");
/*  822 */       result.append("\t\t\telse\n");
/*  823 */       result.append("\t\t\t{\n");
/*  824 */       result.append(getInsertCode(mt, columns));
/*  825 */       result.append("\t\t\t}\n");
/*      */     }
/*      */     else
/*      */     {
/*  829 */       result.append(getInsertCode(mt, columns));
/*      */     }
/*      */ 
/*  832 */     result.append("\t\treturn insert.toString();\n");
/*  833 */     result.append("\t}");
/*      */ 
/*  835 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getInternalInsertMethod(MetaTable mt)
/*      */   {
/*  846 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  849 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  850 */     if (pKey == null)
/*      */     {
/*  853 */       return "";
/*      */     }
/*      */ 
/*  857 */     result.append("\tprotected void internalInsert(ConnectionWrapper conn) throws SQLException\n");
/*  858 */     result.append("\t{\n");
/*  859 */     result.append("\t\tDiagnostics.trace(\"").append(getClassName(mt)).append(".internalUpdate()\");\n\n");
/*  860 */     result.append("\t\tconn.updateExactlyEx(getInsertSQL(conn), 1);\n");
/*  861 */     result.append("\t}");
/*      */ 
/*  863 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getDeleteSQLMethod(MetaTable mt)
/*      */   {
/*  869 */     StringBuffer result = new StringBuffer();
/*  870 */     result.append("\tpublic String getDeleteSQL(ConnectionWrapper conn)\n");
/*  871 */     result.append("\t{\n");
/*  872 */     result.append("\t\tStringBuffer delete = new StringBuffer();\n");
/*  873 */     result.append("\t\tdelete.append(\"DELETE FROM ").append(mt.getDBName().toLowerCase()).append(" \");\n");
/*  874 */     result.append("\t\tdelete.append(\"").append(getPrimaryKeyWhereClauseUpdateDelete(mt)).append("\");\n");
/*  875 */     result.append("\t\treturn delete.toString();\n");
/*  876 */     result.append("\t}");
/*  877 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getInternalDeleteMethod(MetaTable mt)
/*      */   {
/*  885 */     StringBuffer result = new StringBuffer();
/*      */ 
/*  888 */     PrimaryKey pKey = mt.getPrimaryKey();
/*  889 */     if (pKey == null)
/*      */     {
/*  892 */       return "";
/*      */     }
/*      */ 
/*  896 */     result.append("\tprotected void internalDelete(ConnectionWrapper conn)  throws SQLException\n");
/*  897 */     result.append("\t{\n");
/*  898 */     result.append("\t\tDiagnostics.trace(\"").append(getClassName(mt)).append(".internalUpdate()\");\n\n");
/*  899 */     result.append("\t\tconn.updateExactlyEx(getDeleteSQL(conn), 1);\n");
/*  900 */     result.append("\t}");
/*      */ 
/*  902 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getAccessor(MetaColumn mc)
/*      */   {
/*  908 */     StringBuffer result = new StringBuffer();
/*  909 */     String javaType = mapDataType(mc.getDataTypeID(), mc.getDecimals(), mc.getDBName());
/*  910 */     String datumName = toCamelCase(mc.getDBName());
/*  911 */     String methodName = "get" + toTitleCase(mc.getDBName());
/*      */ 
/*  913 */     result.append("\tpublic ").append(javaType).append(" ").append(methodName).append("()\n");
/*  914 */     result.append("\t{\n");
/*  915 */     result.append("\t\treturn ").append(datumName).append(";\n");
/*  916 */     result.append("\t}\n");
/*  917 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getMutator(MetaColumn mc)
/*      */   {
/*  923 */     StringBuffer result = new StringBuffer();
/*  924 */     String javaType = mapDataType(mc.getDataTypeID(), mc.getDecimals(), mc.getDBName());
/*  925 */     String datumName = toCamelCase(mc.getDBName());
/*  926 */     String methodName = "set" + toTitleCase(mc.getDBName());
/*      */ 
/*  928 */     result.append("\tpublic void ").append(methodName).append("(").append(javaType).append(" ").append(datumName).append("In)\n");
/*  929 */     result.append("\t{\n");
/*  930 */     result.append("\t\t").append(datumName).append(" = ").append(datumName).append("In;\n");
/*  931 */     result.append("\t\thandleAction(MODIFY_ACTION);\n");
/*  932 */     result.append("\t}\n");
/*  933 */     return result.toString();
/*      */   }
/*      */ 
/*      */   public static String getMember(MetaColumn mc)
/*      */   {
/*  938 */     StringBuffer result = new StringBuffer();
/*  939 */     String javaType = mapDataType(mc.getDataTypeID(), mc.getDecimals(), mc.getDBName());
/*  940 */     String datumName = toCamelCase(mc.getDBName());
/*  941 */     result.append("\tprivate ").append(javaType).append(" ").append(datumName).append(";\n");
/*  942 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String toCamelCase(String s)
/*      */   {
/*  948 */     if (s == null) {
/*  949 */       return s;
/*      */     }
/*  951 */     if (s.length() == 0) {
/*  952 */       return s;
/*      */     }
/*  954 */     char[] temp = s.toCharArray();
/*  955 */     StringBuffer result = new StringBuffer();
/*  956 */     result.append(Character.toLowerCase(temp[0]));
/*  957 */     int i = 1;
/*  958 */     while (i < temp.length)
/*      */     {
/*  960 */       if (temp[(i++)] == '_')
/*      */       {
/*  962 */         if (i != temp.length)
/*      */         {
/*  964 */           result.append(Character.toUpperCase(temp[(i++)]));
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  969 */         result.append(Character.toLowerCase(temp[(i - 1)]));
/*      */       }
/*      */     }
/*  972 */     return modifyNames(result.toString());
/*      */   }
/*      */ 
/*      */   private static MetaColumn[] getColumnsAsArray(MetaTable mt)
/*      */   {
/*  977 */     Vector temp = mt.getColumns();
/*  978 */     MetaColumn[] result = new MetaColumn[temp.size()];
/*  979 */     for (int i = 0; i < result.length; i++)
/*      */     {
/*  981 */       result[i] = ((MetaColumn)temp.elementAt(i));
/*      */     }
/*  983 */     return result;
/*      */   }
/*      */ 
/*      */   private static String toTitleCase(String s)
/*      */   {
/*  988 */     if (s == null) {
/*  989 */       return s;
/*      */     }
/*  991 */     if (s.length() == 0) {
/*  992 */       return s;
/*      */     }
/*  994 */     char[] temp = s.toCharArray();
/*  995 */     StringBuffer result = new StringBuffer();
/*  996 */     result.append(Character.toUpperCase(temp[0]));
/*  997 */     int i = 1;
/*  998 */     while (i < temp.length)
/*      */     {
/* 1000 */       if (temp[(i++)] == '_')
/*      */       {
/* 1002 */         if (i != temp.length)
/*      */         {
/* 1004 */           result.append(Character.toUpperCase(temp[(i++)]));
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1009 */         result.append(Character.toLowerCase(temp[(i - 1)]));
/*      */       }
/*      */     }
/* 1012 */     return modifyNames(result.toString());
/*      */   }
/*      */ 
/*      */   private static String modifyNames(String modifyMe)
/*      */   {
/* 1017 */     String temp = StringUtil.replaceString(modifyMe, "Id", "ID");
/* 1018 */     temp = StringUtil.replaceString(temp, "Pc", "PC");
/* 1019 */     return temp;
/*      */   }
/*      */ 
/*      */   private static String mapDataType(int SqlType, int decimals, String columnName)
/*      */   {
/* 1024 */     switch (SqlType)
/*      */     {
/*      */     case -1:
/*      */     case 1:
/*      */     case 12:
/* 1029 */       return "String";
/*      */     case -7:
/* 1032 */       return "boolean";
/*      */     case -6:
/*      */     case 4:
/*      */     case 5:
/* 1037 */       return "int";
/*      */     case -5:
/* 1040 */       return "long";
/*      */     case 2:
/*      */     case 3:
/* 1044 */       if (decimals > 0)
/*      */       {
/* 1046 */         return "double";
/*      */       }
/*      */ 
/* 1050 */       if ((columnName.endsWith("ID")) || (columnName.equalsIgnoreCase("MODIFIED_BY")) || (columnName.equalsIgnoreCase("CREATED_BY"))) {
/* 1051 */         return "String";
/*      */       }
/* 1053 */       return "int";
/*      */     case 6:
/* 1057 */       return "float";
/*      */     case 8:
/* 1060 */       return "double";
/*      */     case 91:
/*      */     case 92:
/*      */     case 93:
/* 1065 */       return "Date";
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/*      */     case 0:
/*      */     case 1111:
/*      */     case 2000:
/*      */     case 2001:
/*      */     case 2002:
/*      */     case 2003:
/*      */     case 2004:
/*      */     case 2005:
/*      */     case 2006:
/* 1080 */       return "String";
/*      */     }
/*      */ 
/* 1083 */     return "String";
/*      */   }
/*      */ 
/*      */   private static String getClassName(MetaTable mt)
/*      */   {
/* 1093 */     String tableName = mt.getDBName().toLowerCase();
/* 1094 */     if (tableName.endsWith("ses"))
/*      */     {
/* 1096 */       tableName = tableName.substring(0, tableName.length() - 2);
/*      */     }
/* 1098 */     else if (tableName.endsWith("s"))
/*      */     {
/* 1100 */       tableName = tableName.substring(0, tableName.length() - 1);
/*      */     }
/* 1102 */     else if (tableName.endsWith("ies"))
/*      */     {
/* 1104 */       tableName = tableName.substring(0, tableName.length() - 3) + "y";
/*      */     }
/* 1106 */     return "Default" + toTitleCase(tableName);
/*      */   }
/*      */ 
/*      */   private static String getToStringMethod(MetaTable mt)
/*      */   {
/* 1114 */     StringBuffer result = new StringBuffer();
/* 1115 */     MetaColumn[] columns = getColumnsAsArray(mt);
/*      */ 
/* 1117 */     result.append("\tpublic String toString()\n");
/* 1118 */     result.append("\t{\n");
/*      */ 
/* 1120 */     result.append("\t\tStringBuffer result = new StringBuffer();\n");
/* 1121 */     result.append("\t\tresult.append(\"").append(getClassName(mt)).append(":\\n\");\n");
/* 1122 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/* 1124 */       MetaColumn mc = columns[i];
/* 1125 */       String getter = "get" + toTitleCase(mc.getDBName());
/*      */ 
/* 1127 */       result.append("\t\tresult.append(\"  ").append(mc.getDBName().toLowerCase()).append(" = \").append(this.").append(getter).append("()).append(\"\\n\");\n");
/*      */     }
/*      */ 
/* 1130 */     result.append("\t\treturn result.toString();\n");
/* 1131 */     result.append("\t}\n");
/*      */ 
/* 1133 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private static String getToHTMLStringMethod(MetaTable mt)
/*      */   {
/* 1140 */     StringBuffer result = new StringBuffer();
/* 1141 */     MetaColumn[] columns = getColumnsAsArray(mt);
/*      */ 
/* 1143 */     result.append("\tpublic String toHTMLString()\n");
/* 1144 */     result.append("\t{\n");
/*      */ 
/* 1146 */     result.append("\t\tStringBuffer result = new StringBuffer();\n");
/* 1147 */     result.append("\t\tresult.append(\"").append(getClassName(mt)).append(":<br>\");\n");
/* 1148 */     for (int i = 0; i < columns.length; i++)
/*      */     {
/* 1150 */       MetaColumn mc = columns[i];
/* 1151 */       String getter = "get" + toTitleCase(mc.getDBName());
/*      */ 
/* 1153 */       result.append("\t\tresult.append(\"  ").append(mc.getDBName().toLowerCase()).append(" = \").append(this.").append(getter).append("()).append(\"<br>\");\n");
/*      */     }
/*      */ 
/* 1156 */     result.append("\t\treturn result.toString();\n");
/* 1157 */     result.append("\t}\n");
/*      */ 
/* 1159 */     return result.toString();
/*      */   }
/*      */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.RelationalJavaMapper
 * JD-Core Version:    0.6.2
 */