/*    */ package dynamic.dbtk.meta;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ 
/*    */ public abstract class AbstractDatabaseObject
/*    */ {
/*    */   private int _status;
/*    */   protected static final int NEW_STATUS = 1;
/*    */   protected static final int DIRTY_STATUS = 2;
/*    */   protected static final int CLEAN_STATUS = 3;
/*    */   protected static final int DELETED_STATUS = 4;
/*    */   protected static final int INVALID_STATUS = 5;
/*    */   protected static final int FETCH_ACTION = 101;
/*    */   protected static final int COMMIT_ACTION = 102;
/*    */   protected static final int DELETE_ACTION = 103;
/*    */   protected static final int UPDATED_ACTION = 104;
/*    */   protected static final int MODIFY_ACTION = 105;
/*    */   public static final String USE_IDENTITY = "@@identity";
/*    */ 
/*    */   protected abstract void internalInsert(InvocationContext paramInvocationContext, String paramString);
/*    */ 
/*    */   protected abstract void internalUpdate(InvocationContext paramInvocationContext, String paramString);
/*    */ 
/*    */   protected abstract void internalDelete(InvocationContext paramInvocationContext, String paramString);
/*    */ 
/*    */   public AbstractDatabaseObject()
/*    */   {
/* 37 */     Diagnostics.trace("AbstractDatabaseObject()");
/* 38 */     this._status = 1;
/*    */   }
/*    */ 
/*    */   public void delete()
/*    */   {
/* 43 */     handleAction(103);
/*    */   }
/*    */ 
/*    */   public void commit(InvocationContext ic)
/*    */   {
/* 48 */     commit(ic, null);
/*    */   }
/*    */ 
/*    */   public void commit(InvocationContext ic, String resourceName)
/*    */   {
/* 54 */     Diagnostics.trace("AbstractDatabaseObject.commit()");
/* 55 */     int status = getInternalStatus();
/* 56 */     switch (status)
/*    */     {
/*    */     case 1:
/* 59 */       internalInsert(ic, resourceName);
/* 60 */       handleAction(102);
/* 61 */       break;
/*    */     case 2:
/* 64 */       internalUpdate(ic, resourceName);
/* 65 */       handleAction(102);
/* 66 */       break;
/*    */     case 4:
/* 69 */       internalDelete(ic, resourceName);
/* 70 */       handleAction(102);
/* 71 */       break;
/*    */     case 3:
/*    */     case 5:
/* 76 */       break;
/*    */     default:
/* 79 */       Diagnostics.error("Error in AbstractDatabaseObject.commit(), internalStatus for object is " + status + ", object = " + this);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected int getInternalStatus()
/*    */   {
/* 86 */     return this._status;
/*    */   }
/*    */ 
/*    */   protected void handleAction(int action)
/*    */   {
/* 91 */     switch (this._status)
/*    */     {
/*    */     case 1:
/* 94 */       switch (action)
/*    */       {
/*    */       case 101:
/*    */       case 102:
/* 98 */         this._status = 3;
/* 99 */         break;
/*    */       case 103:
/* 102 */         this._status = 5;
/* 103 */         break;
/*    */       case 105:
/* 106 */         this._status = 1;
/*    */       case 104:
/*    */       }
/* 109 */       break;
/*    */     case 2:
/*    */     case 3:
/* 113 */       switch (action)
/*    */       {
/*    */       case 101:
/*    */       case 102:
/* 117 */         this._status = 3;
/* 118 */         break;
/*    */       case 103:
/* 121 */         this._status = 4;
/* 122 */         break;
/*    */       case 105:
/* 125 */         this._status = 2;
/*    */       case 104:
/*    */       }
/* 128 */       break;
/*    */     case 4:
/* 131 */       switch (action)
/*    */       {
/*    */       case 102:
/* 134 */         this._status = 5;
/* 135 */         break;
/*    */       case 101:
/*    */       case 103:
/*    */       case 104:
/*    */       case 105:
/*    */       }
/*    */ 
/* 146 */       break;
/*    */     case 5:
/* 149 */       switch (action)
/*    */       {
/*    */       case 101:
/*    */       case 102:
/*    */       case 103:
/*    */       case 104:
/*    */       case 105:
/*    */       }
/*    */       break;
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.AbstractDatabaseObject
 * JD-Core Version:    0.6.2
 */