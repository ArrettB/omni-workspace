/*     */ package dynamic.dbtk.meta;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class MetaTable extends DBObject
/*     */ {
/*     */   private Vector columns;
/*     */   private PrimaryKey primaryKey;
/*     */   private Vector foreignKeys;
/*     */   private String owner;
/*     */   private String description;
/*     */   private String DBSourceID;
/*     */ 
/*     */   public MetaTable(Vector columns, PrimaryKey primaryKey, Vector foreignKeys, String owner, String description, String DBSourceID)
/*     */   {
/*  18 */     this.columns = columns;
/*  19 */     this.primaryKey = primaryKey;
/*  20 */     this.foreignKeys = foreignKeys;
/*  21 */     this.owner = owner;
/*  22 */     this.description = description;
/*  23 */     this.DBSourceID = DBSourceID;
/*     */   }
/*     */ 
/*     */   public MetaTable()
/*     */   {
/*  28 */     this.columns = new Vector();
/*  29 */     this.foreignKeys = new Vector();
/*     */   }
/*     */ 
/*     */   public void addColumn(MetaColumn col)
/*     */   {
/*  34 */     if (col != null)
/*     */     {
/*  36 */       this.columns.addElement(col);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setPrimaryKey(PrimaryKey pkey)
/*     */   {
/*  42 */     this.primaryKey = pkey;
/*     */   }
/*     */ 
/*     */   public void addForeignKey(ForeignKey fKey)
/*     */   {
/*  47 */     if (fKey != null)
/*     */     {
/*  49 */       this.foreignKeys.addElement(fKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Vector getColumns()
/*     */   {
/*  55 */     return this.columns;
/*     */   }
/*     */ 
/*     */   public MetaColumn getColumn(String name)
/*     */   {
/*  60 */     for (Enumeration e = this.columns.elements(); e.hasMoreElements(); ) {
/*  61 */       MetaColumn metaColumn = (MetaColumn)e.nextElement();
/*  62 */       if (name.compareTo(metaColumn.getDBName()) == 0) {
/*  63 */         return metaColumn;
/*     */       }
/*     */     }
/*     */ 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   public MetaColumn getColumn(int id)
/*     */   {
/*  76 */     String mcID = Integer.toString(id);
/*     */ 
/*  78 */     for (Enumeration e = this.columns.elements(); e.hasMoreElements(); )
/*     */     {
/*  80 */       MetaColumn mc = (MetaColumn)e.nextElement();
/*     */ 
/*  82 */       if (mcID.equals(mc.getInternalID()))
/*     */       {
/*  84 */         return mc;
/*     */       }
/*     */     }
/*     */ 
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */   public PrimaryKey getPrimaryKey()
/*     */   {
/*  93 */     return this.primaryKey;
/*     */   }
/*     */ 
/*     */   public Vector getForeignKeys()
/*     */   {
/*  98 */     return this.foreignKeys;
/*     */   }
/*     */ 
/*     */   public ForeignKey getForeignKey(String name)
/*     */   {
/* 103 */     for (Enumeration e = this.foreignKeys.elements(); e.hasMoreElements(); ) {
/* 104 */       ForeignKey foreignKey = (ForeignKey)e.nextElement();
/* 105 */       if (name.compareTo(foreignKey.getDBName()) == 0) {
/* 106 */         return foreignKey;
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   public String getOwner()
/*     */   {
/* 116 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 121 */     return this.description;
/*     */   }
/*     */ 
/*     */   public String getDBSourceID()
/*     */   {
/* 126 */     return this.DBSourceID;
/*     */   }
/*     */ 
/*     */   public void setOwner(String owner)
/*     */   {
/* 131 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */   public void setDescription(String desc)
/*     */   {
/* 136 */     this.description = desc;
/*     */   }
/*     */ 
/*     */   public void setDBSourceID(String id)
/*     */   {
/* 141 */     this.DBSourceID = id;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.MetaTable
 * JD-Core Version:    0.6.2
 */