/*    */ package dynamic.dbtk.meta;
/*    */ 
/*    */ import dynamic.util.string.StringUtil;
/*    */ 
/*    */ public class DBObject
/*    */ {
/*    */   private String internalID;
/*    */   private String dbName;
/*    */   private String displayName;
/*    */ 
/*    */   public DBObject()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DBObject(String internalID, String dbName)
/*    */   {
/* 20 */     this.internalID = internalID;
/* 21 */     this.dbName = dbName;
/* 22 */     this.displayName = getDefaultTranslation(dbName);
/*    */   }
/*    */ 
/*    */   private String getDefaultTranslation(String s)
/*    */   {
/* 27 */     return StringUtil.toInitialCaps(s.replace('_', ' ').toLowerCase());
/*    */   }
/*    */ 
/*    */   public String getInternalID()
/*    */   {
/* 32 */     return this.internalID;
/*    */   }
/*    */ 
/*    */   public String getDBName()
/*    */   {
/* 37 */     return this.dbName;
/*    */   }
/*    */ 
/*    */   public String getDisplayName()
/*    */   {
/* 42 */     return this.displayName;
/*    */   }
/*    */ 
/*    */   public void setInternalID(String id)
/*    */   {
/* 47 */     this.internalID = id;
/*    */   }
/*    */ 
/*    */   public void setDBName(String name)
/*    */   {
/* 52 */     this.dbName = name;
/*    */ 
/* 54 */     setDisplayName(getDefaultTranslation(name));
/*    */   }
/*    */ 
/*    */   public void setDisplayName(String name)
/*    */   {
/* 59 */     this.displayName = name;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.meta.DBObject
 * JD-Core Version:    0.6.2
 */