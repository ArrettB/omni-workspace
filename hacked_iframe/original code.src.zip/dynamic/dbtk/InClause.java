/*     */ package dynamic.dbtk;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class InClause
/*     */ {
/*  36 */   static short MAX_IN_ITEMS = 254;
/*     */ 
/*  41 */   Vector vClause = null;
/*     */ 
/*  45 */   String clause = null;
/*     */ 
/*  50 */   int count = 0;
/*     */   String columnName;
/*     */ 
/*     */   public InClause()
/*     */   {
/*  58 */     this(null);
/*     */   }
/*     */ 
/*     */   public InClause(String columnName)
/*     */   {
/*  63 */     this.columnName = columnName;
/*  64 */     this.vClause = new Vector();
/*     */   }
/*     */ 
/*     */   public void add(long val)
/*     */   {
/*  69 */     this.vClause.addElement(new Long(val));
/*     */   }
/*     */ 
/*     */   public void add(int val)
/*     */   {
/*  74 */     this.vClause.addElement(new Integer(val));
/*     */   }
/*     */ 
/*     */   public void add(String val)
/*     */   {
/*  79 */     this.vClause.addElement(val);
/*     */   }
/*     */ 
/*     */   public void add(Vector v)
/*     */   {
/*  84 */     if (v != null)
/*     */     {
/*  86 */       int size = v.size();
/*  87 */       for (int i = 0; i < size; i++)
/*     */       {
/*  89 */         add(v.elementAt(i).toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(Enumeration e)
/*     */   {
/*  96 */     if (e != null)
/*     */     {
/*  98 */       while (e.hasMoreElements())
/*     */       {
/* 100 */         add(e.nextElement().toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(Object[] array)
/*     */   {
/* 107 */     if (array != null)
/*     */     {
/* 109 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 111 */         add(array[i].toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(int[] array)
/*     */   {
/* 118 */     if (array != null)
/*     */     {
/* 120 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 122 */         add(array[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(long[] array)
/*     */   {
/* 129 */     if (array != null)
/*     */     {
/* 131 */       for (int i = 0; i < array.length; i++)
/*     */       {
/* 133 */         add(array[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getInClause()
/*     */     throws Exception
/*     */   {
/* 143 */     return getInClause(null);
/*     */   }
/*     */ 
/*     */   public String getInClause(String columnName)
/*     */     throws Exception
/*     */   {
/* 152 */     if (columnName != null)
/* 153 */       this.columnName = columnName;
/* 154 */     return getClause("OR", this.columnName, " IN");
/*     */   }
/*     */ 
/*     */   public String getNotInClause()
/*     */     throws Exception
/*     */   {
/* 162 */     return getNotInClause(null);
/*     */   }
/*     */ 
/*     */   public String getNotInClause(String columnName)
/*     */     throws Exception
/*     */   {
/* 171 */     if (columnName != null)
/* 172 */       this.columnName = columnName;
/* 173 */     return getClause("AND", this.columnName, " NOT IN");
/*     */   }
/*     */ 
/*     */   public boolean isValid()
/*     */   {
/* 181 */     return this.vClause.size() > 0;
/*     */   }
/*     */ 
/*     */   private void increment(String condition, String column, String inClauseSep)
/*     */   {
/* 189 */     if (this.count == MAX_IN_ITEMS)
/*     */     {
/* 191 */       this.clause = (this.clause + ") " + condition + " " + column + inClauseSep + " (");
/*     */     }
/* 193 */     else if (this.count > 0)
/*     */     {
/* 195 */       this.clause += ",";
/*     */     }
/* 197 */     this.count += 1;
/*     */   }
/*     */ 
/*     */   private String getClause(String condition, String column, String inClauseSep)
/*     */     throws Exception
/*     */   {
/* 208 */     this.clause = new String();
/* 209 */     this.count = 0;
/*     */ 
/* 211 */     if (isValid())
/*     */     {
/* 215 */       this.clause = (this.clause + "(" + column + inClauseSep + "(");
/* 216 */       for (int i = 0; i < this.vClause.size(); i++)
/*     */       {
/* 218 */         Object curVal = this.vClause.elementAt(i);
/* 219 */         if (((curVal instanceof Integer)) || ((curVal instanceof Long)))
/*     */         {
/* 221 */           increment(condition, column, inClauseSep);
/* 222 */           this.clause += curVal;
/*     */         }
/* 224 */         else if ((curVal instanceof String))
/*     */         {
/* 226 */           increment(condition, column, inClauseSep);
/* 227 */           this.clause = (this.clause + "'" + curVal + "'");
/*     */         }
/*     */         else
/*     */         {
/* 231 */           throw new Exception("InClause.getInClause(). Type not supported.");
/*     */         }
/*     */       }
/*     */ 
/* 235 */       this.clause += "))";
/*     */ 
/* 237 */       return this.clause;
/*     */     }
/*     */ 
/* 242 */     return this.clause = this.clause + column + inClauseSep + " (-1) ";
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.InClause
 * JD-Core Version:    0.6.2
 */