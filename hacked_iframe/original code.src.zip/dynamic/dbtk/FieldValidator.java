/*     */ package dynamic.dbtk;
/*     */ 
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.SQLException;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Date;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class FieldValidator
/*     */ {
/*     */   public static boolean validateZips(ConnectionWrapper conn, String field, String value, String zip)
/*     */     throws SQLException
/*     */   {
/*  28 */     if ((value == null) || (value.length() == 0) || (zip == null) || (zip.length() == 0)) return true;
/*     */ 
/*  30 */     String query = "SELECT count(*) FROM zips WHERE zip=" + StringUtil.toSqlString(zip) + "   AND " + field + "=" + StringUtil.toSqlString(value);
/*     */ 
/*  34 */     String count = conn.queryEx(query);
/*  35 */     return (count != null) && (Integer.parseInt(count) > 0);
/*     */   }
/*     */ 
/*     */   public static boolean validateMandatory(String value)
/*     */   {
/*  43 */     return (value != null) && (value.length() > 0);
/*     */   }
/*     */ 
/*     */   public static boolean validateDate(String date)
/*     */   {
/*  51 */     boolean result = true;
/*     */ 
/*  53 */     if ((date == null) || (date.length() == 0)) return result;
/*     */ 
/*     */     try
/*     */     {
/*  57 */       tmp = new StdDate(date);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       Date tmp;
/*  61 */       result = false;
/*     */     }
/*     */ 
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean validateNumber(String s)
/*     */   {
/*  72 */     if (s == null) return true;
/*     */ 
/*  75 */     int start_no = 0;
/*  76 */     if ((s.length() > 0) && (s.charAt(0) == '-')) {
/*  77 */       start_no = s.indexOf("-") + 1;
/*     */     }
/*  79 */     for (int i = start_no; i < s.length(); i++)
/*     */     {
/*  81 */       char c = s.charAt(i);
/*  82 */       if ((!Character.isDigit(c)) && (c != '.'))
/*     */       {
/*  88 */         return false;
/*     */       }
/*     */     }
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean validateLength(String s, int maxLength)
/*     */   {
/*  99 */     if (s == null) return true;
/* 100 */     return s.length() <= maxLength;
/*     */   }
/*     */ 
/*     */   public static boolean validatePhone(String s)
/*     */   {
/* 108 */     if ((s == null) || (s.length() == 0)) return true;
/* 109 */     return StringUtil.getDigits(s, false).length() >= 10;
/*     */   }
/*     */ 
/*     */   public static String formatPercent(String s, String numDecimals, boolean divide)
/*     */   {
/* 118 */     if (s != null) s = s.trim();
/* 119 */     if ((s == null) || (s.length() == 0)) return "";
/*     */ 
/* 121 */     String result = StringUtil.getDBPercent(s, numDecimals, divide);
/* 122 */     if ((validateNumber(result)) && (result != null))
/*     */     {
/* 124 */       BigDecimal value = new BigDecimal(result);
/* 125 */       value = value.movePointRight(2);
/*     */ 
/* 127 */       boolean is_negative = false;
/* 128 */       if (value.doubleValue() < 0.0D)
/*     */       {
/* 130 */         value = value.abs();
/* 131 */         is_negative = true;
/*     */       }
/* 133 */       if ((numDecimals != null) && (validateNumber(numDecimals)))
/*     */       {
/* 135 */         int new_numDecimals = new Integer(numDecimals).intValue();
/* 136 */         if (new_numDecimals < 0)
/*     */         {
/* 138 */           Diagnostics.error("Cannot set number of decimals to less then 0.");
/* 139 */           new_numDecimals = 0;
/*     */         }
/* 141 */         value = value.setScale(new_numDecimals, 6);
/*     */       }
/*     */ 
/* 144 */       if (is_negative) {
/* 145 */         return "(" + value.toString() + "%)";
/*     */       }
/* 147 */       return "" + value.toString() + "%";
/*     */     }
/*     */ 
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean validateMoney(String s)
/*     */   {
/* 159 */     if (s != null) s = s.trim();
/* 160 */     if ((s == null) || (s.length() == 0)) return true;
/*     */ 
/* 162 */     boolean result = true;
/*     */     try
/*     */     {
/* 166 */       String digits = StringUtil.getDigits(s, true);
/* 167 */       NumberFormat.getCurrencyInstance().format(Double.valueOf(digits));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 171 */       result = false;
/*     */     }
/*     */ 
/* 174 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean validateEmail(String s)
/*     */   {
/* 182 */     if ((s == null) || (s.length() == 0)) return true;
/* 183 */     if (s.indexOf("@") == -1) return false;
/* 184 */     if (s.indexOf(".") == -1) return false;
/* 185 */     if (s.length() < 6) return false;
/*     */ 
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   public static String validatePassword(String s)
/*     */   {
/* 195 */     if ((s == null) || (s.length() < 6)) return "This password is too short (min 6)";
/* 196 */     boolean foundNonLetter = false;
/* 197 */     for (int i = 0; i < s.length(); i++)
/*     */     {
/* 199 */       char c = s.charAt(i);
/* 200 */       if (!Character.isLetter(c)) foundNonLetter = true;
/*     */     }
/* 202 */     if (!foundNonLetter) return "This password only contains letters";
/*     */ 
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean validateNetworkAddress(String ip)
/*     */   {
/* 212 */     if (ip == null) return true;
/*     */ 
/* 214 */     StringTokenizer ipAddress = new StringTokenizer(ip, ".");
/*     */ 
/* 216 */     if (ipAddress.countTokens() != 4) return false;
/* 217 */     while (ipAddress.hasMoreTokens()) {
/* 218 */       if (Integer.parseInt(ipAddress.nextToken()) > 255) return false;
/*     */     }
/* 220 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean validatePercent(String s)
/*     */   {
/* 228 */     if (s != null) s = s.trim();
/* 229 */     if ((s == null) || (s.length() == 0)) return true;
/*     */ 
/* 232 */     int start_index = 0;
/* 233 */     int end_index = s.length();
/*     */ 
/* 235 */     if (s.indexOf("(") >= 0) {
/* 236 */       start_index = s.indexOf("(") + 1;
/*     */     }
/* 238 */     if (s.indexOf(")") > 0) {
/* 239 */       end_index = s.indexOf(")");
/*     */     }
/* 241 */     if (s.indexOf("%") > 0) {
/* 242 */       end_index = s.indexOf("%");
/*     */     }
/* 244 */     String result = s.substring(start_index, end_index);
/*     */ 
/* 246 */     if (validateNumber(result))
/*     */     {
/* 248 */       return true;
/*     */     }
/*     */ 
/* 251 */     return false;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.FieldValidator
 * JD-Core Version:    0.6.2
 */