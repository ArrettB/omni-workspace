/*    */ package dynamic.dbtk;
/*    */ 
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class MetaDataColumn
/*    */ {
/* 14 */   private String name = null;
/* 15 */   private String type = null;
/* 16 */   private int size = 0;
/* 17 */   private boolean mandatory = false;
/*    */ 
/*    */   public MetaDataColumn()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MetaDataColumn(ResultSetMetaData meta, int i) throws SQLException {
/* 24 */     this.name = meta.getColumnName(i).toLowerCase();
/* 25 */     this.type = meta.getColumnTypeName(i).toLowerCase();
/* 26 */     if (this.type.equals("datetime")) this.type = "date";
/* 27 */     if (this.type.equals("numeric")) this.type = "number";
/* 28 */     if (this.type.equals("int")) this.type = "number";
/* 29 */     this.size = meta.getPrecision(i);
/* 30 */     if (this.size == 0) this.size = meta.getColumnDisplaySize(i);
/* 31 */     this.mandatory = (meta.isNullable(i) == 0);
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 36 */     return getClass().getName() + "(" + this.name + "): " + this.type + "(" + this.size + ") " + (this.mandatory ? "not null" : "null");
/*    */   }
/*    */   public String getColumnName() {
/* 39 */     return this.name; } 
/* 40 */   public String getColumnTypeName() { return this.type; } 
/* 41 */   public int getColumnDisplaySize() { return this.size; } 
/* 42 */   public boolean isColumnMandatory() { return this.mandatory; }
/*    */ 
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.dbtk.MetaDataColumn
 * JD-Core Version:    0.6.2
 */