/*    */ package dynamic.intraframe.logmanager;
/*    */ 
/*    */ import java.io.RandomAccessFile;
/*    */ 
/*    */ public class FileLoggingRecorder extends LoggingMulticaster
/*    */   implements LogManager
/*    */ {
/*  9 */   private LoggingMulticaster parent = null;
/*    */ 
/*    */   public FileLoggingRecorder(LoggingMulticaster parentObject)
/*    */   {
/* 13 */     this.parent = parentObject;
/*    */   }
/*    */   public void initialize(String ConfigFileName) {
/*    */   }
/*    */   public void destroy() {
/*    */   }
/*    */ 
/*    */   public void writeLogRecord() throws Exception {
/* 21 */     RandomAccessFile ofile = null;
/*    */     try
/*    */     {
/* 25 */       ofile = new RandomAccessFile(this.parent.getLogName(), "rw");
/*    */ 
/* 29 */       ofile.seek(ofile.length());
/*    */ 
/* 31 */       String currentTime = getLogTime();
/*    */ 
/* 34 */       ofile.writeBytes(currentTime + "\t" + this.parent.getActionType() + "\t" + this.parent.getExtendedData() + "\t" + this.parent.getUserId() + "\t" + this.parent.getActionRequest() + "\t" + this.parent.getSessionId() + "\t" + this.parent.getUrlRequest() + "\n");
/*    */     }
/*    */     finally
/*    */     {
/* 45 */       if (ofile != null) ofile.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.logmanager.FileLoggingRecorder
 * JD-Core Version:    0.6.2
 */