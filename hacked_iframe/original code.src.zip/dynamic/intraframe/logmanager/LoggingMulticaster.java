/*     */ package dynamic.intraframe.logmanager;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.Configuration;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.util.Calendar;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class LoggingMulticaster
/*     */ {
/*     */   private String url;
/*     */   private String userId;
/*     */   private String actionRequest;
/*     */   private String sessionId;
/*     */   private String[] parameters;
/*     */   private String actionType;
/*     */   private String extendedData;
/*     */   private String logName;
/*     */ 
/*     */   public LoggingMulticaster()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LoggingMulticaster(InvocationContext ic, String actionType, String extendedData, String logNamePassed)
/*     */     throws Exception
/*     */   {
/* 121 */     Configuration Config = ic.getConfig();
/*     */ 
/* 125 */     setUrlRequest(ic.getHttpServletRequest().getRequestURI());
/*     */ 
/* 128 */     Object tmpUserId = ic.getSessionDatum("userId");
/*     */     String userId;
/* 131 */     if (tmpUserId == null)
/*     */     {
/* 133 */       userId = "unknown";
/*     */     }
/*     */     else
/*     */     {
/* 137 */       userId = tmpUserId.toString();
/*     */     }
/*     */ 
/* 140 */     setUserId(userId);
/* 141 */     setActionRequested(ic.getHttpServletRequest().getQueryString());
/* 142 */     setSessionId(ic.getSessionID());
/*     */ 
/* 145 */     setActionType(actionType);
/*     */ 
/* 149 */     setExtendedData(extendedData);
/*     */ 
/* 154 */     LogConfigurationElement logConfig = new LogConfigurationElement(Config);
/* 155 */     int logConfigIndex = -1;
/*     */ 
/* 157 */     int ilength = logConfig.fileType.length;
/*     */ 
/* 159 */     for (int i = 0; i < ilength; i++)
/*     */     {
/* 161 */       if (logNamePassed.equals(logConfig.fileType[i]))
/*     */       {
/* 164 */         logConfigIndex = i;
/* 165 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 169 */     if (logConfigIndex == -1)
/*     */     {
/* 172 */       Diagnostics.debug("Error, no matching file type found in config file.");
/* 173 */       return;
/*     */     }
/*     */ 
/* 177 */     setLogName(logConfig.logPath[logConfigIndex]);
/*     */ 
/* 183 */     FileLoggingRecorder fileRecord = new FileLoggingRecorder(this);
/* 184 */     fileRecord.writeLogRecord();
/*     */   }
/*     */ 
/*     */   public String getLogDate()
/*     */   {
/* 191 */     Calendar currentDate = Calendar.getInstance();
/* 192 */     String today = currentDate.get(2) + 1 + "-" + currentDate.get(5) + "-" + currentDate.get(1);
/*     */ 
/* 196 */     return today;
/*     */   }
/*     */ 
/*     */   public String getLogTime()
/*     */   {
/* 204 */     Calendar currentDate = Calendar.getInstance();
/*     */ 
/* 206 */     int minute = currentDate.get(12);
/* 207 */     int second = currentDate.get(13);
/*     */ 
/* 209 */     String currentTime = currentDate.get(11) + ":" + (minute < 10 ? "0" + minute : new StringBuffer().append("").append(minute).toString()) + ":" + (second < 10 ? "0" + second : new StringBuffer().append("").append(second).toString());
/*     */ 
/* 213 */     return currentTime;
/*     */   }
/*     */ 
/*     */   public String getLogName()
/*     */   {
/* 219 */     return this.logName;
/*     */   }
/*     */ 
/*     */   public void setLogName(String newLogName)
/*     */   {
/* 224 */     StringBuffer log = new StringBuffer(newLogName);
/*     */ 
/* 226 */     int indexExt = newLogName.lastIndexOf(".log");
/* 227 */     if (indexExt != -1)
/*     */     {
/* 230 */       log.insert(indexExt, "." + getLogDate());
/*     */     }
/*     */     else
/*     */     {
/* 235 */       log.append("." + getLogDate() + ".log");
/*     */     }
/* 237 */     this.logName = log.toString();
/*     */   }
/*     */ 
/*     */   public String getActionType()
/*     */   {
/* 242 */     return this.actionType;
/*     */   }
/*     */ 
/*     */   public void setActionType(String newActionType)
/*     */   {
/* 247 */     this.actionType = newActionType;
/*     */   }
/*     */ 
/*     */   public String getExtendedData()
/*     */   {
/* 252 */     return this.extendedData;
/*     */   }
/*     */ 
/*     */   public void setExtendedData(String newExtendedData)
/*     */   {
/* 257 */     this.extendedData = newExtendedData;
/*     */   }
/*     */ 
/*     */   public String getUrlRequest()
/*     */   {
/* 262 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setUrlRequest(String newUrl)
/*     */   {
/* 267 */     this.url = newUrl;
/*     */   }
/*     */ 
/*     */   public String getUserId()
/*     */   {
/* 272 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public void setUserId(String newUserId)
/*     */   {
/* 277 */     this.userId = newUserId;
/*     */   }
/*     */ 
/*     */   public String getActionRequest()
/*     */   {
/* 282 */     return this.actionRequest;
/*     */   }
/*     */ 
/*     */   public void setActionRequested(String newActionRequest)
/*     */   {
/* 287 */     this.actionRequest = newActionRequest;
/*     */   }
/*     */ 
/*     */   public String getSessionId()
/*     */   {
/* 292 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */   public void setSessionId(String newSessionId)
/*     */   {
/* 297 */     this.sessionId = newSessionId;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.logmanager.LoggingMulticaster
 * JD-Core Version:    0.6.2
 */