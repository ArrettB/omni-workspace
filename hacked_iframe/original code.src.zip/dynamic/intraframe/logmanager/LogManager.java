package dynamic.intraframe.logmanager;

public abstract interface LogManager
{
  public abstract void initialize(String paramString);

  public abstract void writeLogRecord()
    throws Exception;
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.logmanager.LogManager
 * JD-Core Version:    0.6.2
 */