/*    */ package dynamic.intraframe.logmanager;
/*    */ 
/*    */ import dynamic.intraframe.engine.Configuration;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ class LogConfigurationElement
/*    */ {
/* 15 */   private static String TAG_NAME = "LOGMANAGER";
/*    */ 
/* 17 */   public String[] logClass = new String[50];
/* 18 */   public String[] logPath = new String[50];
/* 19 */   public String[] fileType = new String[50];
/*    */ 
/*    */   public LogConfigurationElement(Configuration Config)
/*    */   {
/* 24 */     Diagnostics.trace("LogConfigurationElement()");
/*    */ 
/* 26 */     Document doc = Config.getConfigDocument();
/*    */ 
/* 29 */     NodeList nl = doc.getElementsByTagName(TAG_NAME);
/*    */ 
/* 31 */     if (nl.getLength() >= 1)
/*    */     {
/* 35 */       for (int n = 0; n < nl.getLength(); n++)
/*    */       {
/* 37 */         if (nl.item(n).hasChildNodes())
/*    */         {
/* 40 */           NodeList cn = nl.item(n).getChildNodes();
/*    */ 
/* 42 */           for (int j = 0; j < cn.getLength(); j++)
/*    */           {
/* 45 */             if (cn.item(j).hasChildNodes())
/*    */             {
/* 47 */               NodeList secnodes = cn.item(j).getChildNodes();
/* 48 */               for (int i = 0; i < secnodes.getLength(); i++)
/*    */               {
/* 51 */                 if (secnodes.item(i).hasChildNodes())
/*    */                 {
/* 53 */                   NodeList cncn = secnodes.item(i).getChildNodes();
/*    */ 
/* 56 */                   if (secnodes.item(j).getNodeName() != null)
/*    */                   {
/* 59 */                     this.fileType[i] = secnodes.item(i).getNodeName();
/* 60 */                     Diagnostics.debug("--fileType=" + this.fileType[i]);
/*    */ 
/* 63 */                     if (cncn.item(1).hasChildNodes())
/*    */                     {
/* 65 */                       Diagnostics.debug("setting logClass");
/* 66 */                       NodeList cncncn = cncn.item(1).getChildNodes();
/* 67 */                       this.logClass[i] = cncncn.item(0).getNodeValue();
/* 68 */                       Diagnostics.debug("--logClass=" + this.logClass[i]);
/*    */                     }
/*    */                     else {
/* 71 */                       this.logClass[i] = null;
/*    */                     }
/*    */ 
/* 75 */                     if (cncn.item(3).hasChildNodes())
/*    */                     {
/* 77 */                       Diagnostics.debug("setting logPath");
/* 78 */                       NodeList cncncn = cncn.item(3).getChildNodes();
/* 79 */                       this.logPath[i] = cncncn.item(0).getNodeValue();
/* 80 */                       Diagnostics.debug("--logPath=" + this.logPath[i]);
/*    */                     }
/*    */                     else {
/* 83 */                       this.logPath[i] = null;
/*    */                     }
/*    */                   }
/*    */                 }
/*    */               }
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.logmanager.LogConfigurationElement
 * JD-Core Version:    0.6.2
 */