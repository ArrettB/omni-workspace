/*     */ package dynamic.intraframe.templates;
/*     */ 
/*     */ class TestObject
/*     */ {
/* 217 */   public int field1 = 1;
/* 218 */   public String field2 = "2";
/* 219 */   public Object field3 = new Object();
/*     */ 
/* 220 */   public String method1() { return "method1() was invoked"; } 
/* 221 */   public String method2(int i) { return "method2(" + i + ") was invoked"; } 
/* 222 */   public String method3(String s) { return "method3('" + s + "') was invoked"; } 
/* 223 */   public String method4(String s, int i) { return "method4('" + s + "'," + i + ") was invoked"; } 
/* 224 */   public String method5(boolean b) { return "method5(" + b + ") was invoked"; }
/*     */ 
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.TestObject
 * JD-Core Version:    0.6.2
 */