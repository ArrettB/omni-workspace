/*     */ package dynamic.intraframe.templates;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.ConfigurationException;
/*     */ import dynamic.util.cache.Cache;
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class TemplateManager
/*     */ {
/*  34 */   private Hashtable components = new Hashtable();
/*  35 */   private Hashtable templates = null;
/*  36 */   private TemplatePreparser preparser = new TemplatePreparser();
/*  37 */   private File root = null;
/*  38 */   private Vector extentions = new Vector();
/*     */ 
/*     */   public void initialize(ApplicationContext ac)
/*     */     throws Exception
/*     */   {
/*  46 */     Document xmlDoc = ac.getConfigDocument();
/*  47 */     Element templateElement = XMLUtils.getSingleElement(xmlDoc, "templateManager");
/*     */ 
/*  49 */     String size = templateElement.getAttribute("size");
/*  50 */     if ((size != null) && (size.length() > 0))
/*  51 */       this.templates = new Cache(Integer.parseInt(size));
/*     */     else {
/*  53 */       this.templates = new Hashtable(200);
/*     */     }
/*  55 */     String path = templateElement.getAttribute("path");
/*  56 */     if ((path == null) || (path.length() == 0))
/*     */     {
/*  58 */       throw new ConfigurationException("path not set");
/*     */     }
/*     */ 
/*  62 */     this.root = new File(path);
/*  63 */     if (!this.root.exists())
/*  64 */       throw new ConfigurationException("The path \"" + this.root + "\" does not exist");
/*  65 */     if (!this.root.isDirectory())
/*  66 */       throw new ConfigurationException("The path \"" + this.root + "\" is not a directory");
/*  67 */     if (!this.root.canRead()) {
/*  68 */       throw new ConfigurationException("The path \"" + this.root + "\" is not readable");
/*     */     }
/*     */ 
/*  71 */     this.extentions.removeAllElements();
/*  72 */     String tmp = templateElement.getAttribute("extentions");
/*  73 */     if ((tmp != null) && (tmp.length() > 0))
/*  74 */       this.extentions = StringUtil.stringToVector(tmp, ';');
/*  75 */     this.extentions.insertElementAt(new String(""), 0);
/*     */ 
/*  77 */     NodeList tcList = templateElement.getElementsByTagName("templateComponent");
/*  78 */     for (int i = 0; i < tcList.getLength(); i++)
/*     */     {
/*  80 */       Element tcElement = (Element)tcList.item(i);
/*  81 */       String name = tcElement.getAttribute("name");
/*  82 */       String key = name.toLowerCase();
/*  83 */       String classname = tcElement.getAttribute("class");
/*  84 */       Diagnostics.trace("Loading template component " + name + " class=" + classname);
/*  85 */       Class factory = ac.loadClass(classname);
/*  86 */       TemplateComponent comp = (TemplateComponent)factory.newInstance();
/*  87 */       comp.initialize(name);
/*  88 */       NamedNodeMap attributes = tcElement.getAttributes();
/*  89 */       for (int j = 0; j < attributes.getLength(); j++)
/*     */       {
/*  91 */         Attr a = (Attr)attributes.item(j);
/*  92 */         String aname = a.getName();
/*  93 */         String avalue = a.getValue();
/*  94 */         if ((!aname.equals("name")) && (!aname.equals("class"))) {
/*  95 */           Diagnostics.trace("Adding attribute " + aname + "=\"" + avalue + "\" to template component " + name);
/*  96 */           comp.addAttribute(aname, avalue);
/*     */         }
/*     */       }
/*  98 */       this.components.put(key, comp);
/*     */     }
/*     */ 
/* 101 */     NodeList subList = templateElement.getElementsByTagName("substitution");
/* 102 */     for (int i = 0; i < subList.getLength(); i++)
/*     */     {
/* 104 */       Element subElement = (Element)subList.item(i);
/* 105 */       Element matchElement = (Element)subElement.getElementsByTagName("match").item(0);
/* 106 */       Element replaceElement = (Element)subElement.getElementsByTagName("replace").item(0);
/* 107 */       String match = XMLUtils.getEnclosedText(matchElement);
/* 108 */       String replace = XMLUtils.getEnclosedText(replaceElement);
/* 109 */       this.preparser.addSubstitution(match, replace);
/*     */     }
/*     */ 
/* 112 */     String load = templateElement.getAttribute("load");
/* 113 */     if ((load == null) || (load.length() == 0) || (load.equalsIgnoreCase("yes")))
/* 114 */       loadTemplates(this.root);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 122 */     if (this.components != null)
/*     */     {
/* 124 */       Enumeration e = this.components.elements();
/* 125 */       while (e.hasMoreElements())
/* 126 */         ((TemplateComponent)e.nextElement()).destroy();
/* 127 */       this.components.clear();
/* 128 */       this.components = null;
/*     */     }
/*     */ 
/* 131 */     if (this.templates != null)
/*     */     {
/* 133 */       Enumeration e = this.templates.elements();
/* 134 */       while (e.hasMoreElements())
/* 135 */         ((Template)e.nextElement()).destroy();
/* 136 */       this.templates.clear();
/* 137 */       this.templates = null;
/*     */     }
/*     */ 
/* 140 */     this.preparser = null;
/*     */   }
/*     */ 
/*     */   public String toHTML()
/*     */   {
/* 148 */     StringBuffer result = new StringBuffer();
/* 149 */     result.append("<b>Path:</b> " + this.root + "<br>");
/* 150 */     result.append("<b>Extentions:</b> " + this.extentions + "<br>");
/*     */ 
/* 152 */     result.append("<table width=\"100%\">\n");
/* 153 */     result.append("<tr>\n");
/* 154 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Template</b></font></td>\n");
/* 155 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Loaded</b></font></td>\n");
/* 156 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Last Modified</b></font></td>\n");
/* 157 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Req</b></font></td>\n");
/* 158 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Total</b></font></td>\n");
/* 159 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Last</b></font></td>\n");
/* 160 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Min</b></font></td>\n");
/* 161 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Avg</b></font></td>\n");
/* 162 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Max</b></font></td>\n");
/* 163 */     result.append("</tr>");
/* 164 */     Enumeration keys = Sort.keys(this.templates);
/* 165 */     while (keys.hasMoreElements())
/*     */     {
/* 167 */       String key = (String)keys.nextElement();
/* 168 */       Template t = (Template)this.templates.get(key);
/* 169 */       result.append("<tr>\n");
/* 170 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getName() + "</font></td>\n");
/* 171 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(t.getLoadedTime()) + "</font></td>\n");
/* 172 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(t.getLastModifiedTime()) + "</font></td>\n");
/* 173 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getRequestCount() + "</font></td>\n");
/* 174 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getTotalTime() + "ms</font></td>\n");
/* 175 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getLastTime() + "ms</font></td>\n");
/* 176 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getMinTime() + "ms</font></td>\n");
/* 177 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getAverageTime() + "ms</font></td>\n");
/* 178 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + t.getMaxTime() + "ms</font></td>\n");
/* 179 */       result.append("</tr>");
/*     */     }
/* 181 */     result.append("</table>");
/*     */ 
/* 183 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public boolean isValidTemplate(String name)
/*     */   {
/*     */     try
/*     */     {
/* 195 */       Template result = getTemplate(name);
/* 196 */       return true;
/*     */     }
/*     */     catch (Throwable t) {
/*     */     }
/* 200 */     return false;
/*     */   }
/*     */ 
/*     */   public Template getTemplate(String name)
/*     */     throws Exception
/*     */   {
/* 211 */     if ((name == null) || (name.length() == 0)) throw new NullPointerException("Template was not specified");
/* 212 */     if (name.charAt(0) == '/') name = name.substring(1);
/*     */ 
/* 214 */     Template result = null;
/*     */ 
/* 216 */     for (int i = 0; i < this.extentions.size(); i++)
/*     */     {
/* 218 */       String n = name + (String)this.extentions.elementAt(i);
/* 219 */       File file = new File(this.root, n);
/* 220 */       if (file.exists())
/*     */       {
/* 222 */         if (!file.isFile())
/* 223 */           throw new IOException("File " + file + " is not a normal file");
/* 224 */         if (!file.canRead()) {
/* 225 */           throw new IOException("File " + file + " is not readable");
/*     */         }
/* 227 */         result = (Template)this.templates.get(n);
/* 228 */         if ((result != null) && (file.lastModified() == result.getLastModifiedTime()))
/*     */           break;
/* 230 */         Diagnostics.trace("Loading template " + n);
/* 231 */         String content = readFile(file);
/* 232 */         result = new Template().initialize(this, null, n, content, file.lastModified());
/*     */ 
/* 234 */         this.templates.put(n, result); break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 240 */     if (result == null) {
/* 241 */       throw new FileNotFoundException(name);
/*     */     }
/* 243 */     return result;
/*     */   }
/*     */ 
/*     */   public TemplateComponent getTemplateComponent(String name)
/*     */     throws Exception
/*     */   {
/* 253 */     if (name == null) throw new NullPointerException("TemplateComponent name is null");
/* 254 */     String key = name.toLowerCase();
/* 255 */     TemplateComponent comp = (TemplateComponent)this.components.get(key);
/* 256 */     if (comp == null) throw new Exception("Unknown template component \"" + name + "\"");
/* 257 */     TemplateComponent result = (TemplateComponent)comp.clone();
/* 258 */     return result;
/*     */   }
/*     */ 
/*     */   public String readFile(File file)
/*     */     throws IOException, FileNotFoundException
/*     */   {
/* 268 */     String s = null;
/* 269 */     FileInputStream fis = null;
/*     */     try
/*     */     {
/* 273 */       fis = new FileInputStream(file);
/* 274 */       byte[] buf = new byte[fis.available()];
/* 275 */       fis.read(buf);
/* 276 */       s = new String(buf);
/*     */     }
/*     */     finally
/*     */     {
/* 280 */       if (fis != null) fis.close();
/*     */     }
/*     */ 
/* 283 */     return this.preparser.performSubstitutions(s);
/*     */   }
/*     */ 
/*     */   public void loadTemplates(File path)
/*     */     throws Exception
/*     */   {
/* 292 */     String[] filename = path.list();
/* 293 */     for (int i = 0; i < filename.length; i++)
/*     */     {
/* 295 */       File f = new File(path, filename[i]);
/* 296 */       if (f.isDirectory())
/*     */       {
/* 298 */         loadTemplates(f);
/*     */       }
/*     */       else
/*     */       {
/* 302 */         String name = f.getPath().substring(this.root.getPath().length() + 1);
/* 303 */         name = StringUtil.replaceString(name, "\\", "/");
/* 304 */         getTemplate(name);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.TemplateManager
 * JD-Core Version:    0.6.2
 */