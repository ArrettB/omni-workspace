/*     */ package dynamic.intraframe.templates;
/*     */ 
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.components.SimpleComponent;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.diagnostics.DiagnosticsMessage;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public abstract class TemplateComponent
/*     */   implements Cloneable
/*     */ {
/*     */   protected static final String START_TAG = "<!--#";
/*     */   protected static final String END_TAG = "-->";
/*  26 */   protected TemplateManager manager = null;
/*  27 */   protected TemplateComponent parent = null;
/*  28 */   protected String header = null;
/*  29 */   protected boolean hasEndTag = false;
/*  30 */   protected boolean hasExtendedAttributes = false;
/*     */ 
/*  32 */   protected Vector children = new Vector();
/*  33 */   protected Vector requiredAttributes = new Vector();
/*  34 */   protected Vector optionalAttributes = new Vector();
/*  35 */   protected Vector deprecatedAttributes = new Vector();
/*  36 */   protected Hashtable attributes = new Hashtable();
/*     */ 
/*  38 */   protected String name = null;
/*  39 */   protected long requestCount = 0L;
/*  40 */   protected long totalTime = 0L;
/*  41 */   protected long minTime = -1L;
/*  42 */   protected long maxTime = -1L;
/*  43 */   protected long lastTime = 0L;
/*     */ 
/*     */   public TemplateComponent initialize(String name)
/*     */   {
/*  47 */     this.name = name;
/*  48 */     return this;
/*     */   }
/*     */ 
/*     */   public abstract String includeInternal(InvocationContext paramInvocationContext) throws Exception;
/*     */ 
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/*  55 */     TemplateComponent n = (TemplateComponent)super.clone();
/*  56 */     n.children = ((Vector)this.children.clone());
/*  57 */     n.requiredAttributes = ((Vector)this.requiredAttributes.clone());
/*  58 */     n.optionalAttributes = ((Vector)this.optionalAttributes.clone());
/*  59 */     n.deprecatedAttributes = ((Vector)this.deprecatedAttributes.clone());
/*  60 */     n.attributes = ((Hashtable)this.attributes.clone());
/*  61 */     this.requestCount = 0L;
/*  62 */     this.totalTime = 0L;
/*  63 */     this.minTime = -1L;
/*  64 */     this.maxTime = -1L;
/*  65 */     this.lastTime = 0L;
/*  66 */     return n;
/*     */   }
/*     */ 
/*     */   public final TemplateComponent initialize(TemplateManager manager, TemplateComponent parent, String header, String body)
/*     */     throws Exception
/*     */   {
/*  72 */     this.manager = manager;
/*  73 */     this.parent = parent;
/*  74 */     if (header != null) header = header.trim();
/*  75 */     this.header = header;
/*  76 */     parseAttributes();
/*  77 */     parse(body);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  83 */     if (this.children != null)
/*     */     {
/*  85 */       for (int i = 0; i < this.children.size(); i++)
/*     */       {
/*  87 */         ((TemplateComponent)this.children.elementAt(i)).destroy();
/*     */       }
/*  89 */       this.children.removeAllElements();
/*  90 */       this.children = null;
/*     */     }
/*  92 */     if (this.deprecatedAttributes != null)
/*     */     {
/*  94 */       this.deprecatedAttributes.removeAllElements();
/*  95 */       this.deprecatedAttributes = null;
/*     */     }
/*  97 */     if (this.requiredAttributes != null)
/*     */     {
/*  99 */       this.requiredAttributes.removeAllElements();
/* 100 */       this.requiredAttributes = null;
/*     */     }
/* 102 */     if (this.optionalAttributes != null)
/*     */     {
/* 104 */       this.optionalAttributes.removeAllElements();
/* 105 */       this.optionalAttributes = null;
/*     */     }
/* 107 */     if (this.attributes != null)
/*     */     {
/* 109 */       this.attributes.clear();
/* 110 */       this.attributes = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String include(InvocationContext ic) throws Exception
/*     */   {
/* 116 */     long startTime = System.currentTimeMillis();
/* 117 */     StringBuffer result = new StringBuffer();
/*     */     try
/*     */     {
/* 120 */       result.append(includeInternal(ic));
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 124 */       DiagnosticsMessage m = Diagnostics.error("Problem including template component " + this, t);
/* 125 */       result.append(m.toHTML());
/*     */     }
/*     */     finally
/*     */     {
/* 129 */       this.requestCount += 1L;
/* 130 */       this.lastTime = (System.currentTimeMillis() - startTime);
/* 131 */       this.totalTime += this.lastTime;
/* 132 */       if ((this.minTime == -1L) || (this.lastTime < this.minTime)) this.minTime = this.lastTime;
/* 133 */       if ((this.maxTime == -1L) || (this.lastTime > this.maxTime)) this.maxTime = this.lastTime;
/*     */     }
/*     */ 
/* 136 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 141 */     return this.name;
/*     */   }
/*     */ 
/*     */   public TemplateComponent getParent() throws Exception
/*     */   {
/* 146 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 151 */     String result = this.name;
/* 152 */     if (this.header != null) result = result + " " + this.header;
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   public long getRequestCount()
/*     */   {
/* 158 */     return this.requestCount;
/*     */   }
/*     */ 
/*     */   public long getTotalTime()
/*     */   {
/* 163 */     return this.totalTime;
/*     */   }
/*     */ 
/*     */   public long getMinTime()
/*     */   {
/* 168 */     return this.minTime;
/*     */   }
/*     */ 
/*     */   public long getAverageTime()
/*     */   {
/* 173 */     if (this.requestCount == 0L) return 0L;
/* 174 */     return this.totalTime / this.requestCount;
/*     */   }
/*     */ 
/*     */   public long getMaxTime()
/*     */   {
/* 179 */     return this.maxTime;
/*     */   }
/*     */ 
/*     */   public long getLastTime()
/*     */   {
/* 184 */     return this.lastTime;
/*     */   }
/*     */ 
/*     */   public void addComponent(TemplateComponent child)
/*     */     throws Exception
/*     */   {
/* 191 */     child.parent = this;
/* 192 */     this.children.addElement(child);
/*     */   }
/*     */ 
/*     */   public void addAttribute(String name, String value)
/*     */     throws Exception
/*     */   {
/* 198 */     if ((!this.hasExtendedAttributes) && (!isRegisteredAttribute(name))) throw new Exception("Unknown attribute \"" + name + "\" in TemplateComponent " + getName());
/* 199 */     String key = name.toLowerCase();
/* 200 */     if (this.deprecatedAttributes.contains(key)) Diagnostics.warning("Attribute " + getName() + ":" + name + " is deprecated");
/* 201 */     this.attributes.put(key, new TemplateAttribute(name, value));
/*     */   }
/*     */ 
/*     */   public void allowsExtendedAttributes()
/*     */   {
/* 206 */     this.hasExtendedAttributes = true;
/*     */   }
/*     */ 
/*     */   public Vector getExtendedAttributes() throws Exception
/*     */   {
/* 211 */     if (!this.hasExtendedAttributes) throw new Exception("Attempt to get extended attributes on a componet that does not allow them " + this);
/*     */ 
/* 213 */     Vector result = new Vector();
/*     */ 
/* 215 */     Enumeration e = this.attributes.elements();
/* 216 */     while (e.hasMoreElements())
/*     */     {
/* 218 */       TemplateAttribute a = (TemplateAttribute)e.nextElement();
/* 219 */       String name = a.getName();
/* 220 */       if (!isRegisteredAttribute(name)) {
/* 221 */         result.addElement(name);
/*     */       }
/*     */     }
/* 224 */     return result;
/*     */   }
/*     */ 
/*     */   public String getExtendedAttributesString(InvocationContext ic) throws Exception
/*     */   {
/* 229 */     if (!this.hasExtendedAttributes) throw new Exception("Attempt to get extended attributes on a componet that does not allow them " + this);
/*     */ 
/* 231 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 233 */     Enumeration elements = getExtendedAttributes().elements();
/* 234 */     while (elements.hasMoreElements())
/*     */     {
/* 236 */       String key = (String)elements.nextElement();
/* 237 */       result.append(" " + key + "=" + "\"" + getString(ic, key) + "\"");
/*     */     }
/*     */ 
/* 240 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public void requiresEndTag()
/*     */   {
/* 245 */     this.hasEndTag = true;
/*     */   }
/*     */ 
/*     */   public String includeChildren(InvocationContext ic) throws Exception
/*     */   {
/* 250 */     StringBuffer result = new StringBuffer();
/* 251 */     for (int i = 0; i < this.children.size(); i++)
/*     */     {
/* 253 */       TemplateComponent c = (TemplateComponent)this.children.elementAt(i);
/* 254 */       result.append(c.include(ic));
/*     */     }
/* 256 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected boolean isRegisteredAttribute(String name) throws Exception
/*     */   {
/* 261 */     String key = name.toLowerCase();
/* 262 */     boolean valid = this.requiredAttributes.contains(key);
/* 263 */     if (!valid) valid = this.optionalAttributes.contains(key);
/* 264 */     if (!valid) valid = this.deprecatedAttributes.contains(key);
/* 265 */     return valid;
/*     */   }
/*     */ 
/*     */   protected TemplateAttribute getAttribute(InvocationContext ic, String name) throws Exception
/*     */   {
/* 270 */     if ((!this.hasExtendedAttributes) && (!isRegisteredAttribute(name))) throw new Exception("Attempt to get an unknown attribute \"" + name + "\" from TemplateComponent " + getName());
/* 271 */     String key = name.toLowerCase();
/* 272 */     return (TemplateAttribute)this.attributes.get(key);
/*     */   }
/*     */ 
/*     */   public String getString(InvocationContext ic, String name)
/*     */     throws Exception
/*     */   {
/* 281 */     TemplateAttribute a = getAttribute(ic, name);
/* 282 */     String result = null;
/* 283 */     if (a != null) result = a.evaluate(ic);
/* 284 */     return result;
/*     */   }
/*     */ 
/*     */   public Object getObject(InvocationContext ic, String name) throws Exception
/*     */   {
/* 289 */     TemplateAttribute a = getAttribute(ic, name);
/* 290 */     Object result = null;
/* 291 */     if (a != null) result = a.evaluateObject(ic);
/* 292 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(InvocationContext ic, String name) throws Exception
/*     */   {
/* 297 */     return StringUtil.toBoolean(getString(ic, name));
/*     */   }
/*     */ 
/*     */   public double getDouble(InvocationContext ic, String name) throws Exception
/*     */   {
/* 302 */     String s = getString(ic, name);
/* 303 */     if ((s == null) || (s.length() == 0)) return 0.0D;
/*     */ 
/* 305 */     return Double.valueOf(s).doubleValue();
/*     */   }
/*     */ 
/*     */   public int getInt(InvocationContext ic, String name) throws Exception
/*     */   {
/* 310 */     String s = getString(ic, name);
/* 311 */     if ((s == null) || (s.length() == 0)) return 0;
/* 312 */     return Integer.parseInt(s);
/*     */   }
/*     */ 
/*     */   public void registerRequiredAttribute(String name)
/*     */   {
/* 317 */     String key = name.toLowerCase();
/* 318 */     this.requiredAttributes.addElement(key);
/*     */   }
/*     */ 
/*     */   public void registerDeprecatedAttribute(String name, String defaultValue) throws Exception
/*     */   {
/* 323 */     String key = name.toLowerCase();
/* 324 */     this.deprecatedAttributes.addElement(key);
/* 325 */     if (defaultValue != null)
/* 326 */       this.attributes.put(key, new TemplateAttribute(name, defaultValue));
/*     */   }
/*     */ 
/*     */   public void registerAttribute(String name, String defaultValue) throws Exception
/*     */   {
/* 331 */     String key = name.toLowerCase();
/* 332 */     this.optionalAttributes.addElement(key);
/* 333 */     if (defaultValue != null)
/* 334 */       this.attributes.put(key, new TemplateAttribute(name, defaultValue));
/*     */   }
/*     */ 
/*     */   private int plainText(String text) throws Exception
/*     */   {
/* 339 */     if (text.length() > 0)
/*     */     {
/* 341 */       TemplateComponent a = new SimpleComponent(this.manager, this, text);
/* 342 */       addComponent(a);
/*     */     }
/* 344 */     return text.length();
/*     */   }
/*     */ 
/*     */   private int endOfIdentifier(String s)
/*     */   {
/* 350 */     if (s == null) return -1;
/* 351 */     for (int i = 0; i < s.length(); i++) {
/* 352 */       if (!Character.isJavaIdentifierPart(s.charAt(i))) return i;
/*     */     }
/* 354 */     return s.length();
/*     */   }
/*     */ 
/*     */   protected void parse(String content) throws Exception
/*     */   {
/* 359 */     this.children.removeAllElements();
/* 360 */     if ((content == null) || (content.length() == 0)) return;
/*     */ 
/* 362 */     int lastPos = 0;
/*     */ 
/* 364 */     while (lastPos < content.length())
/*     */     {
/* 367 */       int startTagPos = content.indexOf("<!--#", lastPos);
/* 368 */       if (startTagPos == -1)
/*     */       {
/* 370 */         lastPos += plainText(content.substring(lastPos));
/*     */       }
/*     */       else
/*     */       {
/* 375 */         lastPos += plainText(content.substring(lastPos, startTagPos));
/*     */ 
/* 378 */         int endTagPos = content.indexOf("-->", startTagPos);
/* 379 */         if (endTagPos == -1)
/*     */         {
/* 381 */           throw new Exception("Found start tag with no end tag in component " + content);
/*     */         }
/*     */ 
/* 386 */         int nextStartTagPos = content.indexOf("<!--#", startTagPos + "<!--#".length());
/* 387 */         if ((nextStartTagPos != -1) && (nextStartTagPos < endTagPos))
/*     */         {
/* 389 */           throw new Exception("Found start tag embedded in component " + content);
/*     */         }
/*     */ 
/* 394 */         String theTag = content.substring(startTagPos + "<!--#".length(), endTagPos);
/*     */ 
/* 396 */         if (!Character.isJavaIdentifierStart(theTag.charAt(0))) throw new Exception("Invalid character \"" + theTag.charAt(0) + "\" found in tag " + theTag);
/* 397 */         int tagIndicatorEnd = endOfIdentifier(theTag);
/* 398 */         String name = theTag.substring(0, tagIndicatorEnd);
/* 399 */         String header = theTag.substring(tagIndicatorEnd);
/* 400 */         String body = null;
/*     */ 
/* 403 */         TemplateComponent c = this.manager.getTemplateComponent(name);
/* 404 */         if (c.hasEndTag)
/*     */         {
/* 406 */           String openingTag = "<!--#" + name;
/* 407 */           String closingTag = "<!--#/" + name;
/*     */ 
/* 409 */           int currentPos = endTagPos + "-->".length();
/*     */ 
/* 411 */           int nextClosePos = 0;
/* 412 */           int count = 1;
/* 413 */           while (count > 0)
/*     */           {
/* 415 */             int nextOpenPos = content.indexOf(openingTag, currentPos);
/* 416 */             nextClosePos = content.indexOf(closingTag, currentPos);
/*     */ 
/* 418 */             if (nextClosePos < 0)
/*     */             {
/* 420 */               throw new Exception("Missing \"" + closingTag + "-->" + "\" on component " + theTag);
/*     */             }
/* 422 */             if ((nextOpenPos < 0) || (nextOpenPos > nextClosePos))
/*     */             {
/* 425 */               count--;
/* 426 */               currentPos = nextClosePos + closingTag.length() + "-->".length();
/*     */             }
/*     */             else
/*     */             {
/* 430 */               count++;
/* 431 */               currentPos = nextOpenPos + openingTag.length() + "-->".length();
/*     */             }
/*     */           }
/*     */ 
/* 435 */           body = content.substring(endTagPos + "-->".length(), nextClosePos);
/* 436 */           endTagPos = content.indexOf("-->", nextClosePos);
/* 437 */           if (endTagPos == -1)
/*     */           {
/* 439 */             throw new Exception("Expected " + closingTag + "-->" + " found " + content.substring(nextClosePos));
/*     */           }
/*     */         }
/* 442 */         c.initialize(this.manager, this, header, body);
/* 443 */         addComponent(c);
/*     */ 
/* 445 */         lastPos = endTagPos + "-->".length();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getJavaIdentifier(InvocationContext ic, String name) throws Exception {
/* 451 */     String result = getString(ic, name);
/* 452 */     if (result == null) return result;
/* 453 */     int x = result.lastIndexOf('/');
/* 454 */     if (x != -1) result = result.substring(x + 1);
/* 455 */     return result;
/*     */   }
/*     */ 
/*     */   protected void parseAttributes() throws Exception
/*     */   {
/* 460 */     int LOOKING_FOR_NAME = 1;
/* 461 */     int IN_NAME = 2;
/* 462 */     int LOOKING_FOR_ASSIGN = 3;
/* 463 */     int LOOKING_FOR_VALUE = 4;
/* 464 */     int IN_VALUE = 5;
/*     */ 
/* 466 */     if ((this.header == null) || (this.header.length() == 0)) return;
/*     */ 
/* 468 */     int state = 1;
/* 469 */     String currName = "";
/* 470 */     String currValue = "";
/*     */ 
/* 472 */     char[] input = this.header.trim().toCharArray();
/*     */ 
/* 474 */     for (int i = 0; i < input.length; i++)
/*     */     {
/* 476 */       char c = input[i];
/* 477 */       switch (c)
/*     */       {
/*     */       case '=':
/* 480 */         switch (state)
/*     */         {
/*     */         case 1:
/*     */         case 4:
/* 484 */           throw new Exception("Unexpected = found at offset " + i + " in " + this.header);
/*     */         case 2:
/*     */         case 3:
/* 487 */           state = 4;
/* 488 */           break;
/*     */         case 5:
/* 490 */           currValue = currValue + c;
/*     */         }
/*     */ 
/* 493 */         break;
/*     */       case '\t':
/*     */       case '\n':
/*     */       case '\f':
/*     */       case '\r':
/*     */       case ' ':
/* 500 */         switch (state)
/*     */         {
/*     */         case 2:
/* 503 */           state = 3;
/* 504 */           break;
/*     */         case 5:
/* 506 */           currValue = currValue + c;
/*     */         }
/*     */ 
/* 509 */         break;
/*     */       case '\\':
/* 512 */         switch (state)
/*     */         {
/*     */         case 1:
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/* 518 */           throw new Exception("Unexpected \\ found at offset " + i + " in " + this.header);
/*     */         case 5:
/* 520 */           c = input[(++i)];
/* 521 */           currValue = currValue + c;
/*     */         }
/*     */ 
/* 524 */         break;
/*     */       case '"':
/* 527 */         switch (state)
/*     */         {
/*     */         case 1:
/*     */         case 2:
/*     */         case 3:
/* 532 */           throw new Exception("Unexpected \" found at offset " + i + " in " + this.header);
/*     */         case 4:
/* 534 */           state = 5;
/* 535 */           break;
/*     */         case 5:
/* 537 */           addAttribute(currName, currValue);
/* 538 */           currName = "";
/* 539 */           currValue = "";
/* 540 */           state = 1;
/*     */         }
/*     */ 
/* 543 */         break;
/*     */       default:
/* 546 */         switch (state)
/*     */         {
/*     */         case 1:
/* 549 */           state = 2;
/*     */         case 2:
/* 551 */           currName = currName + c;
/* 552 */           break;
/*     */         case 3:
/* 554 */           addAttribute(currName, "true");
/* 555 */           currName = "" + c;
/* 556 */           currValue = "";
/* 557 */           state = 2;
/* 558 */           break;
/*     */         case 4:
/* 560 */           throw new Exception("Expected \" at offset " + i + " in " + this.header);
/*     */         case 5:
/* 562 */           currValue = currValue + c;
/*     */         }
/*     */         break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 569 */     switch (state)
/*     */     {
/*     */     case 1:
/* 572 */       break;
/*     */     case 2:
/*     */     case 3:
/* 575 */       addAttribute(currName, "true");
/* 576 */       currName = "";
/* 577 */       currValue = "";
/* 578 */       state = 1;
/* 579 */       break;
/*     */     case 4:
/*     */     case 5:
/* 582 */       throw new Exception("Expected \" but found end of contents in " + this.header);
/*     */     }
/* 584 */     for (int i = 0; i < this.requiredAttributes.size(); i++)
/*     */     {
/* 586 */       String name = (String)this.requiredAttributes.elementAt(i);
/* 587 */       if (!this.attributes.containsKey(name))
/* 588 */         throw new Exception("Missing required attribute \"" + name + "\" in component " + this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void debugAttributes(String atPoint)
/*     */   {
/* 594 */     Diagnostics.debug2("TemplateComponent.debugAttributes():" + atPoint);
/* 595 */     Diagnostics.debug2("Vector children" + this.children);
/* 596 */     Diagnostics.debug2("Vector requiredAttributes" + this.requiredAttributes);
/* 597 */     Diagnostics.debug2("Vector optionalAttributes" + this.optionalAttributes);
/* 598 */     Diagnostics.debug2("Hashtable attributes" + this.attributes);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.TemplateComponent
 * JD-Core Version:    0.6.2
 */