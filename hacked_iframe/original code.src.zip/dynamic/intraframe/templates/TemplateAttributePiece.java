/*     */ package dynamic.intraframe.templates;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class TemplateAttributePiece
/*     */ {
/*  22 */   protected String type = null;
/*  23 */   protected String content = null;
/*  24 */   protected String initialObjectAccessName = null;
/*  25 */   protected String initialObjectLoopIndex = null;
/*  26 */   protected Vector chainedNames = new Vector();
/*  27 */   protected Vector chainedLoopIndicies = new Vector();
/*     */ 
/*  31 */   protected static Vector knownTypes = new Vector();
/*     */ 
/*     */   public static boolean isValidType(String type)
/*     */   {
/*  46 */     return knownTypes.contains(type);
/*     */   }
/*     */ 
/*     */   public TemplateAttributePiece(String content)
/*     */     throws Exception
/*     */   {
/*  54 */     this.content = content;
/*     */   }
/*     */ 
/*     */   public TemplateAttributePiece(String type, String content)
/*     */     throws Exception
/*     */   {
/*  62 */     this.type = type;
/*  63 */     this.content = content;
/*  64 */     if (!isValidType(type)) throw new Exception("Invalid type \"" + type + "\" for TemplateAttributePiece");
/*  65 */     parse();
/*     */   }
/*     */ 
/*     */   public boolean isSimple()
/*     */   {
/*  70 */     return this.type == null;
/*     */   }
/*     */ 
/*     */   public final Object evaluate(InvocationContext ic) throws Exception
/*     */   {
/*  75 */     if (isSimple()) return this.content;
/*     */     Object o;
/*  78 */     if (this.type.equals("a"))
/*  79 */       o = ic.getAppGlobalDatum(this.initialObjectAccessName);
/*  80 */     else if (this.type.equals("c"))
/*  81 */       o = ic.getConfigValue(this.initialObjectAccessName);
/*  82 */     else if (this.type.equals("d"))
/*  83 */       o = ic.getTransientDatum(this.initialObjectAccessName);
/*  84 */     else if (this.type.equals("j"))
/*  85 */       o = ic;
/*  86 */     else if (this.type.equals("p"))
/*  87 */       o = ic.getParameter(this.initialObjectAccessName);
/*  88 */     else if (this.type.equals("r"))
/*  89 */       o = ic.getRowDatum(this.initialObjectAccessName);
/*  90 */     else if (this.type.equals("s"))
/*  91 */       o = ic.getSessionDatum(this.initialObjectAccessName);
/*     */     else {
/*  93 */       throw new Exception("Invalid type \"" + this.type + "\" for TemplateAttributePiece");
/*     */     }
/*  95 */     return evaluateUsingReflection(ic, o);
/*     */   }
/*     */ 
/*     */   private void parse() throws Exception
/*     */   {
/* 100 */     Vector parts = StringUtil.stringToVector(this.content, '.');
/* 101 */     String elementX = (String)parts.elementAt(0);
/*     */ 
/* 103 */     int idx = elementX.indexOf("[");
/* 104 */     if (idx != -1)
/*     */     {
/* 106 */       int idx2 = elementX.indexOf("]");
/* 107 */       String loopIndex = elementX.substring(idx + 1, idx2);
/* 108 */       elementX = elementX.substring(0, idx);
/* 109 */       this.initialObjectAccessName = elementX;
/* 110 */       this.initialObjectLoopIndex = loopIndex;
/*     */     }
/*     */     else
/*     */     {
/* 114 */       this.initialObjectAccessName = elementX;
/* 115 */       this.initialObjectLoopIndex = null;
/*     */     }
/*     */ 
/* 119 */     for (int i = 1; i < parts.size(); i++)
/*     */     {
/* 121 */       String element = (String)parts.elementAt(i);
/*     */ 
/* 123 */       idx = element.indexOf("[");
/* 124 */       if (idx != -1)
/*     */       {
/* 126 */         int idx2 = element.indexOf("]");
/* 127 */         String loopIndex = element.substring(idx + 1, idx2);
/* 128 */         element = element.substring(0, idx);
/* 129 */         this.chainedNames.addElement(element);
/* 130 */         this.chainedLoopIndicies.addElement(loopIndex);
/*     */       }
/*     */       else
/*     */       {
/* 134 */         this.chainedNames.addElement(element);
/* 135 */         this.chainedLoopIndicies.addElement(null);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object evaluateUsingReflection(InvocationContext ic, Object o) throws Exception
/*     */   {
/* 142 */     if (this.initialObjectLoopIndex != null)
/*     */     {
/* 144 */       o = getValueByIndex(ic, (Vector)o, this.initialObjectLoopIndex);
/*     */     }
/*     */ 
/* 147 */     for (int i = 0; i < this.chainedNames.size(); i++)
/*     */     {
/* 149 */       if (o == null) o = new String();
/* 150 */       Class c = o.getClass();
/* 151 */       String memberName = (String)this.chainedNames.elementAt(i);
/* 152 */       int idx = memberName.indexOf("(");
/* 153 */       if (idx != -1)
/*     */       {
/* 155 */         int idx2 = memberName.indexOf(")");
/* 156 */         String paramString = memberName.substring(idx + 1, idx2);
/* 157 */         memberName = memberName.substring(0, idx);
/* 158 */         Vector params = StringUtil.stringToVector(paramString, ',');
/* 159 */         Vector classList = new Vector();
/* 160 */         Vector paramList = new Vector();
/*     */ 
/* 162 */         if (((String)params.elementAt(0)).length() > 0)
/*     */         {
/* 165 */           for (int j = 0; j < params.size(); j++)
/*     */           {
/* 167 */             String p = (String)params.elementAt(j);
/* 168 */             int idx3 = p.indexOf("'");
/* 169 */             int idx4 = p.lastIndexOf("'");
/* 170 */             if ((p.length() > 2) && (idx3 == 0) && (idx4 == p.length() - 1))
/*     */             {
/* 173 */               classList.addElement(ic.loadClass("java.lang.String"));
/* 174 */               paramList.addElement(p.substring(idx3 + 1, idx4));
/*     */             }
/* 176 */             else if ((p.equals("false")) || (p.equals("true")))
/*     */             {
/* 179 */               classList.addElement(Boolean.TYPE);
/* 180 */               paramList.addElement(Boolean.valueOf(p));
/*     */             }
/*     */             else
/*     */             {
/* 185 */               classList.addElement(Integer.TYPE);
/* 186 */               paramList.addElement(Integer.valueOf(p));
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 192 */         Method m = null;
/*     */         try
/*     */         {
/* 195 */           m = c.getMethod(memberName, toClassArray(classList));
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 200 */           c = ic.loadClass("dynamic.util.string.StringUtil");
/* 201 */           classList.insertElementAt(ic.loadClass("java.lang.String"), 0);
/* 202 */           paramList.insertElementAt(o == null ? null : o.toString(), 0);
/* 203 */           m = c.getMethod(memberName, toClassArray(classList));
/*     */         }
/* 205 */         o = m.invoke(o, toObjectArray(paramList));
/*     */       }
/*     */       else
/*     */       {
/*     */         try
/*     */         {
/* 211 */           Field f = c.getField(memberName);
/* 212 */           o = f.get(o);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 217 */           if ((o instanceof Hashtable))
/*     */           {
/* 219 */             o = ((Hashtable)o).get(memberName);
/*     */           }
/*     */           else
/*     */           {
/* 223 */             o = ic.format(o, memberName);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 228 */       if (this.chainedLoopIndicies.elementAt(i) != null)
/*     */       {
/* 230 */         o = getValueByIndex(ic, (Vector)o, (String)this.chainedLoopIndicies.elementAt(i));
/*     */       }
/*     */     }
/*     */ 
/* 234 */     if (o == null) o = new String();
/*     */ 
/* 236 */     return o;
/*     */   }
/*     */ 
/*     */   private Object getValueByIndex(InvocationContext ic, Vector v, String indexName) throws Exception
/*     */   {
/* 241 */     if (v == null) return null;
/*     */ 
/* 243 */     String loopValString = (String)ic.getTransientDatum(indexName);
/* 244 */     if (loopValString == null)
/*     */     {
/* 246 */       throw new Exception("Bad Index: " + indexName);
/*     */     }
/*     */ 
/* 249 */     int loopVal = Integer.parseInt(loopValString);
/* 250 */     if (loopVal >= v.size())
/*     */     {
/* 252 */       throw new Exception("Out of Bounds: " + loopVal);
/*     */     }
/*     */ 
/* 255 */     return v.elementAt(loopVal);
/*     */   }
/*     */ 
/*     */   private Object[] toObjectArray(Vector v)
/*     */   {
/* 260 */     Object[] result = new Object[v.size()];
/* 261 */     v.copyInto(result);
/* 262 */     return result;
/*     */   }
/*     */ 
/*     */   private Class[] toClassArray(Vector v)
/*     */   {
/* 267 */     Class[] result = new Class[v.size()];
/* 268 */     v.copyInto(result);
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  32 */     knownTypes.addElement("a");
/*  33 */     knownTypes.addElement("c");
/*  34 */     knownTypes.addElement("d");
/*  35 */     knownTypes.addElement("j");
/*  36 */     knownTypes.addElement("p");
/*  37 */     knownTypes.addElement("r");
/*  38 */     knownTypes.addElement("s");
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.TemplateAttributePiece
 * JD-Core Version:    0.6.2
 */