/*     */ package dynamic.intraframe.templates;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.components.RequiredComponent;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Template extends TemplateComponent
/*     */ {
/*  17 */   private Vector requiredComps = new Vector();
/*  18 */   private String requiredData = null;
/*  19 */   private long loadedTime = 0L;
/*  20 */   private long lastModifiedTime = 0L;
/*     */ 
/*     */   public Template initialize(TemplateManager manager, TemplateComponent parent, String name, String content, long lastModifiedTime) throws Exception
/*     */   {
/*  24 */     initialize(name);
/*  25 */     this.loadedTime = System.currentTimeMillis();
/*  26 */     this.lastModifiedTime = lastModifiedTime;
/*  27 */     requiresEndTag();
/*  28 */     super.initialize(manager, parent, null, content);
/*  29 */     return this;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  34 */     if (this.requiredComps != null)
/*     */     {
/*  36 */       for (int x = 0; x < this.requiredComps.size(); x++)
/*  37 */         ((TemplateComponent)this.requiredComps.elementAt(x)).destroy();
/*  38 */       this.requiredComps.removeAllElements();
/*  39 */       this.requiredComps = null;
/*     */     }
/*  41 */     super.destroy();
/*     */   }
/*     */ 
/*     */   public String include(InvocationContext ic) throws Exception
/*     */   {
/*  46 */     String currentTemplate = ic.getHTMLTemplateName();
/*  47 */     String result = super.include(ic);
/*  48 */     String newTemplate = ic.getHTMLTemplateName();
/*     */ 
/*  50 */     while ((currentTemplate != null) && (!currentTemplate.equals(newTemplate)))
/*     */     {
/*  52 */       currentTemplate = newTemplate;
/*  53 */       result = "";
/*  54 */       if (newTemplate == null) break;
/*  55 */       result = ic.getTemplate(newTemplate).include(ic);
/*  56 */       newTemplate = ic.getHTMLTemplateName();
/*     */     }
/*     */ 
/*  59 */     return result;
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  64 */     return includeChildren(ic);
/*     */   }
/*     */ 
/*     */   public void addComponent(TemplateComponent comp) throws Exception
/*     */   {
/*  69 */     if ((comp instanceof RequiredComponent))
/*  70 */       this.requiredComps.addElement(comp);
/*  71 */     super.addComponent(comp);
/*     */   }
/*     */ 
/*     */   public boolean requirementsMet(InvocationContext ic) throws Exception
/*     */   {
/*  76 */     for (int i = 0; i < this.requiredComps.size(); i++)
/*     */     {
/*  78 */       RequiredComponent curr = (RequiredComponent)this.requiredComps.elementAt(i);
/*  79 */       if (!curr.requirementsMet(ic))
/*     */       {
/*  81 */         this.requiredData = curr.getRequiredData(ic);
/*  82 */         return false;
/*     */       }
/*     */     }
/*  85 */     this.requiredData = null;
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   public String getRequiredData()
/*     */   {
/*  91 */     return this.requiredData;
/*     */   }
/*     */ 
/*     */   public long getLoadedTime()
/*     */   {
/*  96 */     return this.loadedTime;
/*     */   }
/*     */ 
/*     */   public long getLastModifiedTime()
/*     */   {
/* 101 */     return this.lastModifiedTime;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.Template
 * JD-Core Version:    0.6.2
 */