/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.templates.TemplateAttribute;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import dynamic.util.string.StringUtil;
/*    */ 
/*    */ public class RequiredComponent extends TemplateComponent
/*    */ {
/*    */   public RequiredComponent()
/*    */   {
/* 26 */     registerRequiredAttribute("data");
/*    */   }
/*    */ 
/*    */   public String getRequiredData(InvocationContext ic) throws Exception
/*    */   {
/* 31 */     String data = getAttribute(ic, "data").toString();
/* 32 */     int p1 = data.indexOf(":");
/* 33 */     int p2 = data.indexOf("?>");
/*    */ 
/* 35 */     if ((p1 != -1) && (p2 != -1)) {
/* 36 */       return data.substring(p1 + 1, p2);
/*    */     }
/* 38 */     return data;
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic) throws Exception
/*    */   {
/* 43 */     String data = StringUtil.toHTML(getRequiredData(ic));
/*    */     try
/*    */     {
/* 47 */       String value = StringUtil.toHTML(getString(ic, "data"));
/* 48 */       return "<!--" + getName() + "(requirementsMet=" + requirementsMet(ic) + ") data=\"" + data + "\" value=\"" + value + "\" -->";
/*    */     }
/*    */     catch (Throwable t)
/*    */     {
/* 52 */       Diagnostics.error("Problem with " + getName() + " data=\"" + data + "\"", t);
/* 53 */       return "<!--" + getName() + "(requirementsMet=false) data=\"" + data + "\" threw " + StringUtil.toHTML(t.toString()) + " -->";
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean requirementsMet(InvocationContext ic) throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 61 */       return ElseIfComponent.isDefined(getString(ic, "data"));
/*    */     }
/*    */     catch (Throwable t) {
/*    */     }
/* 65 */     return false;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.RequiredComponent
 * JD-Core Version:    0.6.2
 */