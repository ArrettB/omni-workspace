/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.dbtk.MetaData;
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateAttribute;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SmartFormComponent extends TemplateComponent
/*     */ {
/*     */   public static final String BUTTON = "button";
/*     */   public static final String Save = "Save";
/*     */   public static final String Copy = "Copy";
/*     */   public static final String New = "New";
/*     */   public static final String Delete = "Delete";
/*     */   public static final String Cancel = "Cancel";
/*     */   public static final String Done = "Done";
/*     */   public static final String OK = "OK";
/*     */   public static final String View = "View";
/*     */   public static final String Insert = "Insert";
/*     */   public static final String Update = "Update";
/*     */   public static final String READONLY = "readonly";
/*     */   public static final String SMARTFORM_ERROR = "SMARTFORM_ERROR";
/*     */   public static final String METADATA = "METADATA";
/*     */   public static final String RESOURCE = "RESOURCE";
/*     */   public static final String MODE = "mode";
/*     */   public static final String MANDATORY_FIELDS = "mandatory_fields";
/*     */   public static final String MAND_FORM_ERR_MSG = "mandFormErrMsg";
/*     */   public static final String MAND_FIELD_ERR_MSG = "mandFieldErrMsg";
/*     */   public static final String ALL_FIELDS = "all_fields";
/*     */ 
/*     */   public SmartFormComponent()
/*     */     throws Exception
/*     */   {
/*  79 */     registerAttribute("action", null);
/*  80 */     registerAttribute("buttons", "Save,Copy,New,Delete,Cancel");
/*  81 */     registerDeprecatedAttribute("eca", "smartForm");
/*  82 */     registerAttribute("errorText", "true");
/*  83 */     registerAttribute("errorImage", "");
/*  84 */     registerAttribute("readonly", "false");
/*  85 */     registerRequiredAttribute("key");
/*  86 */     registerRequiredAttribute("name");
/*  87 */     registerAttribute("nextTemplate", null);
/*  88 */     registerAttribute("prevTemplate", null);
/*  89 */     registerAttribute("preHandler", null);
/*  90 */     registerAttribute("validate", null);
/*  91 */     registerAttribute("postHandler", null);
/*  92 */     registerDeprecatedAttribute("redisplayTemplate", null);
/*  93 */     registerAttribute("resourceName", null);
/*  94 */     registerAttribute("security", "true");
/*  95 */     registerAttribute("onClickFunction", null);
/*  96 */     registerAttribute("sequence", null);
/*  97 */     registerRequiredAttribute("table");
/*  98 */     registerAttribute("useCSS", "true");
/*  99 */     registerAttribute("mandFormErrMsg", "At least one mandatory field was not specified");
/* 100 */     registerAttribute("mandFieldErrMsg", "This is a mandatory field");
/* 101 */     registerAttribute("value", null);
/* 102 */     requiresEndTag();
/* 103 */     allowsExtendedAttributes();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/* 108 */     StringBuffer result = new StringBuffer();
/* 109 */     ConnectionWrapper conn = null;
/*     */     try
/*     */     {
/* 113 */       String action = getString(ic, "action");
/* 114 */       String buttons = getString(ic, "buttons");
/* 115 */       String resourceName = getString(ic, "resourceName");
/* 116 */       String eca = getString(ic, "eca");
/* 117 */       boolean errorText = getBoolean(ic, "errorText");
/* 118 */       String key = getString(ic, "key");
/* 119 */       String name = getString(ic, "name");
/*     */ 
/* 121 */       int x = name.lastIndexOf('/');
/*     */       String formName;
/* 122 */       if (x == -1)
/* 123 */         formName = name;
/*     */       else
/* 125 */         formName = name.substring(x + 1);
/* 126 */       String redisplayTemplate = ic.getHTMLTemplateName();
/* 127 */       String nextTemplate = getString(ic, "nextTemplate");
/* 128 */       if (nextTemplate == null) nextTemplate = redisplayTemplate;
/* 129 */       String prevTemplate = getString(ic, "prevTemplate");
/* 130 */       if (prevTemplate == null) prevTemplate = nextTemplate;
/* 131 */       String preHandler = getString(ic, "preHandler");
/* 132 */       boolean validate_flag = getBoolean(ic, "validate");
/* 133 */       String postHandler = getString(ic, "postHandler");
/* 134 */       boolean security = getBoolean(ic, "security");
/* 135 */       String onClickFunction = getString(ic, "onClickFunction");
/* 136 */       String sequence = getString(ic, "sequence");
/* 137 */       String table = getString(ic, "table");
/* 138 */       boolean useCSS = getBoolean(ic, "useCSS");
/* 139 */       String mand_form_err_msg = getString(ic, "mandFormErrMsg");
/* 140 */       if (ic.containsTransientDatum("mandFormErrMsg"))
/* 141 */         mand_form_err_msg = (String)ic.getTransientDatum("mandFormErrMsg");
/* 142 */       String mand_field_err_msg = getString(ic, "mandFieldErrMsg");
/* 143 */       if (ic.containsTransientDatum("mandFieldErrMsg"))
/* 144 */         mand_field_err_msg = (String)ic.getTransientDatum("mandFieldErrMsg");
/* 145 */       String value = getString(ic, "value");
/* 146 */       String key_value = getKeyValue(ic);
/* 147 */       String mode = (key_value == null) || (key_value.length() == 0) ? "Insert" : "Update";
/* 148 */       boolean canView = checkRight(ic, name, "View");
/* 149 */       boolean canUpdate = checkRight(ic, name, "Update");
/* 150 */       boolean canInsert = (checkRight(ic, name, "Insert")) && (sequence != null);
/* 151 */       boolean canDelete = checkRight(ic, name, "Delete");
/*     */ 
/* 153 */       if ((mode.equals("Insert")) && (sequence == null))
/*     */       {
/* 155 */         throw new Exception("Missing required attribute \"sequence\" in component " + this);
/*     */       }
/*     */ 
/* 158 */       boolean canSave = ((mode.equals("Update")) && (canUpdate)) || ((mode.equals("Insert")) && (canInsert));
/* 159 */       if ((!canView) || ((mode.equals("Insert")) && (!canInsert)))
/*     */       {
/* 161 */         result.append("<!-- You do not have permission to view this form. -->");
/*     */       }
/*     */       else
/*     */       {
/* 165 */         if ((action == null) || (action.length() == 0)) {
/* 166 */           action = ic.getSessionDatum("action") + eca;
/*     */         }
/* 168 */         String smartFormErrorText = (String)ic.getTransientDatum("SMARTFORM_ERROR");
/*     */ 
/* 170 */         if ((ic.containsTransientDatum("err@table_" + table)) && (!mand_form_err_msg.equalsIgnoreCase("false")))
/*     */         {
/* 172 */           if (smartFormErrorText == null)
/* 173 */             smartFormErrorText = mand_form_err_msg;
/*     */           else
/* 175 */             smartFormErrorText = smartFormErrorText + mand_form_err_msg;
/*     */         }
/* 177 */         if ((errorText) && (smartFormErrorText != null) && (smartFormErrorText.length() > 0)) {
/* 178 */           result.append("<div class=\"errorText\">" + smartFormErrorText + "</div>");
/*     */         }
/* 180 */         result.append("<form name=\"" + formName + "\"");
/* 181 */         result.append(getExtendedAttributesString(ic));
/* 182 */         result.append(" action=\"" + action + "\"");
/* 183 */         result.append(" method=\"post\"");
/* 184 */         result.append(" class=\"SmartForm\"");
/* 185 */         result.append(">\n");
/*     */ 
/* 188 */         conn = (ConnectionWrapper)ic.getResource(resourceName);
/*     */ 
/* 191 */         result.append(hidden("resourceName", resourceName));
/* 192 */         result.append(hidden("sequence", sequence));
/* 193 */         result.append(hidden("table", table));
/* 194 */         result.append(hidden("key", key));
/* 195 */         result.append(hidden(key, key_value));
/* 196 */         ic.setTransientDatum(key, key_value);
/* 197 */         result.append(hidden("mode", mode));
/* 198 */         result.append(hidden("preHandler", preHandler));
/* 199 */         if (validate_flag)
/* 200 */           result.append(hidden("validate", "true"));
/* 201 */         result.append(hidden("postHandler", postHandler));
/* 202 */         result.append(hidden("redisplayTemplate", redisplayTemplate));
/* 203 */         result.append(hidden("nextTemplate", nextTemplate));
/* 204 */         result.append(hidden("prevTemplate", prevTemplate));
/* 205 */         result.append(hidden("onClickFunction", onClickFunction));
/*     */ 
/* 207 */         String query = "select * from " + table + " where " + key + "=" + StringUtil.toSqlString(key_value);
/*     */ 
/* 209 */         ic.setTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + name, new String());
/* 210 */         QueryResults rs = null;
/* 211 */         if (mode.equals("Update"))
/*     */         {
/* 214 */           Diagnostics.trace("SmartFormComponent.include() SQL: " + query);
/* 215 */           rs = conn.resultsQueryEx(query);
/* 216 */           if (rs.next()) ic.setTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + name, rs);
/*     */         }
/*     */ 
/* 219 */         ic.setTransientDatum("View", "" + canView);
/* 220 */         ic.setTransientDatum("Insert", "" + canInsert);
/* 221 */         ic.setTransientDatum("Update", "" + canUpdate);
/* 222 */         ic.setTransientDatum("Delete", "" + canDelete);
/* 223 */         ic.setTransientDatum("Save", "" + canSave);
/* 224 */         ic.setTransientDatum("mode", "" + mode);
/* 225 */         ic.setTransientDatum("RESOURCE", conn);
/* 226 */         ic.setTransientDatum("METADATA", new MetaData(conn, table));
/* 227 */         ic.setTransientDatum("mandFieldErrMsg", mand_field_err_msg);
/* 228 */         if (ic.getTransientDatum("mandatory") == null)
/* 229 */           ic.setTransientDatum("mandatory", new Vector());
/* 230 */         if (ic.getTransientDatum("fields") == null) {
/* 231 */           ic.setTransientDatum("fields", new Vector());
/*     */         }
/*     */ 
/* 234 */         result.append(includeChildren(ic));
/* 235 */         if (rs != null) rs.close();
/*     */ 
/* 237 */         result.append(getButtons(ic, mode, canSave, canInsert, canDelete, onClickFunction));
/* 238 */         result.append("</form>\n\n");
/* 239 */         result.append(getFieldScript(ic, formName));
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 244 */       if (conn != null) conn.release();
/*     */     }
/*     */ 
/* 247 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private String getKeyValue(InvocationContext ic) throws Exception
/*     */   {
/* 252 */     String result = "";
/* 253 */     String key = getString(ic, "key");
/*     */ 
/* 256 */     Object tmp = ic.getTransientDatum(key);
/* 257 */     if (tmp != null)
/*     */     {
/* 259 */       result = tmp.toString();
/* 260 */       Diagnostics.trace("SmartFormComponent.getKeyValue(" + key + "): using transient data = \"" + result + "\"");
/* 261 */       return result;
/*     */     }
/*     */ 
/* 264 */     result = ic.getParameter(key);
/* 265 */     if (result != null)
/*     */     {
/* 267 */       Diagnostics.trace("SmartFormComponent.getKeyValue(" + key + "): using parameter = \"" + result + "\"");
/* 268 */       return result;
/*     */     }
/*     */ 
/* 271 */     result = getString(ic, "value");
/* 272 */     if (result != null)
/*     */     {
/* 274 */       Diagnostics.trace("SmartFormComponent.getKeyValue(" + key + "): using parameter = \"" + result + "\"");
/* 275 */       return result;
/*     */     }
/*     */ 
/* 278 */     tmp = ic.getSessionDatum(key);
/* 279 */     if (tmp != null)
/*     */     {
/* 281 */       result = tmp.toString();
/* 282 */       Diagnostics.trace("SmartFormComponent.getKeyValue(" + key + "): using session data = \"" + result + "\"");
/* 283 */       return result;
/*     */     }
/*     */ 
/* 286 */     Diagnostics.trace("SmartFormComponent.getKeyValue(" + key + "): using default = \"\"");
/* 287 */     return "";
/*     */   }
/*     */ 
/*     */   private boolean checkRight(InvocationContext ic, String name, String rightName) throws Exception
/*     */   {
/* 292 */     boolean result = false;
/*     */ 
/* 294 */     String security = getString(ic, "security");
/* 295 */     if ((security.equalsIgnoreCase("false")) || (security.equalsIgnoreCase("off")) || (security.equalsIgnoreCase("no")) || (security.equalsIgnoreCase("N")))
/*     */     {
/* 297 */       result = true;
/*     */     }
/*     */     else
/*     */     {
/* 301 */       if ((!security.equalsIgnoreCase("true")) && (!security.equalsIgnoreCase("on")) && (!security.equalsIgnoreCase("yes")) && (!security.equalsIgnoreCase("Y")))
/*     */       {
/* 307 */         name = security + "." + name;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 312 */         TemplateAttribute t = new TemplateAttribute("checkRight", "<?s:" + name + "." + rightName + "?>");
/* 313 */         String right = t.evaluate(ic);
/* 314 */         result = ElseIfComponent.isDefined(right);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */         try
/*     */         {
/* 320 */           TemplateAttribute t = new TemplateAttribute("checkRight", "<?s:" + name + "." + rightName.toLowerCase() + "?>");
/* 321 */           String right = t.evaluate(ic);
/* 322 */           result = ElseIfComponent.isDefined(right);
/*     */         }
/*     */         catch (Exception e2)
/*     */         {
/*     */           try
/*     */           {
/* 328 */             TemplateAttribute t = new TemplateAttribute("checkRight", "<?s:" + name + "." + rightName.toUpperCase() + "?>");
/* 329 */             String right = t.evaluate(ic);
/* 330 */             result = ElseIfComponent.isDefined(right);
/*     */           }
/*     */           catch (Exception e3)
/*     */           {
/* 334 */             result = false;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 340 */     Diagnostics.trace("SmartFormComponent.checkRight(" + name + "." + rightName + ") = " + result);
/* 341 */     return result;
/*     */   }
/*     */ 
/*     */   public static String button(String value, String onClickFunction)
/*     */   {
/* 346 */     StringBuffer button_input = new StringBuffer("");
/* 347 */     if (value != null)
/*     */     {
/* 349 */       button_input.append("\t<td><input type=\"submit\" class=\"button\" name=\"button\" value=\"" + StringUtil.toHTML(value.trim()) + "\"");
/* 350 */       if (onClickFunction != null)
/*     */       {
/* 352 */         int index = onClickFunction.indexOf("(");
/* 353 */         if (index == -1)
/* 354 */           index = onClickFunction.length();
/* 355 */         onClickFunction = onClickFunction.substring(0, index);
/* 356 */         button_input.append(" onClick=\"" + onClickFunction.trim() + "('" + value.trim() + "');\"");
/*     */       }
/* 358 */       button_input.append("></td>\n");
/*     */     }
/* 360 */     return button_input.toString();
/*     */   }
/*     */ 
/*     */   public static String hidden(String name, String value)
/*     */   {
/* 365 */     if (value == null) return "";
/* 366 */     return "\t<input type=\"hidden\" name=\"" + name + "\" value=\"" + StringUtil.toHTML(value) + "\">\n";
/*     */   }
/*     */ 
/*     */   private String getButtons(InvocationContext ic, String mode, boolean canSave, boolean canInsert, boolean canDelete, String onClickFunction)
/*     */     throws Exception
/*     */   {
/* 372 */     StringBuffer result = new StringBuffer();
/* 373 */     String buttons = getString(ic, "buttons");
/* 374 */     String name = getString(ic, "name");
/* 375 */     StringTokenizer st = new StringTokenizer(buttons, ",");
/* 376 */     boolean hasAnyButtons = false;
/* 377 */     boolean showOKButton = false;
/* 378 */     boolean showCancelButton = false;
/* 379 */     boolean showDoneButton = false;
/*     */ 
/* 381 */     while (st.hasMoreTokens())
/*     */     {
/* 383 */       String text = st.nextToken();
/* 384 */       boolean showButton = true;
/* 385 */       if (text.equalsIgnoreCase("Save"))
/*     */       {
/* 387 */         showButton = canSave;
/*     */       }
/* 389 */       else if ((text.equalsIgnoreCase("Copy")) || (text.equalsIgnoreCase("New")))
/*     */       {
/* 391 */         showButton = (mode.equals("Update")) && (canInsert);
/*     */       }
/* 393 */       else if (text.equalsIgnoreCase("Delete"))
/*     */       {
/* 395 */         showButton = (mode.equals("Update")) && (canDelete);
/*     */       }
/* 397 */       else if (text.equalsIgnoreCase("Cancel"))
/*     */       {
/* 399 */         showButton = false;
/* 400 */         showCancelButton = true;
/*     */       }
/* 402 */       else if (text.equalsIgnoreCase("OK"))
/*     */       {
/* 404 */         showButton = false;
/* 405 */         showOKButton = true;
/*     */       }
/* 407 */       else if (text.equalsIgnoreCase("Done"))
/*     */       {
/* 409 */         showDoneButton = true;
/* 410 */         showButton = false;
/*     */       }
/*     */       else
/*     */       {
/* 414 */         showButton = checkRight(ic, name, text);
/*     */       }
/*     */ 
/* 417 */       if (showButton)
/*     */       {
/* 419 */         hasAnyButtons = true;
/* 420 */         result.append(button(text, onClickFunction));
/*     */       }
/*     */     }
/* 423 */     if ((hasAnyButtons) && (showCancelButton))
/*     */     {
/* 426 */       result.append(button("Cancel", onClickFunction));
/*     */     }
/* 428 */     else if ((!hasAnyButtons) && ((showCancelButton) || (showOKButton)) && (!showDoneButton))
/*     */     {
/* 431 */       result.append(button("OK", onClickFunction));
/*     */     }
/* 433 */     if (showDoneButton)
/*     */     {
/* 436 */       result.append(button("Done", onClickFunction));
/*     */     }
/*     */ 
/* 439 */     if (result.length() > 0)
/*     */     {
/* 441 */       return "<table><tr>\n" + result + "</tr></table>\n";
/*     */     }
/*     */ 
/* 445 */     return "";
/*     */   }
/*     */ 
/*     */   private String getFieldScript(InvocationContext ic, String formName)
/*     */     throws Exception
/*     */   {
/* 451 */     StringBuffer result = new StringBuffer();
/* 452 */     String key = getString(ic, "key");
/* 453 */     result.append("<script language=\"JavaScript\">\n");
/* 454 */     result.append("var mandatoryFields = new Array(");
/* 455 */     Vector mandatory = (Vector)ic.getTransientDatum("mandatory");
/* 456 */     for (int x = 0; x < mandatory.size(); x++)
/*     */     {
/* 458 */       String fieldName = (String)mandatory.elementAt(x);
/* 459 */       if (!fieldName.equals(key)) {
/* 460 */         result.append(fieldName);
/*     */       }
/* 462 */       if (x + 1 != mandatory.size())
/* 463 */         result.append(", ");
/*     */     }
/* 465 */     result.append(");\n");
/*     */ 
/* 467 */     result.append("var allFields = new Array(");
/* 468 */     Vector fields = (Vector)ic.getTransientDatum("fields");
/* 469 */     for (int x = 0; x < fields.size(); x++)
/*     */     {
/* 471 */       result.append((String)fields.elementAt(x));
/*     */ 
/* 473 */       if (x + 1 != fields.size())
/* 474 */         result.append(", ");
/*     */     }
/* 476 */     result.append(");\n");
/* 477 */     result.append("var saveButton = document." + formName + ".Save;\n");
/* 478 */     result.append("</script>\n");
/* 479 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SmartFormComponent
 * JD-Core Version:    0.6.2
 */