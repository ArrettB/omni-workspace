/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.exec.ExecUtils;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class ExecComponent extends TemplateComponent
/*     */ {
/*     */   public ExecComponent()
/*     */     throws Exception
/*     */   {
/*  46 */     registerAttribute("action", null);
/*  47 */     registerAttribute("class", null);
/*  48 */     registerAttribute("command", null);
/*  49 */     registerAttribute("handler", null);
/*  50 */     allowsExtendedAttributes();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  55 */     String result = "";
/*     */ 
/*  57 */     String action = getString(ic, "action");
/*  58 */     String className = getString(ic, "class");
/*  59 */     String command = getString(ic, "command");
/*  60 */     String handler = getString(ic, "handler");
/*     */ 
/*  62 */     Vector args = new Vector();
/*  63 */     args.addElement("java");
/*  64 */     if (className != null) args.addElement(className);
/*     */ 
/*  66 */     Hashtable backupParams = new Hashtable();
/*     */ 
/*  68 */     Enumeration elements = getExtendedAttributes().elements();
/*  69 */     while (elements.hasMoreElements())
/*     */     {
/*  71 */       String key = (String)elements.nextElement();
/*  72 */       String value = ic.getParameter(key);
/*  73 */       args.addElement(key + "=" + value);
/*  74 */       if (value != null) backupParams.put(key, value);
/*  75 */       value = getString(ic, key);
/*  76 */       ic.setParameter(key, value);
/*     */     }
/*     */ 
/*  79 */     if (action != null)
/*     */     {
/*  81 */       ic.dispatchAction(action);
/*     */     }
/*  83 */     else if (className != null)
/*     */     {
/*  85 */       String[] cmd = new String[args.size()];
/*  86 */       args.copyInto(cmd);
/*  87 */       result = ExecUtils.exec(cmd);
/*     */     }
/*  89 */     else if (command != null)
/*     */     {
/*  91 */       result = ExecUtils.exec(command);
/*  92 */       result = "<PRE>" + StringUtil.toHTML(result) + "</PRE>";
/*     */     }
/*  94 */     else if (handler != null)
/*     */     {
/*  96 */       ic.dispatchHandler(handler);
/*     */     }
/*     */ 
/* 100 */     elements = getExtendedAttributes().elements();
/* 101 */     while (elements.hasMoreElements())
/*     */     {
/* 103 */       String key = (String)elements.nextElement();
/* 104 */       String value = (String)backupParams.get(key);
/* 105 */       if (value == null) ic.removeParameter(key); else {
/* 106 */         ic.setParameter(key, value);
/*     */       }
/*     */     }
/* 109 */     return result;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.ExecComponent
 * JD-Core Version:    0.6.2
 */