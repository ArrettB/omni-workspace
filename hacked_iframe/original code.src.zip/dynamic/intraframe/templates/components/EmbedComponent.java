/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.intraframe.engine.ApplicationContext;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.templates.Template;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Hashtable;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class EmbedComponent extends TemplateComponent
/*    */ {
/*    */   public EmbedComponent()
/*    */     throws Exception
/*    */   {
/* 20 */     registerDeprecatedAttribute("templateName", null);
/* 21 */     registerAttribute("template", null);
/* 22 */     allowsExtendedAttributes();
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic) throws Exception
/*    */   {
/* 27 */     String template = getString(ic, "template");
/* 28 */     if (template == null) template = getString(ic, "templateName");
/* 29 */     if (template == null) throw new NullPointerException("template is null in component " + this);
/*    */ 
/* 31 */     Hashtable backupParams = new Hashtable();
/*    */ 
/* 33 */     Enumeration elements = getExtendedAttributes().elements();
/* 34 */     while (elements.hasMoreElements())
/*    */     {
/* 36 */       String key = (String)elements.nextElement();
/* 37 */       String value = ic.getParameter(key);
/* 38 */       if (value != null) backupParams.put(key, value);
/* 39 */       value = getString(ic, key);
/* 40 */       ic.setParameter(key, value);
/*    */     }
/*    */ 
/* 43 */     String result = ic.getTemplate(template).include(ic);
/*    */ 
/* 46 */     elements = getExtendedAttributes().elements();
/* 47 */     while (elements.hasMoreElements())
/*    */     {
/* 49 */       String key = (String)elements.nextElement();
/* 50 */       String value = (String)backupParams.get(key);
/* 51 */       if (value == null) ic.removeParameter(key); else {
/* 52 */         ic.setParameter(key, value);
/*    */       }
/*    */     }
/* 55 */     return result;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.EmbedComponent
 * JD-Core Version:    0.6.2
 */