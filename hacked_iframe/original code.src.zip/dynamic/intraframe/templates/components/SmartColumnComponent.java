/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.dbtk.MetaData;
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.dbtk.parser.Sql;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.intraframe.templates.TemplateManager;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SmartColumnComponent extends TemplateComponent
/*     */ {
/*     */   public SmartColumnComponent()
/*     */     throws Exception
/*     */   {
/*  73 */     registerAttribute("aTitle", null);
/*  74 */     registerAttribute("colspan", "1");
/*  75 */     registerAttribute("class", null);
/*  76 */     registerAttribute("dTitle", null);
/*  77 */     registerAttribute("filter", null);
/*  78 */     registerAttribute("filterQuery", null);
/*  79 */     registerAttribute("filterQuick", "false");
/*  80 */     registerAttribute("format", null);
/*  81 */     registerAttribute("href", null);
/*  82 */     registerAttribute("height", "0");
/*  83 */     registerAttribute("linkClass", null);
/*  84 */     registerAttribute("name", "c1");
/*  85 */     registerAttribute("rolloverClass", null);
/*  86 */     registerAttribute("row", "1");
/*  87 */     registerAttribute("size", "0");
/*  88 */     registerAttribute("sort", null);
/*  89 */     registerDeprecatedAttribute("table", null);
/*  90 */     registerAttribute("target", null);
/*  91 */     registerAttribute("title", "");
/*  92 */     registerAttribute("value", null);
/*  93 */     registerAttribute("total", null);
/*  94 */     registerAttribute("onClick", null);
/*  95 */     registerAttribute("numDecimals", "0");
/*  96 */     allowsExtendedAttributes();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/* 101 */     StringBuffer result = new StringBuffer();
/* 102 */     int row = getInt(ic, "row");
/* 103 */     int onRow = Integer.parseInt((String)ic.getRequiredTransientDatum("row"));
/* 104 */     int rowid = Integer.parseInt((String)ic.getRequiredTransientDatum("rowid"));
/*     */ 
/* 106 */     if (row != onRow)
/*     */     {
/* 108 */       result.append("</tr>\n<tr rowid=\"" + rowid + "\">\n");
/* 109 */       ic.setTransientDatum("row", "" + row);
/*     */     }
/* 111 */     result.append("\t");
/* 112 */     if (rowid == 0)
/*     */     {
/* 114 */       result.append(getTitle(ic));
/*     */     }
/* 116 */     else if (rowid == -1)
/*     */     {
/* 118 */       result.append(getFilter(ic));
/*     */     }
/* 120 */     else if (rowid == -2)
/*     */     {
/* 122 */       result.append(getTotal(ic));
/*     */     }
/*     */     else
/*     */     {
/* 126 */       result.append(getRow(ic));
/*     */     }
/* 128 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private String getTitle(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 136 */     StringBuffer result = new StringBuffer();
/* 137 */     StringBuffer href = new StringBuffer();
/* 138 */     StringBuffer td = new StringBuffer();
/* 139 */     StringBuffer events = new StringBuffer();
/*     */ 
/* 141 */     String aTitle = getString(ic, "aTitle");
/* 142 */     int colspan = getInt(ic, "colspan");
/* 143 */     String dTitle = getString(ic, "dTitle");
/* 144 */     String filter = getString(ic, "filter");
/* 145 */     String name = getString(ic, "name");
/* 146 */     int row = getInt(ic, "row");
/* 147 */     String sort = getString(ic, "sort");
/* 148 */     String title = getString(ic, "title");
/* 149 */     SmartTableComponent parent = getTable();
/* 150 */     String parentName = parent.getString(ic, "name");
/* 151 */     int height = parent.getInt(ic, "titleHeight");
/* 152 */     if (height == 0) height = parent.getInt(ic, "rowHeight");
/* 153 */     if (height == 0) height = getInt(ic, "height");
/* 154 */     String normal = parent.getTitleClass(ic, "normal");
/* 155 */     String rollover = parent.getTitleClass(ic, "rollover");
/* 156 */     String pressed = parent.getTitleClass(ic, "pressed");
/*     */     String text;
/*     */     String img;
/* 162 */     if (sort == null)
/*     */     {
/* 164 */       text = title;
/* 165 */       img = null;
/*     */     }
/*     */     else
/*     */     {
/* 169 */       String nextSort = null;
/* 170 */       String orderBy = ic.getParameter(parentName + "_order_by");
/* 171 */       if ((orderBy == null) || (orderBy.length() == 0) || (!orderBy.startsWith(sort)))
/*     */       {
/* 173 */         nextSort = "";
/* 174 */         img = null;
/* 175 */         text = title;
/*     */       }
/* 177 */       else if (orderBy.endsWith("desc"))
/*     */       {
/* 179 */         nextSort = null;
/* 180 */         img = parent.getString(ic, "dSort");
/* 181 */         text = dTitle != null ? dTitle : title;
/* 182 */         normal = parent.getTitleClass(ic, "sorted");
/* 183 */         rollover = parent.getTitleClass(ic, "sortedRollover");
/* 184 */         pressed = parent.getTitleClass(ic, "sortedPressed");
/*     */       }
/*     */       else
/*     */       {
/* 188 */         nextSort = " desc";
/* 189 */         img = parent.getString(ic, "aSort");
/* 190 */         text = aTitle != null ? aTitle : title;
/* 191 */         normal = parent.getTitleClass(ic, "sorted");
/* 192 */         rollover = parent.getTitleClass(ic, "sortedRollover");
/* 193 */         pressed = parent.getTitleClass(ic, "sortedPressed");
/*     */       }
/*     */ 
/* 197 */       String url = (String)ic.getRequiredTransientDatum(parentName + "_filter_action");
/* 198 */       String queryString = SmartTableComponent.getQueryString(ic);
/* 199 */       queryString = SmartTableComponent.setParam(queryString, parentName + "_order_by", nextSort != null ? sort + nextSort : null);
/* 200 */       queryString = SmartTableComponent.setParam(queryString, "startWithRow", null);
/* 201 */       if ((queryString != null) && (queryString.length() > 0)) url = url + "?" + queryString;
/* 202 */       String target = (String)ic.getTransientDatum(parentName + "_filter_target");
/* 203 */       href.append("<a href=\"" + url + "\"");
/* 204 */       if (target != null) href.append(" target=\"" + target + "\"");
/*     */ 
/* 206 */       href.append(">");
/*     */ 
/* 208 */       events.append(" style=\"cursor:hand\"");
/* 209 */       if (normal != null)
/*     */       {
/* 211 */         if (pressed != null)
/*     */         {
/* 213 */           events.append(" onMouseDown=\"this.className='" + pressed + "'; return true\"");
/* 214 */           events.append(" onMouseUp=\"this.className='" + (rollover != null ? rollover : normal) + "'; return true\"");
/*     */         }
/* 216 */         if (rollover != null)
/*     */         {
/* 218 */           events.append(" onMouseOver=\"this.className='" + rollover + "'; return true\"");
/* 219 */           events.append(" onMouseOut=\"this.className='" + normal + "'; return true\"");
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 225 */     td.append("<td");
/* 226 */     if (height > 0) td.append(" height=\"" + height + "\"");
/* 227 */     if (normal != null) td.append(" class=\"" + normal + "\"");
/* 228 */     if (colspan > 1) td.append(" colspan=\"" + colspan + "\"");
/* 229 */     td.append(getExtendedAttributesString(ic));
/* 230 */     td.append(events);
/* 231 */     td.append(">\n");
/*     */ 
/* 234 */     if (ic.isInternetExplorer())
/*     */     {
/* 236 */       result.append(href);
/* 237 */       result.append(td);
/*     */     }
/*     */     else
/*     */     {
/* 241 */       result.append(td);
/* 242 */       result.append("&nbsp;");
/* 243 */       result.append(href);
/*     */     }
/*     */ 
/* 247 */     if ((text == null) || (text.length() == 0) || (text.equals(" "))) text = "&nbsp;";
/* 248 */     result.append(text);
/* 249 */     if (img != null) result.append("&nbsp;" + img);
/*     */ 
/* 252 */     if (ic.isInternetExplorer())
/*     */     {
/* 254 */       result.append("</td>");
/* 255 */       if (href.length() > 0) result.append("</a>");
/*     */     }
/*     */     else
/*     */     {
/* 259 */       if (href.length() > 0) result.append("</a>");
/* 260 */       result.append("</td>");
/*     */     }
/*     */ 
/* 263 */     result.append("\n");
/*     */ 
/* 266 */     if ((filter != null) && (filter.length() > 0))
/*     */     {
/* 268 */       Vector filterList = (Vector)ic.getRequiredTransientDatum(parentName + "_filter_list");
/* 269 */       int idx = filter.indexOf(":");
/* 270 */       if (idx != -1) filter = filter.substring(0, idx);
/* 271 */       filterList.addElement(filter);
/*     */     }
/*     */ 
/* 275 */     if (row == 1)
/*     */     {
/* 277 */       int numcols = Integer.parseInt((String)ic.getRequiredTransientDatum("numcols"));
/* 278 */       int skipcols = Integer.parseInt((String)ic.getRequiredTransientDatum("skipcols"));
/* 279 */       if ((text != null) && (text.length() > 0))
/* 280 */         numcols += colspan;
/*     */       else
/* 282 */         skipcols += colspan;
/* 283 */       ic.setTransientDatum("numcols", "" + numcols);
/* 284 */       ic.setTransientDatum("skipcols", "" + skipcols);
/*     */     }
/*     */ 
/* 287 */     if (name != null) ic.setTransientDatum("lastColumn", name);
/*     */ 
/* 289 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private String getFilter(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 297 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 299 */     int colspan = getInt(ic, "colspan");
/* 300 */     String filter = getString(ic, "filter");
/* 301 */     String filterQuery = getString(ic, "filterQuery");
/* 302 */     boolean filterQuick = getBoolean(ic, "filterQuick");
/* 303 */     String name = getString(ic, "name");
/* 304 */     int size = getInt(ic, "size");
/* 305 */     boolean lastColumn = name.equals(ic.getRequiredTransientDatum("lastColumn"));
/* 306 */     SmartTableComponent parent = getTable();
/* 307 */     String parentName = parent.getString(ic, "name");
/* 308 */     int height = parent.getInt(ic, "titleHeight");
/* 309 */     if (height == 0) height = parent.getInt(ic, "rowHeight");
/* 310 */     if (height == 0) height = getInt(ic, "height");
/* 311 */     String css = parent.getFilterClass(ic);
/*     */ 
/* 314 */     result.append("<td");
/* 315 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 316 */     if ((css != null) && (!lastColumn))
/* 317 */       result.append(" class=\"" + css + "\"");
/* 318 */     if (colspan > 1) result.append(" colspan=\"" + colspan + "\"");
/* 319 */     result.append(getExtendedAttributesString(ic));
/* 320 */     result.append(">");
/*     */ 
/* 322 */     if (lastColumn)
/*     */     {
/* 324 */       result.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\"");
/* 325 */       if (height > 0) result.append(" height=\"" + height + "\"");
/* 326 */       result.append("><tr");
/* 327 */       if (height > 0) result.append(" height=\"" + height + "\"");
/* 328 */       result.append("><td");
/* 329 */       if (height > 0) result.append(" height=\"" + height + "\"");
/* 330 */       if (css != null) result.append(" class=\"" + css + "\"");
/* 331 */       result.append(" style=\"width:100%\"");
/* 332 */       result.append(">");
/*     */     }
/*     */ 
/* 335 */     if ((filter != null) && (filter.length() > 0))
/*     */     {
/* 337 */       String value = null;
/* 338 */       int idx = filter.indexOf(":");
/* 339 */       String params = null;
/* 340 */       if (idx != -1)
/*     */       {
/* 342 */         params = filter.substring(idx + 1);
/* 343 */         filter = filter.substring(0, idx);
/* 344 */         value = ic.getParameter(filter);
/* 345 */         if (value == null) value = "";
/*     */ 
/* 347 */         int x = params.indexOf(" ");
/* 348 */         if (x == -1) x = params.indexOf("=");
/* 349 */         if (x == -1)
/*     */         {
/* 351 */           if (filterQuery == null)
/* 352 */             params = params + " LIKE " + StringUtil.toSQLString(new StringBuffer().append(value).append('%').toString());
/*     */           else
/* 354 */             params = params + " = " + StringUtil.toSQLString(value);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 359 */         value = ic.getParameter(filter);
/* 360 */         if (value == null) value = "";
/*     */       }
/*     */ 
/* 363 */       if (filterQuery == null)
/*     */       {
/* 365 */         result.append("<input type=\"text\" name=\"");
/* 366 */         result.append(filter);
/* 367 */         result.append("\" value=\"");
/* 368 */         if ((value != null) && (value.length() > 0))
/* 369 */           result.append(StringUtil.toHTML(value));
/* 370 */         result.append("\"");
/* 371 */         if (size > 0) result.append(" size=\"" + size + "\"");
/* 372 */         result.append(" class=\"regular\" style=\"width:100%\"");
/* 373 */         if (filterQuick)
/* 374 */           result.append(" onChange=\"this.form.submit(); return true\"");
/* 375 */         result.append(">");
/*     */       }
/*     */       else
/*     */       {
/* 379 */         TemplateComponent select = this.manager.getTemplateComponent("SELECT");
/* 380 */         StringBuffer header = new StringBuffer();
/* 381 */         header.append(" name=\"" + filter + "\"");
/* 382 */         header.append(" query=\"" + filterQuery + "\"");
/* 383 */         header.append(" currentValue=\"<?p:" + filter + "?>\"");
/* 384 */         header.append(" firstOption=\"\"");
/* 385 */         header.append(" firstOptionValue=\"\"");
/* 386 */         header.append(" currentValue=\"<?p:" + filter + "?>\"");
/* 387 */         header.append(" class=\"regular\" style=\"width:100%\"");
/* 388 */         if (filterQuick)
/* 389 */           header.append(" onChange=\"this.form.submit(); return true\"");
/* 390 */         select.initialize(this.manager, null, header.toString(), null);
/* 391 */         result.append("\n");
/* 392 */         result.append(select.include(ic));
/*     */       }
/*     */ 
/* 395 */       if ((params != null) && (value != null) && (value.length() > 0))
/*     */       {
/* 397 */         Sql sql = (Sql)ic.getTransientDatum(parentName + "_sql");
/* 398 */         if (sql == null) sql = Sql.fetchSql((String)ic.getTransientDatum(parentName + "_query"));
/* 399 */         sql = ic.processFilter(sql, "simple(" + params + ")");
/* 400 */         ic.setTransientDatum(parentName + "_sql", sql);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 405 */       result.append("&nbsp;");
/*     */     }
/*     */ 
/* 408 */     if (lastColumn)
/*     */     {
/* 410 */       result.append("</td>");
/* 411 */       result.append("<td");
/* 412 */       if (height > 0) result.append(" height=\"" + height + "\"");
/* 413 */       if (css != null) result.append(" class=\"" + css + "\"");
/* 414 */       result.append("><input type=\"submit\" class=\"button2\" value=\"Search\"></td>");
/* 415 */       result.append("<td");
/* 416 */       if (height > 0) result.append(" height=\"" + height + "\"");
/* 417 */       if (css != null) result.append(" class=\"" + css + "\"");
/* 418 */       result.append("><input type=\"button\" class=\"button2\" value=\"Clear\" onClick=\"return clearFields()\"></td>");
/* 419 */       result.append("</td></tr></table>");
/*     */     }
/*     */ 
/* 423 */     result.append("</td>\n");
/*     */ 
/* 425 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public String getRow(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 433 */     StringBuffer result = new StringBuffer();
/* 434 */     StringBuffer href = new StringBuffer();
/* 435 */     StringBuffer td = new StringBuffer();
/* 436 */     StringBuffer events = new StringBuffer();
/*     */ 
/* 438 */     int colspan = getInt(ic, "colspan");
/* 439 */     String name = getString(ic, "name");
/*     */ 
/* 441 */     String value = getString(ic, "value");
/*     */ 
/* 443 */     SmartTableComponent parent = getTable();
/* 444 */     String parentName = parent.getString(ic, "name");
/* 445 */     MetaData meta = (MetaData)ic.getRequiredTransientDatum(parentName + "_metadata");
/* 446 */     int height = getInt(ic, "height");
/* 447 */     if (height == 0) height = parent.getInt(ic, "rowHeight");
/*     */ 
/* 449 */     QueryResults cursor = (QueryResults)ic.getRequiredTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + parentName);
/*     */ 
/* 451 */     if ((value == null) && (name != null))
/*     */     {
/* 453 */       String format = getString(ic, "format");
/* 454 */       if (format == null)
/* 455 */         value = cursor.getString(name);
/* 456 */       else if (format.equalsIgnoreCase("date"))
/* 457 */         value = SmartFieldComponent.formatDate(cursor.getDate(name));
/* 458 */       else if (format.equalsIgnoreCase("datetime"))
/* 459 */         value = SmartFieldComponent.formatDateTime(cursor.getTimestamp(name));
/* 460 */       else if (format.equalsIgnoreCase("time"))
/* 461 */         value = SmartFieldComponent.formatTime(cursor.getTimestamp(name));
/* 462 */       else if (format.equalsIgnoreCase("money"))
/* 463 */         value = SmartFieldComponent.formatMoney(cursor.getString(name));
/* 464 */       else if (format.equalsIgnoreCase("percent"))
/* 465 */         value = SmartFieldComponent.formatPercent(cursor.getString(name), getString(ic, "numDecimals"), false);
/* 466 */       else if (meta.getColumnTypeName(name).equals("date"))
/* 467 */         value = SmartFieldComponent.format(format, cursor.getTimestamp(name));
/* 468 */       else if (meta.getColumnTypeName(name).equals("number"))
/* 469 */         value = SmartFieldComponent.format(format, new Double(cursor.getDouble(name)));
/*     */       else {
/* 471 */         value = "Unknown format \"" + format + "\" on column " + name + " of type " + meta.getColumnTypeName(name);
/*     */       }
/* 473 */       if (getBoolean(ic, "total"))
/*     */       {
/* 475 */         String value_tot = (String)ic.getTransientDatum(name + "_tot");
/* 476 */         if (value_tot == null) value_tot = "0";
/* 477 */         value_tot = "" + Double.toString(Double.valueOf(value_tot).doubleValue() + cursor.getDouble(name));
/* 478 */         ic.setTransientDatum(name + "_tot", value_tot);
/* 479 */         ic.setTransientDatum(parentName + "_total", "true");
/*     */       }
/*     */ 
/* 482 */       if (value != null) value = StringUtil.toHTML(value);
/*     */     }
/*     */ 
/* 485 */     int rowid = Integer.parseInt((String)ic.getRequiredTransientDatum("rowid"));
/* 486 */     String rowClass = parent.getRowClass(ic, rowid, getString(ic, "class"));
/*     */ 
/* 489 */     String url = getString(ic, "href");
/* 490 */     value = group(ic, name, value);
/* 491 */     if ((url != null) && (value != null))
/*     */     {
/* 493 */       String target = getString(ic, "target");
/* 494 */       href.append("<a href=\"" + url + "\"");
/* 495 */       if (target != null) href.append(" target=\"" + target + "\"");
/*     */ 
/* 497 */       href.append(">");
/*     */ 
/* 499 */       String temp_class = parent.getCellLinkClass(ic, rowid, getString(ic, "linkClass"));
/* 500 */       if (StringUtil.hasAValue(temp_class))
/* 501 */         rowClass = temp_class;
/* 502 */       String rowRolloverClass = parent.getRowRolloverClass(ic, rowid, getString(ic, "rolloverClass"));
/* 503 */       events.append(" style=\"cursor:hand\"");
/* 504 */       if ((rowClass != null) && (rowRolloverClass != null))
/*     */       {
/* 506 */         events.append(" onMouseOver=\"this.className='" + rowRolloverClass + "'; return true\"");
/* 507 */         events.append(" onMouseOut=\"this.className='" + rowClass + "'; return true\"");
/*     */       }
/*     */ 
/* 510 */       String on_click = getString(ic, "onClick");
/* 511 */       if (StringUtil.hasAValue(on_click))
/* 512 */         events.append(" onClick=\"" + on_click + "\"");
/* 513 */       if (ic.getTransientDatum("autoClickURL") == null) {
/* 514 */         ic.setTransientDatum("autoClickURL", url);
/*     */       }
/*     */     }
/*     */ 
/* 518 */     td.append("<td");
/* 519 */     if (height > 0) td.append(" height=\"" + height + "\"");
/* 520 */     if (rowClass != null) td.append(" class=\"" + rowClass + "\"");
/* 521 */     if (colspan > 1) td.append(" colspan=\"" + colspan + "\"");
/* 522 */     td.append(getExtendedAttributesString(ic));
/* 523 */     td.append(events);
/* 524 */     td.append(">");
/*     */ 
/* 527 */     if (ic.isInternetExplorer())
/*     */     {
/* 529 */       result.append(href);
/* 530 */       result.append(td);
/*     */     }
/*     */     else
/*     */     {
/* 534 */       result.append(td);
/* 535 */       result.append("&nbsp;");
/* 536 */       result.append(href);
/*     */     }
/*     */ 
/* 540 */     if ((value == null) || (value.length() == 0) || (value.equals(" "))) value = "&nbsp;";
/* 541 */     result.append(value);
/*     */ 
/* 544 */     if (ic.isInternetExplorer())
/*     */     {
/* 546 */       result.append("</td>");
/* 547 */       if (href.length() > 0) result.append("</a>");
/*     */     }
/*     */     else
/*     */     {
/* 551 */       if (href.length() > 0) result.append("</a>");
/* 552 */       result.append("</td>");
/*     */     }
/*     */ 
/* 555 */     result.append("\n");
/*     */ 
/* 557 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public String getTotal(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 565 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 567 */     int colspan = getInt(ic, "colspan");
/* 568 */     String name = getString(ic, "name");
/* 569 */     String value = (String)ic.getTransientDatum(name + "_tot");
/* 570 */     ic.removeTransientDatum(name + "_tot");
/*     */ 
/* 572 */     String format = getString(ic, "format");
/* 573 */     if ((format != null) && (value != null))
/*     */     {
/* 575 */       if (format.equalsIgnoreCase("money"))
/* 576 */         value = SmartFieldComponent.formatMoney(value);
/* 577 */       else if (format.equalsIgnoreCase("percent"))
/* 578 */         value = SmartFieldComponent.formatPercent(value, getString(ic, "numDecimals"), false);
/*     */       else
/* 580 */         value = SmartFieldComponent.format(format, Double.valueOf(value));
/*     */     }
/* 582 */     if (value != null) value = StringUtil.toHTML(value);
/*     */ 
/* 584 */     SmartTableComponent parent = getTable();
/* 585 */     String parentName = parent.getString(ic, "name");
/* 586 */     int height = parent.getInt(ic, "titleHeight");
/* 587 */     if (height == 0) height = parent.getInt(ic, "rowHeight");
/* 588 */     if (height == 0) height = getInt(ic, "height");
/* 589 */     String css = parent.getTotalClass(ic);
/*     */ 
/* 591 */     result.append("<td");
/* 592 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 593 */     if (css != null) result.append(" class=\"" + css + "\"");
/* 594 */     if (colspan > 1) result.append(" colspan=\"" + colspan + "\"");
/* 595 */     result.append(getExtendedAttributesString(ic));
/* 596 */     result.append(">");
/* 597 */     if ((value == null) || (value.length() == 0) || (value.equals(" "))) value = "&nbsp;";
/* 598 */     result.append(value);
/* 599 */     result.append("</td>");
/* 600 */     result.append("\n");
/*     */ 
/* 602 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private String group(InvocationContext ic, String name, String value)
/*     */     throws Exception
/*     */   {
/* 610 */     Vector rowGroups = (Vector)ic.getTransientDatum("group");
/*     */ 
/* 612 */     if (rowGroups == null) return value;
/*     */ 
/* 614 */     int index = rowGroups.indexOf(name);
/* 615 */     if (index == -1) return value;
/*     */ 
/* 617 */     String groupName = (String)rowGroups.elementAt(index);
/* 618 */     String groupValue = (String)ic.getTransientDatum(groupName + "_group");
/*     */ 
/* 620 */     if ((groupValue != null) && (groupValue.equals(value)))
/*     */     {
/* 622 */       value = null;
/*     */     }
/*     */     else
/*     */     {
/* 626 */       ic.setTransientDatum(groupName + "_group", value);
/* 627 */       index++; for (int i = index; i < rowGroups.size(); i++) {
/* 628 */         ic.setTransientDatum((String)rowGroups.elementAt(i) + "_group", null);
/*     */       }
/*     */     }
/* 631 */     return value;
/*     */   }
/*     */ 
/*     */   public SmartTableComponent getTable() throws Exception
/*     */   {
/* 636 */     for (TemplateComponent t = getParent(); t != null; t = t.getParent()) {
/* 637 */       if ((t instanceof SmartTableComponent))
/* 638 */         return (SmartTableComponent)t;
/*     */     }
/* 640 */     throw new Exception("Could not find parent SmartTable for component " + this);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SmartColumnComponent
 * JD-Core Version:    0.6.2
 */