/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.dbtk.connection.ConnectionWrapper;
/*    */ import dynamic.intraframe.engine.ApplicationContext;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ import dynamic.util.string.StringUtil;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class SQLExecComponent extends TemplateComponent
/*    */ {
/*    */   public SQLExecComponent()
/*    */     throws Exception
/*    */   {
/* 24 */     registerRequiredAttribute("sql");
/* 25 */     registerAttribute("resourceName", null);
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic) throws Exception
/*    */   {
/* 30 */     StringBuffer result = new StringBuffer();
/* 31 */     ConnectionWrapper conn = null;
/*    */     try
/*    */     {
/* 35 */       String resourceName = getString(ic, "resourceName");
/* 36 */       String sql = getString(ic, "sql");
/* 37 */       Vector statements = StringUtil.stringToVector(sql, ';');
/*    */ 
/* 39 */       conn = (ConnectionWrapper)ic.getResource(resourceName);
/* 40 */       conn.setAutoCommit(false);
/* 41 */       for (int i = 0; i < statements.size(); i++)
/*    */       {
/* 43 */         String statement = (String)statements.elementAt(i);
/* 44 */         conn.updateEx(statement);
/* 45 */         result.append("<!-- " + StringUtil.toHTML(statement) + " -->\n");
/*    */       }
/* 47 */       conn.commit();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 51 */       if (conn != null)
/*    */         try {
/* 53 */           conn.rollback(); } catch (Exception ex) {
/*    */         }
/* 55 */       throw e;
/*    */     }
/*    */     finally
/*    */     {
/* 59 */       if (conn != null) {
/*    */         try {
/* 61 */           conn.setAutoCommit(true); } catch (Exception ex) {
/* 62 */         }conn.release();
/*    */       }
/*    */     }
/*    */ 
/* 66 */     return result.toString();
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SQLExecComponent
 * JD-Core Version:    0.6.2
 */