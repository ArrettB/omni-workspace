/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ 
/*     */ public class SelectComponent extends TemplateComponent
/*     */ {
/*     */   public SelectComponent()
/*     */     throws Exception
/*     */   {
/*  59 */     registerRequiredAttribute("name");
/*  60 */     registerRequiredAttribute("query");
/*  61 */     registerAttribute("autoSelect", "false");
/*  62 */     registerAttribute("currentValue", "-1");
/*  63 */     registerAttribute("filter", "");
/*  64 */     registerAttribute("firstOption", null);
/*  65 */     registerAttribute("firstOptionValue", "XXX");
/*  66 */     registerAttribute("hide", "false");
/*  67 */     registerAttribute("lastOption", null);
/*  68 */     registerAttribute("lastOptionValue", "YYY");
/*  69 */     registerAttribute("resourceName", null);
/*  70 */     allowsExtendedAttributes();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  75 */     StringBuffer result = new StringBuffer();
/*  76 */     ConnectionWrapper conn = null;
/*     */     try
/*     */     {
/*  79 */       boolean autoSelect = getBoolean(ic, "autoSelect");
/*  80 */       String currentValue = getString(ic, "currentValue");
/*  81 */       String filter = getString(ic, "filter");
/*  82 */       String firstOption = getString(ic, "firstOption");
/*  83 */       String firstOptionValue = getString(ic, "firstOptionValue");
/*  84 */       String lastOption = getString(ic, "lastOption");
/*  85 */       String lastOptionValue = getString(ic, "lastOptionValue");
/*  86 */       boolean hide = getBoolean(ic, "hide");
/*  87 */       String name = getString(ic, "name");
/*  88 */       String query = getString(ic, "query");
/*  89 */       String resourceName = getString(ic, "resourceName");
/*  90 */       int size = getInt(ic, "size");
/*     */ 
/*  92 */       conn = (ConnectionWrapper)ic.getResource(resourceName);
/*     */ 
/*  94 */       result.append("<select name=\"" + name + "\"");
/*  95 */       result.append(getExtendedAttributesString(ic));
/*  96 */       result.append(">\n");
/*  97 */       int count = 0;
/*  98 */       if (firstOption != null)
/*     */       {
/* 100 */         result.append("<option value=\"" + firstOptionValue + "\">" + firstOption + "</option>\n");
/* 101 */         count++;
/*     */       }
/* 103 */       if (filter.length() > 0) query = ic.processFilter(query, filter);
/* 104 */       Diagnostics.debug("SelectComponent.include() SQL: " + query);
/* 105 */       QueryResults rs = conn.resultsQueryEx(query);
/*     */ 
/* 107 */       String id = null;
/* 108 */       String display = null;
/* 109 */       while (rs.next())
/*     */       {
/* 111 */         id = rs.getString(1);
/* 112 */         display = rs.getString(2);
/* 113 */         result.append("<option value=\"" + id + "\"");
/* 114 */         if ((id != null) && (currentValue != null) && (id.equals(currentValue))) result.append(" selected");
/* 115 */         result.append(">" + display + "</option>\n");
/* 116 */         count++;
/*     */       }
/* 118 */       rs.close();
/*     */ 
/* 120 */       if (lastOption != null)
/*     */       {
/* 122 */         result.append("<option value=\"" + lastOptionValue + "\">" + lastOption + "</option>\n");
/* 123 */         count++;
/*     */       }
/* 125 */       result.append("</select>\n");
/* 126 */       if (count == 1)
/*     */       {
/* 128 */         if (autoSelect)
/*     */         {
/* 130 */           result.setLength(0);
/* 131 */           result.append("<select name=\"" + name + "\"");
/* 132 */           result.append(getExtendedAttributesString(ic));
/* 133 */           result.append(">\n");
/* 134 */           result.append("<option value=\"" + id + "\" selected> " + display + "</option>\n");
/* 135 */           ic.setParameter(name, id);
/*     */         }
/* 137 */         else if (hide)
/*     */         {
/* 139 */           result.setLength(0);
/* 140 */           result.append(display);
/* 141 */           result.append("<input type=\"hidden\" name=\"" + name + "\" value=\"" + id + "\">\n");
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/*     */       try {
/* 147 */         if (conn != null) conn.releaseResource(); 
/*     */       } catch (Exception e) {  }
/*     */ 
/*     */     }
/* 150 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SelectComponent
 * JD-Core Version:    0.6.2
 */