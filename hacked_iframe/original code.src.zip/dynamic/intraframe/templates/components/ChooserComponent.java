/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.dbtk.MetaData;
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.Template;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class ChooserComponent extends SmartTableComponent
/*     */ {
/*     */   public static final String CHOOSER_TOP = "__chooser_top";
/*     */   public static final String CHOOSER_MIDDLE = "__chooser_middle";
/*     */   public static final String CHOOSER_BOTTOM = "__chooser_bottom";
/*     */ 
/*     */   public ChooserComponent()
/*     */     throws Exception
/*     */   {
/*  66 */     registerRequiredAttribute("chooserBasePath");
/*  67 */     registerDeprecatedAttribute("returnColumns", null);
/*  68 */     registerRequiredAttribute("rowSelectedClass");
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  73 */     StringBuffer header = new StringBuffer();
/*  74 */     StringBuffer body = new StringBuffer();
/*  75 */     StringBuffer footer = new StringBuffer();
/*  76 */     StringBuffer script = new StringBuffer();
/*  77 */     String name = getString(ic, "name");
/*     */ 
/*  80 */     ic.setTransientDatum("hasColorRowClasses", "false");
/*     */ 
/*  82 */     main(ic, name, "_top", header, body, footer, script);
/*     */ 
/*  84 */     header.insert(0, table(ic, name)).append("</table>\n");
/*  85 */     body.insert(0, table(ic, name)).append("</table>\n");
/*  86 */     footer.insert(0, table(ic, name)).append("</table>\n");
/*     */ 
/*  88 */     ic.setSessionDatum("__chooser_top", header.toString());
/*  89 */     ic.setSessionDatum("__chooser_middle", body.toString());
/*  90 */     ic.setSessionDatum("__chooser_bottom", footer.toString());
/*  91 */     String chooserBasePath = getString(ic, "chooserBasePath");
/*  92 */     Template t = ic.getTemplate(chooserBasePath + "_frameset");
/*  93 */     StringBuffer result = new StringBuffer();
/*  94 */     result.append(script);
/*  95 */     result.append(t.include(ic));
/*  96 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected String body(InvocationContext ic, String name, QueryResults rs, MetaData meta, int startWithRow, int maxRowCount)
/*     */     throws Exception
/*     */   {
/* 104 */     StringBuffer body = new StringBuffer();
/* 105 */     String selectFirstRow = "";
/*     */ 
/* 107 */     int height = getInt(ic, "rowHeight");
/* 108 */     int rowid = 0;
/*     */ 
/* 110 */     String alt1 = getString(ic, "alternator1");
/* 111 */     String alt2 = getString(ic, "alternator2");
/* 112 */     String alt1_1 = null;
/* 113 */     String alt1_2 = null;
/* 114 */     if ((alt1 != null) && (alt1.length() > 0))
/*     */     {
/* 116 */       Vector tvect = StringUtil.stringToVector(alt1, ':');
/* 117 */       alt1_1 = (String)tvect.elementAt(0);
/* 118 */       alt1_2 = (String)tvect.elementAt(1);
/*     */     }
/*     */ 
/* 121 */     String alt2_1 = null;
/* 122 */     String alt2_2 = null;
/* 123 */     if ((alt2 != null) && (alt2.length() > 0))
/*     */     {
/* 125 */       Vector tvect = StringUtil.stringToVector(alt2, ':');
/* 126 */       alt2_1 = (String)tvect.elementAt(0);
/* 127 */       alt2_2 = (String)tvect.elementAt(1);
/*     */     }
/*     */ 
/* 131 */     rowid = 1;
/*     */     do { rowid++; if (rowid >= startWithRow) break;  } while (rs.next());
/*     */ 
/* 133 */     while (rs.next())
/*     */     {
/* 135 */       ic.setTransientDatum("rowid", "" + rowid);
/* 136 */       if ((maxRowCount != 0) && (rowid >= maxRowCount + startWithRow))
/*     */         break;
/* 138 */       body.append("<a href=\"JavaScript:");
/* 139 */       String temp = "select(" + (rowid - startWithRow) + ",";
/* 140 */       for (int i = 1; i <= meta.getColumnCount(); i++)
/*     */       {
/* 142 */         if (i > 1) temp = temp + ",";
/* 143 */         temp = temp + StringUtil.toHTML(StringUtil.toJavaScriptString(rs.getString(i)));
/*     */       }
/* 145 */       temp = temp + ")";
/* 146 */       if (rowid == 1) {
/* 147 */         selectFirstRow = temp;
/*     */       }
/* 149 */       body.append(temp);
/* 150 */       body.append("\">\n");
/*     */ 
/* 152 */       body.append("<tr rowid=\"" + rowid + "\"");
/* 153 */       if (height > 0)
/* 154 */         body.append(" height=\"" + height + "\"");
/* 155 */       body.append(" style=\"cursor:hand\"");
/* 156 */       String rowRolloverClass = getString(ic, "rowRolloverClass");
/* 157 */       if (rowRolloverClass != null)
/*     */       {
/* 159 */         body.append(" onMouseOver=\"setRowClass(" + (rowid - startWithRow) + ",'" + rowRolloverClass + "')\"");
/* 160 */         body.append(" onMouseOut=\"resetRowClass(" + (rowid - startWithRow) + ")\"");
/*     */       }
/* 162 */       body.append(">\n");
/* 163 */       ic.setTransientDatum("row", "1");
/*     */ 
/* 165 */       if (rowid % 2 == 0)
/*     */       {
/* 167 */         if (alt1_2 != null) ic.setTransientDatum(name + ":alt1", alt1_2);
/* 168 */         if (alt2_2 != null) ic.setTransientDatum(name + ":alt2", alt2_2);
/*     */       }
/*     */       else
/*     */       {
/* 172 */         if (alt1_1 != null) ic.setTransientDatum(name + ":alt1", alt1_1);
/* 173 */         if (alt2_1 != null) ic.setTransientDatum(name + ":alt2", alt2_1);
/*     */       }
/*     */ 
/* 176 */       body.append(includeChildren(ic));
/* 177 */       body.append("</tr>\n");
/* 178 */       body.append("</a>\n");
/* 179 */       rowid++;
/*     */     }
/* 181 */     rs.close();
/*     */ 
/* 183 */     if (rowid == startWithRow)
/*     */     {
/* 185 */       String numcols = (String)ic.getRequiredTransientDatum("numcols");
/* 186 */       body.append("<tr><td");
/* 187 */       body.append(" colspan=\"" + numcols + "\"");
/* 188 */       if (height > 0)
/* 189 */         body.append(" height=\"" + height + "\"");
/* 190 */       String css = getRowClass(ic, rowid, getString(ic, "class"));
/* 191 */       if (css != null)
/* 192 */         body.append(" class=\"" + css + "\"");
/* 193 */       body.append(">");
/* 194 */       body.append("No items in the list");
/* 195 */       body.append("</td>\n");
/* 196 */       body.append("</tr>\n");
/*     */     }
/*     */ 
/* 199 */     body.append(getScript(ic, name, meta, selectFirstRow, rowid));
/*     */ 
/* 201 */     return body.toString();
/*     */   }
/*     */ 
/*     */   protected StringBuffer getScript(InvocationContext ic, String name, MetaData meta, String selectFirstRow, int rowid)
/*     */     throws Exception
/*     */   {
/* 210 */     StringBuffer script = new StringBuffer();
/*     */ 
/* 212 */     String rowSelectedClass = getString(ic, "rowSelectedClass");
/*     */ 
/* 214 */     script.append("<script language=\"JavaScript\">\n");
/* 215 */     script.append("<!--//\n");
/*     */ 
/* 217 */     script.append("var currentRow = -1;\n");
/* 218 */     script.append("var defaultClassName;\n");
/* 219 */     script.append("var archiveClassName;");
/* 220 */     script.append("\n");
/*     */ 
/* 223 */     script.append("function selectFirstRow()\n");
/* 224 */     script.append("{\n");
/* 225 */     if (rowid == 2)
/* 226 */       script.append("\t" + selectFirstRow + "\n");
/* 227 */     script.append("}\n");
/*     */ 
/* 229 */     script.append("function setRowClass(row,className)\n");
/* 230 */     script.append("{\n");
/* 231 */     script.append("\tdefaultClassName = document.all." + name + ".rows[row].cells[0].className\n");
/* 232 */     script.append("\tif (row == currentRow) className='" + rowSelectedClass + "';\n");
/* 233 */     script.append("\tfor (i = 0; i < document.all." + name + ".rows[row].cells.length; i++)\n");
/* 234 */     script.append("\t\tdocument.all." + name + ".rows[row].cells[i].className = className;\n");
/* 235 */     script.append("}\n");
/* 236 */     script.append("\n");
/*     */ 
/* 238 */     script.append("function resetRowClass(row)\n");
/* 239 */     script.append("{\n");
/* 240 */     script.append("\tsetRowClass(row, defaultClassName)\n");
/* 241 */     script.append("}\n");
/* 242 */     script.append("\n");
/*     */ 
/* 244 */     script.append("function select(row");
/* 245 */     for (int i = 1; i <= meta.getColumnCount(); i++)
/* 246 */       script.append("," + meta.getColumnName(i));
/* 247 */     script.append(")\n");
/* 248 */     script.append("{\n");
/* 249 */     script.append("\tif (row == currentRow) return; //already selected\n");
/* 250 */     script.append("\ttmp = currentRow;\n");
/* 251 */     script.append("\tcurrentRow = row;\n");
/* 252 */     script.append("\tarchive = defaultClassName;\n");
/* 253 */     script.append("\tif (tmp != -1) setRowClass(tmp, archiveClassName);\n");
/* 254 */     script.append("\tarchiveClassName = archive;\n");
/* 255 */     script.append("\tsetRowClass(currentRow, 'ChooserTableRowSelected');\n");
/* 256 */     script.append("\t//save the data for this row\n");
/* 257 */     for (int i = 1; i <= meta.getColumnCount(); i++)
/* 258 */       script.append("\tparent." + meta.getColumnName(i) + "=" + meta.getColumnName(i) + ";\n");
/* 259 */     script.append("}\n");
/*     */ 
/* 261 */     script.append("\n");
/* 262 */     script.append("// -->\n");
/* 263 */     script.append("</script>\n");
/*     */ 
/* 265 */     return script;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.ChooserComponent
 * JD-Core Version:    0.6.2
 */