/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SQLLoopComponent extends TemplateComponent
/*     */ {
/*  30 */   public static String CURSOR_VAR_PREFIX = "__cursor:";
/*     */ 
/*  32 */   private TemplateComponent headerComponent = null;
/*  33 */   private TemplateComponent footerComponent = null;
/*  34 */   private TemplateComponent noDataComponent = null;
/*  35 */   private TemplateComponent moreRowsComponent = null;
/*     */ 
/*     */   public SQLLoopComponent() throws Exception
/*     */   {
/*  39 */     registerRequiredAttribute("query");
/*  40 */     registerAttribute("alternator1", null);
/*  41 */     registerAttribute("alternator2", null);
/*  42 */     registerAttribute("filter", "");
/*  43 */     registerAttribute("maxRows", "0");
/*  44 */     registerAttribute("name", "q1");
/*  45 */     registerAttribute("resourceName", null);
/*  46 */     requiresEndTag();
/*     */   }
/*     */ 
/*     */   public void addComponent(TemplateComponent child)
/*     */     throws Exception
/*     */   {
/*  52 */     if (child.getName().equalsIgnoreCase("SQLHEADER"))
/*  53 */       this.headerComponent = child;
/*  54 */     else if (child.getName().equalsIgnoreCase("SQLFOOTER"))
/*  55 */       this.footerComponent = child;
/*  56 */     else if (child.getName().equalsIgnoreCase("SQLNODATA"))
/*  57 */       this.noDataComponent = child;
/*  58 */     else if (child.getName().equalsIgnoreCase("SQLMOREROWS"))
/*  59 */       this.moreRowsComponent = child;
/*     */     else
/*  61 */       super.addComponent(child);
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  66 */     StringBuffer result = new StringBuffer();
/*  67 */     ConnectionWrapper conn = null;
/*     */     try
/*     */     {
/*  71 */       String alt1 = getString(ic, "alternator1");
/*  72 */       String alt2 = getString(ic, "alternator2");
/*  73 */       String filter = getString(ic, "filter");
/*  74 */       String name = getString(ic, "name");
/*  75 */       int maxRowCount = getInt(ic, "maxRows");
/*  76 */       String query = getString(ic, "query");
/*  77 */       String resourceName = getString(ic, "resourceName");
/*     */ 
/*  79 */       String alt1_1 = null;
/*  80 */       String alt1_2 = null;
/*  81 */       if ((alt1 != null) && (alt1.length() > 0))
/*     */       {
/*  83 */         Vector tvect = StringUtil.stringToVector(alt1, ':');
/*  84 */         alt1_1 = (String)tvect.elementAt(0);
/*  85 */         alt1_2 = (String)tvect.elementAt(1);
/*     */       }
/*     */ 
/*  88 */       String alt2_1 = null;
/*  89 */       String alt2_2 = null;
/*  90 */       if ((alt2 != null) && (alt2.length() > 0))
/*     */       {
/*  92 */         Vector tvect = StringUtil.stringToVector(alt2, ':');
/*  93 */         alt2_1 = (String)tvect.elementAt(0);
/*  94 */         alt2_2 = (String)tvect.elementAt(1);
/*     */       }
/*     */ 
/*  97 */       conn = (ConnectionWrapper)ic.getResource(resourceName);
/*  98 */       int rowid = 0;
/*  99 */       ic.setTransientDatum(name + ":rowid", "0");
/*     */ 
/* 101 */       if (filter.length() > 0) query = ic.processFilter(query, filter);
/*     */ 
/* 103 */       QueryResults rs = conn.resultsQueryEx(query);
/* 104 */       ic.setTransientDatum(CURSOR_VAR_PREFIX + name, rs);
/*     */ 
/* 107 */       while (rs.next())
/*     */       {
/* 109 */         if ((rowid == 0) && (this.headerComponent != null)) {
/* 110 */           result.append(this.headerComponent.include(ic));
/*     */         }
/* 112 */         rowid++;
/* 113 */         ic.setTransientDatum(name + ":rowid", "" + rowid);
/*     */ 
/* 115 */         if (rowid % 2 == 0)
/*     */         {
/* 117 */           if (alt1_2 != null) ic.setTransientDatum(name + ":alt1", alt1_2);
/* 118 */           if (alt2_2 != null) ic.setTransientDatum(name + ":alt2", alt2_2);
/*     */         }
/*     */         else
/*     */         {
/* 122 */           if (alt1_1 != null) ic.setTransientDatum(name + ":alt1", alt1_1);
/* 123 */           if (alt2_1 != null) ic.setTransientDatum(name + ":alt2", alt2_1);
/*     */         }
/*     */ 
/* 126 */         result.append(includeChildren(ic));
/* 127 */         if ((maxRowCount != 0) && (rowid >= maxRowCount)) break;
/*     */       }
/* 129 */       rs.close();
/*     */ 
/* 131 */       if ((rowid == 0) && (this.noDataComponent != null)) {
/* 132 */         result.append(this.noDataComponent.include(ic));
/*     */       }
/* 134 */       if ((rowid != 0) && (this.footerComponent != null)) {
/* 135 */         result.append(this.footerComponent.include(ic));
/*     */       }
/* 137 */       if ((maxRowCount != 0) && (rowid >= maxRowCount) && (this.moreRowsComponent != null)) {
/* 138 */         result.append(this.moreRowsComponent.include(ic));
/*     */       }
/*     */ 
/* 141 */       rowid++;
/* 142 */       ic.setTransientDatum(name + ":rowid", "" + rowid);
/*     */     }
/*     */     finally
/*     */     {
/* 147 */       if (conn != null) conn.release();
/*     */     }
/*     */ 
/* 150 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SQLLoopComponent
 * JD-Core Version:    0.6.2
 */