/*      */ package dynamic.intraframe.templates.components;
/*      */ 
/*      */ import dynamic.dbtk.FieldValidator;
/*      */ import dynamic.dbtk.MetaData;
/*      */ import dynamic.dbtk.connection.ConnectionWrapper;
/*      */ import dynamic.dbtk.connection.QueryResults;
/*      */ import dynamic.dbtk.parser.Sql;
/*      */ import dynamic.intraframe.engine.ApplicationContext;
/*      */ import dynamic.intraframe.engine.InvocationContext;
/*      */ import dynamic.intraframe.templates.TemplateAttribute;
/*      */ import dynamic.intraframe.templates.TemplateComponent;
/*      */ import dynamic.util.date.StdDate;
/*      */ import dynamic.util.diagnostics.Diagnostics;
/*      */ import dynamic.util.string.StringUtil;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.text.DateFormat;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.Format;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class SmartFieldComponent extends TemplateComponent
/*      */ {
/*      */   public static final String MAND_FIELD_ERR_MSG = "mandFieldErrMsg";
/*      */ 
/*      */   public SmartFieldComponent()
/*      */     throws Exception
/*      */   {
/*  110 */     registerAttribute("calculated", "false");
/*  111 */     registerAttribute("display", null);
/*  112 */     registerAttribute("div", "");
/*  113 */     registerAttribute("filter", null);
/*  114 */     registerDeprecatedAttribute("form", null);
/*  115 */     registerDeprecatedAttribute("id", null);
/*  116 */     registerAttribute("img", null);
/*  117 */     registerAttribute("key", null);
/*  118 */     registerAttribute("mode", "Always");
/*  119 */     registerAttribute("mandatory", null);
/*  120 */     registerAttribute("mandFieldErrMsg", null);
/*  121 */     registerRequiredAttribute("name");
/*  122 */     registerAttribute("nochoice", "false");
/*  123 */     registerAttribute("orderBy", null);
/*  124 */     registerAttribute("query", null);
/*  125 */     registerAttribute("resourceName", null);
/*  126 */     registerAttribute("table", null);
/*  127 */     registerAttribute("title", "");
/*  128 */     registerAttribute("type", "text");
/*  129 */     registerAttribute("validateField", "true");
/*  130 */     registerAttribute("value", null);
/*  131 */     registerAttribute("numDecimals", "0");
/*  132 */     allowsExtendedAttributes();
/*      */   }
/*      */ 
/*      */   public String includeInternal(InvocationContext ic) throws Exception
/*      */   {
/*  137 */     StringBuffer result = new StringBuffer();
/*  138 */     String div = getString(ic, "div");
/*  139 */     String name = getString(ic, "name");
/*  140 */     String title = getString(ic, "title");
/*  141 */     String type = getString(ic, "type");
/*  142 */     boolean isCalculated = getBoolean(ic, "calculated");
/*  143 */     boolean validate_field = getBoolean(ic, "validateField");
/*  144 */     String resourceName = getString(ic, "resourceName");
/*  145 */     String mand_field_err_msg = (String)ic.getTransientDatum("mandFieldErrMsg");
/*  146 */     boolean canView = ((String)ic.getTransientDatum("View")).equals("true");
/*  147 */     boolean canInsert = ((String)ic.getTransientDatum("Insert")).equals("true");
/*  148 */     boolean canUpdate = ((String)ic.getTransientDatum("Update")).equals("true");
/*  149 */     boolean canDelete = ((String)ic.getTransientDatum("Delete")).equals("true");
/*  150 */     boolean canSave = ((String)ic.getTransientDatum("Save")).equals("true");
/*  151 */     MetaData meta = (MetaData)ic.getTransientDatum("METADATA");
/*  152 */     ConnectionWrapper conn = (ConnectionWrapper)ic.getTransientDatum("RESOURCE");
/*  153 */     SmartFormComponent parent = getParentSmartForm();
/*  154 */     String table = parent.getString(ic, "table");
/*  155 */     boolean errorText = parent.getBoolean(ic, "errorText");
/*  156 */     String errorImage = parent.getString(ic, "errorImage");
/*  157 */     if (mand_field_err_msg == null) {
/*  158 */       mand_field_err_msg = (String)ic.getTransientDatum("mandFieldErrMsg");
/*      */     }
/*      */ 
/*  161 */     if ((!canView) || (!shouldInclude(ic))) return result.toString();
/*      */ 
/*  163 */     String typename = meta.getColumnTypeName(name);
/*  164 */     if (typename == null) typename = "";
/*  165 */     String length = "";
/*  166 */     int displaySize = meta.getColumnDisplaySize(name);
/*  167 */     if (displaySize > 0) length = " maxlength=\"" + displaySize + "\"";
/*      */ 
/*  169 */     boolean isMandatory = false;
/*  170 */     String mandatoryString = getString(ic, "mandatory");
/*  171 */     if (mandatoryString != null) isMandatory = getBoolean(ic, "mandatory");
/*  172 */     else if (meta != null) isMandatory = meta.isColumnMandatory(name);
/*      */ 
/*  174 */     boolean isError = false;
/*  175 */     boolean isReadOnly = ((String)ic.getTransientDatum("Save")).equals("false");
/*  176 */     if (!isReadOnly)
/*      */     {
/*  178 */       isReadOnly = parent.getString(ic, "readonly").equals("true");
/*  179 */       if (!isReadOnly)
/*      */       {
/*  181 */         String readonly = getString(ic, "readonly");
/*  182 */         if ((readonly != null) && (readonly.equals("true"))) {
/*  183 */           isReadOnly = true;
/*      */         }
/*      */       }
/*      */     }
/*  187 */     if (errorText)
/*      */     {
/*  189 */       String text = (String)ic.getTransientDatum("err@" + name);
/*  190 */       if ((text != null) && (text.length() > 0)) isError = true;
/*      */ 
/*      */     }
/*      */ 
/*  194 */     if (title.length() > 0)
/*      */     {
/*  196 */       boolean useCSS = parent.getBoolean(ic, "useCSS");
/*      */ 
/*  198 */       if ((useCSS) && (isMandatory) && (!isError) && (!isReadOnly))
/*  199 */         result.append("<span class=\"mandatoryLabel\">" + title + "</span>");
/*  200 */       else if ((useCSS) && (isMandatory) && (isError) && (!isReadOnly))
/*  201 */         result.append("<span class=\"mandatoryLabelError\">" + title + "</span>");
/*      */       else
/*  203 */         result.append(title);
/*  204 */       if (div.length() > 0) result.append(div);
/*      */     }
/*      */ 
/*  207 */     ConnectionWrapper connTemp = null;
/*      */     try
/*      */     {
/*  211 */       if (resourceName != null)
/*  212 */         connTemp = (ConnectionWrapper)ic.getResource(resourceName);
/*      */       else {
/*  214 */         connTemp = conn;
/*      */       }
/*  216 */       if (type.equalsIgnoreCase("droplist"))
/*  217 */         result.append(createDropList(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError, resourceName));
/*  218 */       else if (type.equalsIgnoreCase("chooser"))
/*  219 */         result.append(createChooser(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError, resourceName));
/*  220 */       else if (type.equalsIgnoreCase("date"))
/*  221 */         result.append(createDate(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError));
/*  222 */       else if (type.equalsIgnoreCase("time"))
/*  223 */         result.append(createTime(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError));
/*  224 */       else if (type.equalsIgnoreCase("datetime"))
/*  225 */         result.append(createDateTime(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError));
/*  226 */       else if (type.equalsIgnoreCase("textarea"))
/*  227 */         result.append(createTextArea(ic, connTemp, name, typename, length, canSave, isReadOnly, isMandatory, isError));
/*  228 */       else if (type.equalsIgnoreCase("boolean"))
/*  229 */         result.append(createBoolean(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError));
/*  230 */       else if (type.equalsIgnoreCase("dbhidden"))
/*  231 */         result.append(createDB(ic, connTemp, name, typename, canSave, isReadOnly, isMandatory, isError));
/*  232 */       else if (type.equalsIgnoreCase("phone"))
/*  233 */         result.append(createPhone(ic, connTemp, name, typename, length, canSave, isReadOnly, isMandatory, isError));
/*  234 */       else if (type.equalsIgnoreCase("money"))
/*  235 */         result.append(createMoney(ic, connTemp, name, typename, length, canSave, isReadOnly, isMandatory, isError));
/*  236 */       else if (type.equalsIgnoreCase("percent"))
/*  237 */         result.append(createPercent(ic, connTemp, name, typename, length, canSave, isReadOnly, isMandatory, isError));
/*      */       else {
/*  239 */         result.append(createText(ic, connTemp, name, typename, length, canSave, isReadOnly, isMandatory, isError));
/*      */       }
/*  241 */       if (resourceName != null)
/*  242 */         result.append("<input name=\"" + name + "_resource\" type=\"hidden\" value=\"" + resourceName + "\">");
/*      */     }
/*      */     finally
/*      */     {
/*  246 */       if (resourceName != null) {
/*  247 */         connTemp.release();
/*      */       }
/*      */     }
/*      */ 
/*  251 */     if (isCalculated)
/*      */     {
/*  253 */       result.append("<input name=\"" + name + "_calculated\" type=\"hidden\" value=\"" + isCalculated + "\">");
/*      */     }
/*      */ 
/*  256 */     if (!validate_field)
/*      */     {
/*  258 */       result.append("<input name=\"" + name + "_validate\" type=\"hidden\" value=\"" + validate_field + "\">");
/*      */     }
/*      */ 
/*  261 */     if (errorText)
/*      */     {
/*  263 */       String text = (String)ic.getTransientDatum("err@" + name);
/*  264 */       if ((text != null) && (text.length() > 0) && (!type.equalsIgnoreCase("hidden")))
/*      */       {
/*  266 */         if ((isMandatory) || (mand_field_err_msg.equalsIgnoreCase("false")))
/*  267 */           text = mand_field_err_msg;
/*  268 */         if ((text != null) && (!text.equalsIgnoreCase("false"))) {
/*  269 */           result.append("<div class=\"errorText\">" + errorImage + text + "</div>" + div);
/*      */         }
/*      */       }
/*      */     }
/*  273 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private boolean shouldInclude(InvocationContext ic) throws Exception
/*      */   {
/*  278 */     String mode = getString(ic, "mode");
/*  279 */     String formMode = (String)ic.getTransientDatum("mode");
/*      */ 
/*  281 */     return (mode.equalsIgnoreCase("Always")) || ((mode.equalsIgnoreCase("Insert")) && (formMode.equals("Insert"))) || ((mode.equalsIgnoreCase("Update")) && (formMode.equals("Update")));
/*      */   }
/*      */ 
/*      */   static String format(String pattern, Date date)
/*      */   {
/*  288 */     if (date == null) return "";
/*  289 */     return new SimpleDateFormat(pattern).format(date);
/*      */   }
/*      */ 
/*      */   static String format(String pattern, Double number)
/*      */   {
/*  294 */     if (number == null) return "";
/*  295 */     return new DecimalFormat(pattern).format(number);
/*      */   }
/*      */ 
/*      */   static Date convertToDate(String pattern, String date_string)
/*      */   {
/*  300 */     Date result = null;
/*      */     try
/*      */     {
/*  303 */       ParsePosition pos = new ParsePosition(0);
/*  304 */       SimpleDateFormat date_format = new SimpleDateFormat(pattern);
/*  305 */       result = date_format.parse(date_string, pos);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  309 */       Diagnostics.error("Failed to convert String='" + date_string + "' into format='" + pattern + "'");
/*      */     }
/*  311 */     return result;
/*      */   }
/*      */ 
/*      */   static String convertToDateString(String from_pattern, String to_pattern, String date_string)
/*      */   {
/*  316 */     String result = null;
/*      */     try
/*      */     {
/*  319 */       if (!StringUtil.hasAValue(to_pattern))
/*  320 */         to_pattern = from_pattern;
/*  321 */       ParsePosition pos = new ParsePosition(0);
/*  322 */       SimpleDateFormat date_format = new SimpleDateFormat(from_pattern);
/*  323 */       Date converted_date = date_format.parse(date_string, pos);
/*  324 */       result = format(to_pattern, converted_date);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/*  331 */     return result;
/*      */   }
/*      */ 
/*      */   static String formatDate(Date date)
/*      */   {
/*  336 */     return format("MM/dd/yyyy", date);
/*      */   }
/*      */ 
/*      */   public static String formatDate(String date)
/*      */   {
/*  341 */     String result = convertToDateString("yyyy-MM-dd", "MM/dd/yyyy", date);
/*  342 */     if (!StringUtil.hasAValue(result)) result = convertToDateString("dd-mmm-yyyy", "MM/dd/yyyy", date);
/*  343 */     if (!StringUtil.hasAValue(result)) result = convertToDateString("MM/dd/yyyy", null, date);
/*  344 */     return result;
/*      */   }
/*      */ 
/*      */   static String formatDateTime(Date date)
/*      */   {
/*  349 */     return format("MM/dd/yyyy h:mm a", date);
/*      */   }
/*      */ 
/*      */   static String formatDateTime(String date)
/*      */   {
/*  354 */     String result = convertToDateString("yyyy-MM-dd hh:mm:ss", "MM/dd/yyyy h:mm a", date);
/*  355 */     if (!StringUtil.hasAValue(result)) result = convertToDateString("dd-mmm-yyyy HH:mm:ss", "MM/dd/yyyy h:mm a", date);
/*  356 */     if (!StringUtil.hasAValue(result)) result = convertToDateString("MM/dd/yyyy h:mm a", null, date);
/*  357 */     return result;
/*      */   }
/*      */ 
/*      */   static String formatTime(Date date)
/*      */   {
/*  362 */     return format("h:mm a", date);
/*      */   }
/*      */ 
/*      */   static String formatTime(String date)
/*      */   {
/*  367 */     String result = convertToDateString("h:mm a", null, date);
/*  368 */     if (result == null) result = convertToDateString("h:mm a", null, date);
/*  369 */     else if (result == null) result = convertToDateString("h:mm a", null, date);
/*  370 */     return result;
/*      */   }
/*      */ 
/*      */   static String formatMoney(String value)
/*      */   {
/*  375 */     if (value == null) return "";
/*  376 */     return NumberFormat.getCurrencyInstance().format(Double.valueOf(value));
/*      */   }
/*      */ 
/*      */   static String formatPercent(String value, String numDecimals, boolean divide)
/*      */   {
/*  381 */     if (value == null) return "";
/*  382 */     String result = FieldValidator.formatPercent(value, numDecimals, divide);
/*  383 */     return result;
/*      */   }
/*      */ 
/*      */   public static String getFirst(String value)
/*      */   {
/*  388 */     if (value == null) return null;
/*  389 */     int x = value.indexOf(',');
/*  390 */     if (x != -1) return value.substring(0, x).trim();
/*  391 */     return value;
/*      */   }
/*      */ 
/*      */   private String getValue(InvocationContext ic, String typename) throws Exception
/*      */   {
/*  396 */     return getValueInternal(ic, typename, false, false, false, false);
/*      */   }
/*      */ 
/*      */   private String getDate(InvocationContext ic, String typename) throws Exception
/*      */   {
/*  401 */     return getValueInternal(ic, typename, true, false, false, false);
/*      */   }
/*      */ 
/*      */   private String getDateTime(InvocationContext ic, String typename) throws Exception
/*      */   {
/*  406 */     return getValueInternal(ic, typename, true, true, false, false);
/*      */   }
/*      */ 
/*      */   private String getTime(InvocationContext ic, String typename) throws Exception
/*      */   {
/*  411 */     return getValueInternal(ic, typename, false, true, false, false);
/*      */   }
/*      */ 
/*      */   private String getMoney(InvocationContext ic, String typename) throws Exception
/*      */   {
/*  416 */     return getValueInternal(ic, typename, false, false, true, false);
/*      */   }
/*      */ 
/*      */   private String getPercent(InvocationContext ic, String typename) throws Exception
/*      */   {
/*  421 */     return getValueInternal(ic, typename, false, false, false, true);
/*      */   }
/*      */ 
/*      */   private String getValueInternal(InvocationContext ic, String typename, boolean isDate, boolean withTime, boolean isMoney, boolean isPercent) throws Exception
/*      */   {
/*  426 */     String name = getString(ic, "name");
/*  427 */     String result = null;
/*  428 */     boolean format_flag = true;
/*      */ 
/*  431 */     Object tmp = ic.getTransientDatum(name);
/*  432 */     if (tmp != null)
/*      */     {
/*  434 */       String transient_value = tmp.toString();
/*  435 */       if (StringUtil.hasAValue(transient_value))
/*      */       {
/*  437 */         result = transient_value;
/*  438 */         Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): using transient data = \"" + result + "\"");
/*      */ 
/*  440 */         format_flag = false;
/*      */ 
/*  442 */         if (typename.equals("number")) {
/*  443 */           result = getFirst(result);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  448 */     if (result == null)
/*      */     {
/*  450 */       SmartFormComponent parent = getParentSmartForm();
/*  451 */       String parentName = parent.getString(ic, "name");
/*  452 */       QueryResults cursor = null;
/*      */       try {
/*  454 */         cursor = (QueryResults)ic.getTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + parentName); } catch (ClassCastException e) {
/*      */       }
/*  456 */       if (cursor != null)
/*      */       {
/*  458 */         String row_value = null;
/*      */         try
/*      */         {
/*  461 */           if (isDate)
/*      */           {
/*  463 */             if (withTime)
/*  464 */               row_value = ic.format(cursor.getTimestamp(name), "datetime");
/*      */             else
/*  466 */               row_value = ic.format(cursor.getDate(name), "date");
/*      */           }
/*  468 */           else if (withTime)
/*      */           {
/*  470 */             row_value = ic.format(cursor.getTimestamp(name), "time");
/*      */           }
/*  472 */           else if (isMoney)
/*      */           {
/*  474 */             Double a_double = new Double(cursor.getDouble(name));
/*  475 */             row_value = ic.format(a_double, "money");
/*      */           }
/*  477 */           else if (isPercent)
/*      */           {
/*  479 */             row_value = formatPercent(cursor.getString(name), getString(ic, "numDecimals"), false);
/*      */           }
/*      */           else {
/*  482 */             row_value = cursor.getString(name);
/*      */           }
/*  484 */           if (StringUtil.hasAValue(row_value))
/*      */           {
/*  486 */             result = row_value;
/*  487 */             format_flag = false;
/*  488 */             Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): using row data = \"" + result + "\"");
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (SQLException se)
/*      */         {
/*  496 */           String parameter_value = ic.getParameter(name);
/*  497 */           if (StringUtil.hasAValue(parameter_value))
/*      */           {
/*  499 */             result = parameter_value;
/*  500 */             Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): using parameter = \"" + result + "\"");
/*      */           } else {
/*  502 */             Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): retrieve row data erred.\n" + se.toString());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  508 */     if (result == null)
/*      */     {
/*  511 */       String default_value = getString(ic, "value");
/*  512 */       if (StringUtil.hasAValue(default_value))
/*      */       {
/*  514 */         result = default_value;
/*  515 */         Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): using default value = \"" + result + "\"");
/*  516 */         if (typename.equals("number")) {
/*  517 */           result = getFirst(result);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  522 */     if ((format_flag) && (StringUtil.hasAValue(result)))
/*      */     {
/*  524 */       String formatted_result = null;
/*      */       try
/*      */       {
/*  527 */         if (isDate)
/*      */         {
/*  529 */           if (withTime)
/*  530 */             formatted_result = ic.format(new StdDate(result), "datetime");
/*      */           else
/*  532 */             formatted_result = ic.format(new StdDate(result), "date");
/*      */         }
/*  534 */         else if (withTime)
/*  535 */           formatted_result = ic.format(new StdDate(result), "time");
/*  536 */         else if (isMoney)
/*  537 */           formatted_result = ic.format(result, "money");
/*  538 */         else if (isPercent)
/*      */         {
/*  540 */           formatted_result = formatPercent(result, getString(ic, "numDecimals"), false);
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  545 */         Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): failed to format '" + result + "'.\n" + e.toString());
/*      */       }
/*  547 */       if (StringUtil.hasAValue(formatted_result))
/*      */       {
/*  549 */         Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): formatted '" + result + "' to '" + formatted_result + "'");
/*  550 */         result = formatted_result;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  555 */     if (!StringUtil.hasAValue(result))
/*      */     {
/*  557 */       result = "";
/*  558 */       Diagnostics.trace("SmartFieldComponent.getValue(" + name + "): no data found, defaulting \"\"");
/*      */     }
/*  560 */     ic.setTransientDatum(name, result.toString());
/*      */ 
/*  562 */     return StringUtil.toHTML(result);
/*      */   }
/*      */ 
/*      */   private String createDropList(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError, String fieldResource) throws Exception
/*      */   {
/*  567 */     StringBuffer result = new StringBuffer();
/*  568 */     StringBuffer select = new StringBuffer();
/*  569 */     StringBuffer options = new StringBuffer();
/*      */ 
/*  571 */     select.append("<select name=\"" + name + "\"");
/*  572 */     select.append(getExtendedAttributesString(ic));
/*  573 */     String value = getValue(ic, typename);
/*  574 */     select.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  575 */     select.append(getEvents(ic));
/*      */ 
/*  577 */     int i = 0;
/*  578 */     int selectedIndex = -1;
/*      */ 
/*  580 */     if ((!isMandatory) || (value == null) || (value.length() <= 0))
/*      */     {
/*  583 */       options.append("<option value=\"\">");
/*  584 */       i++;
/*      */     }
/*      */ 
/*  587 */     String display = getString(ic, "display");
/*  588 */     String table = getString(ic, "table");
/*  589 */     String key = getString(ic, "key");
/*  590 */     if (key == null) key = getString(ic, "id");
/*  591 */     String query = getString(ic, "query");
/*  592 */     String filter = getString(ic, "filter");
/*  593 */     if (query == null)
/*      */     {
/*  595 */       String q = "SELECT " + key + " id, " + display + " display  FROM " + table;
/*      */ 
/*  597 */       if ((filter != null) && (filter.length() > 0)) q = q + " WHERE " + filter;
/*      */ 
/*  599 */       String orderBy = getString(ic, "orderBy");
/*  600 */       if (orderBy == null) orderBy = display;
/*  601 */       query = q + " ORDER BY " + orderBy;
/*      */     }
/*      */     else
/*      */     {
/*  605 */       Diagnostics.debug("SmartFieldComponent.createDropList() pre query=" + query);
/*  606 */       query = ic.processFilter(query, filter);
/*  607 */       Diagnostics.debug("SmartFieldComponent.createDropList() post query=" + query);
/*      */     }
/*      */ 
/*  610 */     QueryResults rs = conn.resultsQueryEx(query);
/*  611 */     while (rs.next())
/*      */     {
/*  613 */       String element_id = rs.getString(1);
/*  614 */       String element_display = rs.getString(2);
/*  615 */       options.append("<option value=\"" + element_id + "\"");
/*  616 */       if ((value != null) && (element_id != null) && (value.trim().equalsIgnoreCase(StringUtil.replaceString(element_id.trim(), "&", "&amp;"))))
/*      */       {
/*  618 */         options.append(" selected");
/*  619 */         selectedIndex = i;
/*      */       }
/*  621 */       else if ((value != null) && (element_display != null) && (value.trim().equalsIgnoreCase(StringUtil.replaceString(element_display.trim(), "&", "&amp;"))))
/*      */       {
/*  623 */         options.append(" selected");
/*  624 */         selectedIndex = i;
/*      */       }
/*  626 */       options.append(">" + element_display);
/*  627 */       i++;
/*      */     }
/*  629 */     rs.close();
/*      */ 
/*  631 */     if ((isReadOnly) && (selectedIndex != -1)) {
/*  632 */       select.append(" onChange=\"this.selectedIndex=" + selectedIndex + "\"");
/*      */     }
/*  634 */     select.append(">");
/*  635 */     result.append(select);
/*  636 */     result.append(options);
/*  637 */     result.append("</select>");
/*      */ 
/*  640 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createChooser(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError, String fieldResource)
/*      */     throws Exception
/*      */   {
/*  651 */     StringBuffer result = new StringBuffer();
/*  652 */     String primaryKeyId = getValue(ic, typename);
/*  653 */     String display = getString(ic, "display");
/*  654 */     String table = getString(ic, "table");
/*  655 */     String query = getString(ic, "query");
/*  656 */     String filter = getString(ic, "filter");
/*  657 */     String key = getString(ic, "key");
/*  658 */     if (key == null) key = getString(ic, "id");
/*      */ 
/*  660 */     if ((primaryKeyId != null) && (primaryKeyId.indexOf("&amp") >= 0)) {
/*  661 */       primaryKeyId = StringUtil.replaceString(primaryKeyId.trim(), "&amp;", "&");
/*      */     }
/*  663 */     if ((query == null) && (primaryKeyId != null)) {
/*  664 */       query = "SELECT " + key + " id, " + display + " display  FROM " + table + " where " + key + "=" + conn.toSQLString(primaryKeyId);
/*      */     }
/*  666 */     String valueFromKey = null;
/*  667 */     QueryResults rs = conn.resultsQueryEx(query);
/*  668 */     while ((rs.next()) && (StringUtil.hasAValue(primaryKeyId)))
/*      */     {
/*  670 */       if ((rs.getString(1) != null) && (rs.getString(1).equalsIgnoreCase(primaryKeyId))) {
/*  671 */         valueFromKey = rs.getString(2);
/*      */       }
/*      */     }
/*      */ 
/*  675 */     ResultSetMetaData meta = rs.getMetaData();
/*  676 */     int maxlength = meta.getColumnDisplaySize(2);
/*  677 */     rs.close();
/*      */ 
/*  680 */     String value = null;
/*  681 */     String param = ic.getParameter(name + "_text");
/*      */ 
/*  683 */     if (valueFromKey != null)
/*      */     {
/*  686 */       value = valueFromKey;
/*      */     }
/*  688 */     else if ((param != null) && (param.length() > 0))
/*      */     {
/*  691 */       value = param;
/*      */     }
/*  693 */     else if ((isMandatory) && (ic.getTransientDatum("mode").equals("Insert")) && (getBoolean(ic, "nochoice")))
/*      */     {
/*  696 */       if (filter != null)
/*      */       {
/*  698 */         Diagnostics.debug("SmartFieldComponent.createChooser() pre query=" + query);
/*  699 */         Sql sql = Sql.fetchSql(query);
/*  700 */         sql = ic.processFilter(sql, filter);
/*  701 */         query = sql.getQuery();
/*  702 */         Diagnostics.debug("SmartFieldComponent.createChooser() post query=" + query);
/*      */       }
/*  704 */       rs = conn.resultsQueryEx(query);
/*  705 */       if (rs.next())
/*      */       {
/*  707 */         primaryKeyId = rs.getString(name);
/*  708 */         value = rs.getString(name + "_text");
/*  709 */         if (rs.next())
/*      */         {
/*  711 */           primaryKeyId = null;
/*  712 */           value = null;
/*      */         }
/*      */         else
/*      */         {
/*  717 */           canSave = false;
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  723 */         isError = true;
/*  724 */         ic.setTransientDatum("err@" + name, "There are no possible values for this.");
/*      */       }
/*  726 */       rs.close();
/*      */     }
/*      */ 
/*  729 */     result.append("<input name=\"" + name + "_text\"");
/*  730 */     result.append(" type=\"text\"");
/*  731 */     result.append(getExtendedAttributesString(ic));
/*  732 */     result.append(getCSS(ic, name + "_text", primaryKeyId, canSave, isReadOnly, isMandatory, isError));
/*  733 */     result.append(getEvents(ic));
/*  734 */     if (value != null) {
/*  735 */       result.append(" value=\"" + value + "\"");
/*      */     }
/*  737 */     if (maxlength > 0) {
/*  738 */       result.append(" maxlength=\"" + maxlength + "\"");
/*      */     }
/*  740 */     SmartFormComponent parentForm = getParentSmartForm();
/*  741 */     String parentName = parentForm.getString(ic, "name");
/*  742 */     int x = parentName.lastIndexOf('/');
/*  743 */     if (x != -1) parentName = parentName.substring(x + 1);
/*      */ 
/*  745 */     result.append(" onChange=\"document." + parentName + "." + name + ".value=''\" ");
/*  746 */     result.append(">");
/*      */ 
/*  748 */     if (filter != null)
/*      */     {
/*  750 */       result.append("<input name=\"" + name + "_filter\" type=\"hidden\" value=\"" + StringUtil.toHTML(filter) + "\">");
/*      */     }
/*  752 */     result.append("<input name=\"" + name + "\" type=\"hidden\" value=\"" + (primaryKeyId == null ? "" : primaryKeyId) + "\">");
/*      */ 
/*  754 */     TemplateAttribute t_query = getAttribute(ic, "query");
/*  755 */     if (t_query != null) {
/*  756 */       result.append("<input name=\"" + name + "_query\" type=\"hidden\" value=\"" + StringUtil.toHTML(t_query.toString()) + "\">");
/*      */     }
/*  758 */     String img = getString(ic, "img");
/*  759 */     if ((canSave) && (img != null)) {
/*  760 */       result.append(img);
/*      */     }
/*  762 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createDate(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  767 */     StringBuffer result = new StringBuffer();
/*  768 */     String value = getDate(ic, typename);
/*      */ 
/*  770 */     result.append("<input name=\"" + name + "\"");
/*  771 */     result.append(" type=\"text\"");
/*  772 */     result.append(getExtendedAttributesString(ic));
/*  773 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  774 */     result.append(getEvents(ic));
/*  775 */     result.append(" maxlength=\"10\"");
/*  776 */     result.append(" value=\"" + value + "\">");
/*  777 */     String img = getString(ic, "img");
/*  778 */     if ((canSave) && (img != null))
/*  779 */       result.append(img);
/*  780 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createTime(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  785 */     StringBuffer result = new StringBuffer();
/*  786 */     String value = getTime(ic, typename);
/*      */ 
/*  788 */     result.append("<input name=\"" + name + "\"");
/*  789 */     result.append(" type=\"text\"");
/*  790 */     result.append(getExtendedAttributesString(ic));
/*  791 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  792 */     result.append(getEvents(ic));
/*  793 */     result.append(" maxlength=\"8\"");
/*  794 */     result.append(" value=\"" + value + "\">");
/*  795 */     String img = getString(ic, "img");
/*  796 */     if ((canSave) && (img != null))
/*  797 */       result.append(img);
/*  798 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createDateTime(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  803 */     StringBuffer result = new StringBuffer();
/*  804 */     String value = getDateTime(ic, typename);
/*      */ 
/*  806 */     result.append("<input name=\"" + name + "\"");
/*  807 */     result.append(" type=\"text\"");
/*  808 */     result.append(getExtendedAttributesString(ic));
/*  809 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  810 */     result.append(getEvents(ic));
/*  811 */     result.append(" maxlength=\"19\"");
/*  812 */     result.append(" value=\"" + value + "\">");
/*  813 */     String img = getString(ic, "img");
/*  814 */     if ((canSave) && (img != null))
/*  815 */       result.append(img);
/*  816 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createTextArea(InvocationContext ic, ConnectionWrapper conn, String name, String typename, String length, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  821 */     StringBuffer result = new StringBuffer();
/*  822 */     String value = getValue(ic, typename);
/*      */ 
/*  824 */     result.append("<textarea name=\"" + name + "\"");
/*  825 */     result.append(getExtendedAttributesString(ic));
/*  826 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  827 */     result.append(length);
/*  828 */     result.append(getEvents(ic));
/*  829 */     result.append(">" + value + "</textarea>");
/*      */ 
/*  831 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createBoolean(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  836 */     StringBuffer result = new StringBuffer();
/*  837 */     String value = getValue(ic, typename);
/*      */ 
/*  839 */     result.append("<select name=\"" + name + "\"");
/*  840 */     result.append(getExtendedAttributesString(ic));
/*  841 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  842 */     result.append(getEvents(ic));
/*  843 */     result.append(">");
/*  844 */     if (!isMandatory)
/*  845 */       result.append("<option value=\"\">");
/*  846 */     result.append("<option value=\"Y\"");
/*  847 */     if (value.equalsIgnoreCase("Y"))
/*      */     {
/*  849 */       result.append(" selected");
/*      */     }
/*  851 */     result.append(">Yes");
/*      */ 
/*  853 */     result.append("<option value=\"N\"");
/*  854 */     if (value.equalsIgnoreCase("N"))
/*      */     {
/*  856 */       result.append(" selected");
/*      */     }
/*  858 */     result.append(">No");
/*  859 */     result.append("</select>");
/*      */ 
/*  861 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createDB(InvocationContext ic, ConnectionWrapper conn, String name, String typename, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  866 */     StringBuffer result = new StringBuffer();
/*  867 */     String value = getValue(ic, typename);
/*      */ 
/*  869 */     result.append("<input name=\"" + name + "\" type=\"hidden\"");
/*  870 */     result.append(getExtendedAttributesString(ic));
/*  871 */     result.append(" value=\"" + value + "\"");
/*  872 */     result.append(">");
/*  873 */     result.append("<input name=\"" + name + "_db\" type=\"hidden\" value=\"true\">");
/*  874 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createPhone(InvocationContext ic, ConnectionWrapper conn, String name, String typename, String length, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError)
/*      */     throws Exception
/*      */   {
/*  880 */     StringBuffer result = new StringBuffer();
/*  881 */     String value = getValue(ic, typename);
/*      */ 
/*  883 */     result.append("<input name=\"" + name + "\"");
/*  884 */     result.append(" type=\"text\"");
/*  885 */     result.append(getExtendedAttributesString(ic));
/*  886 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  887 */     result.append(length);
/*  888 */     result.append(" value=\"" + value + "\"");
/*  889 */     result.append(getEvents(ic));
/*  890 */     result.append(">");
/*  891 */     result.append("<input name=\"" + name + "_phone\" type=\"hidden\" value=\"true\">");
/*      */ 
/*  893 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createMoney(InvocationContext ic, ConnectionWrapper conn, String name, String typename, String length, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  898 */     StringBuffer result = new StringBuffer();
/*  899 */     String value = getMoney(ic, typename);
/*  900 */     String format = getString(ic, "format");
/*      */ 
/*  902 */     result.append("<input name=\"" + name + "\"");
/*  903 */     result.append(" type=\"text\"");
/*  904 */     result.append(getExtendedAttributesString(ic));
/*  905 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  906 */     result.append(length);
/*  907 */     result.append(" value=\"" + value + "\"");
/*  908 */     result.append(getEvents(ic));
/*  909 */     result.append(">");
/*  910 */     result.append("<input name=\"" + name + "_money\" type=\"hidden\" value=\"true\">");
/*      */ 
/*  912 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createPercent(InvocationContext ic, ConnectionWrapper conn, String name, String typename, String length, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  917 */     StringBuffer result = new StringBuffer();
/*  918 */     String value = getPercent(ic, typename);
/*  919 */     String format = getString(ic, "format");
/*      */ 
/*  921 */     result.append("<input name=\"" + name + "\"");
/*  922 */     result.append(" type=\"text\"");
/*  923 */     result.append(getExtendedAttributesString(ic));
/*  924 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  925 */     result.append(length);
/*  926 */     result.append(" value=\"" + value + "\"");
/*  927 */     result.append(getEvents(ic));
/*  928 */     result.append(">");
/*  929 */     result.append("<input name=\"" + name + "_percent\" type=\"hidden\" value=\"" + getString(ic, "numDecimals") + "\">");
/*      */ 
/*  931 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String createText(InvocationContext ic, ConnectionWrapper conn, String name, String typename, String length, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError) throws Exception
/*      */   {
/*  936 */     StringBuffer result = new StringBuffer();
/*  937 */     String value = getValue(ic, typename);
/*      */ 
/*  939 */     result.append("<input name=\"" + name + "\"");
/*  940 */     result.append(" type=\"" + getString(ic, "type") + "\"");
/*  941 */     result.append(getExtendedAttributesString(ic));
/*  942 */     result.append(getCSS(ic, name, value, canSave, isReadOnly, isMandatory, isError));
/*  943 */     result.append(length);
/*  944 */     result.append(" value=\"" + value + "\"");
/*  945 */     result.append(getEvents(ic));
/*  946 */     result.append(">");
/*      */ 
/*  948 */     String format = getString(ic, "format");
/*  949 */     if (format != null) result.append("<input name=\"" + name + "_format\" type=\"hidden\" value=\"" + StringUtil.toHTML(format) + "\">");
/*      */ 
/*  951 */     TemplateAttribute query = getAttribute(ic, "query");
/*  952 */     if (query != null) {
/*  953 */       result.append("<input name=\"" + name + "_query\" type=\"hidden\" value=\"" + StringUtil.toHTML(query.toString()) + "\">");
/*      */     }
/*  955 */     return result.toString();
/*      */   }
/*      */ 
/*      */   private String getCSS(InvocationContext ic, String name, String value, boolean canSave, boolean isReadOnly, boolean isMandatory, boolean isError)
/*      */     throws Exception
/*      */   {
/*  969 */     String type = getString(ic, "type");
/*  970 */     if (type.equals("hidden")) return "";
/*      */ 
/*  972 */     SmartFormComponent parent = getParentSmartForm();
/*  973 */     String parentName = parent.getString(ic, "name");
/*  974 */     int x = parentName.lastIndexOf('/');
/*  975 */     if (x != -1) parentName = parentName.substring(x + 1);
/*  976 */     boolean errorText = parent.getBoolean(ic, "errorText");
/*  977 */     boolean useCSS = parent.getBoolean(ic, "useCSS");
/*  978 */     String css = " class=\"regular\"";
/*      */ 
/*  980 */     if (canSave)
/*      */     {
/*  982 */       if (isError)
/*  983 */         css = " class=\"error\"";
/*  984 */       else if ((useCSS) && (isMandatory) && ((value == null) || (value.length() == 0)))
/*  985 */         css = " class=\"mandatory\"";
/*  986 */       else if ((!useCSS) && (isMandatory)) {
/*  987 */         css = " class=\"mandatory\"";
/*      */       }
/*      */     }
/*  990 */     if (isReadOnly)
/*      */     {
/*  992 */       css = " class=\"readonly\" readonly=\"true\"";
/*      */     }
/*      */ 
/*  995 */     if (useCSS)
/*      */     {
/*  998 */       if (isMandatory) {
/*  999 */         ((Vector)ic.getTransientDatum("mandatory")).addElement("document." + parentName + "." + name);
/*      */       }
/* 1001 */       ((Vector)ic.getTransientDatum("fields")).addElement("document." + parentName + "." + name);
/*      */     }
/*      */ 
/* 1004 */     return css;
/*      */   }
/*      */ 
/*      */   private String getEvents(InvocationContext ic) throws Exception
/*      */   {
/* 1009 */     SmartFormComponent parent = getParentSmartForm();
/* 1010 */     boolean useCSS = parent.getBoolean(ic, "useCSS");
/* 1011 */     if (useCSS) return " onFocus=\"fixColors()\" onBlur=\"fixColors()\"";
/* 1012 */     return "";
/*      */   }
/*      */ 
/*      */   public SmartFormComponent getParentSmartForm() throws Exception
/*      */   {
/* 1017 */     for (TemplateComponent t = getParent(); t != null; t = t.getParent()) {
/* 1018 */       if ((t instanceof SmartFormComponent)) return (SmartFormComponent)t;
/*      */     }
/* 1020 */     throw new Exception("Could not find parent SmartFormComponent for component " + this);
/*      */   }
/*      */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SmartFieldComponent
 * JD-Core Version:    0.6.2
 */