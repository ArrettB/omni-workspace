/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SimpleLoopComponent extends TemplateComponent
/*     */ {
/*     */   public SimpleLoopComponent()
/*     */     throws Exception
/*     */   {
/*  44 */     registerDeprecatedAttribute("limitControl", null);
/*  45 */     registerAttribute("alternator1", null);
/*  46 */     registerAttribute("alternator2", null);
/*  47 */     registerAttribute("loopIndex", "i");
/*  48 */     registerAttribute("vector", null);
/*  49 */     requiresEndTag();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  54 */     StringBuffer result = new StringBuffer();
/*     */ 
/*  56 */     String alt1 = getString(ic, "alternator1");
/*  57 */     String alt2 = getString(ic, "alternator2");
/*  58 */     String loopIndex = getString(ic, "loopIndex");
/*  59 */     String limitControl = getString(ic, "limitControl");
/*  60 */     Object o = getObject(ic, "vector");
/*  61 */     Vector vector = null;
/*     */ 
/*  63 */     if ((o != null) && ((o instanceof Vector)))
/*  64 */       vector = (Vector)o;
/*  65 */     else if (limitControl != null) {
/*  66 */       vector = (Vector)ic.getTransientDatum(limitControl);
/*     */     }
/*  68 */     if (vector == null) return "";
/*     */ 
/*  70 */     String alt1_1 = null;
/*  71 */     String alt1_2 = null;
/*  72 */     if ((alt1 != null) && (alt1.length() > 0))
/*     */     {
/*  74 */       Vector tvect = StringUtil.stringToVector(alt1, ':');
/*  75 */       alt1_1 = (String)tvect.elementAt(0);
/*  76 */       alt1_2 = (String)tvect.elementAt(1);
/*     */     }
/*     */ 
/*  79 */     String alt2_1 = null;
/*  80 */     String alt2_2 = null;
/*  81 */     if ((alt2 != null) && (alt2.length() > 0))
/*     */     {
/*  83 */       Vector tvect = StringUtil.stringToVector(alt2, ':');
/*  84 */       alt2_1 = (String)tvect.elementAt(0);
/*  85 */       alt2_2 = (String)tvect.elementAt(1);
/*     */     }
/*     */ 
/*  89 */     for (int rowid = 0; rowid < vector.size(); rowid++)
/*     */     {
/*  91 */       ic.setTransientDatum(loopIndex, "" + rowid);
/*  92 */       if (rowid % 2 == 0)
/*     */       {
/*  94 */         if (alt1_1 != null) ic.setTransientDatum(loopIndex + ":alt1", alt1_1);
/*  95 */         if (alt2_1 != null) ic.setTransientDatum(loopIndex + ":alt2", alt2_1);
/*     */       }
/*     */       else
/*     */       {
/*  99 */         if (alt1_2 != null) ic.setTransientDatum(loopIndex + ":alt1", alt1_2);
/* 100 */         if (alt2_2 != null) ic.setTransientDatum(loopIndex + ":alt2", alt2_2);
/*     */       }
/* 102 */       result.append(includeChildren(ic));
/*     */     }
/* 104 */     ic.removeTransientDatum(loopIndex);
/*     */ 
/* 106 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SimpleLoopComponent
 * JD-Core Version:    0.6.2
 */