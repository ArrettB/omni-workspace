/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.intraframe.engine.ApplicationContext;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ 
/*    */ public class EchoComponent extends TemplateComponent
/*    */ {
/*    */   public EchoComponent()
/*    */     throws Exception
/*    */   {
/* 25 */     registerRequiredAttribute("data");
/* 26 */     registerAttribute("default", null);
/* 27 */     registerAttribute("format", null);
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic) throws Exception
/*    */   {
/* 32 */     String format = getString(ic, "format");
/*    */ 
/* 34 */     if (format != null)
/*    */     {
/* 36 */       Object data = getObject(ic, "data");
/* 37 */       if (data != null) return ic.format(data, format);
/* 38 */       Object def = getObject(ic, "def");
/* 39 */       if (def != null) return ic.format(def, format);
/*    */     }
/*    */     else
/*    */     {
/* 43 */       String data = getString(ic, "data");
/* 44 */       if (data != null) return data;
/* 45 */       String def = getString(ic, "default");
/* 46 */       if (def != null) return def;
/*    */     }
/*    */ 
/* 49 */     return "";
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.EchoComponent
 * JD-Core Version:    0.6.2
 */