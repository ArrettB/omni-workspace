/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class SmartLinkComponent extends TemplateComponent
/*     */ {
/*     */   public SmartLinkComponent()
/*     */     throws Exception
/*     */   {
/*  56 */     registerAttribute("holdParams", "false");
/*  57 */     registerDeprecatedAttribute("eca", null);
/*  58 */     registerAttribute("action", null);
/*  59 */     registerAttribute("page", null);
/*  60 */     allowsExtendedAttributes();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/*  65 */     StringBuffer result = new StringBuffer();
/*  66 */     boolean holdParams = getBoolean(ic, "holdParams");
/*  67 */     String eca = getString(ic, "eca");
/*  68 */     String action = getString(ic, "action");
/*  69 */     String page = getString(ic, "page");
/*     */ 
/*  71 */     if (eca != null)
/*  72 */       result.append(ic.getSessionDatum("action") + eca);
/*  73 */     else if (action != null)
/*  74 */       result.append(ic.getSessionDatum("action") + action);
/*  75 */     else if (page != null) {
/*  76 */       result.append(ic.getSessionDatum("showPage") + page);
/*     */     }
/*  78 */     Hashtable myParams = new Hashtable();
/*     */ 
/*  81 */     if (holdParams)
/*     */     {
/*  83 */       Enumeration keys = ic.getParameterKeys();
/*  84 */       while (keys.hasMoreElements())
/*     */       {
/*  86 */         String key = (String)keys.nextElement();
/*  87 */         if (!key.equals("page")) {
/*  88 */           myParams.put(key, ic.getParameter(key));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  93 */     Enumeration elements = getExtendedAttributes().elements();
/*  94 */     while (elements.hasMoreElements())
/*     */     {
/*  96 */       String key = (String)elements.nextElement();
/*  97 */       myParams.put(key, getString(ic, key));
/*     */     }
/*     */ 
/* 101 */     if (myParams.size() > 0)
/*     */     {
/* 103 */       result.append("?");
/* 104 */       Enumeration myKeys = myParams.keys();
/* 105 */       while (myKeys.hasMoreElements())
/*     */       {
/* 107 */         String key = (String)myKeys.nextElement();
/* 108 */         result.append("&" + key + "=" + StringUtil.toURL((String)myParams.get(key)));
/*     */       }
/*     */     }
/*     */ 
/* 112 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SmartLinkComponent
 * JD-Core Version:    0.6.2
 */