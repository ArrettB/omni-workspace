/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class IfComponent extends ElseIfComponent
/*     */ {
/*  51 */   private TemplateComponent currentComp = this;
/*  52 */   private Vector elseIfComps = new Vector();
/*  53 */   private TemplateComponent elseComponent = null;
/*     */ 
/*     */   public IfComponent() throws Exception
/*     */   {
/*  57 */     requiresEndTag();
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  62 */     if (this.elseComponent != null) this.elseComponent.destroy();
/*  63 */     this.elseComponent = null;
/*  64 */     if (this.elseIfComps != null)
/*     */     {
/*  66 */       for (int i = 0; i < this.elseIfComps.size(); i++)
/*  67 */         ((ElseIfComponent)this.elseIfComps.elementAt(i)).destroy();
/*  68 */       this.elseIfComps.removeAllElements();
/*  69 */       this.elseIfComps = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object clone() throws CloneNotSupportedException
/*     */   {
/*  75 */     IfComponent n = (IfComponent)super.clone();
/*  76 */     n.currentComp = n;
/*  77 */     n.elseIfComps = ((Vector)this.elseIfComps.clone());
/*  78 */     return n;
/*     */   }
/*     */ 
/*     */   public void addComponent(TemplateComponent comp) throws Exception
/*     */   {
/*  83 */     if (comp.getName().equalsIgnoreCase("elseif"))
/*     */     {
/*  85 */       this.elseIfComps.addElement(comp);
/*  86 */       this.currentComp = comp;
/*     */     }
/*  88 */     else if (comp.getName().equalsIgnoreCase("else"))
/*     */     {
/*  90 */       this.elseComponent = comp;
/*  91 */       this.currentComp = comp;
/*     */     }
/*  93 */     else if (this.currentComp != this)
/*     */     {
/*  95 */       this.currentComp.addComponent(comp);
/*     */     }
/*     */     else
/*     */     {
/*  99 */       super.addComponent(comp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/* 105 */     TemplateComponent trueComponent = null;
/* 106 */     if (eval(ic))
/*     */     {
/* 108 */       trueComponent = this;
/*     */     }
/*     */     else
/*     */     {
/* 112 */       for (int i = 0; i < this.elseIfComps.size(); i++)
/*     */       {
/* 114 */         ElseIfComponent EIC = (ElseIfComponent)this.elseIfComps.elementAt(i);
/* 115 */         if (EIC.eval(ic))
/*     */         {
/* 117 */           trueComponent = EIC;
/* 118 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 122 */       if (trueComponent == null) {
/* 123 */         trueComponent = this.elseComponent;
/*     */       }
/*     */     }
/* 126 */     if (trueComponent != null) {
/* 127 */       return trueComponent.includeChildren(ic);
/*     */     }
/* 129 */     return "";
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.IfComponent
 * JD-Core Version:    0.6.2
 */