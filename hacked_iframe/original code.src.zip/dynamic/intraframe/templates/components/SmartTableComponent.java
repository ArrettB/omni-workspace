/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.dbtk.MetaData;
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.dbtk.connection.MemoryResults;
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.dbtk.parser.Sql;
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class SmartTableComponent extends TemplateComponent
/*     */ {
/*     */   public static final int MAX = 100;
/*     */   public static final String QUERY = "_query";
/*     */   public static final String SQL = "_sql";
/*     */   public static final String METADATA = "_metadata";
/*     */   public static final String FILTER_LIST = "_filter_list";
/*     */   public static final String FILTER_ACTION = "_filter_action";
/*     */   public static final String FILTER_FORM = "_filter_form";
/*     */   public static final String FILTER_TARGET = "_filter_target";
/*     */   public static final String ORDER_BY = "_order_by";
/*     */   public static final String MAX_ROWS = "_max_rows";
/*     */   public static final String START_WITH = "_start_with";
/*     */   public static final int TYPE_TITLE = 0;
/*     */   public static final int TYPE_FILTER = -1;
/*     */   public static final int TYPE_TOTAL = -2;
/*     */   public static final String AUTO_CLICK_URL = "autoClickURL";
/*     */ 
/*     */   public SmartTableComponent()
/*     */     throws Exception
/*     */   {
/*  97 */     registerAttribute("alternator1", null);
/*  98 */     registerAttribute("alternator2", null);
/*  99 */     registerAttribute("aSort", "");
/* 100 */     registerAttribute("autoClick", "false");
/* 101 */     registerAttribute("colorRowClasses", null);
/* 102 */     registerAttribute("colorRowCol", null);
/* 103 */     registerAttribute("colorRowVal", null);
/* 104 */     registerAttribute("cursor", null);
/* 105 */     registerAttribute("dSort", "");
/* 106 */     registerAttribute("filter", "");
/* 107 */     registerAttribute("filterClass", null);
/* 108 */     registerAttribute("footerClass", null);
/* 109 */     registerAttribute("group", "");
/* 110 */     registerAttribute("resourceName", null);
/* 111 */     registerAttribute("maxRows", "0");
/* 112 */     registerAttribute("name", "q1");
/* 113 */     registerAttribute("query", null);
/* 114 */     registerDeprecatedAttribute("redisplayTemplate", null);
/* 115 */     registerAttribute("rowClass", null);
/* 116 */     registerAttribute("rowHeight", "0");
/* 117 */     registerAttribute("cellLinkClasses", null);
/* 118 */     registerAttribute("rowRolloverClass", null);
/* 119 */     registerAttribute("titleClass", null);
/* 120 */     registerAttribute("totalClass", null);
/* 121 */     registerAttribute("titleHeight", "0");
/* 122 */     registerAttribute("titleSpacing", "0");
/* 123 */     requiresEndTag();
/* 124 */     allowsExtendedAttributes();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 130 */     StringBuffer result = new StringBuffer();
/* 131 */     StringBuffer header = new StringBuffer();
/* 132 */     StringBuffer body = new StringBuffer();
/* 133 */     StringBuffer footer = new StringBuffer();
/* 134 */     StringBuffer script = new StringBuffer();
/* 135 */     String name = getString(ic, "name");
/* 136 */     main(ic, name, null, header, body, footer, script);
/* 137 */     result.append(table(ic, name)).append(header).append(body).append(footer).append("</table>\n");
/* 138 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected void main(InvocationContext ic, String name, String target, StringBuffer header, StringBuffer body, StringBuffer footer, StringBuffer script)
/*     */     throws Exception
/*     */   {
/* 146 */     ConnectionWrapper conn = null;
/*     */     try
/*     */     {
/* 150 */       ic.setTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + name, new String());
/*     */ 
/* 152 */       Vector rowGroups = StringUtil.stringToVector(getString(ic, "group"));
/* 153 */       ic.setTransientDatum("group", rowGroups);
/*     */ 
/* 155 */       String aSort = getString(ic, "aSort");
/* 156 */       Object o = getObject(ic, "cursor");
/* 157 */       QueryResults rs = null;
/* 158 */       if ((o != null) && (!(o instanceof QueryResults))) o = new MemoryResults(new Vector());
/* 159 */       rs = (QueryResults)o;
/* 160 */       String dSort = getString(ic, "dSort");
/* 161 */       int maxRows = getInt(ic, "maxRows");
/* 162 */       int maxRowCount = maxRows;
/* 163 */       String maxRowString = ic.getParameter(name + "_max_rows");
/* 164 */       if ((maxRowString != null) && (maxRowString.length() > 0))
/* 165 */         maxRowCount = Integer.parseInt(maxRowString);
/* 166 */       int numRows = 0;
/* 167 */       String query = getString(ic, "query");
/* 168 */       Sql sql = null;
/* 169 */       String resourceName = getString(ic, "resourceName");
/*     */ 
/* 171 */       if ((query == null) && (rs == null)) {
/* 172 */         throw new Exception("Neither query or cursor was specified in component " + this);
/*     */       }
/* 174 */       if ((query != null) && (rs != null)) {
/* 175 */         throw new Exception("Both query and cursor were specified in component " + this);
/*     */       }
/* 177 */       if (query != null)
/*     */       {
/* 179 */         Diagnostics.debug("SmartTableComponent.include() pre-filter SQL: " + query);
/* 180 */         conn = (ConnectionWrapper)ic.getResource(resourceName);
/* 181 */         String filter = getString(ic, "filter");
/*     */ 
/* 183 */         if ((filter != null) && (filter.length() > 0))
/*     */         {
/* 185 */           if (sql == null) sql = Sql.fetchSql(query);
/* 186 */           sql = ic.processFilter(sql, filter);
/*     */         }
/*     */ 
/* 189 */         String orderBy = ic.getParameter(name + "_order_by");
/* 190 */         if (orderBy != null)
/*     */         {
/* 192 */           if (sql == null) sql = Sql.fetchSql(query);
/* 193 */           sql = ic.processFilter(sql, "orderby(" + orderBy + ")");
/* 194 */           query = sql.getQuery();
/*     */         }
/*     */       }
/* 197 */       else if ((rs instanceof MemoryResults))
/*     */       {
/* 199 */         numRows = ((MemoryResults)rs).size();
/*     */       }
/*     */ 
/* 207 */       ic.setTransientDatum("numcols", "0");
/* 208 */       ic.setTransientDatum("skipcols", "0");
/* 209 */       Vector filterList = new Vector();
/* 210 */       ic.setTransientDatum(name + "_filter_list", filterList);
/* 211 */       header.append(title(ic, name, target, filterList));
/* 212 */       if (sql != null) ic.setTransientDatum(name + "_sql", sql);
/* 213 */       else if (query != null) ic.setTransientDatum(name + "_query", query);
/* 214 */       header.append(filter(ic, name, target, filterList, maxRows));
/* 215 */       sql = (Sql)ic.getTransientDatum(name + "_sql");
/*     */ 
/* 217 */       if (query != null)
/*     */       {
/* 219 */         if (sql != null)
/*     */         {
/* 221 */           query = sql.getQuery();
/* 222 */           Diagnostics.debug("SmartTableComponent.include() post-filter SQL: " + query);
/*     */         }
/* 224 */         rs = conn.resultsQueryEx(query);
/*     */       }
/* 226 */       ic.setTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + name, rs);
/*     */ 
/* 228 */       MetaData meta = new MetaData(rs.getMetaData());
/* 229 */       ic.setTransientDatum(name + "_metadata", meta);
/*     */ 
/* 231 */       int startWithRow = 1;
/* 232 */       String tmp = ic.getParameter(name + "_start_with");
/* 233 */       if (tmp != null) startWithRow = Integer.parseInt(tmp);
/*     */ 
/* 236 */       body.append(body(ic, name, rs, meta, startWithRow, maxRowCount));
/*     */ 
/* 239 */       int rowid = Integer.parseInt((String)ic.getRequiredTransientDatum("rowid"));
/*     */ 
/* 242 */       String doTotal = (String)ic.getTransientDatum(name + "_total");
/* 243 */       if (doTotal != null) footer.append(total(ic, name));
/* 244 */       ic.removeTransientDatum(name + "_total");
/*     */ 
/* 247 */       if ((startWithRow > 1) || ((maxRowCount != 0) && (rowid - startWithRow >= maxRowCount)))
/*     */       {
/* 249 */         if (query != null)
/*     */         {
/* 251 */           if (sql == null) sql = Sql.fetchSql(query);
/* 252 */           Sql count_sql = ic.processFilter(sql, "count");
/* 253 */           String count_query = count_sql.getQuery();
/* 254 */           Diagnostics.debug("SmartTableComponent.include() count SQL: " + count_query);
/* 255 */           String count = conn.queryEx(count_query);
/* 256 */           if ((count != null) && (count.length() > 0)) numRows = Integer.parseInt(count);
/*     */         }
/* 258 */         footer.append(footer(ic, startWithRow, maxRowCount, maxRows, numRows, target));
/*     */       }
/*     */ 
/* 262 */       script.append("<script language=\"JavaScript\">\n");
/* 263 */       script.append("<!--//\n");
/* 264 */       for (int i = 1; i <= meta.getColumnCount(); i++)
/* 265 */         script.append("\tvar " + meta.getColumnName(i) + "='';\n");
/* 266 */       script.append("// -->\n");
/* 267 */       script.append("</script>\n");
/*     */ 
/* 269 */       if ((rowid == 2) && (getBoolean(ic, "autoClick")))
/*     */       {
/* 271 */         if ((String)ic.getTransientDatum("autoClickURL") != null)
/* 272 */           ic.sendRedirect((String)ic.getTransientDatum("autoClickURL"));
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 277 */       if (conn != null) conn.release();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String title(InvocationContext ic, String name, String target, Vector filterList)
/*     */     throws Exception
/*     */   {
/* 286 */     StringBuffer result = new StringBuffer();
/* 287 */     String action = getRequestURL(ic);
/* 288 */     ic.setTransientDatum(name + "_filter_action", action);
/* 289 */     if (target != null) ic.setTransientDatum(name + "_filter_target", target);
/*     */ 
/* 292 */     int height = getInt(ic, "titleHeight");
/* 293 */     if (height == 0) height = getInt(ic, "rowHeight");
/* 294 */     result.append("<tr rowid=\"0\"");
/* 295 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 296 */     result.append(">\n");
/* 297 */     ic.setTransientDatum("rowid", "0");
/* 298 */     ic.setTransientDatum("row", "1");
/* 299 */     result.append(includeChildren(ic));
/* 300 */     result.append("</tr>\n");
/*     */ 
/* 302 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected String filter(InvocationContext ic, String name, String target, Vector filterList, int maxRows) throws Exception
/*     */   {
/* 307 */     StringBuffer result = new StringBuffer();
/* 308 */     if (filterList.size() > 0)
/*     */     {
/* 310 */       String action = getRequestURL(ic);
/* 311 */       result.append("<form name=\"" + name + "_filter_form" + "\" method=\"get\" action=\"" + action + "\"");
/* 312 */       if (target != null) result.append(" target=\"" + target + "\"");
/* 313 */       result.append(">\n");
/* 314 */       result.append("<tr rowid=\"-1\"");
/* 315 */       int height = getInt(ic, "titleHeight");
/* 316 */       if (height == 0) height = getInt(ic, "rowHeight");
/* 317 */       if (height > 0)
/* 318 */         result.append(" height=\"" + height + "\"");
/* 319 */       result.append(">\n");
/* 320 */       ic.setTransientDatum("rowid", "-1");
/* 321 */       ic.setTransientDatum("row", "1");
/* 322 */       result.append(includeChildren(ic));
/* 323 */       result.append("</tr>\n");
/*     */ 
/* 326 */       Enumeration keys = ic.getParameterKeys();
/* 327 */       while (keys.hasMoreElements())
/*     */       {
/* 329 */         String key = (String)keys.nextElement();
/* 330 */         if ((!filterList.contains(key)) && (!key.equals("startWithRow")))
/*     */         {
/* 332 */           String value = ic.getParameter(key);
/* 333 */           result.append(SmartFormComponent.hidden(key, value));
/*     */         }
/*     */       }
/* 336 */       result.append("</form>\n");
/*     */ 
/* 338 */       result.append("<script language=\"JavaScript\">\n");
/* 339 */       result.append("<!--//\n");
/* 340 */       result.append("function clearFields()\n");
/* 341 */       result.append("{\n");
/* 342 */       Enumeration filterEnum = filterList.elements();
/* 343 */       while (filterEnum.hasMoreElements())
/* 344 */         result.append("\tdocument." + name + "_filter_form" + "." + (String)filterEnum.nextElement() + ".value='';\n");
/* 345 */       result.append("\tif (document." + name + "_filter_form" + ".maxRows) document." + name + "_filter_form" + ".maxRows.value = '" + maxRows + "';\n");
/* 346 */       result.append("\tdocument." + name + "_filter_form" + ".submit();\n");
/* 347 */       result.append("\treturn true;\n");
/* 348 */       result.append("}\n");
/* 349 */       result.append("//-->\n");
/* 350 */       result.append("</script>\n");
/*     */     }
/*     */ 
/* 353 */     int titleSpacing = getInt(ic, "titleSpacing");
/* 354 */     if (titleSpacing > 0) {
/* 355 */       result.append("<tr height=\"" + titleSpacing + "\"><td></td></tr>\n");
/*     */     }
/* 357 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected String body(InvocationContext ic, String name, QueryResults rs, MetaData meta, int startWithRow, int maxRowCount)
/*     */     throws Exception
/*     */   {
/* 365 */     StringBuffer body = new StringBuffer();
/*     */ 
/* 367 */     int height = getInt(ic, "rowHeight");
/* 368 */     int rowid = 0;
/*     */ 
/* 371 */     String colorRowClasses = getString(ic, "colorRowClasses");
/* 372 */     boolean hasColorRowClasses = StringUtil.hasAValue(colorRowClasses);
/* 373 */     int num_cols = meta.getColumnCount();
/* 374 */     String colorRowCol = null;
/* 375 */     String colorRowVal = null;
/* 376 */     if (hasColorRowClasses)
/*     */     {
/* 378 */       colorRowCol = getString(ic, "colorRowCol");
/* 379 */       if (!StringUtil.hasAValue(colorRowCol))
/* 380 */         Diagnostics.debug2("colorRowClasses will not work without 'colorRowCol' form attribute.");
/* 381 */       colorRowVal = getString(ic, "colorRowVal");
/* 382 */       if (!StringUtil.hasAValue(colorRowVal)) {
/* 383 */         Diagnostics.debug2("colorRowClasses will not work without 'colorRowVal' form attribute.");
/*     */       }
/*     */     }
/* 386 */     String alt1 = getString(ic, "alternator1");
/* 387 */     String alt2 = getString(ic, "alternator2");
/* 388 */     String alt1_1 = null;
/* 389 */     String alt1_2 = null;
/* 390 */     if ((alt1 != null) && (alt1.length() > 0))
/*     */     {
/* 392 */       Vector tvect = StringUtil.stringToVector(alt1, ':');
/* 393 */       alt1_1 = (String)tvect.elementAt(0);
/* 394 */       alt1_2 = (String)tvect.elementAt(1);
/*     */     }
/*     */ 
/* 397 */     String alt2_1 = null;
/* 398 */     String alt2_2 = null;
/* 399 */     if ((alt2 != null) && (alt2.length() > 0))
/*     */     {
/* 401 */       Vector tvect = StringUtil.stringToVector(alt2, ':');
/* 402 */       alt2_1 = (String)tvect.elementAt(0);
/* 403 */       alt2_2 = (String)tvect.elementAt(1);
/*     */     }
/*     */ 
/* 407 */     for (rowid = 1; (rowid < startWithRow) && (rs.next()); rowid++);
/* 408 */     ic.setTransientDatum("rowid", "" + rowid);
/*     */ 
/* 410 */     while (rs.next())
/*     */     {
/* 412 */       ic.setTransientDatum("row", "1");
/* 413 */       if ((maxRowCount != 0) && (rowid >= maxRowCount + startWithRow))
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 423 */       boolean condition_met = false;
/* 424 */       if (hasColorRowClasses)
/*     */       {
/* 426 */         for (int i = 1; i <= num_cols; i++)
/*     */         {
/* 428 */           if ((meta.getColumnName(i).equalsIgnoreCase(colorRowCol)) && (rs.getString(i) != null) && (rs.getString(i).equals(colorRowVal)))
/*     */           {
/* 430 */             condition_met = true;
/* 431 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 435 */       if (condition_met)
/* 436 */         ic.setTransientDatum("hasColorRowClasses", colorRowClasses);
/*     */       else {
/* 438 */         ic.setTransientDatum("hasColorRowClasses", "false");
/*     */       }
/* 440 */       body.append("<tr rowid=\"" + rowid + "\"");
/* 441 */       if (height > 0) {
/* 442 */         body.append(" height=\"" + height + "\"");
/*     */       }
/*     */ 
/* 450 */       body.append(">");
/*     */ 
/* 452 */       if (rowid % 2 == 0)
/*     */       {
/* 454 */         if (alt1_2 != null) ic.setTransientDatum(name + ":alt1", alt1_2);
/* 455 */         if (alt2_2 != null) ic.setTransientDatum(name + ":alt2", alt2_2);
/*     */       }
/*     */       else
/*     */       {
/* 459 */         if (alt1_1 != null) ic.setTransientDatum(name + ":alt1", alt1_1);
/* 460 */         if (alt2_1 != null) ic.setTransientDatum(name + ":alt2", alt2_1);
/*     */       }
/*     */ 
/* 463 */       body.append(includeChildren(ic));
/* 464 */       body.append("</tr>\n");
/*     */ 
/* 466 */       rowid++;
/*     */ 
/* 468 */       ic.setTransientDatum("rowid", "" + rowid);
/*     */     }
/* 470 */     rs.close();
/*     */ 
/* 472 */     if (rowid == startWithRow)
/*     */     {
/* 475 */       ic.setTransientDatum("hasColorRowClasses", "false");
/*     */ 
/* 477 */       String numcols = (String)ic.getRequiredTransientDatum("numcols");
/* 478 */       body.append("<tr><td");
/* 479 */       body.append(" colspan=\"" + numcols + "\"");
/* 480 */       if (height > 0)
/* 481 */         body.append(" height=\"" + height + "\"");
/* 482 */       String css = getRowClass(ic, rowid, null);
/* 483 */       if (css != null)
/* 484 */         body.append(" class=\"" + css + "\"");
/* 485 */       body.append(">");
/* 486 */       body.append("No items in the list");
/* 487 */       body.append("</td>\n");
/* 488 */       body.append("</tr>\n");
/*     */     }
/*     */ 
/* 493 */     return body.toString();
/*     */   }
/*     */ 
/*     */   protected String total(InvocationContext ic, String name) throws Exception
/*     */   {
/* 498 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 500 */     int height = getInt(ic, "titleHeight");
/* 501 */     if (height == 0) height = getInt(ic, "rowHeight");
/* 502 */     result.append("<tr rowid=\"-2\"");
/* 503 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 504 */     result.append(">\n");
/* 505 */     ic.setTransientDatum("row", "1");
/* 506 */     ic.setTransientDatum("rowid", "-2");
/* 507 */     result.append(includeChildren(ic));
/* 508 */     result.append("</tr>\n");
/*     */ 
/* 510 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected String footer(InvocationContext ic, int startWithRow, int maxRowCount, int defaultMaxRows, int numRows, String frame)
/*     */     throws Exception
/*     */   {
/* 518 */     StringBuffer result = new StringBuffer();
/* 519 */     String numcols = (String)ic.getRequiredTransientDatum("numcols");
/* 520 */     String skipcols = (String)ic.getRequiredTransientDatum("skipcols");
/* 521 */     int rowid = Integer.parseInt((String)ic.getRequiredTransientDatum("rowid"));
/* 522 */     if (rowid == -2)
/*     */     {
/* 524 */       rowid = startWithRow + maxRowCount;
/* 525 */       if (rowid > numRows)
/* 526 */         rowid = numRows + 1;
/*     */     }
/* 528 */     int height = getInt(ic, "titleHeight");
/* 529 */     if (height == 0) height = getInt(ic, "rowHeight");
/* 530 */     int titleSpacing = getInt(ic, "titleSpacing");
/*     */ 
/* 532 */     if (titleSpacing > 0) {
/* 533 */       result.append("<tr height=\"" + titleSpacing + "\"><td></td></tr>\n");
/*     */     }
/* 535 */     result.append("<tr");
/* 536 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 537 */     result.append(">");
/* 538 */     if (!skipcols.equals("0"))
/*     */     {
/* 540 */       result.append("<td colspan=\"" + skipcols + "\"");
/* 541 */       if (height > 0) result.append(" height=\"" + height + "\"");
/* 542 */       result.append(">&nbsp;</td>");
/*     */     }
/* 544 */     result.append("<td colspan=\"" + numcols + "\"");
/* 545 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 546 */     result.append(">");
/* 547 */     result.append("<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\"");
/* 548 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 549 */     result.append(">");
/* 550 */     result.append("<tr");
/* 551 */     if (height > 0) result.append(" height=\"" + height + "\"");
/* 552 */     result.append(">\n");
/*     */ 
/* 554 */     if ((defaultMaxRows == maxRowCount) && (defaultMaxRows == 100))
/*     */     {
/* 556 */       result.append(footerCell(ic, 0, 0, "&nbsp;&nbsp;&nbsp;", "center", 70, height, false, false, frame));
/*     */     }
/*     */     else
/*     */     {
/* 560 */       result.append(footerCell(ic, 0, 0, "&nbsp;&nbsp;&nbsp;", "center", 20, height, false, false, frame));
/*     */ 
/* 562 */       String text = null;
/* 563 */       boolean clickable = false;
/*     */ 
/* 565 */       int num_to_show = numRows < 100 ? numRows : 100;
/* 566 */       if (numRows <= 100) text = "Show all " + num_to_show; else
/* 567 */         text = "Groups of " + num_to_show;
/* 568 */       clickable = maxRowCount != num_to_show;
/* 569 */       result.append(footerCell(ic, 1, num_to_show, text, "right", 9, height, clickable, !clickable, frame));
/*     */ 
/* 571 */       text = "Groups of " + defaultMaxRows;
/* 572 */       clickable = maxRowCount != defaultMaxRows;
/* 573 */       result.append(footerCell(ic, 1, defaultMaxRows, text, "left", 9, height, clickable, !clickable, frame));
/* 574 */       result.append(footerCell(ic, 0, 0, startWithRow + " - " + (rowid - 1) + " of " + numRows, "center", 30, height, false, false, frame));
/*     */     }
/*     */ 
/* 577 */     if (startWithRow - maxRowCount >= 1)
/* 578 */       result.append(footerCell(ic, startWithRow - maxRowCount, maxRowCount, "Previous " + maxRowCount, "right", 6, height, true, false, frame));
/* 579 */     else if (startWithRow > 1)
/* 580 */       result.append(footerCell(ic, 1, maxRowCount, "Previous " + (startWithRow - 1), "right", 6, height, true, false, frame));
/*     */     else {
/* 582 */       result.append(footerCell(ic, startWithRow - maxRowCount, maxRowCount, "Previous " + maxRowCount, "right", 6, height, false, true, frame));
/*     */     }
/* 584 */     if (startWithRow <= numRows - maxRowCount * 2)
/* 585 */       result.append(footerCell(ic, rowid, maxRowCount, "Next " + maxRowCount, "left", 6, height, true, false, frame));
/* 586 */     else if (startWithRow <= numRows - maxRowCount)
/* 587 */       result.append(footerCell(ic, rowid, maxRowCount, "Next " + (numRows - rowid + 1), "left", 6, height, true, false, frame));
/*     */     else {
/* 589 */       result.append(footerCell(ic, rowid, maxRowCount, "Next " + maxRowCount, "left", 6, height, false, true, frame));
/*     */     }
/* 591 */     result.append(footerCell(ic, 0, 0, "&nbsp;&nbsp;&nbsp;", "center", 20, height, false, false, frame));
/*     */ 
/* 593 */     result.append("</tr></table></td></tr>");
/*     */ 
/* 595 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private String footerCell(InvocationContext ic, int startRow, int maxRowCount, String text, String alignment, int width, int height, boolean clickable, boolean disabled, String target)
/*     */     throws Exception
/*     */   {
/* 603 */     StringBuffer result = new StringBuffer();
/* 604 */     StringBuffer href = new StringBuffer();
/* 605 */     StringBuffer td = new StringBuffer();
/* 606 */     StringBuffer events = new StringBuffer();
/* 607 */     String normal = getFooterClass(ic, "normal");
/* 608 */     String pressed = getFooterClass(ic, "pressed");
/* 609 */     String rollover = getFooterClass(ic, "rollover");
/* 610 */     alignment = "center";
/*     */ 
/* 613 */     if (clickable)
/*     */     {
/* 615 */       String name = getString(ic, "name");
/* 616 */       String url = getRequestURL(ic);
/* 617 */       String queryString = getQueryString(ic);
/* 618 */       queryString = setParam(queryString, name + "_start_with", startRow > 1 ? Integer.toString(startRow) : null);
/* 619 */       queryString = setParam(queryString, name + "_max_rows", Integer.toString(maxRowCount));
/* 620 */       if ((queryString != null) && (queryString.length() > 0)) url = url + "?" + queryString;
/* 621 */       href.append("<a href=\"" + url + "\"");
/* 622 */       if (target != null) href.append(" target=\"" + target + "\"");
/*     */ 
/* 624 */       href.append(">");
/*     */ 
/* 626 */       events.append(" style=\"cursor:hand\"");
/* 627 */       if (normal != null)
/*     */       {
/* 629 */         if (pressed != null)
/*     */         {
/* 631 */           events.append(" onMouseDown=\"this.className='" + pressed + "'; return true\"");
/* 632 */           events.append(normal + "'; return true\"");
/*     */         }
/* 634 */         if (rollover != null)
/*     */         {
/* 636 */           events.append(" onMouseOver=\"this.className='" + rollover + "'; return true\"");
/* 637 */           events.append(" onMouseOut=\"this.className='" + normal + "'; return true\"");
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 643 */     td.append("\t<td nowrap");
/* 644 */     if (height > 0) td.append(" height=\"" + height + "\"");
/* 645 */     if (normal != null) td.append(" class=\"" + normal + "\"");
/* 646 */     if (alignment != null) td.append(" align=\"" + alignment + "\"");
/* 647 */     if (width > 0) td.append(" width=\"" + width + "%\"");
/* 648 */     td.append(events);
/* 649 */     td.append(">\n");
/*     */ 
/* 652 */     if (ic.isInternetExplorer())
/*     */     {
/* 654 */       result.append(href);
/* 655 */       result.append(td);
/*     */     }
/*     */     else
/*     */     {
/* 659 */       result.append(td);
/* 660 */       result.append("&nbsp;");
/* 661 */       result.append(href);
/*     */     }
/*     */ 
/* 665 */     if (disabled) result.append("<span class=\"TableRowTextDisabled\">");
/* 666 */     if ((text == null) || (text.length() == 0) || (text.equals(" "))) text = "&nbsp;";
/* 667 */     result.append(text);
/* 668 */     if (disabled) result.append("</span>");
/*     */ 
/* 671 */     if (ic.isInternetExplorer())
/*     */     {
/* 673 */       result.append("</td>");
/* 674 */       if (href.length() > 0) result.append("</a>");
/*     */     }
/*     */     else
/*     */     {
/* 678 */       if (href.length() > 0) result.append("</a>");
/* 679 */       result.append("</td>");
/*     */     }
/*     */ 
/* 682 */     result.append("\n");
/*     */ 
/* 684 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected String getTitleClass(InvocationContext ic, String type) throws Exception
/*     */   {
/* 689 */     String result = null;
/* 690 */     String normal = null;
/* 691 */     String rollover = null;
/* 692 */     String pressed = null;
/* 693 */     String sorted = null;
/* 694 */     String sortedRollover = null;
/* 695 */     String sortedPressed = null;
/*     */     try
/*     */     {
/* 699 */       String classes = getString(ic, "titleClass");
/* 700 */       Vector tmp = StringUtil.stringToVector(classes, ',');
/* 701 */       normal = (String)tmp.elementAt(0);
/* 702 */       rollover = (String)tmp.elementAt(1);
/* 703 */       pressed = (String)tmp.elementAt(2);
/* 704 */       sorted = (String)tmp.elementAt(3);
/* 705 */       sortedRollover = (String)tmp.elementAt(4);
/* 706 */       sortedPressed = (String)tmp.elementAt(5);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 710 */     if (type.equalsIgnoreCase("normal"))
/* 711 */       result = normal;
/* 712 */     else if (type.equalsIgnoreCase("rollover"))
/* 713 */       result = rollover;
/* 714 */     else if (type.equalsIgnoreCase("pressed"))
/* 715 */       result = pressed;
/* 716 */     else if (type.equalsIgnoreCase("sorted"))
/* 717 */       result = sorted != null ? sorted : getTitleClass(ic, "normal");
/* 718 */     else if (type.equalsIgnoreCase("sortedRollover"))
/* 719 */       result = sortedRollover != null ? sortedRollover : getTitleClass(ic, "rollover");
/* 720 */     else if (type.equalsIgnoreCase("sortedPressed"))
/* 721 */       result = sortedPressed != null ? sortedPressed : getTitleClass(ic, "pressed");
/*     */     else {
/* 723 */       throw new Exception("Unkown class type \"" + type + "\"");
/*     */     }
/* 725 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getFilterClass(InvocationContext ic) throws Exception
/*     */   {
/* 730 */     String result = getString(ic, "filterClass");
/* 731 */     if (result == null) return getTitleClass(ic, "normal");
/* 732 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getTotalClass(InvocationContext ic) throws Exception
/*     */   {
/* 737 */     String result = getString(ic, "totalClass");
/* 738 */     if (result == null) return getTitleClass(ic, "normal");
/* 739 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getFooterClass(InvocationContext ic, String type) throws Exception
/*     */   {
/* 744 */     String result = null;
/* 745 */     String normal = null;
/* 746 */     String rollover = null;
/* 747 */     String pressed = null;
/*     */     try
/*     */     {
/* 751 */       String classes = getString(ic, "footerClass");
/* 752 */       Vector tmp = StringUtil.stringToVector(classes, ',');
/* 753 */       normal = (String)tmp.elementAt(0);
/* 754 */       rollover = (String)tmp.elementAt(1);
/* 755 */       pressed = (String)tmp.elementAt(2);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/* 759 */     if (type.equalsIgnoreCase("normal"))
/* 760 */       result = normal;
/* 761 */     else if (type.equalsIgnoreCase("rollover"))
/* 762 */       result = rollover;
/* 763 */     else if (type.equalsIgnoreCase("pressed"))
/* 764 */       result = pressed;
/*     */     else {
/* 766 */       throw new Exception("Unkown class type \"" + type + "\"");
/*     */     }
/* 768 */     if (result == null) return getTitleClass(ic, type);
/* 769 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getRowClass(InvocationContext ic, int rowid, String rowClassString) throws Exception
/*     */   {
/* 774 */     String result = null;
/*     */ 
/* 777 */     String colorRowClasses = (String)ic.getRequiredTransientDatum("hasColorRowClasses");
/* 778 */     Vector color_row_classes = StringUtil.stringToVector(colorRowClasses);
/* 779 */     if (!colorRowClasses.equalsIgnoreCase("false"))
/*     */     {
/* 781 */       if (color_row_classes.size() > 0)
/* 782 */         result = (String)color_row_classes.elementAt(0);
/*     */       else {
/* 784 */         Diagnostics.error("Did not find first class (Row Class) of colorRowClasses '" + colorRowClasses + "'");
/*     */       }
/*     */     }
/* 787 */     if (result == null)
/*     */     {
/* 789 */       if (rowClassString == null) rowClassString = getString(ic, "rowClass");
/*     */ 
/* 791 */       Vector rowClass = StringUtil.stringToVector(rowClassString, ',');
/* 792 */       if ((rowClass != null) && (rowClass.size() > 0))
/* 793 */         result = (String)rowClass.elementAt((rowid - 1) % rowClass.size());
/*     */       else
/* 795 */         Diagnostics.error("Invalid rowClass in SmartTableComponent.getRowClass().");
/*     */     }
/* 797 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getRowRolloverClass(InvocationContext ic, int rowid, String rowClassString) throws Exception
/*     */   {
/* 802 */     String result = null;
/*     */ 
/* 805 */     String colorRowClasses = (String)ic.getRequiredTransientDatum("hasColorRowClasses");
/* 806 */     Vector color_row_classes = StringUtil.stringToVector(colorRowClasses);
/* 807 */     if (!colorRowClasses.equalsIgnoreCase("false"))
/*     */     {
/* 809 */       if (color_row_classes.size() > 2)
/* 810 */         result = (String)color_row_classes.elementAt(2);
/*     */       else {
/* 812 */         Diagnostics.trace("Did not find third class (Rollover Class) in colorRowClasses in string '" + colorRowClasses + "', using default rowRolloverClass.");
/*     */       }
/*     */     }
/* 815 */     if (result == null)
/*     */     {
/* 817 */       if (rowClassString == null) result = getString(ic, "rowRolloverClass");
/*     */ 
/* 819 */       if (!StringUtil.hasAValue(result)) {
/* 820 */         result = getRowClass(ic, rowid, rowClassString);
/*     */       }
/*     */     }
/* 823 */     return result;
/*     */   }
/*     */ 
/*     */   protected String getCellLinkClass(InvocationContext ic, int rowid, String cellClassString)
/*     */     throws Exception
/*     */   {
/* 831 */     String result = null;
/*     */ 
/* 834 */     String colorRowClasses = (String)ic.getRequiredTransientDatum("hasColorRowClasses");
/* 835 */     Vector color_row_classes = StringUtil.stringToVector(colorRowClasses);
/* 836 */     if (!colorRowClasses.equalsIgnoreCase("false"))
/*     */     {
/* 838 */       if (color_row_classes.size() > 1)
/* 839 */         result = (String)color_row_classes.elementAt(1);
/*     */       else {
/* 841 */         Diagnostics.trace("Did not find 2nd class (Link Class) in colorRowClasses in string '" + colorRowClasses + "', using default cellLinkClass.");
/*     */       }
/*     */     }
/* 844 */     if (!StringUtil.hasAValue(result))
/*     */     {
/* 846 */       if (cellClassString == null) {
/* 847 */         cellClassString = getString(ic, "cellLinkClasses");
/*     */       }
/* 849 */       if ((cellClassString != null) && (cellClassString.length() > 0))
/*     */       {
/* 851 */         Vector cellLinkClasses = StringUtil.stringToVector(cellClassString, ',');
/* 852 */         if ((cellLinkClasses != null) && (cellLinkClasses.size() > 0))
/* 853 */           result = (String)cellLinkClasses.elementAt((rowid - 1) % cellLinkClasses.size());
/*     */         else {
/* 855 */           Diagnostics.error("Invalid cellLinkClass String '" + cellLinkClasses + "' in SmartTableComponent.getCellLinkClass().");
/*     */         }
/*     */       }
/*     */     }
/* 859 */     return result;
/*     */   }
/*     */ 
/*     */   public static String setParam(String queryString, String param, String value)
/*     */   {
/* 867 */     String result = "";
/* 868 */     if (queryString == null)
/*     */     {
/* 871 */       if (value != null)
/*     */       {
/* 873 */         result = param + "=" + StringUtil.toURL(value);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 879 */       int idx1 = 0;
/* 880 */       if (!queryString.startsWith(param + "="))
/*     */       {
/* 882 */         idx1 = queryString.indexOf("&" + param + "=");
/*     */       }
/*     */ 
/* 885 */       if (idx1 == -1)
/*     */       {
/* 887 */         result = queryString;
/*     */       }
/*     */       else
/*     */       {
/* 891 */         result = queryString.substring(0, idx1);
/*     */       }
/*     */ 
/* 894 */       if (value != null)
/*     */       {
/* 896 */         if (idx1 != 0)
/*     */         {
/* 898 */           result = result + "&";
/*     */         }
/* 900 */         result = result + param + "=" + StringUtil.toURL(value);
/*     */       }
/* 902 */       int idx2 = -1;
/* 903 */       if (idx1 != -1)
/*     */       {
/* 905 */         idx2 = queryString.indexOf("&", idx1 + 1);
/*     */       }
/* 907 */       if (idx2 != -1)
/*     */       {
/* 909 */         result = result + queryString.substring(idx2);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 914 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getRequestURL(InvocationContext ic)
/*     */   {
/* 919 */     String result = ic.getSessionDatum("action") + ic.getHTMLTemplateName();
/*     */ 
/* 921 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getQueryString(InvocationContext ic)
/*     */   {
/* 926 */     String result = ic.getHttpServletRequest().getQueryString();
/*     */ 
/* 928 */     Enumeration keys = ic.getParameterKeys();
/* 929 */     while (keys.hasMoreElements())
/*     */     {
/* 931 */       String key = (String)keys.nextElement();
/* 932 */       result = setParam(result, key, ic.getParameter(key));
/*     */     }
/*     */ 
/* 936 */     return result;
/*     */   }
/*     */ 
/*     */   protected String table(InvocationContext ic, String name)
/*     */     throws Exception
/*     */   {
/* 944 */     StringBuffer result = new StringBuffer();
/* 945 */     result.append("<table");
/* 946 */     if (name != null)
/*     */     {
/* 948 */       result.append(" name=\"" + name + "\"");
/* 949 */       result.append(" id=\"" + name + "\"");
/*     */     }
/* 951 */     result.append(getExtendedAttributesString(ic));
/* 952 */     result.append(" border=\"0\"");
/* 953 */     result.append(" cellpadding=\"0\"");
/* 954 */     result.append(" cellspacing=\"0\"");
/* 955 */     result.append(">\n");
/* 956 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SmartTableComponent
 * JD-Core Version:    0.6.2
 */