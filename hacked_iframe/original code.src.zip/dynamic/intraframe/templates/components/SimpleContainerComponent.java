/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ 
/*    */ public class SimpleContainerComponent extends TemplateComponent
/*    */ {
/*    */   public SimpleContainerComponent()
/*    */   {
/* 15 */     requiresEndTag();
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic) throws Exception
/*    */   {
/* 20 */     return includeChildren(ic);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SimpleContainerComponent
 * JD-Core Version:    0.6.2
 */