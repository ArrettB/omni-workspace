/*     */ package dynamic.intraframe.templates.components;
/*     */ 
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.templates.TemplateComponent;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.util.Enumeration;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class ElseIfComponent extends TemplateComponent
/*     */ {
/*     */   public ElseIfComponent()
/*     */     throws Exception
/*     */   {
/*  23 */     registerAttribute("evaluate", null);
/*  24 */     registerAttribute("compare", null);
/*  25 */     registerAttribute("greaterthan", null);
/*  26 */     registerAttribute("lessthan", null);
/*  27 */     registerAttribute("defined", null);
/*  28 */     registerAttribute("undefined", null);
/*     */   }
/*     */ 
/*     */   public static boolean isDefined(String value)
/*     */   {
/*  33 */     return (value != null) && (value.length() > 0) && (!value.equalsIgnoreCase("null")) && (!value.equalsIgnoreCase("false"));
/*     */   }
/*     */ 
/*     */   public boolean eval(InvocationContext ic) throws Exception
/*     */   {
/*  38 */     boolean result = false;
/*     */ 
/*  40 */     if (getAttribute(ic, "evaluate") != null)
/*     */     {
/*  43 */       String evaluate = getString(ic, "evaluate");
/*     */ 
/*  45 */       if (getAttribute(ic, "compare") != null)
/*     */       {
/*  47 */         String compare = getString(ic, "compare");
/*  48 */         Enumeration enums = getTokens(compare);
/*     */ 
/*  50 */         while (enums.hasMoreElements())
/*     */         {
/*  52 */           result = evaluate.equalsIgnoreCase((String)enums.nextElement());
/*  53 */           if (result)
/*     */             break;
/*     */         }
/*     */       }
/*  57 */       else if ((getAttribute(ic, "greaterthan") != null) || (getAttribute(ic, "lessthan") != null))
/*     */       {
/*  59 */         Enumeration greaterthan_enum = null;
/*  60 */         Enumeration lessthan_enum = null;
/*  61 */         if (getAttribute(ic, "greaterthan") != null)
/*  62 */           greaterthan_enum = getTokens(getString(ic, "greaterthan"));
/*  63 */         if (getAttribute(ic, "lessthan") != null)
/*  64 */           lessthan_enum = getTokens(getString(ic, "lessthan"));
/*     */         try
/*     */         {
/*  67 */           double x = new Double(evaluate).doubleValue();
/*  68 */           String token = null;
/*     */ 
/*  70 */           boolean result_gt = false;
/*  71 */           double gt = 0.0D;
/*  72 */           while ((greaterthan_enum != null) && (greaterthan_enum.hasMoreElements()))
/*     */           {
/*  74 */             gt = new Double((String)greaterthan_enum.nextElement()).doubleValue();
/*  75 */             result_gt = x > gt;
/*  76 */             if (result_gt)
/*     */             {
/*     */               break;
/*     */             }
/*     */           }
/*  81 */           boolean result_lt = false;
/*  82 */           double lt = 0.0D;
/*  83 */           while ((lessthan_enum != null) && (lessthan_enum.hasMoreElements()))
/*     */           {
/*  85 */             lt = new Double((String)lessthan_enum.nextElement()).doubleValue();
/*  86 */             result_lt = x < lt;
/*  87 */             if (result_lt) {
/*     */               break;
/*     */             }
/*     */           }
/*  91 */           if ((getAttribute(ic, "greaterthan") != null) && (getAttribute(ic, "lessthan") != null))
/*  92 */             result = (result_gt) && (result_lt);
/*  93 */           else if (getAttribute(ic, "greaterthan") != null)
/*  94 */             result = result_gt;
/*  95 */           else if (getAttribute(ic, "lessthan") != null)
/*  96 */             result = result_lt;
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 100 */           result = false;
/* 101 */           Diagnostics.error("ElseIfComponent.eval() greater/less than function failed, either:\n'evalute' attribute '" + evaluate + "' or \n'greaterthan' attribute '" + getAttribute(ic, "greaterthan") + "' or\n'lessthan' attribute '" + getAttribute(ic, "lessthan") + "' is not a number.\n" + e.toString());
/*     */         }
/*     */       }
/*     */     }
/* 105 */     else if (getAttribute(ic, "defined") != null)
/*     */     {
/*     */       try
/*     */       {
/* 109 */         String defined = getString(ic, "defined");
/* 110 */         Enumeration enums = getTokens(defined);
/* 111 */         while (enums.hasMoreElements())
/*     */         {
/* 113 */           result = isDefined((String)enums.nextElement());
/* 114 */           if (result)
/*     */             break;
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 120 */         result = false;
/*     */       }
/*     */     }
/* 123 */     else if (getAttribute(ic, "undefined") != null)
/*     */     {
/*     */       try
/*     */       {
/* 127 */         String undefined = getString(ic, "undefined");
/* 128 */         Enumeration enums = getTokens(undefined);
/* 129 */         while (enums.hasMoreElements())
/*     */         {
/* 131 */           result = !isDefined((String)enums.nextElement());
/* 132 */           if (result)
/*     */             break;
/*     */         }
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/* 138 */         result = true;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 143 */       throw new Exception("Invalid IF statement " + this);
/*     */     }
/*     */ 
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */   private Enumeration getTokens(String aString)
/*     */   {
/* 151 */     String delimited = StringUtil.replaceString(aString, " or ", "~");
/* 152 */     StringTokenizer tokens = new StringTokenizer(delimited, "~");
/* 153 */     Vector trimmed_tokens = new Vector();
/*     */ 
/* 155 */     while (tokens.hasMoreTokens())
/*     */     {
/* 157 */       String cur_token = tokens.nextToken();
/* 158 */       if (StringUtil.hasAValue(cur_token))
/* 159 */         cur_token = cur_token.trim();
/* 160 */       trimmed_tokens.add(cur_token);
/*     */     }
/* 162 */     if (trimmed_tokens.size() == 0)
/*     */     {
/* 164 */       if (aString == null)
/* 165 */         trimmed_tokens.add("");
/*     */       else
/* 167 */         trimmed_tokens.add(aString);
/*     */     }
/* 169 */     return trimmed_tokens.elements();
/*     */   }
/*     */ 
/*     */   public String includeInternal(InvocationContext ic) throws Exception
/*     */   {
/* 174 */     return includeChildren(ic);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.ElseIfComponent
 * JD-Core Version:    0.6.2
 */