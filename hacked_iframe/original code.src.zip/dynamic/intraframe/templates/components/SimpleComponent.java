/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ import dynamic.intraframe.templates.TemplateManager;
/*    */ 
/*    */ public class SimpleComponent extends TemplateComponent
/*    */ {
/*    */   private String contents;
/*    */ 
/*    */   public SimpleComponent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SimpleComponent(TemplateManager manager, TemplateComponent parent, String contents)
/*    */     throws Exception
/*    */   {
/* 21 */     this.contents = contents;
/* 22 */     initialize("SIMPLE");
/* 23 */     initialize(manager, parent, contents, null);
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic)
/*    */   {
/* 28 */     if (this.contents == null) return "";
/* 29 */     return this.contents;
/*    */   }
/*    */ 
/*    */   protected void parseAttributes()
/*    */   {
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.SimpleComponent
 * JD-Core Version:    0.6.2
 */