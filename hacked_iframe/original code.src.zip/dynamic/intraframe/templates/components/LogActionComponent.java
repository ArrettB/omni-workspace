/*    */ package dynamic.intraframe.templates.components;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.intraframe.logmanager.LoggingMulticaster;
/*    */ import dynamic.intraframe.templates.TemplateComponent;
/*    */ 
/*    */ public class LogActionComponent extends TemplateComponent
/*    */ {
/*    */   public LogActionComponent()
/*    */   {
/* 15 */     registerRequiredAttribute("actionType");
/* 16 */     registerRequiredAttribute("extendedData");
/* 17 */     registerRequiredAttribute("logName");
/*    */   }
/*    */ 
/*    */   public String includeInternal(InvocationContext ic) throws Exception
/*    */   {
/* 22 */     String actionType = getString(ic, "actionType");
/* 23 */     String extendedData = getString(ic, "extendedData");
/* 24 */     String logName = getString(ic, "logName");
/* 25 */     new LoggingMulticaster(ic, actionType, extendedData, logName);
/* 26 */     return "<!--" + getName() + " actionType=\"" + actionType + "\" extendedData=\"" + extendedData + "\" logName=\"" + logName + "\" -->";
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.components.LogActionComponent
 * JD-Core Version:    0.6.2
 */