/*     */ package dynamic.intraframe.templates;
/*     */ 
/*     */ import dynamic.intraframe.engine.BaseInvocationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class TemplateAttribute
/*     */ {
/*     */   private static final String START_TAG = "<?";
/*     */   private static final String END_TAG = "?>";
/*  30 */   private Vector components = new Vector();
/*  31 */   private String name = null;
/*  32 */   private String content = null;
/*     */ 
/*     */   public TemplateAttribute(String name, String content)
/*     */     throws Exception
/*     */   {
/*  39 */     this.name = name;
/*  40 */     this.content = content;
/*  41 */     parse(content);
/*     */   }
/*     */ 
/*     */   private int plainText(String plainText) throws Exception
/*     */   {
/*  46 */     int l = plainText.length();
/*  47 */     if (l > 0)
/*     */     {
/*  49 */       TemplateAttributePiece a = new TemplateAttributePiece(plainText);
/*  50 */       this.components.addElement(a);
/*     */     }
/*  52 */     return l;
/*     */   }
/*     */ 
/*     */   void parse(String content) throws Exception
/*     */   {
/*  57 */     this.components.removeAllElements();
/*  58 */     if ((content == null) || (content.length() == 0)) return;
/*     */ 
/*  60 */     int lastPos = 0;
/*     */ 
/*  62 */     while (lastPos < content.length())
/*     */     {
/*  65 */       int startTagPos = content.indexOf("<?", lastPos);
/*  66 */       if (startTagPos == -1)
/*     */       {
/*  68 */         lastPos += plainText(content.substring(lastPos));
/*     */       }
/*     */       else
/*     */       {
/*  73 */         lastPos += plainText(content.substring(lastPos, startTagPos));
/*     */ 
/*  76 */         int endTagPos = content.indexOf("?>", startTagPos);
/*  77 */         if (endTagPos == -1)
/*     */         {
/*  79 */           lastPos += plainText("<?");
/*     */         }
/*     */         else
/*     */         {
/*  84 */           int nextStartTagPos = content.indexOf("<?", startTagPos + "<?".length());
/*  85 */           if ((nextStartTagPos != -1) && (nextStartTagPos < endTagPos))
/*     */           {
/*  87 */             lastPos += plainText(content.substring(startTagPos, nextStartTagPos));
/*     */           }
/*     */           else
/*     */           {
/*  92 */             String theTag = content.substring(startTagPos + "<?".length(), endTagPos);
/*  93 */             int tagIndicatorEnd = theTag.indexOf(":");
/*  94 */             if (tagIndicatorEnd == -1)
/*     */             {
/*  96 */               lastPos += plainText("<?");
/*     */             }
/*     */             else
/*     */             {
/* 101 */               String tagIndicator = theTag.substring(0, tagIndicatorEnd);
/* 102 */               if (!TemplateAttributePiece.isValidType(tagIndicator))
/*     */               {
/* 104 */                 lastPos += plainText(content.substring(startTagPos, endTagPos + "?>".length()));
/*     */               }
/*     */               else
/*     */               {
/* 109 */                 TemplateAttributePiece a = new TemplateAttributePiece(tagIndicator, theTag.substring(tagIndicatorEnd + 1));
/* 110 */                 this.components.addElement(a);
/* 111 */                 lastPos = endTagPos + "?>".length();
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/* 120 */   public String evaluate(InvocationContext ic) throws Exception { boolean expand_again = false;
/* 121 */     String result = new String();
/* 122 */     for (int i = 0; i < this.components.size(); i++)
/*     */     {
/* 124 */       TemplateAttributePiece a = (TemplateAttributePiece)this.components.elementAt(i);
/* 125 */       if (!a.isSimple()) expand_again = true;
/* 126 */       result = result + a.evaluate(ic);
/*     */     }
/*     */ 
/* 129 */     if (expand_again) {
/* 130 */       result = new TemplateAttribute(this.name, result).evaluate(ic);
/*     */     }
/* 132 */     return result;
/*     */   }
/*     */ 
/*     */   public Object evaluateObject(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 140 */     if ((this.components == null) || (this.components.size() != 1))
/* 141 */       throw new Exception("Cannot evaluate \"" + this.content + "\" to a single object");
/* 142 */     return ((TemplateAttributePiece)this.components.elementAt(0)).evaluate(ic);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 150 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 158 */     return this.content;
/*     */   }
/*     */ 
/*     */   private static void testAndEcho(InvocationContext ic, String s)
/*     */   {
/*     */     try
/*     */     {
/* 168 */       TemplateAttribute foo = new TemplateAttribute("test", s);
/* 169 */       Diagnostics.debug(foo.evaluate(ic));
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 173 */       Diagnostics.error("Problems testing TemplateAttribute", t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 182 */     InvocationContext ic = new BaseInvocationContext();
/* 183 */     ic.setTransientDatum("object", new TestObject());
/* 184 */     ic.setTransientDatum("foo", "<TestString:foo>");
/* 185 */     ic.setTransientDatum("bar", "<TestString:bar>");
/*     */ 
/* 187 */     testAndEcho(ic, "bar");
/* 188 */     testAndEcho(ic, "<?d:foo?>");
/* 189 */     testAndEcho(ic, "<?d:foo?><?d:bar?>");
/* 190 */     testAndEcho(ic, "foo<?d:foo?><?d:bar?>bar");
/* 191 */     testAndEcho(ic, "foo<?d:foo?>fubar<?d:bar?>bar");
/* 192 */     testAndEcho(ic, "foo<?d:foo?><<?d:bar?>bar");
/* 193 */     testAndEcho(ic, "foo<?d:foo?><?d:bar?>bar");
/*     */ 
/* 195 */     testAndEcho(ic, "<?d:object.field1?>");
/* 196 */     testAndEcho(ic, "<?d:object.field2?>");
/* 197 */     testAndEcho(ic, "<?d:object.field3?>");
/* 198 */     testAndEcho(ic, "<?d:object.method1()?>");
/* 199 */     testAndEcho(ic, "<?d:object.method2(765)?>");
/* 200 */     testAndEcho(ic, "<?d:object.method3('foobar')?>");
/* 201 */     testAndEcho(ic, "<?d:object.method4('foobar',872)?>");
/* 202 */     testAndEcho(ic, "<?d:object.method5(true)?>");
/* 203 */     testAndEcho(ic, "<?d:object.method5(false)?>");
/* 204 */     testAndEcho(ic, "<?d:object.method4('foobar',872).toSqlString()?>");
/* 205 */     testAndEcho(ic, "<?d:object.method4('foobar',872).toJavaScriptString()?>");
/* 206 */     testAndEcho(ic, "<?d:object.method4('foobar',872).toHTMLString()?>");
/* 207 */     testAndEcho(ic, "<?d:object.method4('foobar',872).replaceString('method','MeThOd')?>");
/* 208 */     testAndEcho(ic, "<?d:object.method4('foobar',872).thisMethodDoesNotExist()?>");
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.templates.TemplateAttribute
 * JD-Core Version:    0.6.2
 */