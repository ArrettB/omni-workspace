/*    */ package dynamic.intraframe.handlers;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ 
/*    */ public class ChooserHandler extends BaseHandler
/*    */ {
/*    */   public void setUpHandler()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean handleEnvironment(InvocationContext ic)
/*    */   {
/* 21 */     String frame = ic.getParameter("frame");
/* 22 */     if (frame.equalsIgnoreCase("top"))
/*    */     {
/* 24 */       ic.setTransientDatum("__chooser_top", ic.getSessionDatum("__chooser_top"));
/* 25 */       Diagnostics.trace("ChooserHandler.handleEnvironment() clearing __chooser_top");
/* 26 */       ic.removeSessionDatum("__chooser_top");
/*    */     }
/* 28 */     else if (frame.equalsIgnoreCase("middle"))
/*    */     {
/* 30 */       ic.setTransientDatum("__chooser_middle", ic.getSessionDatum("__chooser_middle"));
/* 31 */       Diagnostics.trace("ChooserHandler.handleEnvironment() clearing __chooser_middle");
/* 32 */       ic.removeSessionDatum("__chooser_middle");
/*    */     }
/* 34 */     else if (frame.equalsIgnoreCase("bottom"))
/*    */     {
/* 36 */       ic.setTransientDatum("__chooser_bottom", ic.getSessionDatum("__chooser_bottom"));
/* 37 */       Diagnostics.trace("ChooserHandler.handleEnvironment() clearing __chooser_bottom");
/* 38 */       ic.removeSessionDatum("__chooser_bottom");
/*    */     }
/* 40 */     return true;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.ChooserHandler
 * JD-Core Version:    0.6.2
 */