/*    */ package dynamic.intraframe.handlers;
/*    */ 
/*    */ import dynamic.dbtk.connection.ConnectionWrapper;
/*    */ import dynamic.intraframe.engine.ApplicationContext;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import java.io.OutputStream;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ public class TestHandler extends BaseHandler
/*    */ {
/*    */   public void setUpHandler()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean handleEnvironment(InvocationContext ic)
/*    */   {
/* 21 */     boolean result = false;
/* 22 */     ConnectionWrapper conn = null;
/*    */     try
/*    */     {
/* 26 */       Diagnostics.debug("TestHandler.handleEnvironment()");
/* 27 */       conn = (ConnectionWrapper)ic.getResource();
/* 28 */       String query = "SELECT count(*) from dual";
/* 29 */       Diagnostics.debug2("SQL: " + query);
/* 30 */       String s = conn.queryEx(query);
/* 31 */       String message = query + " succeeded!";
/* 32 */       ic.getHttpServletResponse().getOutputStream().write(message.getBytes());
/* 33 */       result = true;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 37 */       result = false;
/* 38 */       ErrorHandler.handleException(ic, e, "Problem in TestHandler");
/*    */     }
/*    */     finally
/*    */     {
/* 42 */       if (conn != null) conn.release();
/*    */     }
/*    */ 
/* 45 */     return result;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.TestHandler
 * JD-Core Version:    0.6.2
 */