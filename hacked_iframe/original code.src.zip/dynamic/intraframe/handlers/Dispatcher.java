/*     */ package dynamic.intraframe.handlers;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.Configuration;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class Dispatcher
/*     */ {
/*  30 */   private Configuration config = null;
/*  31 */   private Hashtable handlers = new Hashtable();
/*  32 */   private Hashtable plans = new Hashtable();
/*  33 */   private String defaultAction = null;
/*     */ 
/*     */   public void initialize(ApplicationContext ac) throws Exception
/*     */   {
/*  37 */     this.handlers.clear();
/*  38 */     this.plans.clear();
/*  39 */     this.config = ac.getConfig();
/*  40 */     Document xmlDoc = this.config.getConfigDocument();
/*  41 */     Element dispatcherElement = XMLUtils.getSingleElement(xmlDoc, "dispatcher");
/*  42 */     String a = null;
/*  43 */     if (dispatcherElement != null) a = dispatcherElement.getAttribute("default");
/*  44 */     if ((a != null) && (a.length() > 0))
/*     */     {
/*  46 */       Diagnostics.debug("default action is \"" + a + "\"");
/*  47 */       if (a.equals("showPage")) Diagnostics.warning("dispatcher default action of showPage is deprecated (ignored)"); else {
/*  48 */         this.defaultAction = a;
/*     */       }
/*     */     }
/*  51 */     NodeList actionList = dispatcherElement.getElementsByTagName("action");
/*  52 */     for (int i = 0; i < actionList.getLength(); i++)
/*     */     {
/*  54 */       Element actionElement = (Element)actionList.item(i);
/*  55 */       String actionName = actionElement.getAttribute("name");
/*     */ 
/*  57 */       NodeList handlerList = actionElement.getElementsByTagName("handler");
/*  58 */       for (int j = 0; j < handlerList.getLength(); j++)
/*     */       {
/*  60 */         Element handlerElement = (Element)handlerList.item(j);
/*  61 */         String className = handlerElement.getAttribute("class");
/*  62 */         if ((className != null) && (actionName != null))
/*     */         {
/*  64 */           addActionHandler(ac, actionName, className);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  72 */     if (this.plans != null) this.plans.clear();
/*  73 */     this.plans = null;
/*     */ 
/*  75 */     if (this.handlers != null)
/*     */     {
/*  77 */       Enumeration e = this.handlers.elements();
/*  78 */       while (e.hasMoreElements())
/*     */       {
/*  80 */         BaseHandler h = (BaseHandler)e.nextElement();
/*     */         try
/*     */         {
/*  83 */           h.destroy();
/*     */         }
/*     */         catch (Throwable t)
/*     */         {
/*  87 */           Diagnostics.error("Problem trying to destroy " + h, t);
/*     */         }
/*     */       }
/*  90 */       this.handlers.clear();
/*  91 */       this.handlers = null;
/*     */     }
/*     */ 
/*  94 */     this.config = null;
/*     */   }
/*     */ 
/*     */   public boolean isValidAction(String actionName)
/*     */   {
/* 102 */     return this.plans.containsKey(actionName);
/*     */   }
/*     */ 
/*     */   public String getDefaultAction()
/*     */   {
/* 110 */     return this.defaultAction;
/*     */   }
/*     */ 
/*     */   public boolean dispatchAction(InvocationContext ic, String action)
/*     */     throws Exception
/*     */   {
/* 118 */     Vector thePlan = (Vector)this.plans.get(action);
/* 119 */     if (thePlan == null) {
/* 120 */       throw new Exception("Unknown action \"" + action + "\"");
/*     */     }
/* 122 */     String saveAction = ic.getAction();
/* 123 */     ic.setAction(action);
/* 124 */     boolean cont = true;
/* 125 */     for (int i = 0; i < thePlan.size(); i++)
/*     */     {
/* 127 */       BaseHandler handler = (BaseHandler)thePlan.elementAt(i);
/* 128 */       cont = ((BaseHandler)thePlan.elementAt(i)).handle(ic);
/* 129 */       if (!cont)
/*     */       {
/* 131 */         Diagnostics.trace("Dispatcher.dispatchAction(): aborted after handler " + thePlan.elementAt(i).getClass().getName());
/* 132 */         break;
/*     */       }
/*     */     }
/* 135 */     ic.setAction(saveAction);
/* 136 */     return cont;
/*     */   }
/*     */ 
/*     */   public boolean dispatchHandler(InvocationContext ic, String handlerName)
/*     */     throws Exception
/*     */   {
/* 144 */     return getHandler(ic, handlerName).handle(ic);
/*     */   }
/*     */ 
/*     */   public String toHTML()
/*     */   {
/* 149 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 151 */     result.append("<table width=\"100%\">\n");
/* 152 */     result.append("<tr>\n");
/* 153 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Action</b></td>\n");
/* 154 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Handler</b></td>\n");
/* 155 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Loaded</b></td>\n");
/* 156 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Req</b></td>\n");
/* 157 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Last</b></td>\n");
/* 158 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Min</b></td>\n");
/* 159 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Avg</b></td>\n");
/* 160 */     result.append("<td align=\"right\" bgcolor=\"#888888\"><font size=\"2\"><b>Max</b></td>\n");
/* 161 */     result.append("</tr>\n");
/*     */ 
/* 163 */     Enumeration keys = Sort.keys(this.plans);
/* 164 */     while (keys.hasMoreElements())
/*     */     {
/* 166 */       result.append("<tr>\n");
/* 167 */       String key = (String)keys.nextElement();
/* 168 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</td>\n");
/* 169 */       Vector v = (Vector)this.plans.get(key);
/* 170 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 171 */       for (int i = 0; i < v.size(); i++)
/* 172 */         result.append(((BaseHandler)v.elementAt(i)).getName() + "<br>");
/* 173 */       result.append("</td>\n");
/* 174 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 175 */       for (int i = 0; i < v.size(); i++)
/* 176 */         result.append(new StdDate(((BaseHandler)v.elementAt(i)).getLoadedTime()) + "<br>");
/* 177 */       result.append("</td>\n");
/* 178 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 179 */       for (int i = 0; i < v.size(); i++)
/* 180 */         result.append(((BaseHandler)v.elementAt(i)).getRequestCount() + "<br>");
/* 181 */       result.append("</td>\n");
/* 182 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 183 */       for (int i = 0; i < v.size(); i++)
/* 184 */         result.append(((BaseHandler)v.elementAt(i)).getLastTime() + "<br>");
/* 185 */       result.append("</td>\n");
/* 186 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 187 */       for (int i = 0; i < v.size(); i++)
/* 188 */         result.append(((BaseHandler)v.elementAt(i)).getMinTime() + "<br>");
/* 189 */       result.append("</td>\n");
/* 190 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 191 */       for (int i = 0; i < v.size(); i++)
/* 192 */         result.append(((BaseHandler)v.elementAt(i)).getAverageTime() + "<br>");
/* 193 */       result.append("</td>\n");
/* 194 */       result.append("<td align=\"right\" bgcolor=\"#DCDCDC\"><font size=\"1\">");
/* 195 */       for (int i = 0; i < v.size(); i++)
/* 196 */         result.append(((BaseHandler)v.elementAt(i)).getMaxTime() + "<br>");
/* 197 */       result.append("</td>\n");
/* 198 */       result.append("</tr>\n");
/*     */     }
/*     */ 
/* 201 */     result.append("</table>");
/* 202 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public void addActionHandler(ApplicationContext ac, String actionName, String handlerName) throws Exception
/*     */   {
/* 207 */     BaseHandler handlerRef = getHandler(ac, handlerName);
/* 208 */     Vector thePlan = (Vector)this.plans.get(actionName);
/* 209 */     if (thePlan == null)
/*     */     {
/* 211 */       thePlan = new Vector();
/* 212 */       thePlan.addElement(handlerRef);
/* 213 */       this.plans.put(actionName, thePlan);
/*     */     }
/*     */     else
/*     */     {
/* 217 */       thePlan.addElement(handlerRef);
/*     */     }
/*     */   }
/*     */ 
/*     */   private BaseHandler getHandler(ApplicationContext ac, String handlerName) throws Exception
/*     */   {
/* 223 */     BaseHandler handler = (BaseHandler)this.handlers.get(handlerName);
/* 224 */     if (handler == null)
/*     */     {
/* 226 */       Diagnostics.trace("Loading handler " + handlerName);
/* 227 */       Class handlerClass = ac.loadClass(handlerName);
/* 228 */       handler = (BaseHandler)handlerClass.newInstance();
/* 229 */       handler.initialize(this.config);
/* 230 */       this.handlers.put(handlerName, handler);
/*     */     }
/* 232 */     return handler;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.Dispatcher
 * JD-Core Version:    0.6.2
 */