/*    */ package dynamic.intraframe.handlers;
/*    */ 
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import dynamic.util.diagnostics.DiagnosticsMessage;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class ErrorHandler
/*    */ {
/*    */   private static DiagnosticsMessage write(InvocationContext ic, String title, String text, Throwable ex)
/*    */   {
/* 24 */     DiagnosticsMessage m = null;
/*    */     try
/*    */     {
/* 27 */       m = new DiagnosticsMessage(1, title + (text != null ? ": " + text : ""), ex, null);
/* 28 */       Diagnostics.write(m);
/* 29 */       ic.setHTMLTemplateName("error");
/* 30 */       if (title != null)
/* 31 */         ic.setTransientDatum("errTitle", title);
/* 32 */       if (ex != null)
/* 33 */         ic.setTransientDatum("errMessage", m.toHTML());
/* 34 */       else if (text != null)
/* 35 */         ic.setTransientDatum("errMessage", text);
/*    */     }
/*    */     catch (Throwable e)
/*    */     {
/* 39 */       System.err.println("ErrorHandler.write() failed");
/* 40 */       e.printStackTrace();
/*    */     }
/*    */ 
/* 43 */     return m;
/*    */   }
/*    */ 
/*    */   public static DiagnosticsMessage handleError(InvocationContext ic, String title, String text)
/*    */   {
/* 48 */     return write(ic, title, text, null);
/*    */   }
/*    */ 
/*    */   public static DiagnosticsMessage handleException(InvocationContext ic, Throwable ex, String title)
/*    */   {
/* 53 */     return write(ic, title, null, ex);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.ErrorHandler
 * JD-Core Version:    0.6.2
 */