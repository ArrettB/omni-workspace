/*    */ package dynamic.intraframe.handlers;
/*    */ 
/*    */ import com.oreilly.servlet.MultipartRequest;
/*    */ import dynamic.intraframe.engine.ApplicationContext;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class FileUploadHandler extends BaseHandler
/*    */ {
/*    */   public void setUpHandler()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public boolean handleEnvironment(InvocationContext ic)
/*    */   {
/* 33 */     Diagnostics.trace("FileUploadHandler.handleEnvironment()");
/* 34 */     int maxFileSize = 0;
/* 35 */     boolean result = false;
/*    */     try
/*    */     {
/* 38 */       maxFileSize = Integer.parseInt((String)ic.getRequiredAppGlobalDatum("maxFileSize"));
/* 39 */       String directory = (String)ic.getRequiredAppGlobalDatum("uploadDirectory");
/* 40 */       File theDirectory = new File(directory);
/* 41 */       if (!theDirectory.exists())
/*    */       {
/* 43 */         theDirectory.mkdir();
/*    */       }
/*    */ 
/* 46 */       Diagnostics.debug2("Upload directory: " + directory);
/* 47 */       HttpServletRequest req = ic.getHttpServletRequest();
/*    */ 
/* 49 */       String filename = null;
/* 50 */       String type = null;
/*    */ 
/* 54 */       MultipartRequest multi = new MultipartRequest(req, directory, 40000000);
/*    */ 
/* 56 */       Enumeration files = multi.getFileNames();
/* 57 */       while (files.hasMoreElements())
/*    */       {
/* 59 */         String name = (String)files.nextElement();
/* 60 */         filename = multi.getFilesystemName(name);
/* 61 */         type = multi.getContentType(name);
/* 62 */         ic.setTransientDatum("filename", filename);
/* 63 */         ic.setTransientDatum("type", type);
/* 64 */         Diagnostics.debug2("filename=" + filename + ",type=" + type);
/*    */       }
/*    */ 
/* 67 */       File theTempFile = new File(theDirectory, filename);
/*    */ 
/* 70 */       if (theTempFile.length() > maxFileSize)
/*    */       {
/* 72 */         theTempFile.delete();
/* 73 */         throw new IOException("Maximum File size (" + maxFileSize + ") exceeded on upload");
/*    */       }
/*    */ 
/* 77 */       ic.setTransientDatum("message", "The file " + filename + " has successfully been uploaded to " + directory);
/* 78 */       result = true;
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 82 */       String message = "Max file size (" + maxFileSize + ") exceeded on upload. Please choose a different file.";
/* 83 */       ic.setTransientDatum("message", message);
/* 84 */       Diagnostics.error(message, e);
/* 85 */       ic.setHTMLTemplateName("edit/upload");
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 89 */       result = false;
/* 90 */       ErrorHandler.handleException(ic, e, "A problem occurred while uploading the file");
/*    */     }
/*    */     finally
/*    */     {
/*    */     }
/* 95 */     return result;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.FileUploadHandler
 * JD-Core Version:    0.6.2
 */