/*     */ package dynamic.intraframe.handlers;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.BaseInvocationContext;
/*     */ import dynamic.intraframe.engine.BaseServlet;
/*     */ import dynamic.intraframe.engine.Configuration;
/*     */ import dynamic.intraframe.engine.Daemon;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.intraframe.session.SessionManager;
/*     */ import dynamic.intraframe.templates.TemplateManager;
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.diagnostics.DiagnosticsMessage;
/*     */ import dynamic.util.exec.ExecUtils;
/*     */ import dynamic.util.resources.ResourceManager;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.http.Cookie;
/*     */ 
/*     */ public class AdminHandler extends BaseHandler
/*     */ {
/*     */   public void setUpHandler()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean handleEnvironment(InvocationContext ic_in)
/*     */   {
/*  44 */     BaseInvocationContext ic = (BaseInvocationContext)ic_in;
/*     */     try
/*     */     {
/*  48 */       boolean valid = checkLogin(ic);
/*  49 */       String function = ic.getParameter("function");
/*  50 */       if ((function == null) || (function.equalsIgnoreCase("")))
/*     */       {
/*  52 */         ic.setParameter("function", "stats");
/*  53 */         function = "stats";
/*     */       }
/*     */ 
/*  56 */       if (!valid)
/*     */       {
/*  58 */         String out = loginHTML(ic);
/*  59 */         emitInformation(ic, "Login", out);
/*     */       }
/*  61 */       else if (function.equalsIgnoreCase("stats"))
/*     */       {
/*  63 */         String out = statsToHTML(ic);
/*  64 */         emitInformation(ic, "Statistics", out);
/*     */       }
/*  66 */       else if (function.equalsIgnoreCase("config"))
/*     */       {
/*  68 */         String out = configToHTML(ic);
/*  69 */         emitInformation(ic, "Configuration", out);
/*     */       }
/*  71 */       else if (function.equalsIgnoreCase("appglobal"))
/*     */       {
/*  73 */         String out = appGlobalsToHTML(ic);
/*  74 */         emitInformation(ic, "AppGlobals", out);
/*     */       }
/*  76 */       else if (function.equalsIgnoreCase("properties"))
/*     */       {
/*  78 */         String out = propertiesToHTML();
/*  79 */         emitInformation(ic, "Properties", out);
/*     */       }
/*  81 */       else if (function.equalsIgnoreCase("sessions"))
/*     */       {
/*  83 */         String out = sessionsToHTML(ic);
/*  84 */         emitInformation(ic, "Sessions", out);
/*     */       }
/*  86 */       else if (function.equalsIgnoreCase("resources"))
/*     */       {
/*  88 */         String resource = ic.getParameter("resource");
/*  89 */         String option = ic.getParameter("option");
/*  90 */         String href = ic.getSessionDatum("action") + ic.getConfigValue("admin:action") + "?function=resources";
/*  91 */         if ((option != null) && (option.equals("kill")))
/*     */         {
/*  93 */           ic.getResourceManager().killResource(resource);
/*  94 */           ic.sendRedirect(href);
/*     */         }
/*     */         else
/*     */         {
/*  98 */           String out = ic.getResourceManager().toHTML(href, resource);
/*  99 */           emitInformation(ic, "Resources", out);
/*     */         }
/*     */       }
/* 102 */       else if (function.equalsIgnoreCase("handlers"))
/*     */       {
/* 104 */         String out = ic.getDispatcher().toHTML();
/* 105 */         emitInformation(ic, "Handlers", out);
/*     */       }
/* 107 */       else if (function.equalsIgnoreCase("templates"))
/*     */       {
/* 109 */         String out = ic.getTemplateManager().toHTML();
/* 110 */         emitInformation(ic, "Templates", out);
/*     */       }
/* 112 */       else if (function.equalsIgnoreCase("daemons"))
/*     */       {
/* 114 */         String daemon = ic.getParameter("daemon");
/* 115 */         String href = ic.getSessionDatum("action") + ic.getConfigValue("admin:action") + "?function=daemons";
/* 116 */         String out = daemonsToHTML(ic.getDaemons(), href, daemon);
/* 117 */         emitInformation(ic, "Daemons", out);
/*     */       }
/* 119 */       else if (function.equalsIgnoreCase("netstat"))
/*     */       {
/* 121 */         String out = ExecUtils.exec("netstat -a");
/* 122 */         out = "<pre>\n" + StringUtil.toHTML(out) + "\n</pre>";
/* 123 */         emitInformation(ic, "Netstat", out);
/*     */       }
/* 125 */       else if (function.equalsIgnoreCase("diagnostics"))
/*     */       {
/* 127 */         ic.setTransientDatum("port", "" + Diagnostics.getPort());
/* 128 */         ic.setHTMLTemplateName(ic.getConfigValue("diagnostics:template"));
/*     */       }
/* 130 */       else if (function.equalsIgnoreCase("reload"))
/*     */       {
/* 132 */         ic.getServlet().requestReload();
/* 133 */         ic.sendRedirect(ic.getSessionDatum("action") + ic.getConfigValue("admin:action"));
/*     */       }
/*     */       else
/*     */       {
/* 137 */         ErrorHandler.handleError(ic, "Problems handling admin request", "Unknown function \"" + function + "\"");
/*     */       }
/*     */ 
/* 140 */       return true;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 144 */       ErrorHandler.handleException(ic, e, "Problems handling admin request");
/* 145 */     }return false;
/*     */   }
/*     */ 
/*     */   private void emitInformation(InvocationContext ic, String title, String text)
/*     */     throws Exception
/*     */   {
/* 159 */     ic.setHTMLTemplateName(ic.getConfigValue("admin:template"));
/* 160 */     ic.setTransientDatum("title", title);
/* 161 */     ic.setTransientDatum("message", text);
/*     */   }
/*     */ 
/*     */   private boolean checkLogin(InvocationContext ic) throws Exception
/*     */   {
/* 166 */     boolean result = false;
/* 167 */     Cookie validAdminUser = ic.getCookie("ValidAdminUser");
/* 168 */     String username = ic.getParameter("username");
/* 169 */     String password = ic.getParameter("password");
/*     */ 
/* 171 */     String u = ic.getConfigValue("admin:username");
/* 172 */     String p = ic.getConfigValue("admin:password");
/*     */ 
/* 174 */     if ((validAdminUser != null) && (validAdminUser.getValue().equals(u)))
/*     */     {
/* 176 */       result = true;
/*     */     }
/* 178 */     else if ((username == null) || (password == null))
/*     */     {
/* 180 */       result = false;
/*     */     }
/* 182 */     else if ((username.equals(u)) && (password.equals(p)))
/*     */     {
/* 184 */       Cookie c = new Cookie("ValidAdminUser", u);
/* 185 */       c.setComment("This cookie will identify you as a valid admin user and allow you to bypass the login screen for this session.");
/* 186 */       c.setPath((String)ic.getSessionDatum("action"));
/*     */ 
/* 188 */       ic.setCookie(c);
/* 189 */       result = true;
/*     */     }
/*     */     else
/*     */     {
/* 193 */       ic.setTransientDatum("login_error", "true");
/* 194 */       result = false;
/*     */     }
/*     */ 
/* 197 */     if (result) ic.setTransientDatum("ValidAdminUser", "true");
/*     */ 
/* 199 */     return result;
/*     */   }
/*     */ 
/*     */   private String loginHTML(InvocationContext ic)
/*     */   {
/* 204 */     String href = (String)ic.getSessionDatum("action");
/* 205 */     String function = ic.getParameter("function");
/* 206 */     String username = ic.getParameter("username");
/* 207 */     if (username == null) username = "";
/*     */ 
/* 209 */     StringBuffer result = new StringBuffer();
/* 210 */     result.append("<form method=\"post\">\n");
/* 211 */     if (function != null)
/* 212 */       result.append("<input name=\"function\" type=\"hidden\" value=\"" + function + "\">\n");
/* 213 */     result.append("<table>\n");
/* 214 */     result.append("<tr><td><font size=\"2\"><b>Username</b></font></td></tr>\n");
/* 215 */     result.append("<tr><td><input name=\"username\" value=\"" + username + "\"></td></tr>\n");
/* 216 */     result.append("<tr><td><font size=\"2\"><b>Password</b></font></td></tr>\n");
/* 217 */     result.append("<tr><td><input name=\"password\" type=\"password\"></td></tr>\n");
/* 218 */     result.append("<tr><td align=\"right\"><input type=\"submit\" value=\"Login\"></td></tr>\n");
/* 219 */     if (ic.getTransientDatum("login_error") != null)
/* 220 */       result.append("<tr><td><font size=\"2\" color=\"red\">Invalid login<font></td></tr>\n");
/* 221 */     result.append("</table>\n");
/* 222 */     result.append("</form>\n");
/*     */ 
/* 224 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String statsToHTML(BaseInvocationContext ic)
/*     */   {
/* 229 */     System.gc();
/* 230 */     StringBuffer result = new StringBuffer();
/* 231 */     BaseServlet s = ic.getServlet();
/* 232 */     long requests = s.getRequestCount();
/* 233 */     long createdTime = s.getCreatedTime();
/* 234 */     Date now = new Date();
/* 235 */     long uptime = System.currentTimeMillis() - createdTime;
/* 236 */     long rph = ()(requests * 1000.0D * 60.0D * 60.0D / uptime);
/*     */ 
/* 238 */     result.append("<table width=\"100%\">\n");
/* 239 */     result.append("<tr>\n");
/* 240 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Statistic</b></td>\n");
/* 241 */     result.append("<td colspan=\"2\" bgcolor=\"#888888\"><font size=\"2\"><b>Value</b></td>\n");
/* 242 */     result.append("</tr>\n");
/*     */ 
/* 244 */     result.append("<tr>\n");
/* 245 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Now</font></td>\n");
/* 246 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(now) + "</font></td>\n");
/* 247 */     result.append("</tr>\n");
/*     */ 
/* 249 */     result.append("<tr>\n");
/* 250 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Uptime</font></td>\n");
/* 251 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + StdDate.formatDateInterval(uptime) + "</font></td>\n");
/* 252 */     result.append("</tr>\n");
/*     */ 
/* 254 */     result.append("<tr>\n");
/* 255 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Requests</font></td>\n");
/* 256 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + requests + "</font></td>\n");
/* 257 */     result.append("</tr>\n");
/*     */ 
/* 259 */     result.append("<tr>\n");
/* 260 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Requests per Hour</font></td>\n");
/* 261 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + rph + "</font></td>\n");
/* 262 */     result.append("</tr>\n");
/*     */ 
/* 264 */     result.append("<tr>\n");
/* 265 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Currently Running</font></td>\n");
/* 266 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getConcurrentRequestCount() + "</font></td>\n");
/* 267 */     result.append("</tr>\n");
/*     */ 
/* 269 */     result.append("<tr>\n");
/* 270 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Total Time</font></td>\n");
/* 271 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getTotalTime() + "ms</font></td>\n");
/* 272 */     result.append("</tr>\n");
/*     */ 
/* 274 */     result.append("<tr>\n");
/* 275 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Last Request (Last)</font></td>\n");
/* 276 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getLastTime() + "ms</font></td>\n");
/* 277 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getLastRequestURL() + "</font></td>\n");
/* 278 */     result.append("</tr>\n");
/*     */ 
/* 280 */     result.append("<tr>\n");
/* 281 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Quickest Request (Min)</font></td>\n");
/* 282 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getQuickestTime() + "ms</font></td>\n");
/* 283 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getQuickestRequestURL() + "</font></td>\n");
/* 284 */     result.append("</tr>\n");
/*     */ 
/* 286 */     result.append("<tr>\n");
/* 287 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Average Request (Avg)</font></td>\n");
/* 288 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getAverageTime() + "ms</font></td>\n");
/* 289 */     result.append("</tr>\n");
/*     */ 
/* 291 */     result.append("<tr>\n");
/* 292 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Longest Request (Max)</font></td>\n");
/* 293 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getLongestTime() + "ms</font></td>\n");
/* 294 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getLongestRequestURL() + "</font></td>\n");
/* 295 */     result.append("</tr>\n");
/*     */ 
/* 297 */     result.append("<tr>\n");
/* 298 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Date Created</font></td>\n");
/* 299 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(createdTime) + "</font></td>\n");
/* 300 */     result.append("</tr>\n");
/*     */ 
/* 302 */     result.append("<tr>\n");
/* 303 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Date Last Loaded</font></td>\n");
/* 304 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(s.getLoadedTime()) + "</font></td>\n");
/* 305 */     result.append("</tr>\n");
/*     */ 
/* 307 */     result.append("<tr>\n");
/* 308 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Total Memory</font></td>\n");
/* 309 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getTotalMemory() / 1024L + "K</font></td>\n");
/* 310 */     result.append("</tr>\n");
/*     */ 
/* 312 */     result.append("<tr>\n");
/* 313 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Used Memory</font></td>\n");
/* 314 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getUsedMemory() / 1024L + "K</font></td>\n");
/* 315 */     result.append("</tr>\n");
/*     */ 
/* 317 */     result.append("<tr>\n");
/* 318 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Free Memory</font></td>\n");
/* 319 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + s.getFreeMemory() / 1024L + "K</font></td>\n");
/* 320 */     result.append("</tr>\n");
/*     */ 
/* 322 */     DiagnosticsMessage m = s.getLastProblem();
/*     */ 
/* 324 */     result.append("<tr>\n");
/* 325 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">Last Problem</font></td>\n");
/* 326 */     result.append("<td colspan=\"2\" bgcolor=\"#DCDCDC\"><font size=\"1\">" + (m == null ? "None" : m.toHTML()) + "</font></td>\n");
/* 327 */     result.append("</tr>\n");
/*     */ 
/* 329 */     result.append("</table>\n");
/*     */ 
/* 331 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String appGlobalsToHTML(InvocationContext ic)
/*     */   {
/* 336 */     StringBuffer result = new StringBuffer();
/* 337 */     result.append("<table width=\"100%\">\n");
/* 338 */     result.append("<tr>\n");
/* 339 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Key</b></font></td>\n");
/* 340 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Type</b></font></td>\n");
/* 341 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Value</b></font></td>\n");
/* 342 */     result.append("</tr>\n");
/*     */ 
/* 344 */     Enumeration keys = ic.getAppGlobalKeys();
/* 345 */     while (keys.hasMoreElements())
/*     */     {
/* 347 */       String key = (String)keys.nextElement();
/* 348 */       Object value = ic.getAppGlobalDatum(key);
/* 349 */       String type = value.getClass().getName();
/* 350 */       result.append("<tr>\n");
/* 351 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</font></td>\n");
/* 352 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + type + "</font></td>\n");
/* 353 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + value + "</font></td>\n");
/* 354 */       result.append("</tr>");
/*     */     }
/* 356 */     result.append("</table>\n");
/*     */ 
/* 358 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String sessionsToHTML(InvocationContext ic) throws Exception
/*     */   {
/* 363 */     String session = ic.getParameter("session");
/* 364 */     if (session == null) session = ic.getSessionID();
/* 365 */     String href = ic.getSessionDatum("action") + ic.getConfigValue("admin:action") + "?function=sessions";
/* 366 */     String out = ((BaseInvocationContext)ic).getSessionManager().toHTML(href, ic.getSessionID(), session);
/* 367 */     return out;
/*     */   }
/*     */ 
/*     */   public static String transientDataToHTML(InvocationContext ic)
/*     */   {
/* 372 */     StringBuffer result = new StringBuffer();
/* 373 */     result.append("<table width=\"100%\">\n");
/* 374 */     result.append("<tr>\n");
/* 375 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Key</b></font></td>\n");
/* 376 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Type</b></font></td>\n");
/* 377 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Value</b></font></td>\n");
/* 378 */     result.append("</tr>\n");
/*     */ 
/* 380 */     Enumeration keys = ic.getTransientKeys();
/* 381 */     while (keys.hasMoreElements())
/*     */     {
/* 383 */       String key = (String)keys.nextElement();
/* 384 */       Object value = ic.getTransientDatum(key);
/* 385 */       String type = value.getClass().getName();
/* 386 */       result.append("<tr>\n");
/* 387 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</font></td>\n");
/* 388 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + type + "</font></td>\n");
/* 389 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + value + "</font></td>\n");
/* 390 */       result.append("</tr>");
/*     */     }
/* 392 */     result.append("</table>\n");
/*     */ 
/* 394 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String parametersToHTML(InvocationContext ic)
/*     */   {
/* 399 */     StringBuffer result = new StringBuffer();
/* 400 */     result.append("<table width=\"100%\">\n");
/* 401 */     result.append("<tr>\n");
/* 402 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Key</b></font></td>\n");
/* 403 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Type</b></font></td>\n");
/* 404 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Value</b></font></td>\n");
/* 405 */     result.append("</tr>\n");
/*     */ 
/* 407 */     Enumeration keys = ic.getParameterKeys();
/* 408 */     while (keys.hasMoreElements())
/*     */     {
/* 410 */       String key = (String)keys.nextElement();
/* 411 */       Object value = ic.getParameter(key);
/* 412 */       String type = value.getClass().getName();
/* 413 */       result.append("<tr>\n");
/* 414 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</font></td>\n");
/* 415 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + type + "</font></td>\n");
/* 416 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + value + "</font></td>\n");
/* 417 */       result.append("</tr>");
/*     */     }
/* 419 */     result.append("</table>\n");
/*     */ 
/* 421 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String daemonsToHTML(Hashtable daemons, String href, String daemon)
/*     */   {
/* 426 */     StringBuffer result = new StringBuffer();
/* 427 */     result.append("<table width=\"100%\">\n");
/* 428 */     result.append("<tr>\n");
/* 429 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Daemon</b></font></td>\n");
/* 430 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Details</b></font></td>\n");
/* 431 */     result.append("</tr>\n");
/*     */ 
/* 433 */     Enumeration keys = Sort.keys(daemons);
/* 434 */     while (keys.hasMoreElements())
/*     */     {
/* 436 */       String key = (String)keys.nextElement();
/* 437 */       Daemon d = (Daemon)daemons.get(key);
/* 438 */       result.append("<tr>\n");
/* 439 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</font></td>\n");
/* 440 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + d.toHTML(href, key.equals(daemon)) + "</font></td>\n");
/* 441 */       result.append("</tr>");
/*     */     }
/* 443 */     result.append("</table>\n");
/*     */ 
/* 445 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String makePrintable(String s)
/*     */   {
/* 450 */     StringBuffer result = new StringBuffer();
/*     */ 
/* 452 */     for (int i = 0; i < s.length(); i++)
/*     */     {
/* 454 */       char c = s.charAt(i);
/* 455 */       if (c >= ' ')
/* 456 */         result.append(s.substring(i, i + 1));
/* 457 */       else if (c == '\n')
/* 458 */         result.append("\\n");
/* 459 */       else if (c == '\r')
/* 460 */         result.append("\\r");
/* 461 */       else if (c == '\t')
/* 462 */         result.append("\\t");
/*     */       else {
/* 464 */         result.append("\\0" + (c < '\n' ? "0" : "") + c);
/*     */       }
/*     */     }
/* 467 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String propertiesToHTML()
/*     */   {
/* 472 */     StringBuffer result = new StringBuffer();
/* 473 */     char sep = System.getProperty("path.separator").charAt(0);
/*     */ 
/* 475 */     result.append("<table width=\"100%\">\n");
/* 476 */     result.append("<tr>\n");
/* 477 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Property</b></td>\n");
/* 478 */     result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Value</b></td>\n");
/* 479 */     result.append("</tr>\n");
/*     */ 
/* 481 */     Hashtable h = System.getProperties();
/* 482 */     Enumeration keys = Sort.keys(h);
/* 483 */     while (keys.hasMoreElements())
/*     */     {
/* 485 */       Object temp1 = keys.nextElement();
/* 486 */       Object temp2 = h.get(temp1);
/* 487 */       String key = temp1 == null ? "" : temp1.toString();
/* 488 */       String value = temp2 == null ? "" : temp2.toString();
/* 489 */       result.append("<tr>\n");
/* 490 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</font></td>\n");
/* 491 */       result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">");
/*     */ 
/* 493 */       Vector v = new Vector();
/* 494 */       if (key.equals("server.vmargs"))
/* 495 */         v = StringUtil.stringToVector(value, ':');
/* 496 */       else if ((key.indexOf("path") != -1) && (value.indexOf(sep) != -1) && (value.length() > 1))
/* 497 */         v = StringUtil.stringToVector(value, sep);
/*     */       else {
/* 499 */         v.addElement(value);
/*     */       }
/* 501 */       for (int i = 0; i < v.size(); i++)
/*     */       {
/* 503 */         String s = v.elementAt(i).toString();
/* 504 */         if (s.length() > 0) {
/* 505 */           result.append(makePrintable(s) + "<br>\n");
/*     */         }
/*     */       }
/* 508 */       result.append("</font></td>\n");
/* 509 */       result.append("</tr>\n");
/*     */     }
/* 511 */     result.append("</table>\n");
/*     */ 
/* 513 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static int max(int x, int y, int z)
/*     */   {
/* 518 */     if ((x != -1) && (x >= y) && (x >= z)) return x;
/* 519 */     if ((y != -1) && (y >= x) && (y >= z)) return y;
/* 520 */     if ((z != -1) && (z >= x) && (z >= y)) return z;
/* 521 */     return -1;
/*     */   }
/*     */ 
/*     */   public static String configToHTML(InvocationContext ic)
/*     */     throws Exception
/*     */   {
/* 529 */     String s = null;
/* 530 */     FileInputStream fis = null;
/*     */     try
/*     */     {
/* 534 */       fis = new FileInputStream(ic.getConfig().getFile());
/* 535 */       byte[] buf = new byte[fis.available()];
/* 536 */       fis.read(buf);
/* 537 */       s = new String(buf);
/*     */     }
/*     */     finally
/*     */     {
/* 541 */       if (fis != null) fis.close();
/*     */     }
/*     */ 
/* 544 */     s = StringUtil.toHTML(s);
/* 545 */     StringBuffer result = new StringBuffer();
/* 546 */     result.append("<pre><font size=\"2\">");
/*     */ 
/* 549 */     int lastPos = 0;
/* 550 */     while (lastPos < s.length())
/*     */     {
/* 566 */       int startPos = s.indexOf("&lt;", lastPos);
/* 567 */       if (startPos == -1) break;
/* 568 */       int spacePos = s.indexOf(' ', startPos);
/* 569 */       int endTagPos = s.indexOf("&gt;", startPos);
/* 570 */       int endPos = endTagPos;
/* 571 */       if ((spacePos != -1) && (spacePos < endTagPos)) endPos = spacePos;
/* 572 */       if (endPos == -1)
/*     */       {
/* 574 */         result.append(s.substring(, lastPos));
/*     */       }
/*     */       else {
/* 577 */         result.append(s.substring(lastPos, startPos + 4));
/* 578 */         result.append("<font color=\"blue\">");
/* 579 */         result.append(s.substring(startPos + 4, endPos));
/* 580 */         result.append("</font>");
/* 581 */         lastPos = endPos;
/*     */ 
/* 584 */         while (lastPos < endTagPos)
/*     */         {
/* 586 */           endPos = s.indexOf('=', lastPos);
/* 587 */           if ((endPos == -1) || (endPos > endTagPos)) break;
/* 588 */           String s2 = s.substring(lastPos, endPos);
/* 589 */           int spacePos2 = s2.lastIndexOf(' ');
/* 590 */           int tabPos = s2.lastIndexOf('\t');
/* 591 */           int newlinePos = s2.lastIndexOf('\n');
/* 592 */           startPos = max(spacePos2, tabPos, newlinePos);
/* 593 */           if (startPos == -1) break;
/* 594 */           startPos += lastPos;
/* 595 */           result.append(s.substring(lastPos, startPos + 1));
/* 596 */           result.append("<font color=\"red\">");
/* 597 */           result.append(s.substring(startPos + 1, endPos));
/* 598 */           result.append("</font>=");
/* 599 */           lastPos = endPos + 1;
/*     */         }
/*     */       }
/*     */     }
/* 603 */     result.append(s.substring(lastPos));
/* 604 */     result.append("</font></pre>");
/*     */ 
/* 606 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.AdminHandler
 * JD-Core Version:    0.6.2
 */