/*    */ package dynamic.intraframe.handlers;
/*    */ 
/*    */ import dynamic.intraframe.engine.Configuration;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ public abstract class BaseHandler
/*    */ {
/* 11 */   Configuration config = null;
/* 12 */   private long loadedTime = 0L;
/* 13 */   private long requestCount = 0L;
/* 14 */   private long totalTime = 0L;
/* 15 */   private long minTime = -1L;
/* 16 */   private long maxTime = -1L;
/* 17 */   private long lastTime = 0L;
/*    */ 
/*    */   public final Document getConfigDocument()
/*    */   {
/* 21 */     return this.config.getConfigDocument();
/*    */   }
/*    */ 
/*    */   public final void initialize(Configuration cfg) throws Exception
/*    */   {
/* 26 */     this.config = cfg;
/* 27 */     this.loadedTime = System.currentTimeMillis();
/* 28 */     setUpHandler();
/*    */   }
/*    */ 
/*    */   public final boolean handle(InvocationContext ic) throws Exception
/*    */   {
/* 34 */     long startTime = System.currentTimeMillis();
/*    */     boolean result;
/*    */     try {
/* 37 */       result = handleEnvironment(ic);
/*    */     }
/*    */     finally
/*    */     {
/* 41 */       this.requestCount += 1L;
/* 42 */       this.lastTime = (System.currentTimeMillis() - startTime);
/* 43 */       this.totalTime += this.lastTime;
/* 44 */       if ((this.minTime == -1L) || (this.lastTime < this.minTime)) this.minTime = this.lastTime;
/* 45 */       if ((this.maxTime == -1L) || (this.lastTime > this.maxTime)) this.maxTime = this.lastTime;
/*    */     }
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   public final String getName()
/*    */   {
/* 52 */     return getClass().getName();
/*    */   }
/*    */ 
/*    */   public final String toString()
/*    */   {
/* 57 */     return getName();
/*    */   }
/*    */ 
/*    */   public long getLoadedTime()
/*    */   {
/* 62 */     return this.loadedTime;
/*    */   }
/*    */ 
/*    */   public long getRequestCount()
/*    */   {
/* 67 */     return this.requestCount;
/*    */   }
/*    */ 
/*    */   public long getMinTime()
/*    */   {
/* 72 */     return this.minTime;
/*    */   }
/*    */ 
/*    */   public long getAverageTime()
/*    */   {
/* 77 */     if (this.requestCount == 0L) return 0L;
/* 78 */     return this.totalTime / this.requestCount;
/*    */   }
/*    */ 
/*    */   public long getMaxTime()
/*    */   {
/* 83 */     return this.maxTime;
/*    */   }
/*    */ 
/*    */   public long getLastTime()
/*    */   {
/* 88 */     return this.lastTime;
/*    */   }
/*    */ 
/*    */   public abstract void setUpHandler()
/*    */     throws Exception;
/*    */ 
/*    */   public abstract boolean handleEnvironment(InvocationContext paramInvocationContext)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract void destroy();
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.handlers.BaseHandler
 * JD-Core Version:    0.6.2
 */