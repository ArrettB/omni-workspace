/*     */ package dynamic.intraframe.session;
/*     */ 
/*     */ import dynamic.util.date.StdDate;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ public class BaseSessionData
/*     */   implements Serializable, SessionData
/*     */ {
/*     */   private static final String sessionDateAccessed = "sessionDateAccessed";
/*     */   private static final String sessionDateCreated = "sessionDateCreated";
/*     */   private static final String sessionDateExpires = "sessionDateExpires";
/*     */   private static final String sessionDateModified = "sessionDateModified";
/*     */   private static final String sessionDirtyFlag = "sessionDirtyFlag";
/*     */   private static final String sessionID = "sessionID";
/*     */   private static final String sessionTTL = "sessionTTL";
/*     */   private static final String requestURL = "requestURL";
/*     */   private static final String formAction = "formAction";
/*     */   private static final String action = "action";
/*     */   private static final String showPage = "showPage";
/*     */   private static final String ipAddress = "ipAddress";
/*     */   private static final String userAgent = "userAgent";
/*  42 */   private Hashtable data = new Hashtable();
/*     */ 
/*     */   public void initialize(String id, long ttl)
/*     */   {
/*  48 */     Date now = accessed(ttl);
/*  49 */     this.data.put("sessionID", id);
/*  50 */     this.data.put("sessionDateCreated", now);
/*  51 */     this.data.put("sessionDateModified", now);
/*  52 */     this.data.put("sessionDirtyFlag", "true");
/*     */   }
/*     */ 
/*     */   public void setRequestData(String requestURL_in, String requestURI_in, String ipAddress_in, String userAgent_in)
/*     */   {
/*  57 */     this.data.put("requestURL", requestURL_in);
/*  58 */     this.data.put("formAction", requestURI_in);
/*  59 */     this.data.put("action", requestURI_in + "/");
/*  60 */     this.data.put("showPage", requestURI_in + "/");
/*  61 */     this.data.put("ipAddress", ipAddress_in);
/*  62 */     if (userAgent_in != null)
/*  63 */       this.data.put("userAgent", userAgent_in);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  68 */     if (this.data != null) this.data.clear();
/*  69 */     this.data = null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  74 */     return getSessionID();
/*     */   }
/*     */ 
/*     */   public String toHTML(String href, boolean showDetail)
/*     */   {
/*  79 */     StringBuffer result = new StringBuffer();
/*  80 */     result.append("<tr>\n");
/*     */ 
/*  82 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\"><a href=\"" + href);
/*  83 */     if (!showDetail) result.append("&session=" + getSessionID());
/*  84 */     result.append("\">" + getSessionID() + "</a></font></td>\n");
/*  85 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + this.data.get("ipAddress") + "</font></td>\n");
/*  86 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + this.data.get("userAgent") + "</font></td>\n");
/*  87 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(getDateCreated()) + "</font></td>\n");
/*  88 */     result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + new StdDate(getDateExpires()) + "</font></td>\n");
/*     */ 
/*  90 */     result.append("</tr>\n");
/*     */ 
/*  92 */     if (showDetail)
/*     */     {
/*  94 */       result.append("<tr><td colspan=\"5\">\n");
/*  95 */       result.append("<table width=\"100%\">\n");
/*  96 */       result.append("<tr>\n");
/*  97 */       result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Key</b></font></td>\n");
/*  98 */       result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Type</b></font></td>\n");
/*  99 */       result.append("<td bgcolor=\"#888888\"><font size=\"2\"><b>Value</b></font></td>\n");
/* 100 */       result.append("</tr>");
/*     */ 
/* 102 */       Enumeration keys = keys();
/* 103 */       while (keys.hasMoreElements())
/*     */       {
/* 105 */         String key = (String)keys.nextElement();
/* 106 */         Object value = this.data.get(key);
/* 107 */         String type = value.getClass().getName();
/* 108 */         result.append("<tr>");
/* 109 */         result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + key + "</font></td>");
/* 110 */         result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + type + "</font></td>");
/* 111 */         result.append("<td bgcolor=\"#DCDCDC\"><font size=\"1\">" + value + "</font></td>");
/* 112 */         result.append("</tr>");
/*     */       }
/* 114 */       result.append("</table>\n");
/* 115 */       result.append("</td></tr>\n");
/*     */     }
/*     */ 
/* 118 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public Date getDateAccessed()
/*     */   {
/* 123 */     return (Date)this.data.get("sessionDateAccessed");
/*     */   }
/*     */ 
/*     */   public Date getDateCreated()
/*     */   {
/* 128 */     return (Date)this.data.get("sessionDateCreated");
/*     */   }
/*     */ 
/*     */   public Date getDateExpires()
/*     */   {
/* 133 */     return (Date)this.data.get("sessionDateExpires");
/*     */   }
/*     */ 
/*     */   public Date getDateModified()
/*     */   {
/* 138 */     return (Date)this.data.get("sessionDateModified");
/*     */   }
/*     */ 
/*     */   public String getSessionID()
/*     */   {
/* 143 */     return (String)this.data.get("sessionID");
/*     */   }
/*     */ 
/*     */   public boolean isExpired()
/*     */   {
/* 148 */     return System.currentTimeMillis() > getDateExpires().getTime();
/*     */   }
/*     */ 
/*     */   public boolean isDirty()
/*     */   {
/* 153 */     String dirty = (String)get("sessionDirtyFlag");
/* 154 */     return (dirty != null) && (dirty.equals("true"));
/*     */   }
/*     */ 
/*     */   public void clean()
/*     */   {
/* 159 */     this.data.put("sessionDirtyFlag", "false");
/*     */   }
/*     */ 
/*     */   public boolean contains(Object value)
/*     */   {
/* 165 */     return this.data.contains(value);
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 170 */     return this.data.containsKey(key);
/*     */   }
/*     */ 
/*     */   public Enumeration elements()
/*     */   {
/* 175 */     return this.data.elements();
/*     */   }
/*     */ 
/*     */   public Enumeration keys()
/*     */   {
/* 185 */     return Sort.keys(this.data);
/*     */   }
/*     */ 
/*     */   private Date accessed()
/*     */   {
/* 190 */     return accessed(Long.parseLong((String)this.data.get("sessionTTL")));
/*     */   }
/*     */ 
/*     */   public Date accessed(long ttl)
/*     */   {
/* 195 */     this.data.put("sessionTTL", "" + ttl);
/* 196 */     Date now = new Date();
/* 197 */     this.data.put("sessionDateAccessed", now);
/* 198 */     Date expires = new Date(now.getTime() + ttl * 60L * 1000L);
/* 199 */     this.data.put("sessionDateExpires", expires);
/* 200 */     return now;
/*     */   }
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 205 */     Date now = accessed();
/* 206 */     return this.data.get(key);
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object newValue)
/*     */   {
/* 211 */     Date now = accessed();
/* 212 */     this.data.put("sessionDateAccessed", now);
/* 213 */     Object oldValue = this.data.get(key);
/* 214 */     if (oldValue == null)
/*     */     {
/* 216 */       if (newValue != null)
/*     */       {
/* 222 */         this.data.put(key, newValue);
/* 223 */         this.data.put("sessionDateModified", now);
/* 224 */         this.data.put("sessionDirtyFlag", "true");
/*     */       }
/*     */ 
/*     */     }
/* 229 */     else if (newValue == null)
/*     */     {
/* 231 */       this.data.remove(key);
/* 232 */       this.data.put("sessionDateModified", now);
/* 233 */       this.data.put("sessionDirtyFlag", "true");
/*     */     }
/* 235 */     else if (!oldValue.equals(newValue))
/*     */     {
/* 237 */       this.data.put(key, newValue);
/* 238 */       this.data.put("sessionDateModified", now);
/* 239 */       this.data.put("sessionDirtyFlag", "true");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 249 */     Date sessionDateAccessedSaved = (Date)this.data.get("sessionDateAccessed");
/* 250 */     Date sessionDateCreatedSaved = (Date)this.data.get("sessionDateCreated");
/* 251 */     Date sessionDateExpiresSaved = (Date)this.data.get("sessionDateExpires");
/* 252 */     Date sessionDateModifiedSaved = (Date)this.data.get("sessionDateModified");
/* 253 */     String sessionDirtyFlagSaved = (String)this.data.get("sessionDirtyFlag");
/* 254 */     String sessionIDSaved = (String)this.data.get("sessionID");
/* 255 */     String sessionTTLSaved = (String)this.data.get("sessionTTL");
/*     */ 
/* 257 */     String requestURLSaved = (String)this.data.get("requestURL");
/* 258 */     String formActionSaved = (String)this.data.get("formAction");
/* 259 */     String actionSaved = (String)this.data.get("action");
/* 260 */     String showPageSaved = (String)this.data.get("showPage");
/* 261 */     String ipAddressSaved = (String)this.data.get("ipAddress");
/* 262 */     String userAgentSaved = (String)this.data.get("userAgent");
/*     */ 
/* 264 */     this.data.clear();
/*     */ 
/* 266 */     this.data.put("sessionDateAccessed", sessionDateAccessedSaved);
/* 267 */     this.data.put("sessionDateCreated", sessionDateCreatedSaved);
/* 268 */     this.data.put("sessionDateExpires", sessionDateExpiresSaved);
/* 269 */     this.data.put("sessionDateModified", sessionDateModifiedSaved);
/* 270 */     this.data.put("sessionDirtyFlag", sessionDirtyFlagSaved);
/* 271 */     this.data.put("sessionID", sessionIDSaved);
/* 272 */     this.data.put("sessionTTL", sessionTTLSaved);
/*     */ 
/* 274 */     this.data.put("requestURL", requestURLSaved);
/* 275 */     this.data.put("formAction", formActionSaved);
/* 276 */     this.data.put("action", actionSaved);
/* 277 */     this.data.put("showPage", showPageSaved);
/* 278 */     this.data.put("ipAddress", ipAddressSaved);
/* 279 */     this.data.put("userAgent", userAgentSaved);
/*     */   }
/*     */ 
/*     */   public void remove(Object key)
/*     */   {
/* 284 */     put(key, null);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.session.BaseSessionData
 * JD-Core Version:    0.6.2
 */