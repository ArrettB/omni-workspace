/*    */ package dynamic.intraframe.session;
/*    */ 
/*    */ import dynamic.intraframe.engine.ApplicationContext;
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class TestSessionDataListener
/*    */   implements SessionDataListener
/*    */ {
/*    */   public void initialize(ApplicationContext ac)
/*    */   {
/* 12 */     Diagnostics.trace("TestSessionDataListener.initialize()");
/*    */   }
/*    */ 
/*    */   public void afterSessionCreated(SessionData sessionData, HttpServletRequest req) {
/* 16 */     Diagnostics.trace("TestSessionDataListener.afterSessionCreated()");
/*    */   }
/*    */ 
/*    */   public void beforeSessionDestroyed(SessionData sessionData) {
/* 20 */     Diagnostics.trace("TestSessionDataListener.beforeSessionDestroyed()");
/*    */   }
/*    */ 
/*    */   public void afterSessionRestored(SessionData sessionData, HttpServletRequest req) {
/* 24 */     Diagnostics.trace("TestSessionDataListener.afterSessionRestored()");
/*    */   }
/*    */ 
/*    */   public void beforeSessionSaved(SessionData sessionData) {
/* 28 */     Diagnostics.trace("TestSessionDataListener.beforeSessionSaved()");
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 32 */     Diagnostics.trace("TestSessionDataListener.destory()");
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.session.TestSessionDataListener
 * JD-Core Version:    0.6.2
 */