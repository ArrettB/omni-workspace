package dynamic.intraframe.session;

import dynamic.intraframe.engine.ApplicationContext;
import dynamic.intraframe.engine.InvocationContext;
import javax.servlet.http.HttpServletRequest;

public abstract interface SessionManager
{
  public abstract SessionData getSessionData(HttpServletRequest paramHttpServletRequest, ClassLoader paramClassLoader);

  public abstract void terminateSession(SessionData paramSessionData);

  public abstract void terminateSessionByID(String paramString);

  public abstract String getUniqueID();

  public abstract void initialize(ApplicationContext paramApplicationContext)
    throws Exception;

  public abstract String getBoundSessionKey(HttpServletRequest paramHttpServletRequest);

  public abstract void bindSessionKey(InvocationContext paramInvocationContext);

  public abstract String toHTML(String paramString1, String paramString2, String paramString3);

  public abstract SessionData readSessionData(String paramString, ClassLoader paramClassLoader);

  public abstract void writeSessionData(SessionData paramSessionData);

  public abstract void destroy();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.session.SessionManager
 * JD-Core Version:    0.6.2
 */