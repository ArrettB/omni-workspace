package dynamic.intraframe.session;

import java.util.Date;
import java.util.Enumeration;

public abstract interface SessionData
{
  public abstract void initialize(String paramString, long paramLong);

  public abstract void setRequestData(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void destroy();

  public abstract String toHTML(String paramString, boolean paramBoolean);

  public abstract String toString();

  public abstract String getSessionID();

  public abstract Date getDateAccessed();

  public abstract Date getDateCreated();

  public abstract Date getDateExpires();

  public abstract Date getDateModified();

  public abstract boolean isExpired();

  public abstract boolean isDirty();

  public abstract void clean();

  public abstract boolean contains(Object paramObject);

  public abstract boolean containsKey(Object paramObject);

  public abstract Enumeration keys();

  public abstract Enumeration elements();

  public abstract Date accessed(long paramLong);

  public abstract Object get(Object paramObject);

  public abstract void put(Object paramObject1, Object paramObject2);

  public abstract void clear();

  public abstract void remove(Object paramObject);
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.session.SessionData
 * JD-Core Version:    0.6.2
 */