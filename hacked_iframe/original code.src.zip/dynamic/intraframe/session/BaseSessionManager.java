/*     */ package dynamic.intraframe.session;
/*     */ 
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.ConfigurationException;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.util.classloader.DynamicObjectInputStream;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Random;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpUtils;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class BaseSessionManager
/*     */   implements SessionManager, Runnable
/*     */ {
/*     */   private static final String cookieName = "sessionIdentifier";
/*     */   private static final String URL = "URL";
/*     */   private static final String COOKIES = "Cookies";
/*  31 */   private long ttl = 45L;
/*  32 */   private long cttl = 2880L;
/*  33 */   private long pttl = 2880L;
/*  34 */   private String bind = "Cookies";
/*  35 */   private Thread cleaner = null;
/*  36 */   private long lastRun = 0L;
/*  37 */   private boolean havePersistentSessions = false;
/*  38 */   private File root = null;
/*  39 */   private Hashtable sessions = new Hashtable();
/*  40 */   private Vector listeners = new Vector();
/*     */ 
/*     */   public void initialize(ApplicationContext ac)
/*     */     throws Exception
/*     */   {
/*  46 */     Diagnostics.trace("BaseSessionManager.initialize()");
/*     */ 
/*  48 */     Document xmlDoc = ac.getConfigDocument();
/*  49 */     Element sessionManagerElement = XMLUtils.getSingleElement(xmlDoc, "sessionManager");
/*     */ 
/*  51 */     String tmp = sessionManagerElement.getAttribute("loggingPath");
/*  52 */     if ((tmp != null) && (tmp.length() > 0)) {
/*  53 */       Diagnostics.warning("sessionManager:loggingPath is deprecated");
/*     */     }
/*  55 */     tmp = sessionManagerElement.getAttribute("bind");
/*  56 */     if ((tmp != null) && (tmp.length() > 0)) this.bind = tmp;
/*  57 */     Diagnostics.debug("BaseSessionManager.initialize() bind=" + this.bind);
/*     */ 
/*  60 */     String ttlString = sessionManagerElement.getAttribute("ttl");
/*  61 */     this.ttl = Integer.parseInt(ttlString);
/*  62 */     this.cttl = this.ttl;
/*     */ 
/*  64 */     tmp = sessionManagerElement.getAttribute("persistentSession");
/*  65 */     if (tmp != null) this.havePersistentSessions = tmp.equalsIgnoreCase("true");
/*  66 */     String persistentStorage = sessionManagerElement.getAttribute("persistentStorage");
/*  67 */     if ((persistentStorage != null) && (persistentStorage.length() > 0))
/*  68 */       this.root = new File(persistentStorage);
/*  69 */     if (this.havePersistentSessions)
/*     */     {
/*  71 */       if (this.root == null)
/*     */       {
/*  73 */         throw new ConfigurationException("sessionManager:persistentStorage not set");
/*     */       }
/*     */ 
/*  77 */       if (!this.root.exists())
/*  78 */         throw new ConfigurationException("The path \"" + this.root + "\" does not exist");
/*  79 */       if (!this.root.isDirectory())
/*  80 */         throw new ConfigurationException("The path \"" + this.root + "\" is not a directory");
/*  81 */       if (!this.root.canRead())
/*  82 */         throw new ConfigurationException("The path \"" + this.root + "\" is not readable");
/*  83 */       if (!this.root.canWrite()) {
/*  84 */         throw new ConfigurationException("The path \"" + this.root + "\" is not writeable");
/*     */       }
/*     */ 
/*  88 */       String pttlString = sessionManagerElement.getAttribute("persistentTTL");
/*  89 */       if ((pttlString != null) && (pttlString.length() > 0))
/*     */       {
/*  91 */         this.pttl = Integer.parseInt(pttlString);
/*  92 */         this.cttl = this.pttl;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  97 */     String cttlString = sessionManagerElement.getAttribute("cookieTTL");
/*  98 */     if ((cttlString != null) && (cttlString.length() > 0))
/*     */     {
/* 100 */       this.cttl = Integer.parseInt(cttlString);
/*     */     }
/*     */ 
/* 103 */     start();
/*     */ 
/* 106 */     NodeList l = sessionManagerElement.getElementsByTagName("sessionListener");
/* 107 */     for (int i = 0; i < l.getLength(); i++)
/*     */     {
/* 109 */       Element listenerElement = (Element)l.item(i);
/* 110 */       String listenerClass = listenerElement.getAttribute("class");
/* 111 */       Diagnostics.trace("BaseSessionManager.initialize() loading " + listenerClass);
/* 112 */       SessionDataListener listener = (SessionDataListener)ac.loadClass(listenerClass).newInstance();
/* 113 */       if (listener != null)
/*     */       {
/* 115 */         listener.initialize(ac);
/* 116 */         this.listeners.addElement(listener);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized SessionData getSessionData(HttpServletRequest req, ClassLoader loader)
/*     */   {
/* 128 */     SessionData result = null;
/* 129 */     String key = getBoundSessionKey(req);
/* 130 */     boolean created = false;
/* 131 */     boolean readFromDisk = false;
/* 132 */     if (key != null) key = key.trim();
/*     */ 
/* 134 */     if ((key != null) && (key.length() > 0))
/*     */     {
/* 136 */       result = (SessionData)this.sessions.get(key);
/* 137 */       if (result == null)
/*     */       {
/* 139 */         result = readSessionData(key, loader);
/* 140 */         if (result != null) readFromDisk = true;
/*     */       }
/*     */     }
/*     */ 
/* 144 */     if (result == null)
/*     */     {
/* 146 */       created = true;
/* 147 */       result = new BaseSessionData();
/* 148 */       if (key == null) key = getUniqueID();
/* 149 */       result.initialize(key, this.ttl);
/*     */     }
/*     */     else
/*     */     {
/* 153 */       result.accessed(this.ttl);
/*     */     }
/* 155 */     setDefaultSessionData(result, req);
/* 156 */     this.sessions.put(result.getSessionID(), result);
/* 157 */     if (readFromDisk) fireAfterSessionRestored(result, req);
/* 158 */     if (created) fireAfterSessionCreated(result, req);
/*     */ 
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */   public SessionData readSessionData(String key, ClassLoader loader)
/*     */   {
/* 165 */     SessionData result = null;
/*     */ 
/* 167 */     if (!this.havePersistentSessions) return result;
/*     */ 
/* 169 */     File file = new File(this.root, key.substring(1) + ".session");
/* 170 */     DynamicObjectInputStream serializeStream = null;
/*     */     try
/*     */     {
/* 174 */       if (!file.exists())
/*     */       {
/* 177 */         Diagnostics.trace("The file \"" + file + "\" does not exist");
/*     */       } else {
/* 179 */         if (file.isDirectory())
/*     */         {
/* 181 */           throw new IOException("The file \"" + file + "\" is a directory");
/*     */         }
/* 183 */         if (!file.canRead())
/*     */         {
/* 185 */           throw new IOException("The file \"" + file + "\" is not readable");
/*     */         }
/*     */ 
/* 189 */         FileInputStream inputStream = new FileInputStream(file);
/* 190 */         serializeStream = new DynamicObjectInputStream(inputStream, loader);
/* 191 */         result = (BaseSessionData)serializeStream.readObject();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 196 */       Diagnostics.error("Problem reading persistent session " + file, e);
/* 197 */       result = null;
/*     */     }
/*     */     finally {
/*     */       try {
/* 201 */         if (serializeStream != null) serializeStream.close(); 
/*     */       } catch (Exception e) {  }
/*     */ 
/*     */     }
/* 204 */     return result;
/*     */   }
/*     */ 
/*     */   public void writeSessionData(SessionData session)
/*     */   {
/* 209 */     if (!this.havePersistentSessions) return;
/*     */ 
/* 211 */     if (!session.isDirty()) return;
/* 212 */     session.clean();
/*     */ 
/* 214 */     String key = session.getSessionID();
/* 215 */     File file = new File(this.root, key.substring(1) + ".session");
/* 216 */     ObjectOutputStream serializeStream = null;
/*     */     try
/*     */     {
/* 220 */       if (file.exists())
/*     */       {
/* 222 */         if (file.isDirectory())
/* 223 */           throw new IOException("The file \"" + file + "\" is a directory");
/* 224 */         if (!file.canWrite())
/* 225 */           throw new IOException("The file \"" + file + "\" is not writeable");
/*     */       }
/* 227 */       FileOutputStream outputStream = new FileOutputStream(file);
/* 228 */       serializeStream = new ObjectOutputStream(outputStream);
/* 229 */       serializeStream.writeObject(session);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 233 */       Diagnostics.error("Problem writing persistent session " + file, e);
/*     */     }
/*     */     finally {
/*     */       try {
/* 237 */         if (serializeStream != null) serializeStream.close(); 
/*     */       }
/*     */       catch (Exception e) {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/* 244 */   public void terminateSessionByID(String sessionID) { terminateSession((SessionData)this.sessions.get(sessionID)); }
/*     */ 
/*     */ 
/*     */   public void terminateSession(SessionData sessionData)
/*     */   {
/* 249 */     synchronized (this.sessions)
/*     */     {
/* 251 */       fireBeforeSessionDestroyed(sessionData);
/* 252 */       this.sessions.remove(sessionData.getSessionID());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void fireAfterSessionCreated(SessionData sessionData, HttpServletRequest req)
/*     */   {
/* 258 */     for (int i = 0; i < this.listeners.size(); i++)
/*     */     {
/* 260 */       ((SessionDataListener)this.listeners.elementAt(i)).afterSessionCreated(sessionData, req);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void fireBeforeSessionDestroyed(SessionData sessionData)
/*     */   {
/* 266 */     for (int i = 0; i < this.listeners.size(); i++)
/*     */     {
/* 268 */       ((SessionDataListener)this.listeners.elementAt(i)).beforeSessionDestroyed(sessionData);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void fireAfterSessionRestored(SessionData sessionData, HttpServletRequest req)
/*     */   {
/* 274 */     for (int i = 0; i < this.listeners.size(); i++)
/*     */     {
/* 276 */       ((SessionDataListener)this.listeners.elementAt(i)).afterSessionRestored(sessionData, req);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void fireBeforeSessionSaved(SessionData sessionData)
/*     */   {
/* 282 */     for (int i = 0; i < this.listeners.size(); i++)
/*     */     {
/* 284 */       ((SessionDataListener)this.listeners.elementAt(i)).beforeSessionSaved(sessionData);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getUniqueID()
/*     */   {
/* 290 */     long temp = Math.abs(new Random(System.currentTimeMillis()).nextLong());
/* 291 */     synchronized (this.sessions)
/*     */     {
/* 293 */       while (this.sessions.containsKey("/" + Long.toString(temp)))
/* 294 */         temp += 1L;
/*     */     }
/* 296 */     return "/" + Long.toString(temp);
/*     */   }
/*     */ 
/*     */   private void start()
/*     */   {
/* 301 */     this.cleaner = new Thread(this, "SessionCleaner");
/* 302 */     this.cleaner.setPriority(1);
/* 303 */     Diagnostics.registerThread(this.cleaner, Diagnostics.getContext());
/* 304 */     this.cleaner.start();
/*     */   }
/*     */ 
/*     */   private void stop()
/*     */   {
/* 309 */     Thread temp = this.cleaner;
/* 310 */     this.cleaner = null;
/* 311 */     temp.interrupt();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 318 */       Thread thisThread = Thread.currentThread();
/* 319 */       while (this.cleaner == thisThread)
/*     */       {
/* 321 */         this.lastRun = System.currentTimeMillis();
/* 322 */         Enumeration s = this.sessions.elements();
/* 323 */         while (s.hasMoreElements())
/*     */         {
/* 325 */           SessionData session = (SessionData)s.nextElement();
/* 326 */           if (session.isExpired()) terminateSession(session);
/*     */         }
/*     */ 
/* 329 */         cleanPersistentSessions();
/*     */         try
/*     */         {
/* 333 */           Thread.sleep(600000L);
/*     */         }
/*     */         catch (InterruptedException e) {
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 340 */       Diagnostics.error("BaseSessionManager cleaner thread died", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void cleanPersistentSessions()
/*     */   {
/* 346 */     if (this.root == null) return;
/*     */ 
/* 348 */     String[] list = this.root.list(new FilenameFilter() {
/*     */       public boolean accept(File dir, String name) {
/* 350 */         return name.toLowerCase().endsWith(".session");
/*     */       }
/*     */     });
/* 354 */     if (list == null) return;
/*     */ 
/* 356 */     for (int x = 0; x < list.length; x++)
/*     */     {
/* 358 */       File inputFile = new File(this.root, list[x]);
/* 359 */       long expires = inputFile.lastModified() + this.pttl * 60L * 1000L;
/* 360 */       if (System.currentTimeMillis() > expires)
/* 361 */         inputFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized String toHTML(String href, String currentSessionID, String selectedSessionID)
/*     */   {
/* 367 */     StringBuffer result = new StringBuffer();
/* 368 */     result.append("<b>Current Session ID:</b> <a href=\"" + href + "&session=" + currentSessionID + "\">" + currentSessionID + "</a><br>");
/* 369 */     result.append("<b>Cleaning Thread Last Run:</b> " + new Date(this.lastRun) + "<br>");
/* 370 */     result.append("<b>Using Persistent Sessions:</b> " + this.havePersistentSessions + "<br>");
/* 371 */     result.append("<b>Persistent Session Path:</b> " + this.root + "<br>");
/* 372 */     result.append("<b>TTL:</b> " + this.ttl + "<br>");
/* 373 */     result.append("<b>Persistent TTL:</b> " + this.pttl + "<br>");
/* 374 */     result.append("<b>Cookie TTL:</b> " + this.cttl + "<br>");
/*     */ 
/* 376 */     result.append("<table width=\"100%\">\n");
/* 377 */     result.append("<tr>\n");
/* 378 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>ID</b></font></td>\n");
/* 379 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>IP Address</b></font></td>\n");
/* 380 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>User Agent</b></font></td>\n");
/* 381 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Created</b></font></td>\n");
/* 382 */     result.append("<td bgcolor=\"#8888CC\"><font size=\"2\"><b>Expires</b></font></td>\n");
/* 383 */     result.append("</tr>\n");
/*     */ 
/* 385 */     Enumeration keys = Sort.keys(this.sessions);
/* 386 */     while (keys.hasMoreElements())
/*     */     {
/* 388 */       SessionData session = (SessionData)this.sessions.get(keys.nextElement());
/* 389 */       result.append(session.toHTML(href, session.getSessionID().equals(selectedSessionID)));
/*     */     }
/* 391 */     result.append("</table>\n");
/* 392 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private void setDefaultSessionData(SessionData session, HttpServletRequest req)
/*     */   {
/* 398 */     if (req == null) return;
/*     */ 
/* 400 */     String requestURI = req.getRequestURI();
/* 401 */     String requestURL = HttpUtils.getRequestURL(req).toString();
/*     */ 
/* 403 */     String pathInfo = req.getPathInfo();
/* 404 */     if ((pathInfo != null) && (pathInfo.length() > 0))
/*     */     {
/* 406 */       requestURI = requestURI.substring(0, requestURI.length() - pathInfo.length());
/* 407 */       requestURL = requestURL.substring(0, requestURL.length() - pathInfo.length());
/*     */     }
/*     */ 
/* 410 */     if (this.bind.equalsIgnoreCase("URL"))
/*     */     {
/* 412 */       requestURI = requestURI + session.getSessionID();
/* 413 */       requestURL = requestURL + session.getSessionID();
/*     */     }
/*     */ 
/* 418 */     session.setRequestData(requestURL, requestURI, req.getRemoteAddr(), req.getHeader("User-Agent"));
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 423 */     stop();
/* 424 */     if (this.sessions != null)
/*     */     {
/* 426 */       Enumeration s = this.sessions.elements();
/* 427 */       while (s.hasMoreElements())
/* 428 */         ((SessionData)s.nextElement()).destroy();
/* 429 */       this.sessions.clear();
/* 430 */       this.sessions = null;
/*     */     }
/* 432 */     if (this.listeners != null)
/*     */     {
/* 434 */       for (int x = 0; x < this.listeners.size(); x++)
/* 435 */         ((SessionDataListener)this.listeners.elementAt(x)).destroy();
/* 436 */       this.listeners.removeAllElements();
/* 437 */       this.listeners = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getBoundSessionKey(HttpServletRequest request)
/*     */   {
/* 443 */     String result = null;
/*     */ 
/* 445 */     if (request != null)
/*     */     {
/* 447 */       if (this.bind.equalsIgnoreCase("URL"))
/*     */       {
/* 449 */         String key = request.getPathInfo();
/* 450 */         if ((key != null) && (key.length() > 0))
/*     */         {
/* 452 */           int trailing = key.indexOf('/', 1);
/* 453 */           if (trailing != -1) key = key.substring(0, trailing);
/*     */           try
/*     */           {
/* 456 */             Long.parseLong(key.substring(1));
/* 457 */             result = key;
/*     */           } catch (Exception e) {
/*     */           }
/*     */         }
/* 461 */       } else if (this.bind.equalsIgnoreCase("Cookies"))
/*     */       {
/* 463 */         Cookie[] cookies = request.getCookies();
/* 464 */         if (cookies != null)
/*     */         {
/* 466 */           for (int i = 0; i < cookies.length; i++)
/*     */           {
/* 468 */             if (cookies[i].getName().equals("sessionIdentifier"))
/*     */             {
/* 470 */               result = cookies[i].getValue();
/* 471 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 478 */     Diagnostics.trace("BaseSessionManager.getBoundSessionKey() returning " + result);
/* 479 */     return result;
/*     */   }
/*     */ 
/*     */   public void bindSessionKey(InvocationContext ic)
/*     */   {
/* 487 */     if (this.bind.equalsIgnoreCase("Cookies"))
/*     */     {
/* 489 */       Cookie c = new Cookie("sessionIdentifier", ic.getSessionID());
/* 490 */       c.setComment("This cookie will identify you to this Dynamic Information Systems iFrame based application");
/* 491 */       c.setPath((String)ic.getSessionDatum("formAction"));
/* 492 */       c.setMaxAge((int)this.cttl * 60);
/* 493 */       ic.setCookie(c);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.session.BaseSessionManager
 * JD-Core Version:    0.6.2
 */