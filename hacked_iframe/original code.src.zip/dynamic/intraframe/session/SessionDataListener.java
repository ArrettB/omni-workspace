package dynamic.intraframe.session;

import dynamic.intraframe.engine.ApplicationContext;
import javax.servlet.http.HttpServletRequest;

public abstract interface SessionDataListener
{
  public abstract void initialize(ApplicationContext paramApplicationContext);

  public abstract void afterSessionCreated(SessionData paramSessionData, HttpServletRequest paramHttpServletRequest);

  public abstract void beforeSessionDestroyed(SessionData paramSessionData);

  public abstract void afterSessionRestored(SessionData paramSessionData, HttpServletRequest paramHttpServletRequest);

  public abstract void beforeSessionSaved(SessionData paramSessionData);

  public abstract void destroy();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.session.SessionDataListener
 * JD-Core Version:    0.6.2
 */