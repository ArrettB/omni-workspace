/*    */ package dynamic.intraframe.filter;
/*    */ 
/*    */ import dynamic.dbtk.parser.Sql;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ 
/*    */ public class OrderByFilter extends QueryFilter
/*    */ {
/*    */   public Sql process(InvocationContext ic, Sql query, String params)
/*    */   {
/* 16 */     query.setOrderBy("ORDER BY " + params);
/* 17 */     return query;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.filter.OrderByFilter
 * JD-Core Version:    0.6.2
 */