/*    */ package dynamic.intraframe.filter;
/*    */ 
/*    */ import dynamic.dbtk.parser.Sql;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ 
/*    */ public abstract class QueryFilter
/*    */ {
/*    */   private String name;
/*    */ 
/*    */   public QueryFilter initialize(String name)
/*    */   {
/* 19 */     this.name = name;
/* 20 */     return this;
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 29 */     return this.name;
/*    */   }
/*    */ 
/*    */   public abstract Sql process(InvocationContext paramInvocationContext, Sql paramSql, String paramString)
/*    */     throws Exception;
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.filter.QueryFilter
 * JD-Core Version:    0.6.2
 */