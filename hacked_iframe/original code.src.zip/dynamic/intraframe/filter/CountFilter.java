/*    */ package dynamic.intraframe.filter;
/*    */ 
/*    */ import dynamic.dbtk.parser.Sql;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ 
/*    */ public class CountFilter extends QueryFilter
/*    */ {
/*    */   public Sql process(InvocationContext ic, Sql query, String params)
/*    */     throws Exception
/*    */   {
/* 18 */     StringBuffer result = new StringBuffer();
/* 19 */     result.append("SELECT count(*) FROM (");
/* 20 */     query.includeOrderBy(false);
/* 21 */     result.append(query.getQuery());
/* 22 */     query.includeOrderBy(true);
/* 23 */     result.append(") countQuery");
/* 24 */     return Sql.fetchSql(result);
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.filter.CountFilter
 * JD-Core Version:    0.6.2
 */