/*    */ package dynamic.intraframe.filter;
/*    */ 
/*    */ import dynamic.dbtk.parser.Sql;
/*    */ import dynamic.intraframe.engine.InvocationContext;
/*    */ 
/*    */ public class SimpleFilter extends QueryFilter
/*    */ {
/*    */   public Sql process(InvocationContext ic, Sql query, String params)
/*    */   {
/* 17 */     if (params == null) return query;
/* 18 */     query.addWhereAndClause("(" + params + ")");
/* 19 */     return query;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.filter.SimpleFilter
 * JD-Core Version:    0.6.2
 */