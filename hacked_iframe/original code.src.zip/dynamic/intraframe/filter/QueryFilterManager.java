/*     */ package dynamic.intraframe.filter;
/*     */ 
/*     */ import dynamic.dbtk.parser.Sql;
/*     */ import dynamic.intraframe.engine.ApplicationContext;
/*     */ import dynamic.intraframe.engine.InvocationContext;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class QueryFilterManager
/*     */ {
/*  30 */   protected Hashtable filters = new Hashtable();
/*     */ 
/*     */   public QueryFilterManager initialize(ApplicationContext ac) throws Exception
/*     */   {
/*  34 */     Document config = ac.getConfigDocument();
/*  35 */     Element top = XMLUtils.getSingleElement(config, "queryFilterManager");
/*  36 */     NodeList list = XMLUtils.getElementsByTagName(top, "queryFilter");
/*  37 */     for (int x = 0; x < list.getLength(); x++)
/*     */     {
/*  39 */       Element element = (Element)list.item(x);
/*  40 */       String name = element.getAttribute("name");
/*  41 */       String className = element.getAttribute("class");
/*  42 */       QueryFilter filter = ((QueryFilter)ac.loadClass(className).newInstance()).initialize(name);
/*  43 */       addFilter(name, filter);
/*     */     }
/*     */ 
/*  46 */     return this;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  51 */     Enumeration e = this.filters.elements();
/*  52 */     while (e.hasMoreElements())
/*     */     {
/*  54 */       QueryFilter filter = (QueryFilter)e.nextElement();
/*     */       try
/*     */       {
/*  57 */         filter.destroy();
/*     */       }
/*     */       catch (Throwable t)
/*     */       {
/*  61 */         Diagnostics.error("Problem trying to destroy " + filter, t);
/*     */       }
/*     */     }
/*  64 */     this.filters.clear();
/*  65 */     this.filters = null;
/*     */   }
/*     */ 
/*     */   public QueryFilter getFilter(String name) throws Exception
/*     */   {
/*  70 */     QueryFilter result = (QueryFilter)this.filters.get(name);
/*  71 */     if (result == null) throw new Exception("QueryFilter \"" + name + "\" was not found");
/*  72 */     return result;
/*     */   }
/*     */ 
/*     */   public void addFilter(String name, QueryFilter filter)
/*     */   {
/*  77 */     this.filters.put(name, filter);
/*     */   }
/*     */ 
/*     */   public Sql process(InvocationContext ic, Sql query, String filter_list) throws Exception
/*     */   {
/*  82 */     Vector filters = StringUtil.stringToVector(filter_list, ';');
/*  83 */     if (filters == null) return query;
/*     */ 
/*  85 */     for (int i = 0; i < filters.size(); i++)
/*     */     {
/*  87 */       String name = (String)filters.elementAt(i);
/*  88 */       name = name.trim();
/*  89 */       String params = null;
/*  90 */       int begin = name.indexOf("(");
/*  91 */       int end = name.lastIndexOf(")");
/*  92 */       if ((begin != -1) && (end != -1) && (begin < end))
/*     */       {
/*  94 */         params = name.substring(begin + 1, end);
/*  95 */         name = name.substring(0, begin);
/*     */       }
/*  97 */       QueryFilter filter = getFilter(name.trim());
/*  98 */       query = filter.process(ic, query, params);
/*     */     }
/*     */ 
/* 101 */     return query;
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.filter.QueryFilterManager
 * JD-Core Version:    0.6.2
 */