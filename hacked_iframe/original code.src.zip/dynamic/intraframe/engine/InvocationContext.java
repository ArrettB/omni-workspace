package dynamic.intraframe.engine;

import dynamic.dbtk.parser.Sql;
import dynamic.intraframe.session.SessionData;
import dynamic.intraframe.templates.Template;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface InvocationContext extends ApplicationContext
{
  public abstract void initialize(ApplicationContext paramApplicationContext, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, SessionData paramSessionData)
    throws Exception;

  public abstract void destroy();

  public abstract HttpServletRequest getHttpServletRequest();

  public abstract HttpServletResponse getHttpServletResponse();

  public abstract String getSessionID();

  public abstract Object getSessionDatum(String paramString);

  public abstract Object getRequiredSessionDatum(String paramString)
    throws Exception;

  public abstract void setSessionDatum(String paramString, Object paramObject);

  public abstract void removeSessionDatum(String paramString);

  public abstract boolean containsSessionDatum(String paramString);

  public abstract void clearSessionData();

  public abstract Enumeration getSessionKeys();

  public abstract Object getTransientDatum(String paramString);

  public abstract Object getRequiredTransientDatum(String paramString)
    throws Exception;

  public abstract void setTransientDatum(String paramString, Object paramObject);

  public abstract void removeTransientDatum(String paramString);

  public abstract void clearTransientData();

  public abstract boolean containsTransientDatum(String paramString);

  public abstract Enumeration getTransientKeys();

  public abstract String getParameter(String paramString);

  public abstract String[] getParameterValues(String paramString);

  public abstract String getRequiredParameter(String paramString)
    throws Exception;

  public abstract void setParameter(String paramString1, String paramString2);

  public abstract void setParameterValues(String paramString, String[] paramArrayOfString);

  public abstract void removeParameter(String paramString);

  public abstract void clearParameters();

  public abstract boolean containsParameter(String paramString);

  public abstract Enumeration getParameterKeys();

  public abstract Object getRowDatum(String paramString)
    throws Exception;

  public abstract Object getRowDatum(String paramString1, String paramString2)
    throws Exception;

  public abstract String getConfigValue(String paramString)
    throws Exception;

  public abstract void sendRedirect(String paramString)
    throws IOException;

  public abstract boolean isRedirected();

  public abstract void setImmediateAction(ApplicationServerAction paramApplicationServerAction);

  public abstract ApplicationServerAction getImmediateAction();

  public abstract void setPendingSuccessAction(ApplicationServerAction paramApplicationServerAction, String paramString);

  public abstract ApplicationServerAction getPendingSuccessAction(String paramString);

  public abstract void setCookie(Cookie paramCookie);

  public abstract Cookie getCookie(String paramString);

  public abstract boolean dispatchAction(String paramString)
    throws Exception;

  public abstract boolean dispatchHandler(String paramString)
    throws Exception;

  public abstract String getAction();

  public abstract void setAction(String paramString);

  public abstract String getHTMLTemplateName();

  public abstract void setHTMLTemplateName(String paramString);

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, String paramString4)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, String paramString4, boolean paramBoolean)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, Template paramTemplate)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, Template paramTemplate, boolean paramBoolean)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, String paramString4, Object paramObject)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, String paramString4, Object paramObject, boolean paramBoolean)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, Template paramTemplate, Object paramObject)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, Template paramTemplate, Object paramObject, boolean paramBoolean)
    throws Exception;

  public abstract void sendMail(String paramString1, String paramString2, String paramString3, Date paramDate, String paramString4, Object paramObject, String paramString5, boolean paramBoolean)
    throws Exception;

  public abstract boolean isInternetExplorer();

  public abstract boolean isInternetExplorer(int paramInt);

  public abstract boolean isNetscape();

  public abstract boolean isNetscape(int paramInt);

  public abstract Sql processFilter(Sql paramSql, String paramString)
    throws Exception;

  public abstract String processFilter(String paramString1, String paramString2)
    throws Exception;

  public abstract void setHTML2PDF(String paramString)
    throws Exception;

  public abstract void setHTML2PDF(Hashtable paramHashtable)
    throws Exception;
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.InvocationContext
 * JD-Core Version:    0.6.2
 */