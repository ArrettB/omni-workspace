package dynamic.intraframe.engine;

public abstract interface Daemon extends Runnable
{
  public abstract void initialize(ApplicationContext paramApplicationContext, String paramString)
    throws Exception;

  public abstract void destroy();

  public abstract String getName();

  public abstract String toHTML(String paramString, boolean paramBoolean);

  public abstract void start();

  public abstract void stop();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.Daemon
 * JD-Core Version:    0.6.2
 */