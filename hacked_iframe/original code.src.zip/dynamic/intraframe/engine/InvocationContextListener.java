package dynamic.intraframe.engine;

public abstract interface InvocationContextListener
{
  public abstract void initialize(Configuration paramConfiguration);

  public abstract void afterContextCreated(InvocationContext paramInvocationContext);

  public abstract void beforeContextDestroyed(InvocationContext paramInvocationContext);

  public abstract void destroy();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.InvocationContextListener
 * JD-Core Version:    0.6.2
 */