/*     */ package dynamic.intraframe.engine;
/*     */ 
/*     */ import dynamic.dbtk.connection.ConnectionWrapper;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.resources.ResourceManager;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class TestDaemon
/*     */   implements Daemon
/*     */ {
/*  24 */   private ResourceManager resourceManager = null;
/*  25 */   private String name = null;
/*  26 */   private Thread tid = null;
/*     */ 
/*     */   public void initialize(ApplicationContext ac, String name)
/*     */   {
/*  34 */     Diagnostics.trace("TestDaemon.initialize(ac,\"" + name + "\")");
/*  35 */     this.name = name;
/*  36 */     this.resourceManager = ((BaseApplicationContext)ac).getResourceManager();
/*  37 */     Document d = ac.getConfigDocument();
/*  38 */     initialize(d);
/*     */   }
/*     */ 
/*     */   public void initialize(String path, String name)
/*     */     throws Exception
/*     */   {
/*  47 */     Diagnostics.trace("TestDaemon.initialize(\"" + path + "\",\"" + name + "\")");
/*  48 */     this.name = name;
/*  49 */     Document d = XMLUtils.parse(new File(path));
/*  50 */     Element diagnosticsElement = XMLUtils.getSingleElement(d, "diagnostics");
/*  51 */     if (diagnosticsElement != null)
/*     */     {
/*  53 */       Diagnostics.initialize(diagnosticsElement);
/*     */     }
/*  55 */     Element resourceManagerElement = XMLUtils.getSingleElement(d, "resourceManager");
/*  56 */     if (resourceManagerElement != null)
/*     */     {
/*  58 */       String className = resourceManagerElement.getAttribute("class");
/*  59 */       this.resourceManager = ((ResourceManager)Class.forName(className).newInstance());
/*  60 */       this.resourceManager.initialize(resourceManagerElement);
/*     */     }
/*  62 */     initialize(d);
/*     */   }
/*     */ 
/*     */   protected void initialize(Document d)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*  78 */     Diagnostics.trace("TestDaemon.destory()");
/*  79 */     stop();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  87 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String toHTML(String href, boolean showDetail)
/*     */   {
/*  95 */     Diagnostics.trace("TestDaemon.toHTML()");
/*  96 */     return toString();
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/* 104 */     Diagnostics.trace("TestDaemon.start()");
/* 105 */     this.tid = new Thread(this, this.name);
/* 106 */     Diagnostics.registerThread(this.tid);
/* 107 */     this.tid.start();
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 115 */     Diagnostics.trace("TestDaemon.stop()");
/* 116 */     if (this.tid == null) return;
/* 117 */     Thread tmp = this.tid;
/* 118 */     this.tid = null;
/* 119 */     tmp.interrupt();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 129 */       Diagnostics.trace("run() starting");
/* 130 */       while (this.tid == Thread.currentThread())
/*     */       {
/* 132 */         Diagnostics.trace("run()");
/* 133 */         ConnectionWrapper conn = null;
/*     */         try
/*     */         {
/* 136 */           conn = (ConnectionWrapper)this.resourceManager.getResource();
/* 137 */           conn.setAutoCommit(false);
/* 138 */           String query = "SELECT count(*) FROM dual";
/* 139 */           Diagnostics.debug(query);
/* 140 */           conn.queryEx(query);
/* 141 */           Diagnostics.debug("Query was successful");
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 145 */           Diagnostics.error("Problem with query", e);
/* 146 */           if (conn != null)
/*     */             try {
/* 148 */               conn.rollback();
/*     */             } catch (Exception ex) {
/*     */             }
/*     */         } finally {
/*     */           try {
/* 153 */             conn.setAutoCommit(true); } catch (Exception e) {
/*     */           }try { conn.release();
/*     */           } catch (Exception e) {
/*     */           }
/*     */         }
/*     */         try {
/* 159 */           Diagnostics.trace("Sleeping 60 seconds...");
/* 160 */           Thread.sleep(60000L);
/*     */         }
/*     */         catch (InterruptedException ie)
/*     */         {
/* 164 */           Diagnostics.debug("Sleep interrupted");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 170 */       Diagnostics.error("Problem in run()", t);
/*     */     }
/*     */ 
/* 173 */     Diagnostics.debug("run() complete");
/*     */   }
/*     */ 
/*     */   private static void usage()
/*     */   {
/* 181 */     System.out.println("usage: dynamic.intraframe.engine.TestDaemon configFile");
/* 182 */     System.exit(1);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 194 */       if ((args.length != 1) || ((args.length > 0) && (args[0].equals("-help")))) usage();
/* 195 */       Diagnostics.debug("main() starting");
/* 196 */       TestDaemon daemon = new TestDaemon();
/* 197 */       daemon.initialize(args[0], "TestDaemon");
/* 198 */       daemon.start();
/* 199 */       Diagnostics.debug("main() complete");
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 203 */       Diagnostics.error("Problem in main()", t);
/* 204 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.TestDaemon
 * JD-Core Version:    0.6.2
 */