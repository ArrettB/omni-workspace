/*     */ package dynamic.intraframe.engine;
/*     */ 
/*     */ import dynamic.util.classloader.DynamicClassLoader;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.diagnostics.DiagnosticsContext;
/*     */ import dynamic.util.diagnostics.DiagnosticsMessage;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.GenericServlet;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class BaseServlet extends HttpServlet
/*     */ {
/*  31 */   private ApplicationContext ac = null;
/*  32 */   private String configurationFileName = null;
/*  33 */   private Configuration config = null;
/*  34 */   private DiagnosticsContext diagnosticsContext = null;
/*  35 */   private DynamicClassLoader loader = null;
/*  36 */   private boolean reloadRequested = false;
/*  37 */   private DiagnosticsMessage initializationProblem = null;
/*  38 */   private String name = null;
/*     */ 
/*  40 */   private long requestCount = 0L;
/*  41 */   private long concurrentRequestCount = 0L;
/*  42 */   private long createdTime = 0L;
/*  43 */   private long loadedTime = 0L;
/*  44 */   private long totalTime = 0L;
/*  45 */   private long maxTime = -1L;
/*  46 */   private String maxURL = null;
/*  47 */   private long minTime = -1L;
/*  48 */   private String minURL = null;
/*  49 */   private long lastTime = 0L;
/*  50 */   private String lastURL = null;
/*  51 */   private DiagnosticsMessage lastProblem = null;
/*  52 */   private long maxUsedMemory = -1L;
/*  53 */   private long totalMemory = 0L;
/*  54 */   private long freeMemory = 0L;
/*  55 */   private long usedMemory = 0L;
/*  56 */   private boolean available = true;
/*     */ 
/*     */   public void init(ServletConfig config)
/*     */   {
/*     */     try
/*     */     {
/*  67 */       this.createdTime = System.currentTimeMillis();
/*  68 */       this.configurationFileName = config.getInitParameter("iniFile");
/*     */ 
/*  70 */       super.init(config);
/*     */ 
/*  72 */       if (this.ac != null) {
/*  73 */         throw new Exception("Attempt to initialize servlet more than once");
/*     */       }
/*  75 */       initialize();
/*     */     }
/*     */     catch (Throwable problem)
/*     */     {
/*  79 */       this.initializationProblem = (this.lastProblem = Diagnostics.fatal("Problem initializing servlet", problem));
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void initialize()
/*     */   {
/*     */     try
/*     */     {
/*  91 */       this.initializationProblem = null;
/*  92 */       this.loadedTime = System.currentTimeMillis();
/*  93 */       if ((this.configurationFileName == null) || (this.configurationFileName.length() == 0)) {
/*  94 */         throw new ConfigurationException("The configuration file was not specified");
/*     */       }
/*  96 */       this.reloadRequested = false;
/*  97 */       this.config = new Configuration(this.configurationFileName);
/*  98 */       Element diagnosticsElement = XMLUtils.getSingleElement(this.config.getConfigDocument(), "diagnostics");
/*  99 */       this.diagnosticsContext = Diagnostics.initialize(diagnosticsElement);
/*     */ 
/* 101 */       Element applicationContextElement = XMLUtils.getSingleElement(this.config.getConfigDocument(), "applicationContext");
/* 102 */       this.name = applicationContextElement.getAttribute("name");
/* 103 */       String version = applicationContextElement.getAttribute("version");
/* 104 */       if ((this.name != null) && (version != null)) this.name = (this.name + " version " + version);
/* 105 */       Diagnostics.status(this.name + " initializing...");
/* 106 */       initializeClassLoader(applicationContextElement);
/*     */ 
/* 109 */       String className = applicationContextElement.getAttribute("class");
/* 110 */       if ((className == null) || (className.length() == 0))
/* 111 */         throw new ConfigurationException("The applicationContext class was not specified");
/* 112 */       this.ac = ((ApplicationContext)this.loader.loadClass(className).newInstance());
/* 113 */       this.ac.initialize(this, this.config, this.loader);
/* 114 */       reportStatus(0L, System.currentTimeMillis() - this.loadedTime);
/* 115 */       Diagnostics.status(this.name + " initialization complete.");
/*     */     }
/*     */     catch (Throwable problem)
/*     */     {
/* 119 */       this.ac = null;
/* 120 */       this.config = null;
/* 121 */       this.initializationProblem = (this.lastProblem = Diagnostics.fatal("Problem initializing servlet", problem));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initializeClassLoader(Element e)
/*     */   {
/* 131 */     String path = e.getAttribute("dynamicClassPath");
/* 132 */     if ((path != null) && (path.length() > 0))
/*     */     {
/* 134 */       String currentPath = System.getProperty("dynamic.class.path");
/* 135 */       currentPath = StringUtil.appendUnique(currentPath, path, ';');
/* 136 */       Properties p = System.getProperties();
/* 137 */       p.put("dynamic.class.path", currentPath);
/* 138 */       System.setProperties(p);
/*     */     }
/*     */ 
/* 141 */     this.loader = new DynamicClassLoader();
/*     */   }
/*     */ 
/*     */   private boolean shouldReload()
/*     */   {
/* 149 */     if (this.initializationProblem != null)
/*     */     {
/* 151 */       Diagnostics.status("Reloading because previous initialization failed");
/* 152 */       return true;
/*     */     }
/* 154 */     if (this.reloadRequested)
/*     */     {
/* 156 */       Diagnostics.status("Reloading because it was requested by an admin user");
/* 157 */       return true;
/*     */     }
/* 159 */     if ((this.config != null) && (this.config.shouldReload()))
/*     */     {
/* 161 */       Diagnostics.status("Reloading because the configuration file has changed");
/* 162 */       return true;
/*     */     }
/* 164 */     if ((this.loader != null) && (this.loader.shouldReload()))
/*     */     {
/* 166 */       Diagnostics.status("Reloading because the program has been changed");
/* 167 */       return true;
/*     */     }
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */   public void service(HttpServletRequest req, HttpServletResponse res)
/*     */     throws ServletException
/*     */   {
/* 179 */     long requestNumber = ++this.requestCount;
/* 180 */     long startTime = System.currentTimeMillis();
/* 181 */     this.concurrentRequestCount += 1L;
/* 182 */     String requestURL = req.getRequestURI() + (req.getQueryString() == null ? "" : new StringBuffer().append("?").append(req.getQueryString()).toString());
/*     */     try
/*     */     {
/* 186 */       Diagnostics.registerThread(this.diagnosticsContext);
/* 187 */       if (req != null) Diagnostics.status("#" + requestNumber + " - " + requestURL);
/* 188 */       if ((!this.available) || (shouldReload()))
/*     */       {
/* 190 */         synchronized (this)
/*     */         {
/* 192 */           if (shouldReload())
/*     */           {
/* 194 */             this.available = false;
/* 195 */             destroy();
/* 196 */             System.gc();
/* 197 */             initialize();
/* 198 */             this.available = true;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 203 */       if (this.initializationProblem != null)
/* 204 */         reportProblem(this.initializationProblem.toHTML(), res);
/* 205 */       else if (!this.available)
/* 206 */         reportProblem(this.name + " is currently unavailable.", res);
/* 207 */       else if (res != null)
/* 208 */         this.ac.handle(req, res);
/*     */     }
/*     */     catch (Throwable problem)
/*     */     {
/* 212 */       this.lastProblem = Diagnostics.error("Problem with service", problem);
/* 213 */       reportProblem(this.lastProblem.toHTML(), res);
/*     */     }
/*     */     finally
/*     */     {
/* 217 */       this.concurrentRequestCount -= 1L;
/* 218 */       long currentTime = System.currentTimeMillis();
/* 219 */       this.lastTime = (currentTime - startTime);
/* 220 */       this.lastURL = requestURL;
/* 221 */       if ((this.minTime == -1L) || (this.lastTime < this.minTime))
/*     */       {
/* 223 */         this.minTime = this.lastTime;
/* 224 */         this.minURL = requestURL;
/*     */       }
/* 226 */       if ((this.maxTime == -1L) || (this.lastTime > this.maxTime))
/*     */       {
/* 228 */         this.maxTime = this.lastTime;
/* 229 */         this.maxURL = requestURL;
/*     */       }
/* 231 */       this.totalTime += this.lastTime;
/* 232 */       reportStatus(requestNumber, this.lastTime);
/* 233 */       Diagnostics.releaseThread(Thread.currentThread());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void reportProblem(String problem, HttpServletResponse res)
/*     */   {
/*     */     try
/*     */     {
/* 246 */       PrintWriter p = new PrintWriter(res.getOutputStream());
/* 247 */       p.print("<html><body><pre>" + problem + "</pre></body></html>");
/* 248 */       p.flush();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void reportStatus(long requestNumber, long elapsedTime)
/*     */   {
/* 263 */     Runtime runtime = Runtime.getRuntime();
/* 264 */     runtime.gc();
/* 265 */     this.totalMemory = runtime.totalMemory();
/* 266 */     this.freeMemory = runtime.freeMemory();
/* 267 */     this.usedMemory = (this.totalMemory - this.freeMemory);
/* 268 */     Diagnostics.status("#" + requestNumber + " - Time:" + elapsedTime + "ms - Java Heap - Size:" + this.totalMemory / 1024L + "K - Used:" + this.freeMemory / 1024L + "K");
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 273 */     Diagnostics.registerThread(this.diagnosticsContext);
/* 274 */     Diagnostics.status(this.name + " shutting down...");
/*     */     try
/*     */     {
/* 278 */       if (this.ac != null) this.ac.destroy();
/* 279 */       this.ac = null;
/*     */     }
/*     */     catch (Throwable t) {
/*     */     }
/* 283 */     Diagnostics.status(this.name + " shutdown complete.");
/* 284 */     Diagnostics.destroy();
/*     */ 
/* 286 */     this.config = null;
/* 287 */     this.loader = null;
/*     */   }
/*     */ 
/*     */   public void requestReload()
/*     */   {
/* 295 */     this.reloadRequested = true;
/*     */   }
/*     */ 
/*     */   public DiagnosticsMessage getLastProblem()
/*     */   {
/* 303 */     return this.lastProblem;
/*     */   }
/*     */ 
/*     */   public long getRequestCount()
/*     */   {
/* 311 */     return this.requestCount;
/*     */   }
/*     */ 
/*     */   public long getTotalTime()
/*     */   {
/* 319 */     return this.totalTime;
/*     */   }
/*     */ 
/*     */   public long getConcurrentRequestCount()
/*     */   {
/* 327 */     return this.concurrentRequestCount;
/*     */   }
/*     */ 
/*     */   public long getAverageTime()
/*     */   {
/* 335 */     if (this.requestCount == 0L) return 0L;
/* 336 */     return this.totalTime / this.requestCount;
/*     */   }
/*     */ 
/*     */   public long getLastTime()
/*     */   {
/* 344 */     return this.lastTime;
/*     */   }
/*     */ 
/*     */   public String getLastRequestURL()
/*     */   {
/* 352 */     return this.lastURL;
/*     */   }
/*     */ 
/*     */   public long getQuickestTime()
/*     */   {
/* 360 */     return this.minTime;
/*     */   }
/*     */ 
/*     */   public String getQuickestRequestURL()
/*     */   {
/* 368 */     return this.minURL;
/*     */   }
/*     */ 
/*     */   public long getLongestTime()
/*     */   {
/* 376 */     return this.maxTime;
/*     */   }
/*     */ 
/*     */   public String getLongestRequestURL()
/*     */   {
/* 384 */     return this.maxURL;
/*     */   }
/*     */ 
/*     */   public long getCreatedTime()
/*     */   {
/* 392 */     return this.createdTime;
/*     */   }
/*     */ 
/*     */   public long getLoadedTime()
/*     */   {
/* 400 */     return this.loadedTime;
/*     */   }
/*     */ 
/*     */   public long getTotalMemory()
/*     */   {
/* 408 */     return this.totalMemory;
/*     */   }
/*     */ 
/*     */   public long getFreeMemory()
/*     */   {
/* 416 */     return this.freeMemory;
/*     */   }
/*     */ 
/*     */   public long getUsedMemory()
/*     */   {
/* 424 */     return this.usedMemory;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 434 */       for (int i = 1; i <= 5; i++)
/*     */       {
/* 436 */         System.out.println("BaseServlet pass #" + i);
/* 437 */         System.out.println("BaseServlet creating an instance of BaseServlet");
/* 438 */         BaseServlet test = new BaseServlet();
/* 439 */         System.out.println("BaseServlet getting iniFile");
/* 440 */         test.configurationFileName = args[0];
/* 441 */         if ((test.configurationFileName == null) || (test.configurationFileName.length() == 0))
/* 442 */           throw new ConfigurationException("The servlet property iniFile is missing");
/* 443 */         System.out.println("BaseServlet testing initializing");
/* 444 */         test.initialize();
/* 445 */         System.out.println("BaseServlet testing service once");
/* 446 */         test.service(null, null);
/* 447 */         System.out.println("BaseServlet testing service again");
/* 448 */         test.service(null, null);
/* 449 */         System.out.println("BaseServlet testing destroy");
/* 450 */         test.destroy();
/* 451 */         System.out.println("BaseServlet pass #" + i + " complete");
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 456 */       t.printStackTrace();
/* 457 */       System.out.println("BaseServlet testing failed");
/*     */     }
/* 459 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.BaseServlet
 * JD-Core Version:    0.6.2
 */