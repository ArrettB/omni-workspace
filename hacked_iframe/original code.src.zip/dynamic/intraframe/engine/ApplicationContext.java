package dynamic.intraframe.engine;

import dynamic.intraframe.templates.Template;
import dynamic.util.resources.DynamicResource;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.w3c.dom.Document;

public abstract interface ApplicationContext
{
  public abstract void initialize(BaseServlet paramBaseServlet, Configuration paramConfiguration, ClassLoader paramClassLoader)
    throws Exception;

  public abstract void destroy();

  public abstract String toString();

  public abstract DynamicResource getResource()
    throws Exception;

  public abstract DynamicResource getResource(String paramString)
    throws Exception;

  public abstract Object getAppGlobalDatum(String paramString);

  public abstract Object getRequiredAppGlobalDatum(String paramString)
    throws Exception;

  public abstract void setAppGlobalDatum(String paramString, Object paramObject);

  public abstract void removeAppGlobalDatum(String paramString);

  public abstract void clearAppGlobalData();

  public abstract boolean containsAppGlobalDatum(String paramString);

  public abstract Enumeration getAppGlobalKeys();

  public abstract Configuration getConfig();

  public abstract Document getConfigDocument();

  public abstract Template getTemplate(String paramString)
    throws Exception;

  public abstract Provider getProvider(String paramString);

  public abstract void handle(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
    throws Exception;

  public abstract Class loadClass(String paramString)
    throws Exception;

  public abstract String format(Object paramObject, String paramString)
    throws Exception;

  /** @deprecated */
  public abstract String getActionParam();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.ApplicationContext
 * JD-Core Version:    0.6.2
 */