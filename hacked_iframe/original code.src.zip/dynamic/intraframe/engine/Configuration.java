/*    */ package dynamic.intraframe.engine;
/*    */ 
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ import dynamic.util.xml.XMLUtils;
/*    */ import java.io.File;
/*    */ import org.w3c.dom.Document;
/*    */ 
/*    */ public class Configuration
/*    */ {
/*    */   public static final String AC = "applicationContext";
/*    */   public static final String AC_LISTENER = "applicationContextListener";
/*    */   public static final String ACTION = "action";
/*    */ 
/*    */   /** @deprecated */
/*    */   public static final String ACTION_PARAM = "actionParameter";
/*    */   public static final String AG_DATUM = "appGlobalDatum";
/*    */   public static final String DAEMON = "daemon";
/*    */   public static final String DAEMONS = "daemons";
/*    */   public static final String DIAGNOSTICS = "diagnostics";
/*    */   public static final String DISPATCHER = "dispatcher";
/*    */   public static final String FORMAT = "format";
/*    */   public static final String HANDLER = "handler";
/*    */   public static final String IC_LISTENER = "invocationContextListener";
/*    */   public static final String IC = "invocationContext";
/*    */   public static final String MATCH = "match";
/*    */   public static final String PROPERTY = "property";
/*    */   public static final String PROVIDER = "provider";
/*    */   public static final String PROVIDERS = "providers";
/*    */   public static final String QUERY_FILTER_MANAGER = "queryFilterManager";
/*    */   public static final String REPLACE = "replace";
/*    */   public static final String RESOURCE_MANAGER = "resourceManager";
/*    */   public static final String SESSION_LISTENER = "sessionListener";
/*    */   public static final String SESSION_MANAGER = "sessionManager";
/*    */   public static final String SUB = "substitution";
/*    */   public static final String TEMPLATE_MANAGER = "templateManager";
/*    */   public static final String TEMP_COMP = "templateComponent";
/* 49 */   private File file = null;
/* 50 */   private Document config = null;
/* 51 */   private long lastModified = 0L;
/*    */ 
/*    */   public Configuration()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Configuration(String filename) throws Exception
/*    */   {
/* 59 */     this.file = new File(filename);
/* 60 */     this.lastModified = this.file.lastModified();
/* 61 */     this.config = XMLUtils.parse(this.file);
/*    */   }
/*    */ 
/*    */   public File getFile()
/*    */   {
/* 66 */     return this.file;
/*    */   }
/*    */ 
/*    */   public Document getConfigDocument()
/*    */   {
/* 71 */     return this.config;
/*    */   }
/*    */ 
/*    */   public boolean shouldReload()
/*    */   {
/* 76 */     if (this.lastModified != this.file.lastModified())
/*    */     {
/* 78 */       Diagnostics.debug("BaseConfiguration.shouldReload() returning true " + this.lastModified + " != " + this.file.lastModified());
/* 79 */       return true;
/*    */     }
/*    */ 
/* 82 */     return false;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.Configuration
 * JD-Core Version:    0.6.2
 */