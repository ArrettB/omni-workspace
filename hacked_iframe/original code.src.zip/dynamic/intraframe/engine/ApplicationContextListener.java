package dynamic.intraframe.engine;

public abstract interface ApplicationContextListener
{
  public abstract void initialize(Configuration paramConfiguration);

  public abstract void afterContextCreated(ApplicationContext paramApplicationContext);

  public abstract void beforeContextDestroyed(ApplicationContext paramApplicationContext);

  public abstract void destroy();
}

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.ApplicationContextListener
 * JD-Core Version:    0.6.2
 */