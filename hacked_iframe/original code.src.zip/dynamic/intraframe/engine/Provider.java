/*    */ package dynamic.intraframe.engine;
/*    */ 
/*    */ public class Provider
/*    */ {
/*  5 */   private String name = null;
/*  6 */   private String id = null;
/*  7 */   private String type = null;
/*    */ 
/*    */   public Provider(String name, String id, String type)
/*    */   {
/* 11 */     this.name = name;
/* 12 */     this.id = id;
/* 13 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 18 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getId()
/*    */   {
/* 23 */     return this.id;
/*    */   }
/*    */ 
/*    */   public String getType()
/*    */   {
/* 28 */     return this.type;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 32 */     return getClass().getName() + ": name=" + this.name + " id=" + this.id + " type=" + this.type;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.Provider
 * JD-Core Version:    0.6.2
 */