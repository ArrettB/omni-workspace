/*    */ package dynamic.intraframe.engine;
/*    */ 
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ 
/*    */ public class TestInvocationContextListener
/*    */   implements InvocationContextListener
/*    */ {
/*    */   public void initialize(Configuration config)
/*    */   {
/*  9 */     Diagnostics.trace("TestInvocationContextListener.initialize()");
/*    */   }
/*    */ 
/*    */   public void afterContextCreated(InvocationContext ic) {
/* 13 */     Diagnostics.trace("TestInvocationContextListener.afterContextCreated()");
/*    */   }
/*    */ 
/*    */   public void beforeContextDestroyed(InvocationContext ic) {
/* 17 */     Diagnostics.trace("TestInvocationContextListener.beforeContextDestroyed()");
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 21 */     Diagnostics.trace("TestInvocationContextListener.destory()");
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.TestInvocationContextListener
 * JD-Core Version:    0.6.2
 */