/*    */ package dynamic.intraframe.engine;
/*    */ 
/*    */ import dynamic.util.diagnostics.Diagnostics;
/*    */ 
/*    */ public class TestApplicationContextListener
/*    */   implements ApplicationContextListener
/*    */ {
/*    */   public void initialize(Configuration config)
/*    */   {
/*  9 */     Diagnostics.trace("TestApplicationContextListener.initialize()");
/*    */   }
/*    */ 
/*    */   public void afterContextCreated(ApplicationContext ac) {
/* 13 */     Diagnostics.trace("TestApplicationContextListener.afterContextCreated()");
/*    */   }
/*    */ 
/*    */   public void beforeContextDestroyed(ApplicationContext ac) {
/* 17 */     Diagnostics.trace("TestApplicationContextListener.beforeContextDestroyed()");
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 21 */     Diagnostics.trace("TestApplicationContextListener.destory()");
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.TestApplicationContextListener
 * JD-Core Version:    0.6.2
 */