/*     */ package dynamic.intraframe.engine;
/*     */ 
/*     */ import dynamic.dbtk.connection.QueryResults;
/*     */ import dynamic.dbtk.parser.Sql;
/*     */ import dynamic.intraframe.filter.QueryFilterManager;
/*     */ import dynamic.intraframe.handlers.Dispatcher;
/*     */ import dynamic.intraframe.session.SessionData;
/*     */ import dynamic.intraframe.session.SessionManager;
/*     */ import dynamic.intraframe.templates.Template;
/*     */ import dynamic.intraframe.templates.TemplateManager;
/*     */ import dynamic.intraframe.templates.components.SQLLoopComponent;
/*     */ import dynamic.util.diagnostics.Diagnostics;
/*     */ import dynamic.util.html2pdf.Html2pdf;
/*     */ import dynamic.util.html2pdf.Request;
/*     */ import dynamic.util.mail.MailSender;
/*     */ import dynamic.util.resources.DynamicResource;
/*     */ import dynamic.util.resources.ResourceManager;
/*     */ import dynamic.util.sorting.Sort;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import dynamic.util.xml.XMLUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ public class BaseInvocationContext
/*     */   implements InvocationContext
/*     */ {
/*  45 */   private BaseApplicationContext ac = null;
/*  46 */   private HttpServletRequest req = null;
/*  47 */   private HttpServletResponse res = null;
/*  48 */   private SessionData session = null;
/*  49 */   private Vector listeners = null;
/*  50 */   private Hashtable transientData = null;
/*  51 */   private Hashtable parameterData = null;
/*  52 */   private boolean redirectRequested = false;
/*  53 */   private ApplicationServerAction immediateAction = null;
/*  54 */   private String action = null;
/*  55 */   private String template = null;
/*  56 */   private DynamicResource defaultResource = null;
/*     */ 
/*     */   public BaseInvocationContext()
/*     */   {
/*  60 */     this.transientData = new Hashtable();
/*  61 */     this.parameterData = new Hashtable();
/*  62 */     this.listeners = new Vector();
/*     */   }
/*     */ 
/*     */   public void initialize(ApplicationContext ac, HttpServletRequest req, HttpServletResponse res, SessionData session) throws Exception
/*     */   {
/*  67 */     this.ac = ((BaseApplicationContext)ac);
/*  68 */     this.req = req;
/*  69 */     this.res = res;
/*  70 */     this.session = session;
/*     */ 
/*  73 */     parseURL();
/*     */ 
/*  75 */     if (req != null)
/*     */     {
/*  77 */       Enumeration keys = req.getParameterNames();
/*  78 */       while (keys.hasMoreElements())
/*     */       {
/*  80 */         String s = (String)keys.nextElement();
/*  81 */         String[] values = req.getParameterValues(s);
/*  82 */         if (values.length == 1) setParameter(s, values[0]); else {
/*  83 */           setParameterValues(s, values);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  88 */     Document xmlDoc = getConfigDocument();
/*  89 */     Element invocationContextElement = XMLUtils.getSingleElement(xmlDoc, "invocationContext");
/*  90 */     if (invocationContextElement == null) {
/*  91 */       throw new ConfigurationException("Could not element invocationContext");
/*     */     }
/*     */ 
/*  94 */     NodeList nodes = invocationContextElement.getElementsByTagName("invocationContextListener");
/*  95 */     for (int i = 0; i < nodes.getLength(); i++)
/*     */     {
/*  97 */       Element listenerElement = (Element)nodes.item(i);
/*  98 */       String listenerClass = listenerElement.getAttribute("class");
/*  99 */       InvocationContextListener temp = (InvocationContextListener)ac.loadClass(listenerClass).newInstance();
/* 100 */       if (temp != null)
/*     */       {
/* 102 */         temp.initialize(ac.getConfig());
/* 103 */         this.listeners.addElement(temp);
/*     */       }
/*     */     }
/*     */ 
/* 107 */     fireAfterContextCreated();
/*     */   }
/*     */ 
/*     */   public void destroy() {
/*     */     try {
/* 112 */       writeSessionData(); } catch (Exception e) {
/*     */     }try { fireBeforeContextDestroyed(); } catch (Exception e) {
/*     */     }
/* 115 */     if (this.listeners != null)
/*     */     {
/* 117 */       for (int x = 0; x < this.listeners.size(); x++)
/* 118 */         ((InvocationContextListener)this.listeners.elementAt(x)).destroy();
/* 119 */       this.listeners.removeAllElements();
/* 120 */       this.listeners = null;
/*     */     }
/*     */ 
/* 123 */     if (this.defaultResource != null) this.defaultResource.release(true);
/*     */ 
/* 125 */     if (this.transientData != null)
/*     */     {
/* 127 */       this.transientData.clear();
/* 128 */       this.transientData = null;
/*     */     }
/*     */ 
/* 131 */     if (this.parameterData != null)
/*     */     {
/* 133 */       this.parameterData.clear();
/* 134 */       this.parameterData = null;
/*     */     }
/*     */ 
/* 137 */     this.session = null;
/* 138 */     this.res = null;
/* 139 */     this.req = null;
/* 140 */     this.ac = null;
/* 141 */     this.action = null;
/* 142 */     this.template = null;
/* 143 */     this.immediateAction = null;
/*     */   }
/*     */ 
/*     */   public void parseURL() throws Exception
/*     */   {
/* 148 */     if (this.req == null) return;
/*     */ 
/* 150 */     String currentAction = null;
/* 151 */     String currentTemplate = null;
/*     */ 
/* 154 */     String pathInfo = this.req.getPathInfo();
/* 155 */     if ((pathInfo != null) && (pathInfo.length() > 0) && (pathInfo.charAt(0) == '/')) pathInfo = pathInfo.substring(1);
/* 156 */     Vector parts = StringUtil.stringToVector(pathInfo, '/');
/* 157 */     if (parts != null)
/*     */     {
/* 159 */       if (parts.size() > 0)
/*     */       {
/* 161 */         if (getSessionID().equals("/" + parts.elementAt(0)))
/*     */         {
/* 163 */           pathInfo = pathInfo.substring(getSessionID().length() - 1);
/* 164 */           if ((pathInfo.length() > 0) && (pathInfo.charAt(0) == '/')) pathInfo = pathInfo.substring(1);
/* 165 */           parts.removeElementAt(0);
/*     */         }
/*     */       }
/* 168 */       if (parts.size() > 0)
/*     */       {
/* 170 */         String a = (String)parts.elementAt(0);
/* 171 */         if (getDispatcher().isValidAction(a))
/*     */         {
/* 173 */           pathInfo = pathInfo.substring(a.length());
/* 174 */           if ((pathInfo.length() > 0) && (pathInfo.charAt(0) == '/')) pathInfo = pathInfo.substring(1);
/* 175 */           parts.removeElementAt(0);
/* 176 */           currentAction = a;
/*     */         }
/*     */       }
/* 179 */       if (parts.size() > 0)
/*     */       {
/* 181 */         String t = pathInfo;
/* 182 */         if (getTemplateManager().isValidTemplate(t))
/* 183 */           currentTemplate = t;
/* 184 */         else if (getTemplateManager().isValidTemplate(t + File.separatorChar + "index"))
/* 185 */           currentTemplate = t + File.separatorChar + "index";
/*     */         else {
/* 187 */           currentTemplate = t;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 192 */     String a = null;
/* 193 */     if (getActionParam() != null) a = this.req.getParameter(getActionParam());
/* 194 */     if (a != null)
/*     */     {
/* 196 */       Diagnostics.warning(getActionParam() + " parameter is deprecated");
/*     */ 
/* 198 */       if (currentAction != null) {
/* 199 */         throw new Exception("action found in URI " + currentAction + " and in query string " + a);
/*     */       }
/* 201 */       currentAction = a;
/*     */     }
/*     */ 
/* 205 */     if (currentAction == null) currentAction = getDispatcher().getDefaultAction();
/*     */ 
/* 207 */     if ((currentAction != null) && (!currentAction.equals("showPage"))) {
/* 208 */       setAction(currentAction);
/*     */     }
/*     */ 
/* 211 */     String t = this.req.getParameter("page");
/* 212 */     if (t != null)
/*     */     {
/* 214 */       Diagnostics.warning("page parameter is deprecated");
/*     */ 
/* 216 */       if (currentTemplate != null) {
/* 217 */         throw new Exception("template found in URI " + currentTemplate + " and in query string " + t);
/*     */       }
/* 219 */       currentTemplate = t;
/*     */     }
/*     */ 
/* 222 */     if ((currentAction == null) && (currentTemplate == null)) {
/* 223 */       currentTemplate = "index";
/*     */     }
/* 225 */     if (currentTemplate != null)
/* 226 */       setHTMLTemplateName(currentTemplate);
/*     */   }
/*     */ 
/*     */   public Object getSessionDatum(String datumName)
/*     */   {
/* 231 */     if (this.session == null)
/*     */     {
/* 233 */       Diagnostics.warning("Attempted to retrieve session data \"" + datumName + "\" before a session was attached to the InvocationContext");
/* 234 */       return null;
/*     */     }
/* 236 */     return this.session.get(datumName);
/*     */   }
/*     */ 
/*     */   public Object getRequiredSessionDatum(String datumName) throws Exception
/*     */   {
/* 241 */     Object result = getSessionDatum(datumName);
/* 242 */     if (result == null)
/* 243 */       throw new Exception("Missing required session datum \"" + datumName + "\"");
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   public void setSessionDatum(String datumName, Object datum)
/*     */   {
/* 249 */     if (this.session == null)
/*     */     {
/* 251 */       Diagnostics.warning("Attempted to set session datum \"" + datumName + "\" before a session was attached to the InvocationContext");
/* 252 */       return;
/*     */     }
/*     */ 
/* 255 */     if (datum == null)
/*     */     {
/* 257 */       Diagnostics.warning("Setting session datum \"" + datumName + "\" to null");
/* 258 */       this.session.remove(datumName);
/*     */     }
/*     */     else
/*     */     {
/* 262 */       this.session.put(datumName, datum);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeSessionDatum(String datumName)
/*     */   {
/* 268 */     if (this.session == null)
/*     */     {
/* 270 */       Diagnostics.warning("Attempted to remove session datum \"" + datumName + "\" before a session was attached to the InvocationContext");
/* 271 */       return;
/*     */     }
/* 273 */     this.session.remove(datumName);
/*     */   }
/*     */ 
/*     */   public Enumeration getSessionKeys()
/*     */   {
/* 278 */     if (this.session == null)
/*     */     {
/* 280 */       Diagnostics.warning("Attempted to get session keys before a session was attached to the InvocationContext");
/* 281 */       return null;
/*     */     }
/* 283 */     return this.session.keys();
/*     */   }
/*     */ 
/*     */   public boolean containsSessionDatum(String datumName)
/*     */   {
/* 288 */     if (this.session == null)
/*     */     {
/* 290 */       Diagnostics.warning("Attempted to check for session datum \"" + datumName + "\" before a session was attached to the InvocationContext");
/* 291 */       return false;
/*     */     }
/* 293 */     return this.session.containsKey(datumName);
/*     */   }
/*     */ 
/*     */   public void clearSessionData()
/*     */   {
/* 298 */     if (this.session == null)
/*     */     {
/* 300 */       Diagnostics.warning("Attempted to clear session data before a session was attached to the InvocationContext");
/* 301 */       return;
/*     */     }
/* 303 */     this.session.clear();
/*     */   }
/*     */ 
/*     */   public SessionData getHttpSession()
/*     */   {
/* 308 */     return this.session;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getHttpServletRequest()
/*     */   {
/* 313 */     return this.req;
/*     */   }
/*     */ 
/*     */   public void setHttpServletRequest(HttpServletRequest req)
/*     */   {
/* 318 */     this.req = req;
/*     */   }
/*     */ 
/*     */   public HttpServletResponse getHttpServletResponse()
/*     */   {
/* 323 */     return this.res;
/*     */   }
/*     */ 
/*     */   public void setHttpServletResponse(HttpServletResponse res)
/*     */   {
/* 328 */     this.res = res;
/*     */   }
/*     */ 
/*     */   public void setHttpSession(SessionData sess)
/*     */   {
/* 333 */     this.session = sess;
/*     */   }
/*     */ 
/*     */   public String getAction()
/*     */   {
/* 338 */     return this.action;
/*     */   }
/*     */ 
/*     */   public void setAction(String action)
/*     */   {
/* 343 */     this.action = action;
/*     */   }
/*     */ 
/*     */   public String getHTMLTemplateName()
/*     */   {
/* 348 */     return this.template;
/*     */   }
/*     */ 
/*     */   public void setHTMLTemplateName(String template)
/*     */   {
/* 353 */     if (this.template != null)
/* 354 */       Diagnostics.trace("Overriding template \"" + this.template + "\" with new template \"" + template + "\"");
/* 355 */     this.template = template;
/*     */   }
/*     */ 
/*     */   public Object getTransientDatum(String key)
/*     */   {
/* 360 */     return this.transientData.get(key);
/*     */   }
/*     */ 
/*     */   public Object getRequiredTransientDatum(String key) throws Exception
/*     */   {
/* 365 */     Object result = getTransientDatum(key);
/* 366 */     if (result == null)
/* 367 */       throw new Exception("Missing required transient datum \"" + key + "\"");
/* 368 */     return result;
/*     */   }
/*     */ 
/*     */   public void setTransientDatum(String key, Object value)
/*     */   {
/* 373 */     if (value != null)
/*     */     {
/* 375 */       this.transientData.put(key, value);
/*     */     }
/*     */     else
/*     */     {
/* 379 */       Diagnostics.warning("Setting transient datum \"" + key + "\" to null");
/* 380 */       this.transientData.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeTransientDatum(String datumName)
/*     */   {
/* 386 */     this.transientData.remove(datumName);
/*     */   }
/*     */ 
/*     */   public void clearTransientData()
/*     */   {
/* 391 */     this.transientData.clear();
/*     */   }
/*     */ 
/*     */   public Enumeration getTransientKeys()
/*     */   {
/* 396 */     return Sort.keys(this.transientData);
/*     */   }
/*     */ 
/*     */   public boolean containsTransientDatum(String key)
/*     */   {
/* 401 */     return this.transientData.containsKey(key);
/*     */   }
/*     */ 
/*     */   public String getParameter(String key)
/*     */   {
/* 409 */     Object result = this.parameterData.get(key);
/* 410 */     if (result == null) return null;
/* 411 */     if ((result instanceof String)) return (String)result;
/* 412 */     return ((String[])result)[0];
/*     */   }
/*     */ 
/*     */   public String[] getParameterValues(String key)
/*     */   {
/* 420 */     Object result = this.parameterData.get(key);
/* 421 */     if (result == null) return null;
/* 422 */     if ((result instanceof String)) return new String[] { (String)result };
/* 423 */     return (String[])result;
/*     */   }
/*     */ 
/*     */   public String getRequiredParameter(String key)
/*     */     throws Exception
/*     */   {
/* 431 */     String result = getParameter(key);
/* 432 */     if (result == null)
/* 433 */       throw new Exception("Missing required parameter \"" + key + "\"");
/* 434 */     return result;
/*     */   }
/*     */ 
/*     */   public void setParameter(String key, String value)
/*     */   {
/* 439 */     if (value != null)
/*     */     {
/* 441 */       this.parameterData.put(key, value);
/*     */     }
/*     */     else
/*     */     {
/* 445 */       Diagnostics.warning("Setting parameter \"" + key + "\" to null");
/* 446 */       this.parameterData.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setParameterValues(String key, String[] values)
/*     */   {
/* 452 */     if (values != null)
/*     */     {
/* 454 */       this.parameterData.put(key, values);
/*     */     }
/*     */     else
/*     */     {
/* 458 */       Diagnostics.warning("Setting parameter \"" + key + "\" to null");
/* 459 */       this.parameterData.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeParameter(String key)
/*     */   {
/* 466 */     this.parameterData.remove(key);
/*     */   }
/*     */ 
/*     */   public void clearParameters()
/*     */   {
/* 471 */     this.parameterData.clear();
/*     */   }
/*     */ 
/*     */   public Enumeration getParameterKeys()
/*     */   {
/* 476 */     return Sort.keys(this.parameterData);
/*     */   }
/*     */ 
/*     */   public boolean containsParameter(String key)
/*     */   {
/* 481 */     return this.parameterData.containsKey(key);
/*     */   }
/*     */ 
/*     */   public void sendRedirect(String location) throws IOException
/*     */   {
/* 486 */     this.res.sendRedirect(location);
/* 487 */     this.redirectRequested = true;
/*     */   }
/*     */ 
/*     */   public boolean isRedirected()
/*     */   {
/* 492 */     return this.redirectRequested;
/*     */   }
/*     */ 
/*     */   public void setImmediateAction(ApplicationServerAction action)
/*     */   {
/* 497 */     if (action != null)
/*     */     {
/* 499 */       Diagnostics.debug("Set Immediate Action: " + action.actionName);
/*     */     }
/*     */     else
/*     */     {
/* 503 */       Diagnostics.debug("Set Immediate Action: " + null);
/*     */     }
/* 505 */     this.immediateAction = action;
/*     */   }
/*     */ 
/*     */   public ApplicationServerAction getImmediateAction()
/*     */   {
/* 510 */     return this.immediateAction;
/*     */   }
/*     */ 
/*     */   public void setPendingSuccessAction(ApplicationServerAction action, String pendingSuccessOfWhat)
/*     */   {
/* 515 */     if ((action != null) && (getHttpSession() != null))
/*     */     {
/* 517 */       Diagnostics.debug("Set Pending Action: " + action.actionName);
/* 518 */       getHttpSession().put("_nextAction", action);
/* 519 */       getHttpSession().put("_nextActionIf", pendingSuccessOfWhat);
/*     */     }
/*     */     else
/*     */     {
/* 523 */       getHttpSession().remove("_nextAction");
/* 524 */       getHttpSession().remove("_nextActionIf");
/*     */     }
/*     */   }
/*     */ 
/*     */   public ApplicationServerAction getPendingSuccessAction(String currentAction)
/*     */   {
/* 530 */     ApplicationServerAction temp = (ApplicationServerAction)getHttpSession().get("_nextAction");
/* 531 */     String ifClause = (String)getHttpSession().get("_nextActionIf");
/* 532 */     setPendingSuccessAction(null, null);
/* 533 */     if ((ifClause != null) && (ifClause.indexOf(currentAction) != -1))
/*     */     {
/* 535 */       return temp;
/*     */     }
/*     */ 
/* 539 */     return null;
/*     */   }
/*     */ 
/*     */   public void setCookie(Cookie c)
/*     */   {
/* 545 */     if (this.res != null)
/* 546 */       this.res.addCookie(c);
/*     */   }
/*     */ 
/*     */   public Cookie getCookie(String key)
/*     */   {
/* 551 */     if (this.req == null) return null;
/*     */ 
/* 553 */     Cookie[] cookies = this.req.getCookies();
/* 554 */     if (cookies == null) return null;
/*     */ 
/* 556 */     for (int i = 0; i < cookies.length; i++) {
/* 557 */       if (cookies[i].getName().equals(key))
/* 558 */         return cookies[i];
/*     */     }
/* 560 */     return null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 565 */     StringBuffer buffer = new StringBuffer("THE INFORMATION IS: ");
/*     */ 
/* 567 */     if (this.req != null)
/*     */     {
/* 569 */       buffer.append("QUERY STRING: ");
/* 570 */       buffer.append(this.req.getQueryString());
/* 571 */       Enumeration enum = this.req.getParameterNames();
/* 572 */       while (enum.hasMoreElements())
/*     */       {
/* 574 */         String name = (String)enum.nextElement();
/* 575 */         String[] values = this.req.getParameterValues(name);
/* 576 */         if (values != null)
/*     */         {
/* 578 */           for (int i = 0; i < values.length; i++) {
/* 579 */             buffer.append("\n" + name + " (" + i + ") " + values[i]);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 584 */     buffer.append("\nRESPONSE: " + getHttpServletResponse());
/* 585 */     buffer.append("\nREQUEST: " + getHttpServletRequest());
/* 586 */     buffer.append("\nSESSION: " + getHttpSession());
/* 587 */     buffer.append("\nTEMPLATE NAME: " + getHTMLTemplateName());
/* 588 */     buffer.append("\nACTION: " + getAction());
/* 589 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public Object getRowDatum(String key) throws Exception
/*     */   {
/* 594 */     String cursor = null;
/* 595 */     String column = null;
/*     */ 
/* 597 */     Vector parts = StringUtil.stringToVector(key, ':');
/*     */ 
/* 599 */     if (parts.size() == 1)
/*     */     {
/* 601 */       cursor = "q1";
/* 602 */       column = (String)parts.elementAt(0);
/*     */     }
/* 604 */     else if (parts.size() == 2)
/*     */     {
/* 606 */       cursor = (String)parts.elementAt(0);
/* 607 */       column = (String)parts.elementAt(1);
/*     */     }
/*     */ 
/* 610 */     return getRowDatum(cursor, column);
/*     */   }
/*     */ 
/*     */   public Object getRowDatum(String cursor, String column) throws Exception
/*     */   {
/* 615 */     Object result = null;
/*     */     int i;
/*     */     try
/*     */     {
/* 621 */       i = Integer.parseInt(column);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/* 625 */       i = 0;
/*     */     }
/*     */ 
/* 628 */     Object o = getTransientDatum(SQLLoopComponent.CURSOR_VAR_PREFIX + cursor);
/* 629 */     if (o == null)
/*     */     {
/* 631 */       throw new NullPointerException("Unknown result set \"" + cursor + "\"");
/*     */     }
/* 633 */     if ((o instanceof QueryResults))
/*     */     {
/* 635 */       QueryResults resultSet = (QueryResults)o;
/* 636 */       if (i != 0)
/* 637 */         result = resultSet.getObject(i);
/*     */       else
/* 639 */         result = resultSet.getObject(column);
/*     */     }
/* 641 */     else if ((o instanceof String))
/*     */     {
/* 643 */       result = (String)o;
/*     */     }
/*     */     else
/*     */     {
/* 647 */       throw new SQLException("Unknown type for result set \"" + o.getClass().getName() + "\"");
/*     */     }
/*     */ 
/* 650 */     return result;
/*     */   }
/*     */ 
/*     */   public String getConfigValue(String path)
/*     */     throws Exception
/*     */   {
/* 659 */     return XMLUtils.getValue(getConfig().getConfigDocument(), path);
/*     */   }
/*     */ 
/*     */   private void fireAfterContextCreated()
/*     */   {
/* 664 */     for (int i = 0; i < this.listeners.size(); i++)
/* 665 */       ((InvocationContextListener)this.listeners.elementAt(i)).afterContextCreated(this);
/*     */   }
/*     */ 
/*     */   private void fireBeforeContextDestroyed()
/*     */   {
/* 670 */     for (int i = 0; i < this.listeners.size(); i++)
/* 671 */       ((InvocationContextListener)this.listeners.elementAt(i)).beforeContextDestroyed(this);
/*     */   }
/*     */ 
/*     */   public DynamicResource getResource() throws Exception
/*     */   {
/* 676 */     return getResource(null);
/*     */   }
/*     */ 
/*     */   public DynamicResource getResource(String resourceName) throws Exception
/*     */   {
/* 681 */     DynamicResource result = null;
/*     */ 
/* 683 */     if ((resourceName == null) && (this.defaultResource != null))
/*     */     {
/* 685 */       result = this.defaultResource;
/* 686 */       Diagnostics.debug("InvocationContext.getResource() using shared resource " + result);
/*     */     }
/*     */     else
/*     */     {
/* 690 */       result = this.ac.getResource(resourceName);
/* 691 */       if ((resourceName == null) && (result != null) && (result.isShareable()))
/*     */       {
/* 693 */         result.share();
/* 694 */         this.defaultResource = result;
/* 695 */         Diagnostics.debug("InvocationContext.getResource() creating shared resource " + result);
/*     */       }
/*     */     }
/*     */ 
/* 699 */     return result;
/*     */   }
/*     */ 
/*     */   public String getSessionID()
/*     */   {
/* 704 */     return this.session.getSessionID();
/*     */   }
/*     */ 
/*     */   public boolean dispatchAction(String action) throws Exception
/*     */   {
/* 709 */     return getDispatcher().dispatchAction(this, action);
/*     */   }
/*     */ 
/*     */   public boolean dispatchHandler(String handler) throws Exception
/*     */   {
/* 714 */     return getDispatcher().dispatchHandler(this, handler);
/*     */   }
/*     */ 
/*     */   public void writeSessionData()
/*     */   {
/* 719 */     getSessionManager().writeSessionData(this.session);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, String message) throws Exception
/*     */   {
/* 724 */     sendMail(to, from, subject, date, message, null, "text/plain; charset=us-ascii", false);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, String message, boolean asynchronous) throws Exception
/*     */   {
/* 729 */     sendMail(to, from, subject, date, message, null, "text/plain; charset=us-ascii", asynchronous);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, Template template) throws Exception
/*     */   {
/* 734 */     sendMail(to, from, subject, date, template.include(this), null, "text/html; charset=us-ascii", false);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, Template template, boolean asynchronous) throws Exception
/*     */   {
/* 739 */     sendMail(to, from, subject, date, template.include(this), null, "text/html; charset=us-ascii", asynchronous);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, String message, Object attachment) throws Exception
/*     */   {
/* 744 */     sendMail(to, from, subject, date, message, attachment, "text/plain; charset=us-ascii", false);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, String message, Object attachment, boolean asynchronous) throws Exception
/*     */   {
/* 749 */     sendMail(to, from, subject, date, message, attachment, "text/plain; charset=us-ascii", asynchronous);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, Template template, Object attachment) throws Exception
/*     */   {
/* 754 */     sendMail(to, from, subject, date, template.include(this), attachment, "text/html; charset=us-ascii", false);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, Template template, Object attachment, boolean asynchronous) throws Exception
/*     */   {
/* 759 */     sendMail(to, from, subject, date, template.include(this), attachment, "text/html; charset=us-ascii", asynchronous);
/*     */   }
/*     */ 
/*     */   public void sendMail(String to, String from, String subject, Date date, String message, Object attachment, String contentType, boolean asynchronous) throws Exception
/*     */   {
/* 764 */     MailSender ms = new MailSender(to, from, subject, date, message);
/* 765 */     ms.setServerInfo(getConfigValue("mail:host"), getConfigValue("mail:port"));
/* 766 */     if (contentType != null) ms.setContentType(contentType);
/* 767 */     if (attachment != null) ms.addAttachment(attachment);
/* 768 */     if (asynchronous) ms.start(); else
/* 769 */       ms.send();
/*     */   }
/*     */ 
/*     */   public boolean isInternetExplorer()
/*     */   {
/* 774 */     if (this.req == null) return true;
/* 775 */     String userAgent = this.req.getHeader("User-Agent");
/* 776 */     if (userAgent == null) return true;
/* 777 */     return (userAgent.indexOf("Mozilla") != -1) && (userAgent.indexOf("MSIE") != -1);
/*     */   }
/*     */ 
/*     */   public boolean isInternetExplorer(int version)
/*     */   {
/* 782 */     if (this.req == null) return true;
/* 783 */     String userAgent = this.req.getHeader("User-Agent");
/* 784 */     if (userAgent == null) return true;
/* 785 */     boolean isIE = (userAgent.indexOf("Mozilla") != -1) && (userAgent.indexOf("MSIE") != -1);
/* 786 */     if (!isIE) return false;
/* 787 */     String tmp = userAgent.substring(8, 9);
/* 788 */     return tmp.equals(Integer.toString(version));
/*     */   }
/*     */ 
/*     */   public boolean isNetscape()
/*     */   {
/* 793 */     if (this.req == null) return false;
/* 794 */     String userAgent = this.req.getHeader("User-Agent");
/* 795 */     if (userAgent == null) return false;
/* 796 */     return (userAgent.indexOf("Mozilla") != -1) && (userAgent.indexOf("MSIE") == -1);
/*     */   }
/*     */ 
/*     */   public boolean isNetscape(int version)
/*     */   {
/* 801 */     if (this.req == null) return false;
/* 802 */     String userAgent = this.req.getHeader("User-Agent");
/* 803 */     if (userAgent == null) return false;
/* 804 */     boolean isNS = (userAgent.indexOf("Mozilla") != -1) && (userAgent.indexOf("MSIE") == -1);
/* 805 */     String tmp = userAgent.substring(8, 9);
/* 806 */     return tmp.equals(Integer.toString(version));
/*     */   }
/*     */ 
/*     */   public String processFilter(String query, String filters) throws Exception
/*     */   {
/* 811 */     Sql parsed_query = Sql.fetchSql(query);
/* 812 */     return processFilter(parsed_query, filters).getQuery();
/*     */   }
/*     */ 
/*     */   public Sql processFilter(Sql query, String filters) throws Exception
/*     */   {
/* 817 */     return getQueryFilterManager().process(this, query, filters);
/*     */   }
/*     */ 
/*     */   public void setHTML2PDF(String html) throws Exception
/*     */   {
/* 822 */     Hashtable hashtable = new Hashtable();
/* 823 */     hashtable.put("html_String", html);
/* 824 */     hashtable.put("table_header", "");
/* 825 */     hashtable.put("landscape", "false");
/* 826 */     hashtable.put("pagesize", "letter");
/* 827 */     setHTML2PDF(hashtable);
/*     */   }
/*     */ 
/*     */   public void setHTML2PDF(Hashtable hashtable) throws Exception
/*     */   {
/* 832 */     Request request = new Request(hashtable);
/* 833 */     Html2pdf html2pdf = new Html2pdf(this, request);
/* 834 */     html2pdf.processRequest(request, true);
/*     */   }
/*     */ 
/*     */   public void initialize(BaseServlet servlet, Configuration config, ClassLoader loader)
/*     */   {
/* 840 */     throw new RuntimeException("Wrong initalizer called");
/*     */   }
/*     */ 
/*     */   public Object getAppGlobalDatum(String key)
/*     */   {
/* 845 */     return this.ac.getAppGlobalDatum(key);
/*     */   }
/*     */ 
/*     */   public Object getRequiredAppGlobalDatum(String key) throws Exception
/*     */   {
/* 850 */     return this.ac.getRequiredAppGlobalDatum(key);
/*     */   }
/*     */ 
/*     */   public void setAppGlobalDatum(String name, Object value)
/*     */   {
/* 855 */     this.ac.setAppGlobalDatum(name, value);
/*     */   }
/*     */ 
/*     */   public void removeAppGlobalDatum(String name)
/*     */   {
/* 860 */     this.ac.removeAppGlobalDatum(name);
/*     */   }
/*     */ 
/*     */   public void clearAppGlobalData()
/*     */   {
/* 865 */     this.ac.clearAppGlobalData();
/*     */   }
/*     */ 
/*     */   public Enumeration getAppGlobalKeys()
/*     */   {
/* 870 */     return this.ac.getAppGlobalKeys();
/*     */   }
/*     */ 
/*     */   public boolean containsAppGlobalDatum(String key)
/*     */   {
/* 875 */     return this.ac.containsAppGlobalDatum(key);
/*     */   }
/*     */ 
/*     */   public Document getConfigDocument()
/*     */   {
/* 880 */     return this.ac.getConfigDocument();
/*     */   }
/*     */ 
/*     */   public Configuration getConfig()
/*     */   {
/* 885 */     return this.ac.getConfig();
/*     */   }
/*     */ 
/*     */   public Template getTemplate(String templateName) throws Exception
/*     */   {
/* 890 */     return this.ac.getTemplate(templateName);
/*     */   }
/*     */ 
/*     */   public Provider getProvider(String key)
/*     */   {
/* 895 */     return this.ac.getProvider(key);
/*     */   }
/*     */ 
/*     */   public String format(Object o, String pattern) throws Exception
/*     */   {
/* 900 */     return this.ac.format(o, pattern);
/*     */   }
/*     */ 
/*     */   public void handle(HttpServletRequest req, HttpServletResponse res) throws Exception
/*     */   {
/* 905 */     this.ac.handle(req, res);
/*     */   }
/*     */ 
/*     */   public SessionManager getSessionManager()
/*     */   {
/* 910 */     return this.ac.getSessionManager();
/*     */   }
/*     */ 
/*     */   public Dispatcher getDispatcher()
/*     */   {
/* 915 */     return this.ac.getDispatcher();
/*     */   }
/*     */ 
/*     */   public ResourceManager getResourceManager()
/*     */   {
/* 920 */     return this.ac.getResourceManager();
/*     */   }
/*     */ 
/*     */   public TemplateManager getTemplateManager()
/*     */   {
/* 925 */     return this.ac.getTemplateManager();
/*     */   }
/*     */ 
/*     */   public QueryFilterManager getQueryFilterManager() throws Exception
/*     */   {
/* 930 */     QueryFilterManager qfm = this.ac.getQueryFilterManager();
/* 931 */     if (qfm == null) throw new Exception("No QueryFilterManager defined");
/* 932 */     return qfm;
/*     */   }
/*     */ 
/*     */   public Class loadClass(String name) throws Exception
/*     */   {
/* 937 */     return this.ac.loadClass(name);
/*     */   }
/*     */ 
/*     */   public Hashtable getDaemons()
/*     */   {
/* 942 */     return this.ac.getDaemons();
/*     */   }
/*     */ 
/*     */   public BaseServlet getServlet()
/*     */   {
/* 947 */     return this.ac.getServlet();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String getActionParam()
/*     */   {
/* 955 */     return this.ac.getActionParam();
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.BaseInvocationContext
 * JD-Core Version:    0.6.2
 */