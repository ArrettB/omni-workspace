/*    */ package dynamic.intraframe.engine;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ public class ApplicationServerAction
/*    */   implements Serializable
/*    */ {
/* 10 */   public String actionName = null;
/*    */ 
/* 12 */   public Hashtable parameters = null;
/*    */ 
/*    */   public ApplicationServerAction(String name, Hashtable params)
/*    */   {
/* 16 */     this.actionName = name;
/* 17 */     this.parameters = params;
/*    */   }
/*    */ 
/*    */   public ApplicationServerAction(String name) {
/* 21 */     this.actionName = name;
/* 22 */     this.parameters = null;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 27 */     return this.actionName + "  ( " + this.parameters + " )";
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.ApplicationServerAction
 * JD-Core Version:    0.6.2
 */