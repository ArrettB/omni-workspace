/*    */ package dynamic.intraframe.engine;
/*    */ 
/*    */ public class ConfigurationException extends Exception
/*    */ {
/*    */   private Throwable rootCause;
/*    */ 
/*    */   public ConfigurationException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConfigurationException(String message)
/*    */   {
/* 30 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConfigurationException(String message, Throwable rootCause)
/*    */   {
/* 44 */     super(message);
/* 45 */     this.rootCause = rootCause;
/*    */   }
/*    */ 
/*    */   public ConfigurationException(Throwable rootCause)
/*    */   {
/* 64 */     super(rootCause.getLocalizedMessage());
/* 65 */     this.rootCause = rootCause;
/*    */   }
/*    */ 
/*    */   public Throwable getRootCause()
/*    */   {
/* 82 */     return this.rootCause;
/*    */   }
/*    */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     dynamic.intraframe.engine.ConfigurationException
 * JD-Core Version:    0.6.2
 */