/*     */ import dynamic.util.diagnostics.DiagnosticsMessage;
/*     */ import dynamic.util.string.StringUtil;
/*     */ import java.applet.Applet;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import netscape.javascript.JSObject;
/*     */ 
/*     */ public class DiagnosticsApplet extends Applet
/*     */   implements Runnable
/*     */ {
/*  12 */   String host = null;
/*  13 */   int port = 0;
/*     */   JSObject jsroot;
/*  16 */   Thread tid = null;
/*  17 */   Socket socket = null;
/*     */ 
/*     */   public void init()
/*     */   {
/*  21 */     System.out.println("init()");
/*     */     try
/*     */     {
/*  25 */       this.host = getDocumentBase().getHost();
/*  26 */       this.port = Integer.parseInt(getParameter("port"));
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  30 */       this.host = null;
/*  31 */       this.port = 0;
/*  32 */       t.printStackTrace();
/*     */     }
/*     */ 
/*  35 */     System.out.println("Done with init()");
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  40 */     System.out.println("start()");
/*     */     try
/*     */     {
/*  44 */       if ((this.host == null) || (this.host.length() == 0) || (this.port <= 0)) return;
/*  45 */       this.jsroot = JSObject.getWindow(this);
/*  46 */       if (this.jsroot == null) return;
/*     */ 
/*  48 */       if (this.tid != null) return;
/*  49 */       this.tid = new Thread(this, "DiagnosticsApplet");
/*  50 */       this.tid.setPriority(5);
/*  51 */       this.tid.start();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  55 */       this.jsroot = null;
/*  56 */       this.tid = null;
/*  57 */       t.printStackTrace();
/*     */     }
/*     */ 
/*  60 */     System.out.println("Done with start()");
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/*  65 */     System.out.println("stop()");
/*     */     try
/*     */     {
/*  69 */       if (this.tid != null)
/*     */       {
/*  71 */         Thread temp = this.tid;
/*  72 */         this.tid = null;
/*  73 */         temp.interrupt();
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  78 */       t.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/*  82 */       this.tid = null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  87 */       if (this.socket != null)
/*  88 */         this.socket.close();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*  92 */       t.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/*  96 */       this.socket = null;
/*     */     }
/*     */ 
/*  99 */     System.out.println("Done with stop()");
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 104 */     System.out.println("destroy()");
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 109 */     System.out.println("run()");
/*     */     try
/*     */     {
/* 113 */       boolean connected = false;
/* 114 */       ObjectInputStream ois = null;
/* 115 */       Throwable problem = null;
/*     */ 
/* 117 */       Thread thisThread = Thread.currentThread();
/* 118 */       for (; Thread.currentThread() == this.tid; 
/* 163 */         (connected) && (Thread.currentThread() == this.tid))
/*     */       {
/* 120 */         System.out.println(Thread.currentThread().toString());
/* 121 */         if (!connected)
/*     */         {
/* 123 */           if (problem != null)
/*     */           {
/* 125 */             write("\nProblem with connection: " + problem);
/* 126 */             problem = null;
/*     */           }
/* 128 */           write("\nTrying to connect to Diagnostics at " + this.host + ":" + this.port);
/*     */         }
/*     */ 
/* 131 */         while ((!connected) && (Thread.currentThread() == this.tid))
/*     */         {
/*     */           try
/*     */           {
/* 135 */             this.socket = new Socket(this.host, this.port);
/* 136 */             ois = new ObjectInputStream(this.socket.getInputStream());
/* 137 */             connected = true;
/* 138 */             problem = null;
/*     */           }
/*     */           catch (Throwable t)
/*     */           {
/* 143 */             problem = t;
/* 144 */             this.socket = null;
/* 145 */             ois = null;
/* 146 */             connected = false;
/* 147 */             write("Problem connecting: " + t);
/* 148 */             t.printStackTrace();
/*     */             try {
/* 150 */               Thread.sleep(1000L); } catch (InterruptedException e) {  }
/*     */           }
/*     */         }
/* 153 */         if (connected)
/*     */         {
/* 155 */           write("Connected to Diagnostics at " + this.host + ":" + this.port);
/* 156 */           for (int i = 0; i <= 15; i++)
/*     */           {
/* 158 */             DiagnosticsMessage msg = new DiagnosticsMessage(i, DiagnosticsMessage.color[i], null, null);
/* 159 */             write(msg.toHTML());
/*     */           }
/* 156 */           continue;
/*     */           try
/*     */           {
/* 167 */             DiagnosticsMessage msg = (DiagnosticsMessage)ois.readObject();
/* 168 */             if (msg != null) write(msg.toHTML());
/* 169 */             problem = null;
/*     */           }
/*     */           catch (Throwable t)
/*     */           {
/* 187 */             problem = t;
/* 188 */             this.socket = null;
/* 189 */             ois = null;
/* 190 */             connected = false;
/* 191 */             t.printStackTrace();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 198 */       t.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/* 202 */       stop();
/*     */     }
/*     */ 
/* 205 */     System.out.println("Done with run()");
/*     */   }
/*     */ 
/*     */   public void write(String message)
/*     */   {
/*     */     try
/*     */     {
/* 212 */       message = StringUtil.replaceString(message, "\\", "\\\\");
/* 213 */       message = StringUtil.replaceString(message, "\r", "");
/* 214 */       message = StringUtil.replaceString(message, "\n", "<br>");
/* 215 */       message = StringUtil.replaceString(message, "'", "\\'");
/* 216 */       if (!message.endsWith("<br>")) message = message + "<br>";
/* 217 */       System.out.println("write(" + message + ")");
/* 218 */       this.jsroot.eval("write('" + message + "')");
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 222 */       System.out.println("write('" + message + "')");
/* 223 */       t.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 229 */     System.out.println("main()");
/*     */   }
/*     */ }

/* Location:           /Users/dave/kettle_river_consulting/customers/omni_workspace/iFrame framework/original code/
 * Qualified Name:     DiagnosticsApplet
 * JD-Core Version:    0.6.2
 */